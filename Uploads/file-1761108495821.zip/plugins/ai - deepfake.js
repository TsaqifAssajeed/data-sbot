// ✨ Plugin ai - deepfake ✨

// plugins/deepfake.js

//by malik.js

const axios = require("axios");
const crypto = require("crypto");
const CryptoJS = require("crypto-js");
const FormData = require("form-data");

class SignatureGenerator {
  constructor() {
    this.publicKey = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwlO+boC6cwRo3UfXVBadaYwcX
0zKS2fuVNY2qZ0dgwb1NJ+/Q9FeAosL4ONiosD71on3PVYqRUlL5045mvH2K9i8b
AFVMEip7E6RMK6tKAAif7xzZrXnP1GZ5Rijtqdgwh+YmzTo39cuBCsZqK9oEoeQ3
r/myG9S+9cR5huTuFQIDAQAB
-----END PUBLIC KEY-----`;
  }
  generateRandomString(length) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz01234_";
    return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  }
  aesEncrypt(text, key) {
    const keyUtf8 = CryptoJS.enc.Utf8.parse(key);
    return CryptoJS.AES.encrypt(text, keyUtf8, {
      iv: keyUtf8,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    }).toString();
  }
  rsaEncrypt(text) {
    return crypto.publicEncrypt({
      key: this.publicKey,
      padding: crypto.constants.RSA_PKCS1_PADDING
    }, Buffer.from(text, "utf8")).toString("base64");
  }
}

class DeepFakeAPI {
  constructor() {
    this.baseUrl = "https://api.deepfakemaker.io";
    this.appId = "aifaceswap";
    this.fingerprint = "817ddfb1-ea6c-4e07-b37d-3aa9281e4fb7";
    this.originFrom = "7cc7af6c758b6e74";
    this.themeVersion = "83EmcUoQTUv50LhNx0VrdcK8rcGexcP35FcZDcpgWsAXEyO4xqL5shCY6sFIWB2Q";
    this.signatureGenerator = new SignatureGenerator();
  }

  generateApiHeaders() {
    const aesSecret = this.signatureGenerator.generateRandomString(16);
    const secret_key = this.signatureGenerator.rsaEncrypt(aesSecret);
    const fp1 = this.signatureGenerator.aesEncrypt(`${this.appId}:${this.fingerprint}`, aesSecret);
    return {
      "content-type": "application/json",
      fp: this.fingerprint,
      fp1,
      "x-guide": secret_key,
      "x-code": Date.now().toString(),
      "theme-version": this.themeVersion,
      "user-agent": "Mozilla/5.0"
    };
  }

  generateUploadHeaders(boundary) {
    const aesSecret = this.signatureGenerator.generateRandomString(16);
    const secret_key = this.signatureGenerator.rsaEncrypt(aesSecret);
    const sign = this.signatureGenerator.aesEncrypt(`${this.appId}:${crypto.randomUUID()}:${secret_key}`, aesSecret);
    return {
      "content-type": `multipart/form-data; boundary=${boundary}`,
      "x-guide": secret_key,
      "x-sign": sign,
      "x-code": Date.now().toString(),
      "theme-version": this.themeVersion,
      "user-agent": "Mozilla/5.0"
    };
  }

  async uploadBuffer(buffer) {
    const form = new FormData();
    form.append("file", buffer, { filename: `image-${Date.now()}.jpg`, contentType: "image/jpeg" });
    form.append("fn_name", "cloth-change");
    form.append("request_from", "4");
    form.append("origin_from", this.originFrom);

    const headers = this.generateUploadHeaders(form.getBoundary());
    const res = await axios.post(`${this.baseUrl}/aitools/upload-img`, form, { headers }).catch(err => {
      throw new Error(err.response?.data?.message || err.message);
    });
    if (res.data?.code !== 200) throw new Error("Upload gagal: " + (res.data?.message || "Unknown"));
    return res.data.data.path;
  }

  async createTask(imagePath, prompt) {
    const payload = {
      fn_name: "cloth-change",
      call_type: 3,
      input: { source_image: imagePath, prompt, request_from: 4, type: 1 },
      request_from: 4,
      origin_from: this.originFrom
    };
    const headers = this.generateApiHeaders();
    const res = await axios.post(`${this.baseUrl}/aitools/of/create`, payload, { headers }).catch(err => {
      throw new Error(err.response?.data?.message || err.message);
    });
    if (res.data?.code !== 200) throw new Error("Task gagal: " + (res.data?.message || "Unknown"));
    return res.data.data.task_id;
  }

  async checkStatus(taskId) {
    const payload = { task_id: taskId, fn_name: "cloth-change", call_type: 3, consume_type: 0, request_from: 4, origin_from: this.originFrom };
    const headers = this.generateApiHeaders();
    const res = await axios.post(`${this.baseUrl}/aitools/of/check-status`, payload, { headers }).catch(err => {
      throw new Error(err.response?.data?.message || err.message);
    });
    return res.data.data;
  }

  async generate(buffer, prompt) {
    const path = await this.uploadBuffer(buffer);
    const taskId = await this.createTask(path, prompt);
    for (let i = 0; i < 50; i++) {
      const status = await this.checkStatus(taskId);
      if (status?.status === 2) return `https://res.deepfakemaker.io/${status.result_image}`;
      if (status?.status === -1) throw new Error("Task gagal.");
      await new Promise(r => setTimeout(r, 5000));
    }
    throw new Error("Polling timeout");
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      `📌 Kirim gambar dengan caption *${usedPrefix + command} nude* atau reply gambar dengan caption prompt.`,
      m
    );
  }
  if (!m.quoted || !m.quoted.mimetype || !/image/.test(m.quoted.mimetype)) {
    return conn.reply(m.chat, "❌ Reply gambar dengan perintah ini.", m);
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  let buffer = await m.quoted.download();
  const api = new DeepFakeAPI();

  try {
    const resultUrl = await api.generate(buffer, text);

    // kirim sebagai gambar
    await conn.sendMessage(m.chat, {
      image: { url: resultUrl },
      caption: `✅ Selesai!\n📌 Prompt: ${text}`
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
    await conn.reply(m.chat, `❌ Error dari server: ${e.message}`, m);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  }
};

handler.help = ["deepfake <prompt>"];
handler.tags = ["ai"];
handler.command = /^deepfake$/i;
handler.register = true;
handler.limit = true;

module.exports = handler;