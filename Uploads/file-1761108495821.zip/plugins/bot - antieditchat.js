// 📝 plugin bot - antieditchat

const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const cron = require('node-cron');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const TMP_DIR = './tmp';

// Buat folder tmp jika belum ada
async function ensureTmpDir() {
    try {
        await fsPromises.mkdir(TMP_DIR, { recursive: true });
    } catch (e) {
        console.error('Gagal membuat folder tmp untuk antieditchat:', e);
    }
}

// Simpan pesan sementara
async function saveMessage(chatId, messageId, messageData) {
    try {
        const fileName = `pesan_${chatId}_${messageId}.json`;
        const filePath = path.join(TMP_DIR, fileName);
        let mediaFilePath = null;

        const messageType = Object.keys(messageData.message || {})[0];
        if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(messageType)) {
            const mediaMsg = messageData.message[messageType];
            if (mediaMsg.url) {
                const stream = await downloadContentFromMessage(mediaMsg, messageType.replace('Message', ''));
                let buffer = Buffer.concat([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                const ext = messageType === 'stickerMessage' ? 'webp' : (mediaMsg.mimetype?.split('/')[1] || 'bin');
                mediaFilePath = path.join(TMP_DIR, `media_${chatId}_${messageId}.${ext}`);
                await fsPromises.writeFile(mediaFilePath, buffer);
            }
        }

        const safeMessage = JSON.parse(JSON.stringify(messageData, (key, value) => {
            if (key === 'buffer' || key === 'stream') return undefined;
            return value;
        }));

        await fsPromises.writeFile(filePath, JSON.stringify({
            ...safeMessage,
            mediaFilePath,
            timestamp: Date.now()
        }));
    } catch (e) {
        console.error('Gagal menyimpan pesan untuk antieditchat:', e);
    }
}

// Ambil pesan dari file
async function getMessage(chatId, messageId) {
    try {
        const filePath = path.join(TMP_DIR, `pesan_${chatId}_${messageId}.json`);
        const data = await fsPromises.readFile(filePath, 'utf8');
        return JSON.parse(data);
    } catch {
        return null;
    }
}

// Pembersihan tmp setiap hari pukul 3 pagi
function startCleanup() {
    cron.schedule('0 3 * * *', async () => {
        try {
            const files = await fsPromises.readdir(TMP_DIR);
            const now = Date.now();
            const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 hari

            for (const file of files) {
                if (file.startsWith('pesan_')) {
                    const filePath = path.join(TMP_DIR, file);
                    const data = JSON.parse(await fsPromises.readFile(filePath, 'utf8'));
                    if (now - data.timestamp > maxAge) {
                        await fsPromises.unlink(filePath);
                        if (data.mediaFilePath) {
                            try { await fsPromises.unlink(data.mediaFilePath); } catch {}
                        }
                    }
                }
            }
        } catch (e) {
            console.error('Gagal membersihkan tmp untuk antieditchat:', e);
        }
    }, { timezone: 'Asia/Jakarta' });
}

ensureTmpDir();
startCleanup();

module.exports = {
    name: 'antieditchat',
    async before(m, { conn, isBotAdmin }) {
        if (m.isBaileys && m.fromMe) return;
        const chat = global.db.data.chats[m.chat];

        // Simpan pesan saat diterima
        if (m.message && m.isGroup && chat.antiEditChat) {
            await saveMessage(m.chat, m.id, m);
        }

        // Deteksi pesan yang diedit
        if (chat.antiEditChat && m.message?.protocolMessage?.type === 14 && m.isGroup && isBotAdmin) {
            const { key, editedMessage } = m.message.protocolMessage;
            const sender = key.participant || m.sender;
            const senderName = m.pushName || await conn.getName(sender) || sender.split('@')[0];

            // Log untuk debugging
            console.log('protocolMessage:', JSON.stringify(m.message.protocolMessage, null, 2));

            const cached = await getMessage(m.chat, key.id);
            let originalMessage = 'tidak dapat ditemukan';
            let editedMessageText = 'tidak dapat ditemukan';

            // Ambil pesan asli dari cache
            if (cached && cached.message) {
                const type = Object.keys(cached.message)[0];
                if (type === 'conversation') {
                    originalMessage = cached.message.conversation;
                } else if (type === 'extendedTextMessage') {
                    originalMessage = cached.message.extendedTextMessage.text;
                } else if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(type)) {
                    originalMessage = `[Media: ${type.replace('Message', '')}] ${cached.message[type].caption || ''}`;
                }
            }

            // Ambil pesan yang diedit dari protocolMessage
            if (editedMessage) {
                try {
                    // Coba akses pesan yang diedit dari berbagai kemungkinan struktur
                    let messageContent = editedMessage.message || editedMessage;
                    if (typeof messageContent === 'object' && messageContent !== null) {
                        const editedType = Object.keys(messageContent)[0] || 'unknown';

                        if (editedType === 'conversation') {
                            editedMessageText = messageContent.conversation;
                        } else if (editedType === 'extendedTextMessage') {
                            editedMessageText = messageContent.extendedTextMessage?.text || 'Teks tidak tersedia';
                        } else if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(editedType)) {
                            editedMessageText = `[Media: ${editedType.replace('Message', '')}] ${messageContent[editedType].caption || ''}`;
                        } else {
                            editedMessageText = 'Jenis pesan tidak dikenali';
                        }
                    } else {
                        editedMessageText = 'Konten pesan tidak valid';
                    }
                } catch (e) {
                    console.error('Gagal memproses editedMessage:', e, 'editedMessage:', editedMessage);
                    editedMessageText = 'Gagal memproses pesan yang diedit';
                }
            } else {
                console.error('editedMessage tidak tersedia:', editedMessage);
            }

            // Kirim notifikasi dengan pesan sebelum dan sesudah diedit
            await conn.sendMessage(m.chat, {
                text: `*‼️ ANTI EDIT CHAT AKTIF*\n\n– pesan dari @${sender.split('@')[0]} telah diedit!\n\n*pesan sebelum diedit :* ${originalMessage}\n*pesan setelah diedit :* ${editedMessageText}`,
                contextInfo: {
                    mentionedJid: [sender],
                    externalAdReply: {
                        title: '‼️ Pesan Diedit',
                        body: `@${senderName} mengedit pesan`,
                        thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ANTIEDIT.png',
                        mediaType: 1
                    }
                }
            });
        }
    }
};