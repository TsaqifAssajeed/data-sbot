let handler = (m) => m;

// Handler pra-pemrosesan dengan handler.before
handler.before = async function (m, { conn }) {
    const chat = global.db.data.chats[m.chat] || {};
    const isAntiBot = m.isGroup ? (chat.antiBot || false) : false;

    // Pastikan antibot aktif, pesan bukan dari bot itu sendiri, dan bukan event grup
    if (m.isGroup && isAntiBot && !m.fromMe && !m.messageStubType) {
        // Hanya proses pesan dengan tipe tertentu (abaikan event grup)
        if (m.type && !['chat', 'image', 'video', 'sticker', 'audio', 'document', 'location'].includes(m.type)) {
            return; // Abaikan semua event grup dan jenis pesan lainnya
        }

        const validChars = '0123456789ABCDEF'; // Karakter yang diperbolehkan
        const idLengthByDevice = {
            ios: 18,
            desktop: 18,
            web: 20,
            android: [21, 32] // Rentang 21-32 untuk Android
        };
        const botIDs = ['B1EY', 'BAE5', 'BAE0', 'B1E', '3EB0', 'FTG']; // Filter awal

        // Fungsi untuk memeriksa semua kondisi bot
        const checkBotID = (id) => {
            let reasons = [];

            // Cek filter awal berdasarkan 4 huruf pertama
            if (botIDs.some(prefix => id.startsWith(prefix))) {
                reasons.push('- ID User asli tidak valid');
            }

            // Cek apakah ada karakter tidak valid
            if ([...id].some(char => !validChars.includes(char))) {
                reasons.push('- Mengandung karakter BOT');
            }

            // Cek panjang ID
            const idLength = id.length;
            if (idLength !== idLengthByDevice.ios && idLength !== idLengthByDevice.desktop &&
                idLength !== idLengthByDevice.web &&
                !(idLength >= idLengthByDevice.android[0] && idLength <= idLengthByDevice.android[1])) {
                reasons.push('- Panjang karakter tidak sesuai aturan');
            }

            return { isBot: reasons.length > 0, reasons };
        };

        // Cek apakah ID terdeteksi sebagai bot
        const { isBot, reasons } = checkBotID(m.id);
        const reasonText = reasons.length > 0 ? reasons.join('\n') : '';

        // Cek apakah pengirim adalah admin
        const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
        const isAdmin = groupMetadata?.participants.find(p => p.id === m.sender)?.admin || false;

        // Deteksi bot berdasarkan ID
        if (isBot) {
            const warn = global.db.data.users[m.sender]?.warn || 0;
            const maxWarnings = 5; // Jumlah maksimum peringatan
            const remainingWarnings = maxWarnings - warn;

            // Menyusun pesan peringatan
            let warningMessage = `⚠️ *「 ANTI BOT 」* ⚠️\n\n` +
                `*Pengirim:* @${m.sender.split('@')[0]}\n` +
                `_Terdeteksi sebagai bot_ 😤\n\n` +
                `💳 *ID Bot*: ${m.id}\n` +
                `📌 *Peringatan*: ${warn + 1}/${maxWarnings}\n` +
                `📥 *Sisa peringatan*: ${remainingWarnings}\n` +
                `*Alasan Deteksi:*\n${reasonText}\n\n` +
                `> Jika peringatan habis, kamu akan di-kick dari grup ini`;

            if (isAdmin) {
                warningMessage += `\n\n_Anda adalah admin, jadi tidak ada tindakan yang diambil._ 😊`;
            } else {
                // Update jumlah peringatan
                global.db.data.users[m.sender].warn = warn + 1;

                if (warn + 1 >= maxWarnings) {
                    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                    await conn.sendMessage(m.chat, {
                        text: `⛔ @${m.sender.split('@')[0]} telah melampaui batas peringatan karena bot terdeteksi!\n` +
                              `*Alasan Deteksi:*\n${reasonText}\nAkan di-tendang dari grup!`,
                        mentions: [m.sender]
                    });

                    // Reset peringatan setelah kick
                    global.db.data.users[m.sender].warn = 0;
                }
            }

            // Kirimkan peringatan di grup
            await m.reply(warningMessage, null, { mentions: [m.sender] });
        }
    }
}

// Handler untuk mendeteksi bot dan sistem peringatan
handler.all = async function (m, chatUpdate) {
    const conn = this;

    if (!conn || !m || !m.chat || !m.key || m.fromMe || m.messageStubType) return;

    // Hanya proses pesan dengan tipe tertentu (abaikan event grup)
    if (m.type && !['chat', 'image', 'video', 'sticker', 'audio', 'document', 'location'].includes(m.type)) return;

    // Cek apakah fitur anti-bot aktif di grup ini
    let chat = global.db.data.chats[m.chat];
    if (!chat || !chat.antiBot) return;

    const validChars = '0123456789ABCDEF'; // Karakter yang diperbolehkan
    const idLengthByDevice = {
        ios: 18,
        desktop: 18,
        web: 20,
        android: [21, 32] // Rentang 21-32 untuk Android
    };
    const botIDs = ['B1EY', 'BAE5', 'BAE', 'B1E', '3EB0', 'FTG']; // Filter awal

    // Fungsi untuk memeriksa semua kondisi bot
    const checkBotID = (id) => {
        let reasons = [];

        // Cek filter awal berdasarkan 4 huruf pertama
        if (botIDs.some(prefix => id.startsWith(prefix))) {
            reasons.push('- ID User asli tidak valid');
        }

        // Cek apakah ada karakter tidak valid
        if ([...id].some(char => !validChars.includes(char))) {
            reasons.push('- Mengandung karakter BOT');
        }

        // Cek panjang ID
        const idLength = id.length;
        if (idLength !== idLengthByDevice.ios && idLength !== idLengthByDevice.desktop &&
            idLength !== idLengthByDevice.web &&
            !(idLength >= idLengthByDevice.android[0] && idLength <= idLengthByDevice.android[1])) {
            reasons.push('- Panjang karakter tidak sesuai aturan');
        }

        return { isBot: reasons.length > 0, reasons };
    };

    const who = m.sender;
    const { isBot, reasons } = checkBotID(m.id);
    const reasonText = reasons.length > 0 ? reasons.join('\n') : '';

    // Cek apakah pengirim adalah admin
    const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
    const isAdmin = groupMetadata?.participants.find(p => p.id === who)?.admin || false;

    // Inisialisasi data pengguna jika belum ada
    if (!(who in global.db.data.users)) {
        global.db.data.users[who] = { warn: 0 };
    }

    let warn = global.db.data.users[who].warn;
    const maxWarnings = 3;

    if (isBot) {
        if (isAdmin) {
            // Pesan khusus untuk admin
            const adminBotMessage = `⚠️ *「 ANTI BOT 」* ⚠️\n\n` +
                `*Pengguna:* @${who.split('@')[0]}\n` +
                `_Admin terdeteksi sebagai bot, pesan tidak dihapus dan tidak ada peringatan._ 😊\n\n` +
                `*Alasan Deteksi:*\n${reasonText}`;

            await conn.sendMessage(m.chat, {
                text: adminBotMessage,
                mentions: [who]
            });
        } else {
            try {
                await conn.sendMessage(m.chat, { delete: m.key });

                if (warn < maxWarnings) {
                    global.db.data.users[who].warn += 1;

                    // Peringatan untuk grup
                    const groupWarning = `⚠️ *「 ANTI BOT 」* ⚠️\n\n` +
                        `⏳ *Segera ditindak lanjuti!* ⏳\n\n` +
                        `*Pengguna:* @${who.split`@`[0]}\n` +
                        `_Tolong matikan atau self-bot kamu, grup ini mengaktifkan fitur AntiBot_ 😤\n\n` +
                        `💳 *ID Bot*: ${m.id}\n` +
                        `📌 *Peringatan*: ${warn + 1}/${maxWarnings}\n` +
                        `📥 *Sisa peringatan*: ${maxWarnings - (warn + 1)}\n` +
                        `*Alasan Deteksi:*\n${reasonText}\n\n` +
                        `> Jika peringatan habis, kamu akan di-kick dari grup ini`;

                    await conn.sendMessage(m.chat, {
                        text: groupWarning,
                        mentions: [who]
                    });
                } else if (warn >= maxWarnings) {
                    global.db.data.users[who].warn = 0;

                    await conn.sendMessage(m.chat, {
                        text: `⛔ @${who.split`@`[0]} telah melampaui batas ${maxWarnings} peringatan karena bot terdeteksi!\n` +
                              `*Alasan Deteksi:*\n${reasonText}\nAkan di-tendang dari grup!`,
                        mentions: [who]
                    });

                    await time(3000); // Delay 3 detik sebelum kick
                    await conn.groupParticipantsUpdate(m.chat, [who], 'remove');

                    await conn.sendMessage(who, {
                        text: `♻️ Anda telah dikeluarkan dari grup karena melampaui ${maxWarnings} peringatan bot!`
                    });
                }
            } catch (err) {
                console.error('Gagal memproses peringatan bot:', err);
            }
        }
    }
};

const time = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};


module.exports = handler;