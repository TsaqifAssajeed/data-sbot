const fetch = require("node-fetch")

let handler = async (m, { conn, usedPrefix, command, text }) => {
if (!text) return m.reply(`Mau Cari Apk Apa?\nGunakan Seperti Contoh\n${usedPrefix + command} Geometry Dash`)
m.reply('Proses...')
await fetch(`https://api.diioffc.web.id/api/search/playstore?query=${text}`).then(async (res) => {
let response = await res.json()
let teks = '*🔎 Hasil Pencarian PLAY STORE*\n\n'
for (let i of response.result) {
teks += `*◦ Title :* ${i.nama}\n`
teks += `*◦ Developer :* ${i.developer}\n`
teks += `*◦ Rating :* ${i.rate}\n`
teks += `*◦ Link Developer Url :* ${i.link_dev}\n`
teks += `*◦ Link Apps Url :* ${i.link}\n\n`
}
m.reply(teks)
}).catch(err => m.reply('Error Anjir...'))
}

handler.command = ["playstore"]
handler.help = ["playstore"]
handler.tags = ["internet"]

handler.register = true
handler.limit = true
module.exports = handler