const fetch = require('node-fetch');

const handler = async (m, { text }) => {
    if (!text) return m.reply('Kasih kata-kata dulu dong!');

    try {
        const res = await fetch(`https://api.siputzx.my.id/api/ai/latukam?content=${encodeURIComponent(text)}`);
        const json = await res.json();

        if (!json.status || !json.data) return m.reply('Gak ada jawaban dari pak amba, lagi sibuk rek.');

        m.reply(json.data);
    } catch (error) {
        console.error(error);
        m.reply('Gagal dapat respons, coba lagi ya.');
    }
};

handler.command = /^latukam$/i;
handler.help = ['latukam <pertanyaan>'];
handler.tags = ['ai'];
handler.limit = true;

handler.register = true
module.exports = handler;