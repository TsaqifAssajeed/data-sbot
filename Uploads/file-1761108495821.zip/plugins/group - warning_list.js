const { normalizeJid } = require('../function/jid')

let handler = async (m, { conn, groupMetadata }) => {
    let users = Object.entries(global.db.data.users)
        .filter(([jid, user]) => user.warn > 0)
        .map(([jid, user], index) => {
            let userNumber = jid.split('@')[0].replace(/^\+/, '').replace(/[^0-9]/g, '')
            let name = conn.getName(jid) || 'Unknown'
            return {
                jid: normalizeJid(jid),
                name,
                userNumber,
                warn: user.warn,
                reasons: user.warnReasons || ['Tidak ada alasan yang dicatat']
            }
        })

    if (users.length === 0) {
        return m.reply('Tidak ada pengguna yang memiliki peringatan di grup ini.')
    }

    let message = `📋 *Daftar Pengguna yang Diperingatkan* 📋\n\n`
    message += `Grup: *${groupMetadata.subject}*\n\n`
    users.forEach((user, index) => {
        message += `${index + 1}. *${user.name}* (@${user.userNumber})\n`
        message += `   Peringatan: ${user.warn}/${global.maxwarn}\n`
        message += `   Alasan:\n`
        user.reasons.forEach((reason, i) => {
            message += `     ${i + 1}. ${reason}\n`
        })
        message += `\n`
    })

    m.reply(message, null, { mentions: users.map(user => user.jid) })
}

handler.help = ['listwarn', 'warnlist']
handler.tags = ['group']
handler.command = ['listwarn', 'warnlist']
handler.group = false
handler.admin = false
handler.botAdmin = false
handler.register = true
handler.limit = false
module.exports = handler