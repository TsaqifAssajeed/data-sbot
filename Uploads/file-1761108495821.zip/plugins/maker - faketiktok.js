const axios = require('axios');
const FormData = require('form-data');

const handler = async (m, { conn, text, args, command, usedPrefix }) => {
  try {
    // Validate input format
    if (!text.includes('|')) {
      return m.reply(`📸 Kirim gambar dengan caption berikut:\n\n✨ Nama|Username|Verified(true/false)|Followers|Following|Likes|Bio|Dark(true/false)|IsFollow(true/false)\n\n📝 Contoh: *${usedPrefix + command} Bella Bell|bellabell|true|150000|500|200000|Jangan Lupa Makan Rendang|true|false*\n\n🔄 Atau reply gambar dengan caption di atas!`);
    }

    // Check for image
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    if (!mime || !mime.startsWith('image/')) {
      return m.reply('🖼️ Silakan kirim atau reply *gambar* untuk foto profil! 📷');
    }

    await conn.sendMessage(m.chat, { react: { text: '🚀', key: m.key } }); // Efek react
    await m.reply('⏳ Sedang memproses gambar...'); // Loading message

    const buffer = await q.download();
    const ext = mime.split('/')[1];
    const filename = `pp.${ext}`;

    const Uguu = async (buffer, filename) => {
      const form = new FormData();
      form.append('files[]', buffer, { filename });

      const { data } = await axios.post('https://uguu.se/upload.php', form, {
        headers: form.getHeaders(),
      });

      if (data.files && data.files[0]) {
        return data.files[0].url;
      } else {
        throw new Error('Upload gagal');
      }
    };

    const pp = await Uguu(buffer, filename);

    let [name, username, verified, followers, following, likes, bio, dark = 'true', isFollow = 'true'] = text.split('|').map(v => v.trim());

    // Validate required fields
    if (!name || !username || !followers || !following || !likes || !bio) {
      return m.reply('❌ Semua data wajib diisi! Pastikan format sesuai contoh. 📋');
    }

    const imageUrl = `${flowfalcon}/imagecreator/faketiktok?name=${encodeURIComponent(name)}&username=${encodeURIComponent(username)}&pp=${encodeURIComponent(pp)}&verified=${verified}&followers=${followers}&following=${following}&likes=${likes}&bio=${encodeURIComponent(bio)}&dark=${dark}&isFollow=${isFollow}`;

    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: '✅ Fake TikTok profile berhasil dibuat! 🎉'
    }, { quoted: m });

  } catch (err) {
    console.error('Error in faketiktok handler:', err);
    m.reply('😓 Terjadi kesalahan saat memproses permintaan. Coba lagi nanti ya! 🔄');
  }
};

handler.help = ['faketiktok <nama|username|verified|followers|following|likes|bio|dark|isFollow>'];
handler.tags = ['maker'];
handler.command = /^faketiktok$/i;
handler.limit = true;

handler.register = true
module.exports = handler;