const axios = require('axios');

// Fungsi untuk query ke API Deepseek
async function deepseekQuery(prompt) {
    try {
        const response = await axios.get(`${global.alyachan}/api/deepseek`, {
            params: {
                msg: prompt,
                thinking: 'no',
                legacy: 'yes',
                apikey: global.alyachankey
            }
        });
        return response.data.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || error.message);
    }
}

let handler = async (m, { text, command, usedPrefix, conn }) => {
    if (!text) {
        throw `Harap masukkan teks.\nContoh:\n${usedPrefix + command} Halo, apa kabar?`;
    }

    // Kirim reaction loading
    await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
    });

    try {
        // Query ke API Deepseek
        let responseData = await deepseekQuery(text);

        // Format respons utama
        let responseText = responseData.content || 'Tidak ada konten yang diterima.';
        
        // Tambahkan data tambahan jika tersedia
        let additionalInfo = '';
        if (responseData.thoughts) {
            additionalInfo += `\n\n*Pemikiran:* ${responseData.thoughts}`;
        }
        if (responseData.search_queries && responseData.search_queries.length > 0) {
            additionalInfo += `\n\n*Pencarian:* ${responseData.search_queries.join(', ')}`;
        }
        if (responseData.search_results && responseData.search_results.length > 0) {
            additionalInfo += `\n\n*Hasil Pencarian:* ${responseData.search_results.join(', ')}`;
        }
        if (responseData.search_indexes && responseData.search_indexes.length > 0) {
            additionalInfo += `\n\n*Indeks Pencarian:* ${responseData.search_indexes.join(', ')}`;
        }
        if (responseData.message_id) {
            additionalInfo += `\n\n*ID Pesan:* ${responseData.message_id}`;
        }
        if (responseData.parent_id) {
            additionalInfo += `\n\n*ID Induk:* ${responseData.parent_id}`;
        }

        // Ganti markdown
        responseText = responseText.replace(/\*\*(.*?)\*\*/g, '*$1*');
        responseText = responseText.replace(/### (.*?)(?=\n)/g, '`$1`');
        responseText = responseText.replace(/##/g, '✦');
        // Hapus referensi sumber seperti [1], [2], dll.
        responseText = responseText.replace(/\[\d+\]/g, '');
        responseText += additionalInfo;
        responseText += '\n\n> AI Deepseek';

        // Kirim dengan contextInfo
        await conn.sendMessage(
            m.chat,
            {
                text: responseText,
                contextInfo: {
                    externalAdReply: {
                        title: ' 🐋 AI Deepseek Response',
                        body: '',
                        thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1760798620480.jpeg',
                        sourceUrl: '',
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            },
            {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: '0@s.whatsapp.net',
                        remoteJid: 'status@broadcast'
                    },
                    message: { conversation: 'AI Deepseek Response' }
                }
            }
        );

        // Kirim reaksi sukses
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
    } catch (e) {
        console.error('Error:', e);
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        m.reply(`🚫 Error saat memproses permintaan: ${e.message}`);
    }
};

handler.command = ['aideepseek', 'deepseek'];
handler.tags = ['ai'];
handler.help = ['deepseek'].map(a => a + ' *[text]*');

handler.register = true;
handler.limit = true;
module.exports = handler;