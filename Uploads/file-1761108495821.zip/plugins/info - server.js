const os = require('os');
const axios = require('axios');
const cheerio = require('cheerio');

const checkHost = {
  api: {
    base: 'https://check-host.net',
    timeout: 30000,
    retries: 5
  },
  headers: {
    'Accept': 'application/json',
    'User-Agent': 'Postify/1.0.0'
  },
  types: ['ping', 'http', 'tcp', 'udp', 'dns', 'info'],

  hostname: (host) => {
    const regex = /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$|^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return regex.test(host);
  },

  domain: (input) => {
    if (input.startsWith('http://') || input.startsWith('https://')) {
      return new URL(input).hostname;
    }
    return input;
  },

  flagEmoji: (cc) => {
    const codePoints = cc
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt());
    return String.fromCodePoint(...codePoints);
  },

  request: async (endpoint, params = {}) => {
    try {
      const { data } = await axios.get(`${checkHost.api.base}/${endpoint}`, {
        params,
        headers: checkHost.headers,
        timeout: checkHost.api.timeout
      });
      return data;
    } catch (error) {
      console.error(`${error.message}`, error.response?.data);
      throw error;
    }
  },

  info: async (host) => {
    try {
      const response = await axios.get(`${checkHost.api.base}/ip-info`, {
        params: { host },
        headers: checkHost.headers,
        timeout: checkHost.api.timeout
      });

      const $ = cheerio.load(response.data);
      const infox = {};

      $('.ipinfo-item').each((index, element) => {
        const provider = $(element).find('strong a').text().trim().split('\n')[0].trim().toLowerCase().replace(/\s+/g, '_');
        const data = {};

        $(element).find('table tr').each((i, row) => {
          let key = $(row).find('td:first-child').text().trim().toLowerCase().replace(/\s+/g, '_');
          let value = $(row).find('td:last-child').text().trim();
          
          value = value.replace(/\s+/g, ' ').trim();
          if (key === "ip_range") {
            value = value.split('CIDR')[0].trim();
          }
          if (key === "country") {
            const src = $(row).find('td:last-child img.flag').attr('src');
            if (src) {
              const cc = src.split('/').pop().split('.')[0];
              data['country_code'] = cc.toLowerCase();
              data['country_flag'] = `https://check-host.net${src}`;
              data['country_flag_emoji'] = checkHost.flagEmoji(cc);
            }
          }
          if (value !== '') {
            data[key] = key === 'country_flag' || key === 'country_flag_emoji' ? value : value.toLowerCase();
          }
        });

        infox[provider] = data;
      });

      return { status: true, data: infox };
    } catch (error) {
      return { status: false, message: `${error.message}` };
    }
  },

  results: async (requestId, nodes, tries = 0) => {
    if (!requestId || Object.keys(nodes).length === 0 || tries >= 20) {
      return { status: false, message: "Waduh, nodenya kosong atau enggak terlalu kebanyakan nyoba bree 🤣" };
    }

    try {
      const nodesParams = Object.keys(nodes).map(node => `nodes[]=${encodeURIComponent(node)}`).join('&');
      const data = await checkHost.request(`check-result/${requestId}`, new URLSearchParams(nodesParams));

      for (const node in data) {
        if (data[node] && nodes[node] && nodes[node].length >= 2) {
          const cc = nodes[node][0].toLowerCase();
          const countryName = nodes[node][1].toLowerCase();
          data[node] = {
            ...data[node],
            country_code: cc,
            country_name: countryName,
            flag_url: `https://check-host.net/images/flags/${cc}.png`,
            flag_emoji: checkHost.flagEmoji(cc)
          };
        }
      }

      const remainingNodes = Object.keys(nodes).filter(node => !(node in data));

      if (remainingNodes.length > 0 && tries < 19) {
        await new Promise(resolve => setTimeout(resolve, 3000));
        const nodesx = Object.fromEntries(remainingNodes.map(node => [node, nodes[node]]));
        const nextResults = await checkHost.results(requestId, nodesx, tries + 1);
        return { status: true, data: { ...data, ...nextResults.data } };
      }

      return { status: true, data };
    } catch (error) {
      return { status: false, message: `${error.message}` };
    }
  },

  check: async (host, type = 'ping', paramek = {}) => {
    if (!host || host.trim() === '') {
      return { status: false, message: 'Lah, hostnya mana bree? 🗿' };
    }

    if (!checkHost.types.includes(type)) {
      return { status: false, message: `Yaelah, tipe checknya nggak ada bree. Coba pilih salah satu dari ini dahh: ${checkHost.types.join(', ')}` };
    }

    const hostx = checkHost.domain(host);
    if (!checkHost.hostname(hostx)) {
      return { status: false, message: 'Kalo masukin input tuh yang bener bree 🗿' };
    }

    const tipes = type === 'info' ? 'ip-info' : `check-${type}`;

    if (type === 'tcp' || type === 'udp') {
      if (!paramek.port) {
        return { status: false, message: `Ebuseet, portnya lupa diisi tuh buat check ${type}.` };
      }
    } else if (type === 'dns') {
      if (!paramek.type) {
        return { status: false, message: 'Record type buat DNS checknya mana nih bree? Jangan bikin emosi mulu napa 🗿'};
      }
    }

    try {
      if (type === 'info') {
        return await checkHost.info(hostx);
      }

      const response = await checkHost.request(tipes, { host: hostx, ...paramek });
      
      if (!response || typeof response !== 'object') {
        return { status: false, message: "Yaelah, servernya ngasih response ngaco bree 😂" };
      }

      const { request_id, nodes } = response;
      if (!request_id || !nodes) {
        return { status: false, message: "Initial checknya failed bree 😂\nCoba lagi nanti ae yak ..." };
      }

      await new Promise(resolve => setTimeout(resolve, 5000));

      const result = await checkHost.results(request_id, nodes);

      if (result.status) {
        return {
          status: true,
          data: {
            host: hostx,
            type: type,
            result: result.data
          }
        };
      } else {
        return result;
      }
    } catch (error) {
      return { status: false, message: `${error.message}` };
    }
  }
};

const handler = async (m, { conn }) => {
  try {
    // Build combined message with enhanced formatting and emojis
    let message = `📡 *Server Details* 📡\n`;
    
    // Server Info section
    message += `┌─────────────────\n`;
    message += `│  Hostname: ${process.env.npm_package_name || 'Unknown'} 🖥️\n`;
    message += `│  Type: ${os.type()} ⚙️\n`;
    message += `│  Platform: ${os.platform()} 🖼️\n`;
    message += `│  Release: ${os.release()} 📊\n`;
    message += `│  Architecture: ${os.arch()} 🏗️\n`;
    message += `│  Home: ${os.homedir()} 🏠\n`;
    message += `│  Temp Folder: ${os.tmpdir()} 📁\n`;
    message += `│  Auth Folder: /session 🔒\n`;
    message += `│  Total Memory: ${Math.round(os.totalmem() / 1024 / 1024)} MB 💾\n`;
    message += `│  Free Memory: ${Math.round(os.freemem() / 1024 / 1024)} MB 🆓\n`;
    message += `│  RAM Usage: ${formatSize(os.totalmem() - os.freemem())} / ${formatSize(os.totalmem())} 📈\n`;
    message += `└─────────────────\n`;
    
    // Fetch public IP address with fallback
    let publicIp = 'unknown';
    const ipApis = [
      'https://api.ipify.org?format=json',
      'https://api.myip.com',
      'https://ipapi.co/json/'
    ];

    for (const api of ipApis) {
      try {
        const response = await axios.get(api, { timeout: 5000 });
        publicIp = response.data.ip || response.data.query || 'unknown';
        if (publicIp !== 'unknown' && checkHost.hostname(publicIp)) {
          break;
        }
      } catch (error) {
        console.error(`Error fetching public IP from ${api}:`, error.message);
      }
    }

    // Fetch IP and location data using checkHost
    let ipInfo = { status: false, data: {} };
    if (publicIp !== 'unknown' && checkHost.hostname(publicIp)) {
      ipInfo = await checkHost.info(publicIp);
    }
    if (!ipInfo.status) {
      message += `🌐 *Network Info* 🌐\n`;
      message += `┌─────────────────\n`;
      message += `│ ⚠️ Failed to fetch network info: ${ipInfo.message || 'Unknown error'} 😓\n`;
      message += `└─────────────────\n`;
    } else {
      // Network Info section
      message += `🌐 *Network Info* 🌐\n`;
      message += `┌─────────────────\n`;
      const providerData = Object.values(ipInfo.data)[0] || {};
      for (const key in providerData) {
        if (key === 'country') {
          message += `│ 🌍 Country: ${providerData[key]} ${providerData.country_flag_emoji || ''}\n`;
          message += `│ 🏳️ Country Code: ${providerData.country_code || 'N/A'}\n`;
          message += `│ 🎌 Country Flag: ${providerData.country_flag_emoji || 'N/A'}\n`;
        } else if (key === 'ip') {
          message += `│  IP Address: ${providerData[key]} 📡\n`;
        } else if (key !== 'country_code' && key !== 'country_flag' && key !== 'country_flag_emoji') {
          message += `│  ${ucword(key.replace(/_/g, ' '))}: ${providerData[key]} 📡\n`;
        }
      }
      message += `└─────────────────\n`;
    }

    // System Info section
    message += `⚡️ *System Info* ⚡️\n`;
    message += `┌─────────────────\n`;
    message += `│ ⏰ Uptime: ${toTime(os.uptime() * 1000)} 🕒\n`;
    message += `│ 💻 Processor: ${os.cpus()[0].model} 🚀\n`;
    message += `└─────────────────\n`;

    // Send combined message
    await conn.relayMessage(m.chat, {
      extendedTextMessage: {
        text: message,
        contextInfo: {
          externalAdReply: {
            title: `Server Uptime: ${toTime(os.uptime() * 1000)} ⏱️`,
            mediaType: 1,
            previewType: 0,
            renderLargerThumbnail: true,
            thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1754785792968.jpeg',
            sourceUrl: ''
          }
        },
        mentions: [m.sender]
      }
    }, {});
  } catch (error) {
    console.error('Error in server info handler:', error);
    await m.reply('🚨 Error retrieving server information! 😓');
  } finally {
    deleteMessage();
  }
};

// Handler metadata
handler.command = ['server', 'os'];
handler.help = ['server / os'];
handler.tags = ['info'];

handler.register = true

module.exports = handler;

// Utility functions
function deleteMessage() {
  // Placeholder for message deletion logic
}

function formatSize(bytes) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  if (bytes === 0) return '0 Bytes';
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}

function ucword(str) {
  return str.replace(/\b\w/g, (char) => char.toUpperCase());
}

function toTime(milliseconds) {
  const seconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  return `${days} days, ${hours % 24} hours, ${minutes % 60} minutes, ${seconds % 60} seconds`;
}