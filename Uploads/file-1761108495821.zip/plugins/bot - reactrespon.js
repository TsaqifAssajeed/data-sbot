// ✨ Plugin _reactrespon ✨

//======== REACT PESAN BY HIKMALL ========//
const { setTimeout } = require('timers'); // TIMER ini untuk schedule pembersihan cache otomatis
const { translate } = require('@vitalets/google-translate-api'); // TRANSLATE ini untuk menerjemahkan teks pesan

//======== DEFAULT 3 JAM ========//
const store = {}; // Objek cache ini menyimpan pesan sementara agar bisa diakses saat react
const INTERVAL_RESET = 3 * 60 * 60 * 1000; // Interval reset cache setiap 3 jam

//========== MENYIMPAN PESAN KE CACHE =======//
function simpanPesanKeCache(pesan) {
    // Fungsi ini untuk menyimpan setiap pesan group ke cache agar bisa di-refer saat react
    const dataPesan = {
        id: pesan.key.id, // ID unik pesan untuk referensi
        chat: pesan.key.remoteJid, // ID chat tempat pesan dikirim
        pengirim: pesan.key.participant || pesan.key.remoteJid, // Nomor pengirim pesan
        dariSaya: pesan.key.fromMe, // Menandai apakah pesan dari bot
        waktu: pesan.messageTimestamp, // Timestamp pesan untuk catatan
        text: pesan.message?.conversation || pesan.message?.extendedTextMessage?.text || null // Isi teks pesan
    };
    store[pesan.key.id] = dataPesan; // Menyimpan data pesan ke cache
}

//====== BACA PESAN DARI CACHE ==========
function bacaPesanDariCache(idPesan) {
    // Fungsi ini untuk mengambil pesan dari cache berdasarkan ID
    return store[idPesan] || null;
}

//====== HAPUS PESAN VIA ID ==========
function hapusPesanDariCache(idPesan) {
    // Fungsi ini untuk menghapus pesan dari cache
    delete store[idPesan];
}

//======== MEMBERSIHKAN CACHE ========
function bersihkanCache() {
    // Fungsi ini membersihkan semua cache pesan untuk menghindari penumpukan data
    Object.keys(store).forEach(key => delete store[key]);
    store.waktuResetTerakhir = Date.now(); // Menyimpan waktu terakhir pembersihan cache
}

//========== WAKTU RESET BERIKUTNYA =========//
function hitungWaktuHinggaResetBerikutnya() {
    // Fungsi ini menghitung sisa waktu hingga cache di-reset lagi
    const waktuResetTerakhir = store.waktuResetTerakhir || Date.now();
    const waktuSejakResetTerakhir = Date.now() - waktuResetTerakhir;
    return Math.max(0, INTERVAL_RESET - waktuSejakResetTerakhir); // Pastikan tidak negatif
}

//======= JADWAL PEMBERSIHAN CACHE ========//
function jadwalkanPembersihanCache() {
    // Fungsi ini untuk menjadwalkan pembersihan cache otomatis
    const waktuHinggaResetBerikutnya = hitungWaktuHinggaResetBerikutnya();
    setTimeout(() => {
        bersihkanCache(); // Bersihkan cache
        jadwalkanPembersihanCache(); // Schedule ulang pembersihan cache
    }, waktuHinggaResetBerikutnya);
}
jadwalkanPembersihanCache(); // Mulai schedule otomatis

/* 
==================================================
  REACT PESAN BY HIKMALL - WATERMARK
==================================================

👤 Creator   : Hikmal
📝 Fungsi    : Plugin untuk react pesan di group WhatsApp
               - 🆔 = Translate pesan otomatis ke bahasa Indonesia
               - ❌ / 🗑 = Hapus pesan
               - 🦶🏻 / 🦵🏻 / 🦿 = Kick user dari group (hanya admin)
📦 Modul     : timers, @vitalets/google-translate-api
📆 Version   : 1.0
⚡ Catatan   : 
    - Cache pesan disimpan sementara agar bisa di-react
    - Hanya admin yang bisa menggunakan fitur kick/hapus
    - Bot harus admin agar bisa menjalankan kick/hapus
💡 Tips      : 
    - Emoji react bisa ditambahkan sesuai kebutuhan
    - Translate bisa diterapkan pada semua pesan group
==================================================
*/
// ======== FUNGSIONALITAS UTAMA ======== //
async function before(m, { conn }) {
    if (m.isBaileys && !m.fromMe) return; // Abaikan pesan sistem atau bukan dari bot
    if (m.isGroup) simpanPesanKeCache(m); // Simpan semua pesan group ke cache

    if (m.mtype === 'reactionMessage' && m.isGroup) {
        const reaksi = m.msg; // Data reaction dari user
        const emojiReaksi = reaksi.text; // Emoji yang direact
        const idPesanTarget = reaksi.key.id; // ID pesan yang direact
        const emojiValid = ['🆔', '❌', '🗑', '🦶🏻', '🦵🏻', '🦿'];
if (!emojiValid.includes(emojiReaksi)) return; // stop kalau bukan emoji valid

        //=============== FUNGSI TRANSLATE =============//
        if (emojiReaksi === '🆔') { 
            // Emoji 🆔 digunakan untuk menerjemahkan pesan target
            const pesanTarget = bacaPesanDariCache(idPesanTarget);
            if (!pesanTarget || !pesanTarget.text) return m.reply('⚠ Tidak ada teks untuk diterjemahkan.');
            try {
                let result = await translate(pesanTarget.text, { to: 'id' });
                m.reply(`🌐 Terjemahan:\n\n${result.text}`); // Mengirim hasil terjemahan
            } catch (e) {
                m.reply('⚠ Gagal translate.'); // Jika gagal translate
            }
            return; // Akhiri proses translate
        }

        // ===== CEK ADMIN PENGIRIM ===== //
        const metadataGrup = await conn.groupMetadata(m.chat); // Mengambil data metadata grup
        const pesertaPengirim = metadataGrup.participants.find(p => p.jid === m.sender); // Ambil info pengirim
        const pengirimAdmin = pesertaPengirim?.admin === 'admin' || pesertaPengirim?.admin === 'superadmin'; // Cek apakah pengirim admin
        if (!pengirimAdmin) return m.reply('🚩 Hanya admin yang bisa menggunakan fitur ini!'); // Hanya admin yang bisa lanjut

        //======== FUNGSI KICK =============//
        if (['🦶🏻', '🦵🏻', '🦿'].includes(emojiReaksi)) {
            const pesanTarget = bacaPesanDariCache(idPesanTarget);
            //if (!pesanTarget) return m.reply('🚩 Pesan tidak ditemukan di cache!');

            const nomorBot = conn.user.jid; // Nomor bot
            const pesertaBot = metadataGrup.participants.find(p => p.jid === nomorBot); // Cek bot di grup
            const botAdalahAdmin = pesertaBot?.admin === 'admin' || pesertaBot?.admin === 'superadmin'; // Pastikan bot admin
            if (!botAdalahAdmin) return m.reply('🚩 Bot bukan admin!'); // Jika bot bukan admin, stop

            try {
                await conn.groupParticipantsUpdate(m.chat, [pesanTarget.pengirim], 'remove'); // Kick user target
                m.reply(`🚩 Pengguna @${pesanTarget.pengirim.split('@')[0]} telah di-kick!`), null, {
                    mentions: [pesanTarget.pengirim] // Mention user target
                };
            } catch (e) {
                m.reply('⚠ Gagal kick user, mungkin dia admin atau bot tidak cukup izin.'); // Jika gagal kick
            }
            hapusPesanDariCache(idPesanTarget); // Hapus cache pesan target
            return;
        }

        //============= FUNGSI HAPUS PESAN ==============//
        if (!['❌', '🗑'].includes(emojiReaksi)) return; // Hanya emoji ❌ atau 🗑 untuk hapus
        const pesanTarget = bacaPesanDariCache(idPesanTarget);
        if (!pesanTarget) return m.reply('🚩 Pesan tidak ditemukan di cache!');

        const nomorBot = conn.user.jid; // Nomor bot
        const pesertaBot = metadataGrup.participants.find(p => p.jid === nomorBot); // Ambil data bot
        const botAdalahAdmin = pesertaBot?.admin === 'admin' || pesertaBot?.admin === 'superadmin'; // Pastikan bot admin
        if (!botAdalahAdmin) return m.reply('🚩 Bot bukan admin!'); // Stop jika bot bukan admin

        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: pesanTarget.chat, // ID chat
                fromMe: pesanTarget.dariSaya, // Apakah dari bot
                id: pesanTarget.id, // ID pesan
                participant: pesanTarget.pengirim // Target peserta
            }
        }); // Menghapus pesan
        hapusPesanDariCache(idPesanTarget); // Hapus cache pesan target
    }
    return; // Akhiri function
}

module.exports = { before }; // Export function sebelum pesan diproses untuk plugin