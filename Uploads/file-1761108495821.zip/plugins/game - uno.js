let games = {}

const colors = ["red", "yellow", "green", "blue"]
const specialCards = ["skip", "reverse", "draw2", "wild", "wild4"]

function generateDeck() {
    let deck = []
    for (let color of colors) {
        for (let i = 0; i <= 9; i++) {
            deck.push({ color, value: i.toString() })
            if (i !== 0) deck.push({ color, value: i.toString() })
        }
        for (let s of ["skip", "reverse", "draw2"]) {
            deck.push({ color, value: s })
            deck.push({ color, value: s })
        }
    }
    for (let i = 0; i < 4; i++) {
        deck.push({ color: "wild", value: "wild" })
        deck.push({ color: "wild", value: "wild4" })
    }
    return shuffle(deck)
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[array[i], array[j]] = [array[j], array[i]]
    }
    return array
}

function formatCard(c) {
    return c.color === "wild" ? `🌈 ${c.value}` : `${c.color} ${c.value}`
}

let handler = async (m, { conn, command, text, args }) => {
    let subcmd = (args[0] || "").toLowerCase()

    // Cari game berdasarkan player
    let game = Object.values(games).find(g => g.players.includes(m.sender))
    let roomId = game ? game.origin : m.chat

    switch (command) {
        case "uno": {
            if (subcmd === "create") {
                if (games[roomId]) return m.reply("❌ Room sudah ada!")
                games[roomId] = {
                    host: m.sender,
                    players: [m.sender],
                    hands: {},
                    deck: generateDeck(),
                    discard: [],
                    turn: 0,
                    started: false,
                    origin: roomId
                }
                return m.reply("🎮 Room UNO berhasil dibuat!\nKetik *.uno join* untuk bergabung.")
            }

            if (subcmd === "join") {
                game = games[roomId]
                if (!game) return m.reply("❌ Belum ada room. Buat dulu dengan *.uno create*")
                if (game.started) return m.reply("❌ Game sudah dimulai!")
                if (game.players.includes(m.sender)) return m.reply("❌ Kamu sudah join.")
                game.players.push(m.sender)
                return m.reply("✅ Kamu join ke room UNO!")
            }

            if (subcmd === "start") {
                game = games[roomId]
                if (!game) return m.reply("❌ Tidak ada room UNO.")
                if (m.sender !== game.host) return m.reply("❌ Hanya host yang bisa start!")
                if (game.players.length < 2) return m.reply("❌ Minimal 2 pemain!")
                game.started = true

                // bagi kartu
                for (let p of game.players) {
                    game.hands[p] = []
                    for (let i = 0; i < 7; i++) {
                        game.hands[p].push(game.deck.pop())
                    }
                    let cards = game.hands[p].map((c, i) => `[${i + 1}] ${formatCard(c)}`).join("\n")
                    conn.sendMessage(p, { text: `🃏 Kartu kamu:\n${cards}\n\nGunakan: .uno play <nomor> [warna]` })
                }

                // ambil kartu pertama untuk top card
                game.discard.push(game.deck.pop())

                // umumkan di group siapa player pertama
                return conn.sendMessage(game.origin, {
                    text: `🎉 *Game UNO dimulai!*\n\n🂠 Top card pertama: *${formatCard(game.discard.at(-1))}*\n👉 Giliran pertama: @${game.players[0].split("@")[0]}\n\nGunakan perintah: .uno play <nomor> [warna]`,
                    mentions: game.players
                })
            }

            if (subcmd === "cards") {
                if (!game) return m.reply("❌ Tidak ada room.")
                if (!game.hands[m.sender]) return m.reply("❌ Kamu tidak ikut game.")
                let cards = game.hands[m.sender].map((c, i) => `[${i + 1}] ${formatCard(c)}`).join("\n")
                return conn.sendMessage(m.sender, { text: `🃏 Kartu kamu:\n${cards}` })
            }

            if (subcmd === "status") {
                if (!game) return m.reply("❌ Tidak ada room.")
                let playerList = game.players.map((p, i) => `${i === game.turn ? "👉" : ""} @${p.split("@")[0]} (${game.hands[p].length} kartu)`).join("\n")
                return m.reply(
                    `🎮 Status UNO\nTop card: ${formatCard(game.discard.at(-1))}\n\n${playerList}`,
                    { mentions: game.players }
                )
            }

            if (subcmd === "play") {
                if (!game) return m.reply("❌ Tidak ada room.")
                if (!game.started) return m.reply("❌ Game belum dimulai.")
                if (game.players[game.turn] !== m.sender) return m.reply("❌ Bukan giliranmu!")

                let idx = parseInt(args[1]) - 1
                if (isNaN(idx)) return m.reply("❌ Masukkan nomor kartu.")
                let card = game.hands[m.sender][idx]
                if (!card) return m.reply("❌ Nomor kartu tidak valid.")

                let top = game.discard.at(-1)
                if (card.color !== top.color && card.value !== top.value && card.color !== "wild") {
                    return m.reply("❌ Kartu tidak cocok dengan top card!")
                }

                game.hands[m.sender].splice(idx, 1)
                game.discard.push(card)

                if (card.color === "wild") {
                    let newColor = (args[2] || "").toLowerCase()
                    if (!colors.includes(newColor)) return m.reply("❌ Pilih warna baru: red, yellow, green, blue")
                    card.color = newColor
                }

                if (game.hands[m.sender].length === 0) {
                    delete games[roomId]
                    return m.reply(
                        `🎉 UNO SELESAI!\nPemenang: @${m.sender.split("@")[0]}`,
                        { mentions: [m.sender] }
                    )
                }

                game.turn = (game.turn + 1) % game.players.length
                return conn.sendMessage(game.origin, {
                    text: `✅ @${m.sender.split("@")[0]} memainkan ${formatCard(card)}\n🂠 Top card baru: *${formatCard(card)}*\n👉 Giliran berikutnya: @${game.players[game.turn].split("@")[0]}`,
                    mentions: [m.sender, game.players[game.turn]]
                })
            }

            if (subcmd === "draw") {
                if (!game) return m.reply("❌ Tidak ada room.")
                if (game.players[game.turn] !== m.sender) return m.reply("❌ Bukan giliranmu!")

                let newCard = game.deck.pop()
                game.hands[m.sender].push(newCard)
                let cards = game.hands[m.sender].map((c, i) => `[${i + 1}] ${formatCard(c)}`).join("\n")
                conn.sendMessage(m.sender, { text: `🃏 Kamu ambil 1 kartu: ${formatCard(newCard)}\n\nKartu kamu sekarang:\n${cards}` })

                game.turn = (game.turn + 1) % game.players.length
                return conn.sendMessage(game.origin, {
                    text: `@${m.sender.split("@")[0]} ambil kartu.\n👉 Giliran berikutnya: @${game.players[game.turn].split("@")[0]}`,
                    mentions: [m.sender, game.players[game.turn]]
                })
            }

            if (subcmd === "leave") {
                if (!game) return m.reply("❌ Tidak ada room.")
                if (!game.players.includes(m.sender)) return m.reply("❌ Kamu tidak ikut game.")
                game.players = game.players.filter(p => p !== m.sender)
                delete game.hands[m.sender]
                if (game.players.length < 2) {
                    delete games[roomId]
                    return m.reply("❌ Game berakhir karena pemain kurang.")
                }
                return m.reply(`@${m.sender.split("@")[0]} keluar dari game.`, { mentions: [m.sender] })
            }

            return m.reply(
                `🎮 *UNO MULTIPLAYER GAME*\n\n📝 *Commands:*\n• .uno create\n• .uno join\n• .uno start\n• .uno play <nomor> [warna]\n• .uno draw\n• .uno cards\n• .uno status\n• .uno leave`
            )
        }
    }
}

handler.help = ['uno']
handler.tags = ['game']
handler.command = /^uno$/i

handler.register = true
handler.limit = true
module.exports = handler