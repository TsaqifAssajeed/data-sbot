let handler = async (m, { conn, text, participants, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di grup!");
    if (!isAdmin && !isOwner) return m.reply("Hanya admin yang bisa menggunakan perintah ini!");

    let member = participants.map(v => v.id) || []; // Ambil semua ID anggota grup

    let forwardMessage = {};
    let hasMedia = false;

    if (m.quoted) {
        // Handle reply seperti totag
        if (m.quoted.mtype === 'conversation' || m.quoted.mtype === 'extendedTextMessage') {
            forwardMessage = { text: (m.quoted.text || '') + (text ? `\n\n${text}` : ''), mentions: member };
        } else if (m.quoted.mtype === 'imageMessage' || m.quoted.mtype === 'videoMessage' || m.quoted.mtype === 'documentMessage' || m.quoted.mtype === 'audioMessage' || m.quoted.mtype === 'stickerMessage') {
            let media = await m.quoted.download(); // Unduh media
            hasMedia = true;
            forwardMessage = { 
                [m.quoted.mtype.replace('Message', '')]: media, // Sesuaikan jenis media
                caption: (m.quoted.text || '') + (text ? `\n\n${text}` : ''),
                mentions: member
            };
        } else {
            return m.reply("⚠️ Jenis pesan tidak didukung untuk hidetag! ⚠️");
        }
    } else {
        // Handle seperti hidetag asli
        forwardMessage = { text: text || ' ', mentions: member };
    }

    let sentMessage = await conn.sendMessage(m.chat, forwardMessage, { quoted: m });

    // Kirim reaksi ke pesan bot sendiri
    await conn.sendMessage(m.chat, { 
        react: { text: "📢", key: sentMessage.key } // Reaksi dengan emoji pengeras suara
    });

    if (handler.deleteUserMessage) {
        await conn.sendMessage(m.chat, { delete: m.key }); // Hapus pesan pengguna
    }
}

handler.help = ['hidetag <pesan>/<reply>']
handler.tags = ['group']
handler.command = /^(h|ht|hidetag)$/i

handler.group = true
handler.admin = true // Hanya bisa digunakan oleh admin grup

handler.deleteUserMessage = false; // Ubah ke false jika tidak ingin menghapus pesan pengguna

handler.register = true
handler.limit = true
module.exports = handler;