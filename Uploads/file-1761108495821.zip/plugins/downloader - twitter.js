const fetch = require('node-fetch')

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `Contoh pemakaian:\n${usedPrefix + command} https://x.com/...`

  // Kirim pesan tunggu hanya sekali
  await m.reply('Mohon tunggu...')

  try {
    const res = await fetch(`https://api.siputzx.my.id/api/d/twitter?url=${encodeURIComponent(args[0])}`)
    if (!res.ok) throw `Error ${res.status}`
    const json = await res.json()

    if (!json.status || !json.data) throw `❌ Gagal ambil data Twitter!`

    let { imgUrl, downloadLink, videoTitle, videoDescription } = json.data
    let message = `📌 *Twitter Downloader*\n\n📝 *Judul:* ${videoTitle}\n📖 *Deskripsi:* ${videoDescription}\n`

    if (downloadLink) {
      message += `📥 *Download Link*: ${downloadLink}`
      
      // Deteksi apakah media adalah gambar atau video berdasarkan imgUrl
      const isImage = imgUrl.includes('/media/')
      
      if (isImage) {
        await conn.sendMessage(m.chat, { image: { url: downloadLink }, caption: `Thumbnail: ${videoTitle}` }, { quoted: m })
      } else {
        await conn.sendMessage(m.chat, { video: { url: downloadLink }, caption: `Video: ${videoTitle}` }, { quoted: m })
      }
    } else {
      throw `❌ Tidak ada media yang tersedia untuk diunduh!`
    }

    // Kirim pesan utama hanya sekali
    await conn.sendMessage(m.chat, { text: message }, { quoted: m })

  } catch (err) {
    console.error(err)
    throw `❌ Terjadi kesalahan: ${err.message || err}`
  }
}

handler.help = ['twitter <link>']
handler.tags = ['downloader']
handler.command = /^(twitter|twdl|twvid)$/i
handler.limit = true
handler.once = true // Mencegah handler dipanggil lebih dari sekali untuk event yang sama

handler.register = true
module.exports = handler