let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.tempatngocok)}”`, m)
}
handler.help = ['tempatngocok']
handler.tags = ['cek']
handler.command = /^(tempatngocok)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.tempatngocok = [
'Di Kantor DPR\n*Astaga*😂', 
'Di Rumah Tetangga\n*Kurang Kerjaan Amat Lu*😂', 
'Di Kamar Mandi\n*Standar Aja, Tapi Plis Lah Kalo Bisa Jangan Coli Kalo Gak Pake Foto Messi*😂', 
'Di Kamar Sambil Liat Video Pop Mie\n*Astaga Bro Aduhai, Tapi Boleh Dong Kirim Video Nya*😋',
 'Di Depan Ortu Nya\n*Bro, Lu Dicoret Dari KK Sih Abis Ini*😂', 
 'Di Belakang Rumah\n*Gajelas Lu, Kan Di Kamar Bisa, Ngapain Malah Di belakang Rumah Anjir*😂', 
 'Di Depan Depan Pacar Nya\n*Ayang Jadi Makin Sayang Karna Titid Lu 20CM*💀', 
 'Di Kantor Gubernur\n*Langsung Di Angkat Jadi Gubernur Karna Cara Coli Nya Nggak Biasa*💀', 
 'Di Dalam Kulkas\n*Joni Mu Bilek (Bang Dingin Bang)*😂', 
 'Dirumah Mas Amba\n*Diajarin Tatacara Coli Yang Benar Loh Ya*😋', 
 'Di Dalam Lemari\n*Astaga Kyk Gaada Tempat Lain Aja*💀', 
 'Diatas Motor\n*New FreeStyle Unlocked*😂', 
 'Di Depan Ustad\n*Abis Ini Diceramahin 30 Juz*😂', 
 'Di Atas Genteng Rumah Tetangga\n*Penyakit Coli Gila*💀', 
 'Di Pinggir Jalan\n*Gaada Kerjaan Lain Ya Lu?*😊', 
 'Di Dalam Angkot\n*Liat Tempat Lah Cok*😂', 
 'Di Toko Hp\n*Beli Hp Woi Malah Coli Lu Tolol*🤬', 
 'Di Depan Calon Mertua\n*Calon Mertua Malah Minta Dinikahin*💀', 
 'Di Kamar Ortu\n*Jangan Lupa Bersihin Dan Pake Pengharum Ruangan Ntar Ketahuan Cok*😂', 
 'Di Markas OPM\n*Angkat Tangan Kiri*💀', 
 'Di Neraka\n*Udah Panas Masih Aja Coli*💀', 
 'Di Atas Pohon\n*Itu Siapa, Kelitan Burung Nya Tuh*🐦', 
 'Di Dalam Gereja\n*Bodo*😡', 
 'Di Mall\n*Pengunjung Pada Videoin Elu Njir Malu Dikit Lah*😂', 
 'Di Tengah Jalan\n*Woi Tolol Bikin Macet Aja Lu*😑', 
 'Di Lampu Merah\n*Orang Orang Pada Ngamen Lu Malah Coli*😂', 
 'Di Depan Kepala Sekolah\n*Kepala Sekolah Malah Nyepong*💀', 
 'Di Kantor Lurah\n*Lurah Pun Bingung Sama Kelakuan Elu*', 
 'Di Wc Sekolah\n*Liat Tempat Lah Bjir*😑', 
 'Di Wc Umum\n*Cepetan Crot Wou Gw Udah Kebelet Berak*😠', 
 'Di Dalam Maxim\n*Sopir Nya Malah Ikutan*😨', 
 'Di Rumah Ayang\n*Dicoliin Ayang Juga Loh Ya*😋', 
 'Di Kebun Pisang\n*Ewe Pisang Njir Bukan Coli Dia Mah*',
]