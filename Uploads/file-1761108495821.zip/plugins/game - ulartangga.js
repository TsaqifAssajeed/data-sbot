const jimp = require("jimp");

const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

const { drawBoard } = require("../lib/ulartangga.js"); // ganti path sesuai tempat file kamu

const getRandom = function (array) {
    return array[Math.floor(Math.random() * array.length)];
};

let data = [{
    map: "https://telegra.ph/file/46a0c38104f79cdbfe83f.jpg",
    XavierMarket: { 2:38, 7:14, 8:31, 15:26, 21:42, 28:84, 36:44, 51:67, 78:98, 71:91, 87:94, 16:6, 46:25, 49:11, 62:19, 64:60, 74:53, 89:68, 92:88, 95:75, 99:80 },
    name: "Classic",
    stabil_x: 20,
    stabil_y: 20
},
{
    map: "https://telegra.ph/file/46a0c38104f79cdbfe83f.jpg",
    XavierMarket: { 2:38, 7:14, 8:31, 15:26, 21:42, 28:84, 36:44, 51:67, 78:98, 71:91, 87:94, 16:6, 46:25, 49:11, 62:19, 64:60, 74:53, 89:68, 92:88, 95:75, 99:80 },
    name: "Classic 2",
    stabil_x: 20,
    stabil_y: 20
}];

let thumb = "https://c.termai.cc/i34/LszP.jpg";

let handler = async function (m, { conn, usedPrefix, command, args }) {
    // buat react supaya tidak error
    if (typeof m.react !== "function") {
        m.react = (emoji, key = (m.key || m?.m?.key)) =>
            conn.sendMessage(m.chat, { react: { text: emoji, key } });
    }

    try {
        if (!global.Data) global.Data = {};
        if (!Data.ulartangga) Data.ulartangga = {};

        const chat = m.chat;
        const sender = m.sender;
        const ut = Data.ulartangga;
        const value = args[0];
        const target = args[1];

        if (command === "ulartangga" || command === "ut") {
            if (value === "create") {
                if (chat in ut) return m.reply("Group masih dalam sesi permainan");
                let anu = getRandom(data);
                ut[chat] = {
                    room: chat,
                    owner: sender,
                    status: false,
                    date: Date.now(),
                    turn: 0,
                    player: [],
                    map: anu.map,
                    map_name: anu.name,
                    ular_tangga: anu.XavierMarket,
                    stabil_x: anu.stabil_x,
                    stabil_y: anu.stabil_y
                };
                let data_player = {
                    id: sender,
                    number: ut[chat].player.length + 1,
                    sesi: chat,
                    status: false,
                    langkah: 1,
                    color: "Merah"
                };
                ut[chat].player.push(data_player);
                await m.reply("Room berhasil dibuat, ketik *.ut join* untuk bergabung");

            } else if (value === "join") {
                if (!ut[chat]) return m.reply("Belum ada sesi permainan");
                if (ut[chat].status === true)
                    return m.reply("Sesi permainan sudah dimulai");
                if (ut[chat].player.length >= 4)
                    return m.reply("Maaf jumlah player telah penuh");
                if (ut[chat].player.some(p => p.id === sender))
                    return m.reply("Kamu sudah join dalam room ini");

                const colors = ["Merah", "Kuning", "Hijau", "Biru"];
                let data_player = {
                    id: sender,
                    number: ut[chat].player.length + 1,
                    sesi: chat,
                    status: false,
                    langkah: 1,
                    color: colors[ut[chat].player.length]
                };
                ut[chat].player.push(data_player);
                let player = [];
                let text = `\n*⌂ U L A R - T A N G G A*\n\n`;
                for (let i = 0; i < ut[chat].player.length; i++) {
                    text += `${ut[chat].player[i].color}: @${ut[chat].player[i].id.replace(
                        "@s.whatsapp.net",
                        ""
                    )}\n`;
                    player.push(ut[chat].player[i].id);
                }
                text += "\nJumlah player minimal adalah 2 dan maximal 4";
                await conn.sendMessage(chat, {
                    text: text.trim(),
                    contextInfo: {
                        externalAdReply: {
                            title: "U L A R - T A N G G A",
                            mediaType: 1,
                            renderLargerThumbnail: true,
                            thumbnail: await resize(thumb, 300, 175),
                            sourceUrl: "",
                            mediaUrl: thumb,
                        },
                        mentionedJid: player,
                    },
                });

            } else if (value === "start") {
                if (!ut[chat]) return m.reply("Belum ada sesi permainan");
                if (ut[chat].player.length < 2)
                    return m.reply("Maaf jumlah player belum memenuhi syarat");
                if (!ut[chat].player.some(p => p.id === sender))
                    return m.reply("Kamu belum join dalam room ini");
                if (ut[chat].status === true)
                    return m.reply("Sesi permainan telah dimulai");
                if (ut[chat].owner !== sender)
                    return m.reply(`Hanya host yang dapat memulai permainan`);

                ut[chat].status = true;
                ut[chat].turn = 0;

                let player = [];
                let text = `*⌂ U L A R - T A N G G A*\n\n`;
                for (let i = 0; i < ut[chat].player.length; i++) {
                    text += `${ut[chat].player[i].color}: @${ut[chat].player[i].id.replace(
                        "@s.whatsapp.net",
                        ""
                    )}\n`;
                    player.push(ut[chat].player[i].id);
                }
                text += `\nMenunggu giliran pertama`;

                await conn.sendMessage(chat, {
                    text: "*⌂ U L A R - T A N G G A*\n\nGame dimulai! Ketik *.ut kocok* untuk jalan.",
                    contextInfo: {
                        externalAdReply: {
                            title: "U L A R - T A N G G A",
                            mediaType: 1,
                            renderLargerThumbnail: true,
                            thumbnail: await resize(thumb, 300, 175),
                            sourceUrl: "",
                            mediaUrl: thumb,
                        },
                        mentionedJid: player,
                    },
                });

                await conn.sendMessage(chat, {
                    image: await drawBoard(ut[chat].map, 1, null, null, null, ut[chat].stabil_x, ut[chat].stabil_y),
                    caption: text,
                    mentions: player
                });

            } else if (value === "kocok") {
                await kocokDadu(m, conn, chat, ut);

            } else if (value === "delete") {
                if (!ut[chat]) return m.reply("Tidak ada sesi permainan");
                if (ut[chat].owner !== sender)
                    return m.reply(`Hanya host yang dapat menghapus permainan`);
                delete ut[chat];
                m.reply("Sesi permainan berhasil dihapus");
            } else {
                let text = `\n*⌂ U L A R - T A N G G A*\n\nCommand:\n`;
                text += ` • ${usedPrefix}ut create\n`;
                text += ` • ${usedPrefix}ut join\n`;
                text += ` • ${usedPrefix}ut start\n`;
                text += ` • ${usedPrefix}ut kocok\n`;
                text += ` • ${usedPrefix}ut delete\n`;
                text += ` • ${usedPrefix}ut player\n`;
                await m.reply(text.trim());
            }
        }
    } catch (e) {
        m.reply("Error: " + e.message);
    }
};

async function kocokDadu(m, conn, chat, ut) {
    const sender = m.sender;
    if (!ut[chat]) return;
    const currentPlayer = ut[chat].player[ut[chat].turn];
    if (currentPlayer.id !== sender) return m.reply("Bukan giliran kamu");

    const dadu = Math.floor(Math.random() * 6 + 1);
    await conn.sendMessage(chat, {
        sticker: { url: `https://raw.githubusercontent.com/fgmods/fg-team/main/games/dados/${dadu}.webp` }
    }, { quoted: m });

    const langkahAwal = currentPlayer.langkah;
    currentPlayer.langkah += dadu;

    if (currentPlayer.langkah > 100) {
        currentPlayer.langkah = 100 - (currentPlayer.langkah - 100);
    }

    let XavierMarket = ut[chat].ular_tangga;
    let teks = "";
    if (Object.keys(XavierMarket).includes(currentPlayer.langkah.toString())) {
        teks = currentPlayer.langkah > XavierMarket[currentPlayer.langkah] ? "\n🐍 Kena ular!" : "\n🪜 Naik tangga!";
        currentPlayer.langkah = XavierMarket[currentPlayer.langkah];
    }

    const user1 = ut[chat].player[0] ? ut[chat].player[0].langkah : null;
    const user2 = ut[chat].player[1] ? ut[chat].player[1].langkah : null;
    const user3 = ut[chat].player[2] ? ut[chat].player[2].langkah : null;
    const user4 = ut[chat].player[3] ? ut[chat].player[3].langkah : null;

    const imageBuffer = await drawBoard(ut[chat].map, user1, user2, user3, user4, ut[chat].stabil_x, ut[chat].stabil_y);

    if (currentPlayer.langkah === 100) {
        await conn.sendMessage(chat, {
            image: imageBuffer,
            caption: `🎉 @${sender.split("@")[0]} MENANG! 🎉`,
            mentions: [sender]
        }, { quoted: m });
        delete ut[chat];
        return;
    }

    ut[chat].turn = (ut[chat].turn + 1) % ut[chat].player.length;
    const nextPlayer = ut[chat].player[ut[chat].turn];

    return await conn.sendMessage(chat, {
        image: imageBuffer,
        caption: `${currentPlayer.color} *${langkahAwal}* → *${currentPlayer.langkah}*${teks}\n\nMenunggu @${nextPlayer.id.replace("@s.whatsapp.net", "")} ketik *.ut kocok*`,
        mentions: [nextPlayer.id]
    }, { quoted: m });
}

handler.help = ["ulartangga", "ut"];
handler.tags = ["game"];
handler.command = /^(ulartangga|ut)$/i;

handler.register = true
handler.limit = true
module.exports = handler;