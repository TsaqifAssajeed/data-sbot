const fs = require('fs');

// Set untuk melacak grup yang sudah dikirimi pesan
const sentGroups = new Set();

let handler = async (m, { conn }) => {
    //console.log("Command /lebaran dijalankan oleh:", m.sender);

    if (!conn) {
        //console.error("Koneksi conn tidak tersedia!");
        await conn.sendMessage(m.chat, { text: "Bot tidak terhubung, silakan hubungi admin." });
        return;
    }

    let audioPath = './src/takbiran.MP3'; // File audio lokal
    let img = 'https://i.supa.codes/j8E-HD'; // Gambar khusus untuk hari H
    let lebaranMessage = `🎉 *Allhamdulillah* \n\nتَقَبَّلَ اللَّهُ مِنَّا وَمِنْكُمْ وَ تَقَبَّلْ ياَ كَرِيْمُ.\n\n"Taqabbalallahu minna wa minkum taqabbal ya karim"\n\n"Semoga Allah menerima amal ibadah kita dan kamu semua, dan terimalah ya (Allah) Yang Maha Mulia"\n\n🌙 Mohon maaf lahir dan batin guys. Semoga kita semua diberkahi dengan kebahagiaan dan kesehatan! 🙏✨\n\n> Auto Broadcast`;

    try {
        // Ambil semua grup yang bot masuki
        let chats = await conn.groupFetchAllParticipating();
        let chatIds = Object.keys(chats);
        console.log("Total grup yang bot masuki:", chatIds.length);
        console.log("Daftar grup:", chatIds);

        if (chatIds.length === 0) {
            //console.warn("Bot tidak berada di grup manapun!");
            await conn.sendMessage(m.chat, { text: "Bot tidak ada di grup manapun untuk mengirim pesan." });
            return;
        }

        let successCount = 0;
        let skippedCount = 0;

        for (let chatId of chatIds) {
            try {
                // Cek apakah grup sudah dikirimi pesan sebelumnya
                if (sentGroups.has(chatId)) {
                    console.log(`Grup ${chatId} sudah dikirimi pesan sebelumnya, dilewati.`);
                    skippedCount++;
                    continue;
                }

                let groupMetadata = chats[chatId];
                if (!groupMetadata || !groupMetadata.id) {
                   // console.log(`Chat ${chatId} bukan grup, dilewati.`);
                    continue;
                }

                let participants = groupMetadata.participants.map(v => v.id);
                console.log(`Mengirim pesan ke grup ${chatId} dengan ${participants.length} anggota`);

                let sentMessage = await conn.sendMessage(chatId, {
                    text: lebaranMessage,
                    mentions: participants,
                    contextInfo: {
                        externalAdReply: {
                            title: "✨ Selamat Idul Fitri ✨",
                            thumbnailUrl: img,
                            mediaType: 1,
                            renderLargerThumbnail: true,
                            sourceUrl: "https://Tahun 1446 H/2025 M 🥰"
                        }
                    }
                });

                // Tambahkan reaksi
                await conn.sendMessage(chatId, {
                    react: { text: "🙏🏻", key: sentMessage.key }
                });

                // Kirim pesan suara jika file ada
                if (fs.existsSync(audioPath)) {
                    let audioBuffer = fs.readFileSync(audioPath);
                    await conn.sendMessage(chatId, {
                        audio: audioBuffer,
                        mimetype: 'audio/mpeg',
                        ptt: true
                    });
                } else {
                    console.warn(`File audio tidak ditemukan: ${audioPath}`);
                }

                // Tandai grup sebagai sudah dikirimi pesan
                sentGroups.add(chatId);
                successCount++;
                await new Promise(resolve => setTimeout(resolve, 3000)); // Jeda 1 detik antar grup

            } catch (error) {
                console.error(`Gagal mengirim ke grup ${chatId}:`, error);
            }
        }

        // Konfirmasi ke pengirim
        await conn.sendMessage(m.chat, { 
            text: `Pesan Lebaran berhasil dikirim ke ${successCount} grup baru. ${skippedCount} grup dilewati karena sudah dikirimi sebelumnya.` 
        });

    } catch (error) {
        console.error("Error saat mengambil daftar grup:", error);
        await conn.sendMessage(m.chat, { text: `Terjadi kesalahan: ${error.message}` });
    }
};

// Command setup
handler.help = ['lebaran'];
handler.tags = ['fun'];
handler.command = /^(lebaran)$/i;
handler.owner = true; // Ubah ke true jika hanya owner yang boleh menjalankan
handler.mods = false;
handler.premium = false;
handler.group = true; // Command hanya bisa dijalankan di grup
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;

handler.register = true
handler.limit = true
module.exports = handler;