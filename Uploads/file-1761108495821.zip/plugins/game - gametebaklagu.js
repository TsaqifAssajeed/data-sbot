const fs = require('fs')
const { default: axios } = require('axios')

let timeout = 45000 // ubah waktu menjawab soal disini!!
let poin = 4999 // ubah hadiah disini!!

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.game = conn.game || {}
    let id = 'tebaklagu-' + m.chat
    if (id in conn.game) return conn.reply(m.chat, '🤬 Masih ada soal belum terjawab di chat ini', conn.game[id][0])

    let src = JSON.parse(fs.readFileSync('./lib/tebaklagu.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]

    let caption = `
*TEBAK LAGU*

🎶 Artist : ${json.artis}
⏰ Waktu : *${(timeout / 1000).toFixed(0)} detik*
🎁 Hadiah : ${poin} XP

> Ketik ${usedPrefix}hlagu untuk bantuan
`.trim()

    let msg = await conn.reply(m.chat, caption, m)

    let timer = setTimeout(() => {
        if (conn.game[id]) {
            conn.reply(m.chat, `⏰ Waktu habis!\n\nJawabannya adalah *${json.judul}*`, conn.game[id][0])
            delete conn.game[id]
        }
    }, timeout)

    conn.game[id] = [msg, json, poin, timer]

    let res = await axios.get(json.lagu, { responseType: 'arraybuffer' })

    await conn.sendMessage(m.chat, {
        audio: Buffer.from(res.data),
        mimetype: 'audio/mpeg',
        ptt: true
    }, { quoted: msg })
}

handler.help = ['tebaklagu']
handler.tags = ['game']
handler.command = /^tebaklagu$/i
handler.game = true

handler.register = true
handler.limit = true
module.exports = handler