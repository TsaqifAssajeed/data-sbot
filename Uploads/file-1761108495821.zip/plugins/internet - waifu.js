//let fetch = require('node-fetch');

let handler = async (m, { text, usedPrefix, command }) => {
 if (!text) return m.reply `[ Notice ] ${usedPrefix + command} masukkan prompt nya!`;
    try {
       m.reply('*Process generating image, please wait...*');
       let sdxl = await (await fetch(`https://endpoint.web.id/ai/sdxl-waifu?key=${global.key}&prompt=` + text)).json();
 
      if (sdxl.result && sdxl.result.image) {
      let baby = sdxl.result;
 conn.sendMessage(m.chat, { image: { url: baby.image }, caption: '[ Succes Get Image To Your Prompt ]' }, { quoted: m });
    } else if (sdxl.result.message) {
     m.reply(sdxl.result.message);
 } else {
     m.reply('*No image generated and no message available.*');
 }
 } catch (e) {
 m.reply('Terjadi kesalahan....');
 }
}

handler.help = ['waifu-sdxl']
handler.tags = ['anime']
handler.command = /^(waifu-sdxl)$/i
handler.limit = true

handler.register = true
module.exports = handler