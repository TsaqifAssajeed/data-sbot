const https = require('https');

// Fungsi untuk query ke API Perplexity AI
async function eaiquery(prompt, model = "perplexity-ai") {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            message: prompt,
            model: model,
            history: []
        });

        const options = {
            hostname: 'whatsthebigdata.com',
            port: 443,
            path: '/api/ask-ai/',
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'origin': 'https://whatsthebigdata.com',
                'referer': 'https://whatsthebigdata.com/ai-chat/',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36'
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result.text);
                } catch (error) {
                    reject(error.message);
                }
            });
        });

        req.on('error', error => reject(error.message));
        req.write(postData);
        req.end();
    });
}

let handler = async (m, { text, command, usedPrefix, conn }) => {
   if (!text) {
      throw `Harap masukkan teks.\nContoh:\n${usedPrefix + command} Apa itu Kucing?`;
   }

   // Kirim reaction loading
   await conn.sendMessage(m.chat, {
      react: { text: '⏳', key: m.key }
   });

   try {
      // Query ke API Perplexity AI
      let responseText = await eaiquery(`Jawab pertanyaan berikut dalam bahasa Indonesia: ${text}`);

      // Ganti markdown
      responseText = responseText.replace(/\*\*(.*?)\*\*/g, '*$1*');
      responseText = responseText.replace(/### (.*?)(?=\n)/g, '`$1`');
      responseText = responseText.replace(/##/g, '✦');
      // Hapus referensi sumber seperti [1], [2], dll., tetapi pertahankan jika berisi teks
      responseText = responseText.replace(/\[\d+\]/g, '');
      responseText += '\n\n> ChatGPT Realtiime';

      // Kirim dengan contextInfo
      await conn.sendMessage(
         m.chat,
         {
            text: responseText,
            contextInfo: {
               externalAdReply: {
                  title: '🤖 ChatGPT AI Response',
                  body: '',
                  thumbnailUrl:
                     'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1758082632617.jpeg',
                  sourceUrl: '',
                  mediaType: 1,
                  renderLargerThumbnail: false
               }
            }
         },
         {
            quoted: {
               key: {
                  fromMe: false,
                  participant: '0@s.whatsapp.net',
                  remoteJid: 'status@broadcast'
               },
               message: { conversation: 'AI Response' }
            }
         }
      );

      // Kirim reaksi sukses
      await conn.sendMessage(m.chat, {
         react: { text: '✅', key: m.key }
      });
   } catch (e) {
      console.error('Error:', e);
      await conn.sendMessage(m.chat, {
         react: { text: '❌', key: m.key }
      });
      m.reply(`🚫 Error saat memproses permintaan: ${e.message}`);
   }
};

handler.command = ['openai', 'gpt', 'ai'];
handler.tags = ['ai'];
handler.help = ['ai', 'gpt'].map(a => a + ' *[text]*');

handler.register = true
handler.limit = true
module.exports = handler;