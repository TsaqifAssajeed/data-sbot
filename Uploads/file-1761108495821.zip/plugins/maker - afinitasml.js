const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    const quoted = m.quoted || m;
    const mime = (quoted.msg || quoted).mimetype || '';
    
    if (!mime || !/image/.test(mime)) {
      return m.reply(`❌ Kirim atau reply gambar dengan caption *${usedPrefix + command}*`);
    }

    await m.reply('Bentar Sedang Memproses...');

    
    const mediaPath = await conn.downloadAndSaveMediaMessage(quoted);

    
    const form = new FormData();
    form.append('file', fs.createReadStream(mediaPath));

    const cloudRes = await axios.post('https://cloudgood.xyz/upload.php', form, {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    });

    fs.unlinkSync(mediaPath);

    const imageUrl = cloudRes.data?.url;
    if (!imageUrl) return m.reply('❌ Gagal upload gambar ke CloudGood.');

    
    const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    const mediaBuffer = Buffer.from(response.data);

    const userImage = await loadImage(mediaBuffer);
    const bg = await loadImage('https://files.catbox.moe/qw4nef.png');

    const canvas = createCanvas(bg.width, bg.height);
    const ctx = canvas.getContext('2d');

    const frame = { x: 450, y: 847, width: 205, height: 205 };
    const avatarWidth = 300;
    const avatarHeight = 300;
    const avatarX = frame.x + (frame.width - avatarWidth) / 2;
    const avatarY = frame.y + (frame.height - avatarHeight) / 2;

    const minSide = Math.min(userImage.width, userImage.height);
    const cropX = (userImage.width - minSide) / 2;
    const cropY = (userImage.height - minSide) / 2;

    ctx.drawImage(userImage, cropX, cropY, minSide, minSide, avatarX, avatarY, avatarWidth, avatarHeight);
    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

    const buffer = canvas.toBuffer('image/png');

    await conn.sendMessage(m.chat, {
      image: buffer,
      caption: 'Affinitas ML By ARMAN BOTzz'
    }, { quoted: m });

  } catch (err) {
    console.error('[PPML ERROR]', err);
    m.reply(`❌ Terjadi kesalahan:\n${err.message || 'Unknown error'}`);
  }
};

handler.help = ['afinitasml'];
handler.tags = ['maker'];
handler.command = /^afinitasml$/i;

handler.register = true
handler.limit = true
module.exports = handler;