let handler = async (m, { text }) => {
    if (!text) return m.reply("⚠️ Harap masukkan NIM atau nama mahasiswa setelah perintah.");

    m.reply("_🔍 Sedang mencari data..._");

    try {
        let { data } = await require('axios').get(`https://api.ryzendesu.vip/api/search/mahasiswa?query=${encodeURIComponent(text)}`, {
            headers: { 'accept': 'application/json' }
        });

        if (!data || data.length === 0) return m.reply("❌ Data mahasiswa tidak ditemukan.");

        let hasil = data.map(mahasiswa => 
            `📛 *Nama*: ${mahasiswa.nama}\n` +
            `🆔 *NIM*: ${mahasiswa.nim}\n` +
            `🏛️ *Universitas*: ${mahasiswa.nama_pt}\n` +
            `📖 *Program Studi*: ${mahasiswa.nama_prodi}`
        ).join("\n\n");

        m.reply("*🔎 Hasil Pencarian Mahasiswa:*\n\n" + hasil);

    } catch (err) {
        console.error(err);
        m.reply("🚨 Terjadi kesalahan saat mengambil data. Coba lagi nanti.");
    }
};

handler.help = ["mahasiswa ( NIM / Nama Lnegkap )"];
handler.tags = ["internet"];
handler.command = ["mahasiswa"];

handler.register = true
handler.limit = true
module.exports = handler;
