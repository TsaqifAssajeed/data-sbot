let handler = async (m, { conn, args, isAdmin, isBotAdmin }) => {
    if (!m.isGroup) return conn.reply(m.chat, 'Fitur ini hanya bisa digunakan di grup!', m);
    if (!isAdmin) return conn.reply(m.chat, 'Kamu harus menjadi admin untuk menggunakan perintah ini!', m);
    if (!isBotAdmin) return conn.reply(m.chat, 'Bot harus menjadi admin untuk menggunakan fitur ini!', m);

    let chat = global.db.data.chats[m.chat];
    if (args[0] === 'on') {
        chat.antiDelete = true;
        await conn.reply(m.chat, '✅ Fitur Anti-Delete telah diaktifkan di grup ini!', m);
    } else if (args[0] === 'off') {
        chat.antiDelete = false;
        await conn.reply(m.chat, '❌ Fitur Anti-Delete telah dinonaktifkan di grup ini!', m);
    } else {
        await conn.reply(m.chat, 'Gunakan perintah:\n.antidelete on - Untuk mengaktifkan\n.antidelete off - Untuk menonaktifkan', m);
    }
};

handler.help = ['antidelete on/off'];
handler.tags = ['group'];
handler.command = /^antidelete$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

handler.register = true
handler.limit = true
module.exports = handler;