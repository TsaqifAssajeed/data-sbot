let handler = async (m, { conn, command }) => {
  let user = m.sender
  let now = new Date() * 1
  let trialDuration = 86400000 // 24 jam dalam milidetik

  if (command === 'freetrial') {
    if (global.db.data.users[user].premiumUsed) {
      return conn.reply(m.chat, `Anda sudah menggunakan pernah mengklaim free trial premium sebelumnya. Akses free Trial hanya sekali saja. Silahkan ketik .sewa jika ingin beli premium`, m)
    }

    global.db.data.users[user].premium = true
    global.db.data.users[user].premiumDate = now + trialDuration
    global.db.data.users[user].premiumUsed = true // Menandai bahwa user sudah klaim trial
    global.db.data.users[user].limit = (global.db.data.users[user].limit || 0) + 150 // Tambah 150 limit
    global.db.data.users[user].money = (global.db.data.users[user].money || 0) + 5000 // Tambah 5000 money
    
    const expiredDate = new Date(global.db.data.users[user].premiumDate).toLocaleString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'Asia/Makassar' // WITA
    })

    await conn.sendMessage(
      m.chat,
      {
        text: `🎉 *FREE TRIAL PREMIUM*\n\n🔑 Premium: Ya\n⏱ Sisa Waktu: ${msToDate(trialDuration)}\n🗓 Expired pada: ${expiredDate}\n\n🎁 *Bonus Berlaku selama Premium*\n- Bisa akses semua fitur Premium\n- Limit bertambah +150\n- Money bertambah +5000`,
        contextInfo: {
          externalAdReply: {
            title: '🎉 Free Trial Premium Aktif',
            body: namebot,
            thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/aaaaaa.png',
            sourceUrl: '',
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      {
        quoted: {
          key: {
            fromMe: false,
            participant: '0@s.whatsapp.net',
            remoteJid: 'status@broadcast'
          },
          message: { conversation: 'Free Trial Premium' }
        },
        mentions: [user]
      }
    )

    // Pengecekan kedaluwarsa premium setelah 24 jam
    setTimeout(async () => {
      let currentTime = new Date() * 1
      if (currentTime > global.db.data.users[user].premiumDate && global.db.data.users[user].premium) {
        global.db.data.users[user].premium = false
        if (m.isGroup) {
          await conn.sendMessage(
            m.chat,
            {
              text: `📢 *Masa Free Trial Premium Habis*\n\nPengguna @${user.split('@')[0]} telah kehabisan masa free trial premium. Silakan  ketik .sewa untuk membeli premium!`,
              contextInfo: {
                externalAdReply: {
                  title: '📢 WAKTUNYA HABIS..!!',
                  body: namebot,
                  thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/adobestock_612624700.webp',
                  sourceUrl: '',
                  mediaType: 1,
                  renderLargerThumbnail: true
                },
                mentionedJid: [user]
              },
             
            },
            { quoted: m }
          )
        }
      }
    }, trialDuration)
  } else if (command === 'cektrial') {
    let userData = global.db.data.users[user]
    if (!userData.premiumUsed) {
      return conn.reply(m.chat, `Anda belum menggunakan free trial premium. Ketik .freetrial untuk mengaktifkan!`, m)
    }

    if (!userData.premium) {
      return conn.reply(m.chat, `Masa free trial premium Anda telah habis. Silakan hubungi owner dengan perintah .owner untuk membeli premium, atau ketik .sewa untuk cek paket premium!`, m)
    }

    const remainingTime = userData.premiumDate - now
    const expiredDate = new Date(userData.premiumDate).toLocaleString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'Asia/Makassar' // WITA
    })

    await conn.sendMessage(
      m.chat,
      {
        text: `📋 *Status Free Trial Premium*\n\n🔑 Premium: Ya\n⏱ Sisa Waktu: ${msToDate(remainingTime)}\n🗓 Expired pada: ${expiredDate}\n\n🎁 *Bonus Berlaku selama Premium*\n- Bisa akses semua fitur Premium\n- Limit bertambah +150\n- Money bertambah +5000`,
        contextInfo: {
          externalAdReply: {
            title: '📋 Status Free Trial Premium',
            body: namebot,
            thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/aaaaaa.png',
            sourceUrl: '',
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      },
      {
        quoted: {
          key: {
            fromMe: false,
            participant: '0@s.whatsapp.net',
            remoteJid: 'status@broadcast'
          },
          message: { conversation: 'Status Free Trial Premium' }
        },
        mentions: [user]
      }
    )
  }
}

handler.help = ['freetrial', 'cektrial']
handler.tags = ['premium']
handler.command = /^(freetrial|cektrial)$/i

handler.register = true
module.exports = handler

function msToDate(ms) {
  let temp = ms
  let hours = Math.floor(temp / (1000 * 60 * 60))
  let minutes = Math.floor((temp % (1000 * 60 * 60)) / (1000 * 60))
  let seconds = Math.floor((temp % (1000 * 60)) / 1000)
  return `${hours} jam ${minutes} menit ${seconds} detik`
}