let handler = async (m, { conn, text, command, prefix }) => {
    // Cek apakah input sesuai format
    if (!text || !text.includes('|')) {
        return m.reply(`Contoh:\n${prefix + command} Siapa presiden RI?|Jokowi|Prabowo|Anies`)
    }

    // Pecah teks berdasarkan '|'
    let [question, ...options] = text.split('|').map(v => v.trim())

    // Validasi jumlah opsi
    if (options.length < 2) {
        return m.reply('Minimal 2 opsi diperlukan untuk membuat polling.')
    }

    // Kirim polling ke grup/chat
    let sentMessage = await conn.sendMessage(m.chat, {
        poll: {
            name: question,
            values: options,
            selectableCount: 1 // 🔒 hanya bisa memilih satu jawaban
        }
    }, { quoted: m })

    // Jika handler diatur untuk menghapus pesan user, hapus
    if (handler.deleteUserMessage && m.key) {
        await conn.sendMessage(m.chat, { delete: m.key })
    }
}

// Informasi bantuan dan metadata command
handler.help = ['createpolling <pertanyaan>|<opsi1>|<opsi2>|...']
handler.tags = ['tools']
handler.command = /^createpolling|poll|polling|cpoll$/i

// Aturan akses
handler.group = true        // tidak wajib di grup
handler.admin = true        // tidak perlu admin

// Opsional: hapus pesan pengguna setelah polling dikirim
handler.deleteUserMessage = false

handler.register = true
handler.limit = true
module.exports = handler
