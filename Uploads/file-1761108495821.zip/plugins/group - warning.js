const { normalizeJid } = require('../function/jid')

let war = global.maxwarn
let handler = async (m, { conn, text, args, groupMetadata, usedPrefix, command }) => {      
    let who
    let reason
    let userNumber

    // Cek apakah input adalah tag, quote, atau nomor telepon
    if (m.isGroup) {
        who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
        if (!who && args[0]) {
            // Cek apakah args[0] adalah nomor telepon (dengan atau tanpa +, spasi, atau tanda hubung)
            let input = args[0].replace(/[^0-9+]/g, '') // Hilangkan spasi, tanda hubung, dll, kecuali +
            if (/^\+?\d{10,15}$/.test(input)) {
                userNumber = input.replace(/^\+/, '') // Hilangkan + jika ada
                who = `${userNumber}@s.whatsapp.net`
            }
        }
    } else {
        who = m.chat
    }

    if (!who) throw `Tag, sebut seseorang, atau masukkan nomor telepon\n\n📌 [ Contoh ] : ${usedPrefix + command} @user <alasan> atau ${usedPrefix + command} +6287853303857|alasan atau ${usedPrefix + command} +62 878-5330-3857|alasan`

    who = normalizeJid(who)
    if (!(who in global.db.data.users)) throw `Pengguna tidak ditemukan di database saya`

    // Ambil alasan murni setelah tag atau nomor telepon
    if (args[0] && args[0].includes('|')) {
        // Jika menggunakan format nomor|alasan
        reason = args.join(' ').split('|')[1]?.trim()
    } else {
        // Jika menggunakan format tag atau nomor alasan
        reason = args.slice(1).join(' ').trim()
    }
    if (!reason) throw `Alasan peringatan wajib diisi\n\n📌 [ Contoh ] : ${usedPrefix + command} @user <alasan> atau ${usedPrefix + command} +6287853303857|alasan atau ${usedPrefix + command} +62 878-5330-3857|alasan`

    let name = conn.getName(m.sender)
    userNumber = userNumber || who.split('@')[0].replace(/^\+/, '').replace(/[^0-9]/g, '')
    let user = global.db.data.users[who]
    let warn = user.warn

    if (warn < war) {
        user.warn += 1
        if (!user.warnReasons) user.warnReasons = []
        user.warnReasons.push(reason)
        m.reply(`
⚠️ *Pengguna yang Diperingatkan* ⚠️

✧ *Admin:* ${name}
✧ *Pengguna:* @${userNumber}
✧ *Peringatan:* ${user.warn}/${war}
✧ *Alasan:* ${reason}`, null, { mentions: [who] })
    } else if (warn >= war) {
        user.warn = 0 // Reset warn ke 0, tetapi pertahankan warnReasons
        m.reply(`⛔ Pengguna melebihi peringatan *${war}* sehingga akan dihapus dari grup`)
        await time(3000)
        await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
        m.reply(`♻️ @${userNumber} telah dikeluarkan dari grup *${groupMetadata.subject}* karena telah diperingatkan *${war}* kali. Riwayat peringatan tetap tersimpan.`, null, { mentions: [who] })
    }
}

handler.help = ['warn @user <alasan> | <nomor_telepon> <alasan>']
handler.tags = ['group']
handler.command = ['warn']
handler.group = false
handler.admin = false
handler.botAdmin = false
handler.register = true
handler.limit = false
module.exports = handler

const time = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}