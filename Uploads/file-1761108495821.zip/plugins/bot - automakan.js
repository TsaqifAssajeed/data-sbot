const fs = require('fs');
const axios = require('axios');

module.exports = {
    before: async function (m) {
        this.automakan = this.automakan || {};
        let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? this.user.jid : m.sender;
        let id = m.chat;

        const date = new Date((new Date).toLocaleString("en-US", { timeZone: "Asia/Makassar" }));
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
        let isActive = Object.values(this.automakan).includes(true);

        const jadwalmakan = {
            "Makan Pagi": "07:15",
            "Makan Siang": "12:15",
            "Makan Malam": "19:35",
        };

        // Daftar URL thumbnail makanan
        const foodThumbnails = [
            "https://awsimages.detik.net.id/community/media/visual/2022/11/20/rijsttafel-indonesia-2.jpeg?w=600&q=90",
            "https://blog.bankmega.com/wp-content/uploads/2022/11/Makanan-Khas-Tradisional.jpg",
            "https://blog.bankmega.com/wp-content/uploads/2022/10/Makanan-tradisional-indonesia.jpg",
            "https://www.astronauts.id/blog/wp-content/uploads/2022/08/Makanan-Khas-Daerah-tiap-Provinsi-di-Indonesia-Serta-Daerah-Asalnya.jpg",
            "https://asset.kompas.com/crops/MWIOSkw05jzdo1H-Y5GRGs9b_Hg=/0x0:0x0/750x500/data/photo/buku/632354a8e1cf9.jpg"
        ];

        if (id in this.automakan && isActive) {
            return false;
        }

        for (const [makan, waktu] of Object.entries(jadwalmakan)) {
            if (timeNow === waktu && !(id in this.automakan)) {
                // Pilih thumbnail secara acak
                let imgUrl = foodThumbnails[Math.floor(Math.random() * foodThumbnails.length)];
                let caption = `Hai kak @${who.split`@`[0]},\n\nWaktu *${makan}* telah tiba!`;
                let vnUrl = "https://github.com/ChandraGO/Data-Jagoan-Project/raw/525643df448dada7f6edb076eb8b8665fa9db552/src/makan.MP3";

                caption += `\nSaatnya makan! Pastikan kamu mengisi energi dengan makanan yang sehat.\n\n*${waktu}*`;

                this.automakan[id] = [
                    this.reply(m.chat, caption, null, {
                        contextInfo: {
                            mentionedJid: [who],
                            externalAdReply: {
                                title: `⏰ ${makan} Time!`,
                                thumbnailUrl: imgUrl,
                                mediaType: 1,
                                renderLargerThumbnail: true,
                                sourceUrl: "https://Makan Bang"
                            }
                        }
                    })
                ];

                try {
                    const response = await axios.get(vnUrl, { responseType: 'arraybuffer' });
                    const audioBuffer = Buffer.from(response.data);
                    this.automakan[id].push(
                        this.sendMessage(m.chat, {
                            audio: audioBuffer,
                            mimetype: 'audio/mpeg',
                            ptt: true
                        }, { quoted: m })
                    );
                } catch (error) {
                    console.warn(`Gagal mengunduh audio dari: ${vnUrl}`, error);
                }

                this.automakan[id].push(
                    setTimeout(() => {
                        delete this.automakan[id];
                    }, 57000)
                );
            }
        }
    },
    disabled: false
};