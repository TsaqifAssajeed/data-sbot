let handler = async (m, { conn }) => {
    conn.susun = conn.susun ? conn.susun : {}
    let id = m.chat

    if (!(id in conn.susun)) {
        m.reply('Tidak ada soal yang sedang berjalan di chat ini!')
        return
    }

    let json = conn.susun[id] // Gunakan langsung tanpa indeks [1]
    let ans = json.jawaban

    if (!ans) {
        m.reply('Error: Soal tidak ditemukan atau sudah kadaluarsa.')
        return
    }

    // Buat clue dengan mengganti huruf vokal menjadi '_'
    let clue = ans.replace(/[AIUEOaiueo]/g, '_')
    m.reply('Petunjuk: ```' + clue + '```')
}

handler.command = /^susn/i
handler.limit = true

handler.register = true
module.exports = handler
