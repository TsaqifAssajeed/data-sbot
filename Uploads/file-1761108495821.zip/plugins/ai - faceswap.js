const axios = require("axios")
const FormData = require("form-data")

let sesiSwap = {}

let handler = async (m, { conn }) => {
  const sender = m.sender
  const quoted = m.quoted
  const mimeCaption = m.mimetype || ""
  const mimeReply = quoted?.mimetype || ""
  const isImageCaption = mimeCaption.startsWith("image/")
  const isImageReply = mimeReply.startsWith("image/")

  const getImageBuffer = async () => {
    if (isImageReply) return await quoted.download()
    if (isImageCaption) return await m.download()
    return null
  }

  if (!sesiSwap[sender]) {
    const img1 = await getImageBuffer()
    if (!img1) return m.reply("🖼️ Kirim gambar *Original* dengan caption *.faceswap* atau reply gambar lalu ketik *.faceswap*")

    sesiSwap[sender] = {
      step: 1,
      img1,
      timeout: setTimeout(() => {
        delete sesiSwap[sender]
        m.reply("⌛ Sesi face swap kadaluarsa. Silakan mulai dari awal dengan *.faceswap*")
      }, 60000)
    }

    return m.reply("✅ Gambar pertama diterima boss.\nSekarang kirim gambar kedua *Gambar Swapnya* (dengan caption *.faceswap* atau reply juga bisa).")
  }

  if (sesiSwap[sender].step === 1) {
    const img2 = await getImageBuffer()
    if (!img2) return m.reply("🖼️ Kirim gambar kedua (dengan caption *.faceswap* atau reply gambar dan ketik *.faceswap*)")

    clearTimeout(sesiSwap[sender].timeout)

    m.reply("⏳ Sedang memproses face swap, tunggu sebentar...")

    try {
      const form = new FormData()
      form.append("image1", sesiSwap[sender].img1, { filename: "img1.jpg" })
      form.append("image2", img2, { filename: "img2.jpg" })

      const res = await axios.post(global.apisiput + "api/imgedit/faceswap", form, {
        headers: form.getHeaders()
      })

      if (res.data?.status && res.data?.data) {
        await conn.sendMessage(m.chat, {
          image: { url: res.data.data },
          caption: "✅ Face swap selesai!"
        }, { quoted: m })
      } else {
        throw "API tidak merespons dengan benar."
      }
    } catch (err) {
      console.error(err)
      m.reply("❌ Terjadi error saat swap wajah:\n" + (err.message || err))
    } finally {
      delete sesiSwap[sender]
    }
  }
}

handler.help = ['faceswap']
handler.tags = ['ai','premium']
handler.command = /^faceswap$/i
handler.limit = 10
handler.premium = true

handler.register = true
module.exports = handler
