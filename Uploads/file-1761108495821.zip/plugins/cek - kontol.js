let handler = async (m, { conn, text }) => {
  let who, name;

  // Case 1: Mentioned user (@tag)
  if (m.mentionedJid && m.mentionedJid[0]) {
    who = m.mentionedJid[0];
    name = conn.getName(who);
  } 
  // Case 2: Text input (name provided)
  else if (text && !text.startsWith('@')) {
    who = m.sender; // Still use sender's JID for context
    name = text.trim();
  } 
  // Case 3: No parameter (use sender's mention)
  else {
    who = m.fromMe ? conn.user.jid : m.sender;
    name = `@${who.split('@')[0]}`; // Use mention format for sender
  }

  if (!name) {
    return conn.reply(m.chat, "🚩 Tidak dapat menemukan nama pengguna!", m);
  }

  let ukuran = Math.floor(Math.random() * 19) + 1; // Ukuran dalam cm
  let emot = ukuran < 3 ? "😂" : ukuran < 7 ? "😲" : ukuran < 10 ? "👀" : ukuran < 15 ? "🤤" : "🥵";

  // Format the name for output: use mention format for tagged users or no parameter, plain text for provided names
  let displayName = (m.mentionedJid && m.mentionedJid[0]) || (!text || text.startsWith('@')) ? `@${who.split('@')[0]}` : name;

  conn.reply(m.chat, `
*––––––『 CEK - KON 』––––––*
• Nama : ${displayName}
• Kontol : ${pickRandom(['item bgt njing', 'benda itu hijau', 'Bintik Bintik Njir', 'Putih Mulus Banget', 'Fantablack Njir', 'Pink Banget', 'Hitam Mengkilap', 'Warna Golden', 'Abu Abu', 'Gede Putih Tpi Gaada Biji Nya'])}
• Kondisi : ${pickRandom(['perjaka', 'ga perjaka', 'udh pernah di sepong', 'udah pernah di masukin ke memek', 'pernah di masukin ke bool', 'belum sunat njir', 'jumbo'])}
• Jembut : ${pickRandom(['lebat', 'ada sedikit', 'gada jembut', 'tipis', 'muluss'])}
• Ukuran : ${ukuran} cm ${emot}
`, m, { contextInfo: { mentionedJid: (m.mentionedJid && m.mentionedJid[0]) || (!text || text.startsWith('@')) ? [who] : [] } });
}

handler.help = ['cekkontol [@tag|nama]']
handler.tags = ['cek']
handler.command = /^cekkontol$/i
handler.premium = false
handler.register = true
handler.limit = true
module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}