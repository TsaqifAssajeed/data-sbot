const axios = require('axios');
const cheerio = require('cheerio');

const characters = [
  "Aamon", "Akai", "Aldous", "Alice", "Alpha", "Alucard", "Angela", "Argus", "Arlott", "Atlas",
  "Aulus", "Aurora", "Badang", "Balmond", "Bane", "Barats", "Baxia", "Beatrix", "Belerick",
  "Benedetta", "Brody", "Bruno", "Carmilla", "Cecilion", "Chou", "Cici", "Claude", "Clint",
  "Cyclops", "Diggie", "Dyrroth", "Edith", "Esmeralda", "Estes", "Eudora", "Fanny", "Faramis",
  "Floryn", "Franco", "Fredrinn", "Freya", "Gatotkaca", "Gloo", "Gord", "Granger", "Grock",
  "Guinevere", "Gusion", "Hanabi", "Hanzo", "Harith", "Harley", "Hayabusa", "Helcurt", "Hilda",
  "Hylos", "Irithel", "Ixia", "Jawhead", "Johnson", "Joy", "Julian", "Kadita", "Kagura", "Kaja",
  "Karina", "Karrie", "Khaleed", "Khufra", "Kimmy", "Lancelot", "Layla", "Leomord", "Lesley",
  "Ling", "Lolita", "Lunox", "Luo Yi", "Lylia", "Martis", "Masha", "Mathilda", "Melissa",
  "Minotaur", "Minsitthar", "Miya", "Moskov", "Nana", "Natalia", "Natan", "Novaria", "Odette",
  "Paquito", "Pharsa", "Phoveus", "Popol and Kupa", "Rafaela", "Roger", "Ruby", "Saber",
  "Selena", "Silvanna", "Sun", "Terizla", "Thamuz", "Tigreal", "Uranus", "Vale", "Valentina",
  "Valir", "Vexana", "Wanwan", "Xavier", "Yin", "Yu Zhong", "Yve", "Zhask", "Zilong"
];

let hadiah = {
  money: 5000,
  limit: 2,
  exp: 200
};

async function scrapeHeroAudio(attempt = 1, maxAttempts = 3) {
  try {
    const query = characters[Math.floor(Math.random() * characters.length)];
    const url = `https://mobile-legends.fandom.com/wiki/${query}/Audio/id`;
    const response = await axios.get(url, {
      timeout: 30000,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive"
      },
    });
    const $ = cheerio.load(response.data);
    const audioSrc = $("audio").map((i, el) => $(el).attr("src")).get();
    const randomAudio = audioSrc[Math.floor(Math.random() * audioSrc.length)];

    if (!randomAudio) {
      throw new Error(`No audio found for character: ${query}`);
    }

    return { name: query, audio: randomAudio };
  } catch (error) {
    console.error(`Scrape Error (Attempt ${attempt}):`, error.message);
    if (attempt < maxAttempts) {
      return scrapeHeroAudio(attempt + 1, maxAttempts); // Retry dengan hero lain
    }
    throw new Error("Failed to fetch hero audio data after multiple attempts");
  }
}

async function handler(m, { conn }) {
  conn.game = conn.game || {};
  let id = 'tebakheroml_' + m.chat;

  if (id in conn.game) {
    return conn.reply(m.chat, '❗ Masih ada game *Tebak Hero ML* yang belum selesai di chat ini.', conn.game[id].msg);
  }

  try {
    const { name, audio } = await scrapeHeroAudio();
    const resAudio = await axios.get(audio, { 
      responseType: 'arraybuffer',
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });
    const audioBuffer = Buffer.from(resAudio.data);

    let teks = `🎮 *Tebak Hero ML!*

🧠 Tebak nama hero dari suara berikut ini!
⏱️ Waktu menjawab: *60 detik*
😖 Salah menjawab akan diberi emot 💩

🏳️ Ketik *nyerah* jika ingin menyerah.
🎁 Hadiah jika menang:
+💰 ${hadiah.money} Money
+🔋 ${hadiah.limit} Limit
+✨ ${hadiah.exp} XP`;

    // Kirim audio lebih dulu
    let msg = await conn.sendMessage(m.chat, {
      audio: audioBuffer,
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: m });

    // Kirim teks penjelasan setelah audio
    await conn.sendMessage(m.chat, {
      text: teks
    }, { quoted: m });

    conn.game[id] = {
      id,
      name: name.toLowerCase(),
      msg,
      starter: m.sender,
      timeout: setTimeout(() => {
        if (conn.game[id]) {
          conn.reply(m.chat, `⏱️ Waktu habis!\nJawaban: *${name}*`, conn.game[id].msg);
          delete conn.game[id];
        }
      }, 60000)
    };
  } catch (e) {
    console.error(e);
    m.reply('❌ Terjadi kesalahan saat memulai game. Coba lagi nanti.');
  }
}

handler.before = async function (m, { conn }) {
  conn.game = conn.game || {};
  let id = 'tebakheroml_' + m.chat;
  if (!(id in conn.game)) return false;

  let room = conn.game[id];
  let jawaban = room.name;
  let userJawab = m.text?.toLowerCase();
  if (!userJawab) return false;

  if (/^(me)?nyerah$/i.test(userJawab)) {
    if (m.sender !== room.starter) return m.reply('❌ Hanya pengguna yang memulai game yang dapat menyerah.');
    clearTimeout(room.timeout);
    conn.reply(m.chat, `😔 Menyerah ya?\nJawaban: *${jawaban}*`, room.msg);
    delete conn.game[id];
    return true;
  }

  if (userJawab === jawaban) {
    clearTimeout(room.timeout);

    let user = global.db.data.users[m.sender];
    user.money += hadiah.money;
    user.limit += hadiah.limit;
    user.exp += hadiah.exp;

    conn.sendMessage(m.chat, { react: { text: "🎉", key: m.key }});
    conn.reply(m.chat, `🎉 *Benar!* Jawabannya: *${jawaban}*\n\n🎁 Kamu mendapat:\n+💰 ${hadiah.money} Money\n+🔋 ${hadiah.limit} Limit\n+✨ ${hadiah.exp} XP`, room.msg);
    delete conn.game[id];
  } else {
    conn.sendMessage(m.chat, { react: { text: "💩", key: m.key }});
  }

  return true;
};

handler.help = ['tebakheroml'];
handler.tags = ['game'];
handler.command = /^tebakheroml$/i;
handler.group = true;
handler.register = true;
handler.limit = true;

module.exports = handler;