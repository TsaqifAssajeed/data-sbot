let handler = async (m, { conn, args }) => {
    if (!args.length || args.join(" ").trim() === "") {
        throw `❌ *Masukkan teks deskripsi!* 😕\n\nContoh: .setdeskgroup
Rules Grup WhatsApp :  
*1. Dilarang Toxic*
*2. Dilarang Share Konten 18+*    
*3. Dilarang Spam Bot* 
*4. Dilarang Rasis & SARA* 
*5. Dilarang Promo/Jualan Tanpa Izin*   
*6. Jangan Tag Admin Sembarangan* 
*7. Jaga Topik Grup*  

*⚠️ Pelanggaran = Warning / Kick / Ban ⚠️*  

> Silahkan improve sendiri aksih emot2 manja dll
`;
    }

    await conn.groupUpdateDescription(m.chat, args.join(" "));
    m.reply('✅ *Sukses mengganti deskripsi grup!* 🎊');
}

handler.help = ['setdesk <text>']
handler.tags = ['group']
handler.command = /^set(desk|deskripsi|deskripsigc|deskripsigroup|deskripsigrup|deskgc)?$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false
handler.register = false
handler.admin = true
handler.botAdmin = true

handler.register = true
handler.limit = true
module.exports = handler