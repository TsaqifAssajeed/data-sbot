const storeMessages = {}; // In-memory store untuk menyimpan metadata pesan

// Save message to store
async function saveMessageToStore(message) {
  const messageData = {
    id: message.key.id,
    chat: message.key.remoteJid,
    sender: message.key.participant || message.key.remoteJid,
    fromMe: message.key.fromMe,
    timestamp: message.messageTimestamp,
    isPinned: false // Flag untuk status pin
  };
  storeMessages[message.key.id] = messageData;
}

// Save pinned message to store
async function savePinnedMessage(messageId, time) {
  if (storeMessages[messageId]) {
    storeMessages[messageId].isPinned = true;
    storeMessages[messageId].pinDuration = time; // Simpan durasi pin
  }
}

// Read message from store
async function readMessageFromStore(messageId) {
  return storeMessages[messageId] || null;
}

const handler = async (m, { conn, command, args }, { store } = {}) => {
  // Simpan pesan ke store jika di grup
  if (m.isGroup && m.key && m.key.id) {
    await saveMessageToStore(m);
  }

  // Pastikan user reply ke pesan
  if (!m.quoted) return m.reply('📌 Balas pesan yang ingin di-pin!');

  // Periksa apakah bot admin
  const groupMetadata = await conn.groupMetadata(m.chat);
  const isAdmin = groupMetadata.participants.find(p => p.id === conn.user.jid)?.admin;
  if (!isAdmin) return m.reply('❌ Bot harus menjadi admin untuk mem-pin pesan!');

  // Ambil key dari pesan yang di-reply
  let key = m.quoted.key || m.quoted.fakeObj?.key;
  //console.log('Quoted Message:', JSON.stringify(m.quoted, null, 2)); // Log m.quoted untuk debugging
  //console.log('Message Key:', JSON.stringify(key, null, 2)); // Log key untuk debugging

  // Jika key tidak valid, coba ambil dari storeMessages atau store
  if (!key || !key.id || !key.remoteJid) {
    console.log('Key tidak valid, mencoba mengambil dari storeMessages...');
    const storedMessage = await readMessageFromStore(m.quoted.id);
    if (storedMessage) {
      key = {
        id: storedMessage.id,
        remoteJid: storedMessage.chat,
        fromMe: storedMessage.fromMe,
        participant: storedMessage.sender
      };
      console.log('Key dari storeMessages:', JSON.stringify(key, null, 2));
    } else if (store && store.messages && store.messages[m.chat]) {
      console.log('Mencoba mengambil dari store.messages...');
      const messages = store.messages[m.chat].all() || [];
      const quotedMsg = messages.find(msg => msg.key.id === m.quoted.id);
      if (quotedMsg) {
        key = quotedMsg.key;
        console.log('Key dari store:', JSON.stringify(key, null, 2));
      }
    }
    if (!key || !key.id || !key.remoteJid) {
      return m.reply('❌ Gagal mendapatkan ID pesan yang di-reply. Pastikan kamu membalas pesan yang valid!');
    }
  }

  // Default durasi dan timeInput
  let time = 86400; // 24 jam
  let timeInput = '24h'; // Default untuk pesan balasan

  // Validasi durasi untuk .semat
  if (args[0]) {
    timeInput = args[0].toLowerCase();
    if (timeInput === '7d') {
      time = 604800; // 7 hari
    } else if (timeInput === '30d') {
      time = 2592000; // 30 hari
    } else if (timeInput !== '24h') {
      return m.reply('⏳ Durasi tidak valid! Gunakan: 24h, 7d, atau 30d. Contoh: .semat 7d');
    }
  } else {
    m.reply('ℹ️ Tidak ada durasi yang ditentukan. Menggunakan default 24 jam.\nIngin mengguankan Durasi lain? :\nketik .semat <24h, 7d, 30d>\n> 24h = 24 jam\n> 7d = 7 hari\n> 30d = 30 hari');
  }

  try {
    console.log('Sending pin request:', { type: 1, time, key }); // Log sebelum mengirim
    await conn.sendMessage(m.chat, {
      pin: {
        type: 1, // Hanya pin
        time, // Durasi dalam detik
        key   // Key pesan yang di-pin
      }
    });
    console.log('Pin request sent successfully'); // Log setelah sukses

    // Simpan status pin ke store
    await savePinnedMessage(m.quoted.id, time);

    m.reply(`✅ Pesan berhasil di-pin selama ${timeInput}!`);
  } catch (err) {
    console.error('Pin Error:', err);
    m.reply(`❌ Gagal memproses pin pesan: ${err.message}`);
  }
};


handler.tags = ['group'];
handler.help = ['semat <24h|7d|30d> (balas pesan)'];
handler.command = ['semat'];
handler.group = true;

handler.register = true
handler.limit = true
module.exports = handler;