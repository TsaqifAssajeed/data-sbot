/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const fetch = require('node-fetch');
let handler = async (m, {
    usedPrefix,
    command
}) => {
    conn.sendMessage(m.chat, {
		react: {
			text: '🕑',
			key: m.key,
		}
	})
    try {
        let response = await fetch('https://al-quran-8d642.firebaseio.com/data.json')
        let data = await response.json()
        let teks = data.map((item, index) => {
            return `🔍 *[ RESULT ${index + 1} ]*

📢 *Arti:* ${item.arti}
🌐 *Asma:* ${item.asma}
🎧 *Audio:* ${item.audio}
📖 *Ayat:* ${item.ayat}
📝 *Keterangan:* ${item.keterangan.replace(/<[^>]+>/g, '')}
📛 *Nama:* ${item.nama}
🔢 *Nomor:* ${item.nomor}
📖 *Rukuk:* ${item.rukuk}
🔠 *Type:* ${item.type}
🔢 *Urut:* ${item.urut}
`
        }).filter(v => v).join("\n\n________________________\n\n")

        await m.reply(teks)
    } catch (e) {
        try {
            let f = await fetch(`https://api.alquran.cloud/v1/surah`)
            let xx = await f.json()
            let teks = xx.data.map((item, index) => {
                return `🔍 *[ RESULT ${index + 1} ]*

🌐 *English:* ${item.englishName}
📢 *Arti:* ${item.englishNameTranslation}
📛 *Nama:* ${item.name}
🔢 *Nomor:* ${item.numberOfAyahs}
🔠 *Type:* ${item.type}
`
            }).filter(v => v).join("\n\n________________________\n\n")

            await m.reply(teks)
        } catch (e) {
            await m.reply(eror)
        }
    }

}
handler.help = ['daftarsurah']
handler.tags = ['islami']
handler.command = /^((list|daftar)sura(t|h))$/i

handler.register = true
handler.limit = true
module.exports = handler;