let fetch = require('node-fetch')
let handler = async (m, { conn, args, command }) => {
  let response = args.join(' ').split('|')
  if (!args[0]) return conn.reply(m.chat, `• *Example :* .${command} kemii`, m)
  conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

  let scripts = {
    flaming2: "fluffy-logo",
    flaming3: "sketch-name",
    flaming5: "water-logo",
    flaming6: "water-logo"
  };

  let backgrounds = {
    flaming2: "",
    flaming3: "&fillTextType=1&fillTextPattern=Warning!",
    flaming5: "&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000",
    flaming6: "&fillTextType=0&backgroundColor=%23101820"
  };

  if (!scripts[command]) return conn.reply(m.chat, '• *Invalid command!*', m);

  let res = `https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=${scripts[command]}&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100${backgrounds[command]}&text=${response[0]}`

  conn.sendFile(m.chat, res, 'flaming.jpg', `ꜱᴜᴅᴀʜ ᴊᴀᴅɪ`, m, false)
}

handler.help = ['flaming2', 'flaming3', 'flaming5', 'flaming6'].map(v => v + ' *<text>*')
handler.tags = ['maker']
handler.command = /^(flaming2|flaming3|flaming5|flaming6)$/i

handler.register = true
handler.limit = true
module.exports = handler
