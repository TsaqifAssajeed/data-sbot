/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

async function handler(m, { command }) {
    command = command.toLowerCase()
    this.anonymous = this.anonymous ? this.anonymous : {}
    switch (command) {
        case 'next':
        case 'leave': {
            let room = Object.values(this.anonymous).find(room => room.check(m.sender))
            if (!room) throw '*[ ! ] Anda tidak berada dalam obrolan anonim*'
            m.reply('*[ ✓ ] Sukses keluar dari anonymous chat*')
            let other = room.other(m.sender)
            if (other) conn.sendMessage(other,{text: '*[ ! ] Partner keluar dari chat*'},{quoted:m})
            delete this.anonymous[room.id]
            if (command === 'leave') break
        }
        case 'start': {
            if (Object.values(this.anonymous).find(room => room.check(m.sender))) throw '*[ ! ] Anda masih dalam obrolan anonim*'
            let room = Object.values(this.anonymous).find(room => room.state === 'WAITING' && !room.check(m.sender))
            if (room) {
                conn.reply(room.b,'*[ ✓ ] mencari partner*',m)
                room.b = m.sender
                room.state = 'CHATTING'
                conn.reply(room.b,'*[ ✓ ] Partner Ditemukan*',m)
            } else {
                let id = + new Date
                this.anonymous[id] = {
                    id,
                    a: m.sender,
                    b: '',
                    state: 'WAITING',
                    check: function (who = '') {
                        return [this.a, this.b].includes(who)
                    },
                    other: function (who = '') {
                        return who === this.a ? this.b : who === this.b ? this.a : ''
                    },
                }
                m.reply('*[ ! ] Menunggu Partner obrolan Anonimous...*')
            }
            break
        }
    }
}
handler.help = ['start *[start sessions]*', 'leave *[end sessions]*', 'next *[next panther]*']
handler.tags = ["anonymous"]
handler.command = ['start', 'leave', 'next']
handler.private = true

handler.register = true
handler.limit = true
module.exports = handler