const {
    proto,
    generateWAMessage,
    areJidsSameUser
} = require('@whiskeysockets/baileys')

module.exports = {
    async all(m, chatUpdate) {
        // Abaikan pesan dari sistem Baileys
        if (m.isBaileys) return;
        // Abaikan pesan tanpa properti message
        if (!m.message) return;
        // Abaikan pesan tanpa m.msg
        if (!m.msg) return;
        // Abaikan pesan tanpa fileSha256
        if (!m.msg.fileSha256) return;
        // Abaikan jika hash tidak ada di database stiker
        const hashKey = m.msg.fileSha256.toString('hex');
        if (!(hashKey in global.db.data.sticker)) return;

        // Ambil data stiker dari database
        let hash = global.db.data.sticker[hashKey];
        let { text, mentionedJid } = hash;

        // Generate pesan baru
        let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
            userJid: this.user.id,
            quoted: m.quoted && m.quoted.fakeObj
        });
        messages.key.fromMe = areJidsSameUser(m.sender, this.user.id);
        messages.key.id = m.key.id;
        messages.pushName = m.pushName;
        if (m.isGroup) messages.participant = m.sender;

        // Kirim pesan sebagai event messages.upsert
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'
        };
        this.ev.emit('messages.upsert', msg);
    }
};