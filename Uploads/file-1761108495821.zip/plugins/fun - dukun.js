const fetch = require("node-fetch");

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply("⚠️ Masukkan Nama!");
  }

  const anu = `https://api.siputzx.my.id/api/ai/dukun?content=${encodeURIComponent(text)}`;
  const res = await fetch(anu);
  const response = await res.json();

  // Kirim reaksi 👍 ke pesan
  await conn.sendMessage(m.chat, {
    react: {
      text: "👍",
      key: m.key,
    },
  });

  try {
    // Kirim hasil dari API
    await conn.sendMessage(m.chat, { text: response.data }, { quoted: m });
  } catch (e) {
    console.error(e);
    await m.reply("⚠️ Terjadi kesalahan saat memproses permintaan.");
  }
};

handler.command = ["dukun"];
handler.help = ["dukun <nama>"];
handler.tags = ["fun"];
handler.limit = true;

handler.register = true
module.exports = handler;