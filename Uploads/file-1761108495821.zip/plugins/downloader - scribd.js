const { lookup } = require('mime-types')

async function scribdDownloader(url, retry = true) {
    if (!url.includes('www.scribd.com')) throw new Error('❌ URL tidak valid.')

    const apiUrl = `${global.alyachan}/api/scribd?apikey=${global.alyachankey}&url=${encodeURIComponent(url)}`
    
    try {
        const response = await fetch(apiUrl, {
            headers: {
                "accept": "application/json"
            }
        })
        if (!response.ok) throw new Error(`${response.status} ${response.statusText}`)

        const data = await response.json()
        console.log('API Response:', JSON.stringify(data)) // Log untuk debug

        if (!data || typeof data.status !== 'boolean' || !data.status) {
            throw new Error('⚠️ Gagal mendapatkan data dari API atau status tidak valid')
        }

        const { filename, url: download_url } = data.data
        if (!filename || !download_url) throw new Error('⚠️ Data API tidak lengkap')

        // Ekstrak ekstensi file dan tentukan mimetype
        const ext = filename.split('.').pop()
        const mimetype = lookup(ext.toLowerCase()) || 'application/octet-stream'

        return {
            filename,
            mimetype,
            download_url
        }
    } catch (err) {
        console.error('Error di scribdDownloader:', err)
        if (retry) {
            console.log('Mencoba ulang permintaan API...')
            return scribdDownloader(url, false) // Coba ulang sekali
        }
        throw err
    }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `❌ Masukkan URL Scribd!\n\nContoh:\n${usedPrefix + command} https://www.scribd.com/document/427934304/Critique-Paper`

    try {
        await m.reply('⏳ Sedang memproses link Scribd...')

        const scraped = await scribdDownloader(args[0])
        let { filename, mimetype, download_url } = scraped

        let caption = `*📥 Scribd Downloader*\n\n` +
                     `📄 *Nama File:* ${filename}`

        // Kirim file langsung via WhatsApp
        await conn.sendMessage(m.chat, {
            document: { url: download_url },
            fileName: filename,
            mimetype: mimetype,
            caption
        }, { quoted: m })

        await m.reply('✅ File berhasil dikirim.')
    } catch (err) {
        console.error('Error di handler:', err)
        throw `❌ Gagal memproses link Scribd: ${err.message}. Coba beberapa saat lagi.`
    }
}

handler.help = ['scribd <url>']
handler.tags = ['downloader']
handler.command = /^(scribd|scdl)$/i
handler.limit = 10

handler.register = true
module.exports = handler