let fetch = require('node-fetch')

let timeout = 100000
let poin = 500
let handler = async (m, { conn, usedPrefix, command }) => {
    conn.tebakbendera2 = conn.tebakbendera2 ? conn.tebakbendera2 : {}
    let id = m.chat

    // Fungsi .nyerah
    if (command === 'nyerah') {
        if (!(id in conn.tebakbendera2)) {
            m.reply('❌ Tidak ada permainan tebak bendera yang sedang berjalan di chat ini!')
            return
        }
        let jawaban = conn.tebakbendera2[id].jawaban
        clearTimeout(conn.tebakbendera2[id].timeout) // Hentikan timeout
        conn.reply(m.chat, `🏳️ *Kamu Menyerah!*\nJawabannya adalah: *${jawaban}*`, conn.tebakbendera2[id].message)
        delete conn.tebakbendera2[id] // Hapus sesi permainan
        return
    }

    // Logika utama tebakbendera
    if (id in conn.tebakbendera2) {
        conn.reply(m.chat, '⏳ Masih ada soal belum terjawab di chat ini!', conn.tebakbendera2[id].message)
        return
    }
    let src = await (await fetch(`https://api.botcahx.eu.org/api/game/tebakbendera?apikey=${btc}`)).json()
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `
${json.bendera}

┌─⊷ *🌟 TEBAK BENDERA 🌟*
▢ ⏰ Timeout *${(timeout / 1000).toFixed(2)} detik*
▢ 💡 Ketik ${usedPrefix}teii untuk petunjuk
▢ 🏳️ Ketik ${usedPrefix}nyerah untuk menyerah
▢ 🎁 Bonus: *${poin} Kredit Sosial*
▢ ✏️ *Kirim jawaban langsung tanpa reply soal ini!*
└──────────────
`.trim()
    conn.tebakbendera2[id] = {
        message: await conn.reply(m.chat, caption, m),
        jawaban: json.nama.toLowerCase(),
        poin,
        startTime: Date.now(),
        timeoutValue: timeout, // Simpan timeout di sini
        timeout: setTimeout(() => {
            if (conn.tebakbendera2[id]) {
                conn.reply(m.chat, `⏰ Waktu habis bro!\nJawabannya adalah *${json.nama}* 😭`, conn.tebakbendera2[id].message)
                delete conn.tebakbendera2[id]
            }
        }, timeout)
    }
}

handler.help = ['tebakbendera', 'nyerah']
handler.tags = ['game']
handler.command = /^(tebakbendera|nyerah)$/i // Tambahkan nyerah ke command
handler.register = false
handler.group = true

handler.register = true
handler.limit = true
module.exports = handler