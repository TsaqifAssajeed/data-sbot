const axios = require('axios');

// Fungsi untuk mengekstrak URL Dropbox dari teks
function extractDropboxUrl(text) {
    const urlRegex = /https:\/\/www\.dropbox\.com\/[^\s]*/;
    const match = text.match(urlRegex);
    return match ? match[0] : null;
}

const handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) return m.reply(`⚠️ Contoh Penggunaan: ${usedPrefix + command} *[url dropbox]*`);

    // Ekstrak URL dari teks input
    const dropboxUrl = extractDropboxUrl(text);
    if (!dropboxUrl) return m.reply(`⚠️ Tidak ditemukan URL Dropbox yang valid dalam input! Pastikan URL benar. 🔗`);

    m.reply('🔍 Sedang mengunduh file dari Dropbox... ⏳');

    try {
        // Panggil API AlyaChan untuk Dropbox
       // console.log('ℹ️ Memulai percobaan AlyaChan API untuk Dropbox...');
        const result = await dropboxAlyaChan(dropboxUrl);

        if (!result || !result.status || !result.data) {
            return m.reply('❌ Gagal mendapatkan data. Pastikan URL Dropbox valid! 🔗\n💡 *Tips*: Gunakan URL lengkap dari Dropbox.');
        }

      //  console.log('✅ Berhasil mengunduh menggunakan AlyaChan API');

        // Format tampilan hasil
        const cpt = `*📥 D R O P B O X 📥*\n\n` +
                    `📄 *Judul*: ${result.data.title} \n` +
                    `📏 *Ukuran*: ${result.data.size} \n` +
                    `📎 *Ekstensi File*: ${result.data.file_type_extension}\n` +
                    `🔗 *URL Download*: ${result.data.url}`;
                    

        // Kirim file dengan thumbnail jika tersedia
        const fileUrl = result.data.url;
        //console.log('ℹ️ Mengirim file:', { fileUrl });
        await conn.sendFile(m.chat, fileUrl, '', cpt, m);

    } catch (error) {
        console.error('❌ Error umum:', error.message, error.stack);
        m.reply('😓 Terjadi kesalahan saat mengambil data. Coba lagi nanti! 🔄');
    }
};

handler.help = ["dropbox"].map((a) => a + " *[url dropbox]*");
handler.tags = ["downloader"];
handler.command = ["dropbox"];
handler.register = true;
handler.limit = true;
module.exports = handler;

async function dropboxAlyaChan(url) {
    try {
        const response = await axios.get(`${global.alyachan}/api/dropbox`, {
            params: {
                url: url,
                apikey: global.alyachankey
            },
            timeout: 15000
        });

        if (response.data && response.data.status === true && response.data.data) {
            return response.data;
        }

        return null;
    } catch (error) {
        console.error('❌ Error di dropboxAlyaChan:', error.message);
        return null;
    }
}