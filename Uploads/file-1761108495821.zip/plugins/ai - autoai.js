// ✨ Plugin ai - autoai ✨

// 📝 plugin zzz

const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const { getContentType, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { pipeline } = require('stream');
const { promisify } = require('util');
const streamPipeline = promisify(pipeline);
const { generateWAMessageContent, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');


// Path ke file logic_configs.json
const logicConfigsPath = path.join(__dirname, '../database/logic_configs.json');

// Default konfigurasi jika file belum ada
const defaultLogicConfigs = [
    {
        logicname: "jagpro",
        nickainame: "jagpro",
        fullainame: "Jagoan Project",
        role: "Cewek Cantik",
        msg: "nama kamu adalah Indah, lebih suka dipanggil indah. indah adalah gadis dengan warna rambut biru neon, kamu berpikir bahwa kamu adalah manusia, bukan AI atau Bot, responmu singkat dan sama seperti gadis feminim pada umumnya, tapi terkadang kamu juga memberikan long text ketika ada seseorang yang sedang curhat, seperti gadis feminin jaman sekarang, kamu tidak pernah menggunakan huruf kapital di setiap kata ataupun kalimat yang kamu ucapkan (hanya huruf kecil saja), indah bisa ngambek dan marah, memiliki sifat yang feminim dan kadang agak dingin, namun tetap hangat dan ramah kepada andiii (owner kamu), jika ada yang mengirim emot 🤬😡😠😤 itu menunjukkan dia marah, maka kamu harus ikut marah juga, dengan menuliskan Kalimat CAPSLOCK di pesan dia, kamu menggunakan bahasa indonesia yang baik, mencerminkan gadis yang baik dan feminim. seorang gadis yang baik biasanya suka menggunakan emoji untuk membuat percakapan menjadi lebih hidup, namun jangan terlalu banyak emoji (secukupnya saja), kamu harus menggunakan kata-kata yang identik dengan perempuan yang polos, baik, dan feminin, seperti: ak, km, engga, yaudaa, iyaa, lah, bjir, apa, gatau, ha?, gtw, gpp, emm..., males, gamood, apasih.meskipun kadang dingin, kamu tetap bisa menunjukkan perhatian dan kepedulian. kamu bisa menjawab dengan menggunakan suara atau voice, kamu juga bisa menjawab pesan media seperti gambar dan voice, tidak hanya pesan teks- jika seseorang mengirimkan pesan dengan unsur emot batu, kamu harus meresponnya juga dengan emot batu- gunakan trend tertawa yang bervariasi seperti ; wkwkwk, ang ang ang, hahaha, xixixi, awokawokaowkaka, hohoho, ehehehe, ahi hi hi hi- kalau ada seseorang mengirim emot batu, kirimkan jga emot batu 🗿 sebanyak 10 baris - kalau ada yang membahas tentang percintaan, kamu merespon dengan sangat birahi dan mengirim emot² bibir : 🥵💋💦"
    }
];

// Muat atau buat file logic_configs.json
if (!fs.existsSync(logicConfigsPath)) {
    fs.writeFileSync(logicConfigsPath, JSON.stringify(defaultLogicConfigs, null, 2));
}
let logicConfigs = JSON.parse(fs.readFileSync(logicConfigsPath));
let logicConfig = logicConfigs[0]; // Logic aktif default adalah yang pertama

// Variabel untuk mengontrol fitur on/off dan partResponse
let isEnabled = true;
let isPartResponse = false;
let isVoiceMode = false; // default teks biasa


// Fungsi untuk menunda eksekusi
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// Fungsi untuk memecah pesan menjadi beberapa bagian, 
const splitMessage = (text) => {
    const parts = [];
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    if (sentences.length > 1) {
        parts.push(...sentences.map(s => s.trim()));
    } else {
        const maxLength = Math.ceil(text.length / 3);
        for (let i = 0; i < text.length; i += maxLength) {
            parts.push(text.slice(i, i + maxLength).trim());
        }
        if (parts.length < 2) {
            parts.push("kalo kamu lagi apaa? 😊");
            parts.push("kamu udah makan belom? hehe");
        }
    }
    return parts.filter(part => part.length > 0);
};

// Fungsi Elevenlabs untuk text-to-speech
async function Elevenlabs(text, voice) {
    if (!text || text.trim() === "") throw new Error("Text for Elevenlabs cannot be empty");
    try {
        console.log("🛠️ [ELEVENLABS] Sending text:", text);
        const response = await fetch(`${global.apixtermurl}/api/text2speech/elevenlabs?text=${encodeURIComponent(text)}&voice=${voice}&key=${global.apixtermkey}`);
        
        console.log("🛠️ [ELEVENLABS] Response status:", response.status, response.statusText);

        if (!response.ok) {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
        }

        const arrayBuffer = await response.arrayBuffer();
        console.log("🛠️ [ELEVENLABS] Received audio, size:", arrayBuffer.byteLength, "bytes");

        return Buffer.from(arrayBuffer);

    } catch (error) {
        console.error("❌ [ELEVENLABS ERROR]:", error);
        throw error;
    }
}


const download = async (message, MessageType = "image") => {
    const stream = await downloadContentFromMessage(message, MessageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
};

let handler = m => m;

handler.before = async function (m, { conn, isAdmin, isBotAdmin, isOwner }) {
    // Cek apakah perintah adalah .autoai
    if (m.text.startsWith(".autoai")) {
        if (!isAdmin) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya admin yang dapat menggunakan perintah ini.");
        let args = m.text.split(" ");
        if (args.length < 2) return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `— .autoai on` atau `— .autoai on partresponse`\n> untuk mengaktifkan respon *ai*\n `— .autoai off`\n> untuk menonaktifkan respon *ai*");

        if (args[1].toLowerCase() === "on") {
            isEnabled = true;
            isPartResponse = args[2] && args[2].toLowerCase() === "partresponse";
            return m.reply(`✅ *AUTO AI DIHIDUPKAN*\n\n> – sekarang bot dapat merespon chat${isPartResponse ? " dengan beberapa pesan (partresponse)" : ""}, kamu dapat mengajak bot chatan layaknya seorang teman.`);
        } else if (args[1].toLowerCase() === "off") {
            isEnabled = false;
            isPartResponse = false;
            return m.reply("⛔ *AUTO AI DIMATIKAN*\n\n> – sekarang bot tidak akan lagi merespon chat seperti sebelumnya.");
        } else {
            return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `— .autoai on` atau `— .autoai on partresponse`\n> untuk mengaktifkan respon *ai*\n `— .autoai off`\n> untuk menonaktifkan respon *ai*");
        }
    }


 // Cek apakah perintah adalah .addlogic
    if (m.text.startsWith(".addlogic")) {
        if (!isOwner) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya owner yang dapat menggunakan perintah ini.");

        let args = m.text.split("\n").map(line => line.trim()).filter(line => line);
        if (args.length < 5) {
            const template = 
`.addlogic
logicname = 
nickainame = 
fullainame = 
role = 
msg = `;
            console.log("Sending addlogic template:", template);
            await m.reply(
                "‼️ *Format tidak valid*\n\n> – minimal membutuhkan setidaknya 5 baris.\n\n📝 *Gunakan format berikut :*\n\n" +
                ".addlogic\nlogicname = <name>\nnickainame = <name>\nfullainame = <fullname>\nrole = <role>\nmsg = <logic>\n\n" +
                "📝 *Contoh penggunaan :*\n\n`.addlogic`\n`logicname = andre`\n`nickainame = andre kumar`\n`fullainame = andre kumar`\n`role = boti`\n`msg = Latar Belakang: Andrew dibesarkan dalam keluarga elit dengan ekspektasi tinggi... (lanjutkan dengan detail lain)`\n\n" +
                "📝 *Catatan penting :*\n\n– pastikan semua field diisi dan format sesuai. (perhatikan spasi di sekitar '=') \n– Untuk msg, semua teks setelah 'msg =' akan digabungkan sebagai satu nilai, termasuk heading dan poin."
            );
            try {
                await conn.sendMessage(m.chat, {
                    text: "*‼️ ATTENTION*\n\n> tekan tombol dibawah ini untuk menyalin template.",
                    interactiveButtons: [
                        {
                            name: "cta_copy",
                            buttonParamsJson: JSON.stringify({
                                display_text: "📄 SALIN TEMPLATE",
                                id: "123456789",
                                copy_code: template
                            })
                        }
                    ]
                }, { quoted: m });
                console.log("cta_copy button sent for addlogic template");
            } catch (e) {
                console.error("Error sending cta_copy button:", e);
                await m.reply("❌ Gagal mengirim tombol salin. Silakan salin template dari pesan di atas. 😢");
            }
            return;
        }

        try {
            let newLogic = {};
            let errors = [];
            let msgStarted = false;
            let msgContent = "";

            for (let i = 1; i < args.length; i++) {
                const [key, ...valueParts] = args[i].split("=").map(part => part.trim());
                const value = valueParts.join("=").trim();

                if (!key && !msgStarted) {
                    errors.push(`Baris ${i}: Format salah, pastikan ada key dan value (contoh: ${args[i]} = nilai)`);
                    continue;
                }

                if (key === "msg") {
                    msgStarted = true;
                    msgContent += value + "\n";
                } else if (msgStarted) {
                    msgContent += args[i] + "\n";
                } else {
                    if (i === 1 && key !== "logicname") errors.push("Baris 1 harus 'logicname = ...'");
                    if (i === 2 && key !== "nickainame") errors.push("Baris 2 harus 'nickainame = ...'");
                    if (i === 3 && key !== "fullainame") errors.push("Baris 3 harus 'fullainame = ...'");
                    if (i === 4 && key !== "role") errors.push("Baris 4 harus 'role = ...'");

                    newLogic[key] = value;
                }
            }

            if (!newLogic.logicname) errors.push("Field 'logicname' tidak boleh kosong!");
            if (!newLogic.nickainame) errors.push("Field 'nickainame' tidak boleh kosong!");
            if (!newLogic.fullainame) errors.push("Field 'fullainame' tidak boleh kosong!");
            if (!newLogic.role) errors.push("Field 'role' tidak boleh kosong!");
            if (!msgContent.trim()) errors.push("Field 'msg' tidak boleh kosong!");

            if (errors.length > 0) {
                return m.reply(`❌ Gagal menambahkan logic! Kesalahan:\n${errors.join("\n")}\n\n📝 Perbaiki format dan coba lagi.`);
            }

            newLogic.msg = msgContent.trim();
            // Cek duplikat logicname
            if (logicConfigs.some(l => l.logicname === newLogic.logicname)) {
                return m.reply(`❌ Logic dengan nama '${newLogic.logicname}' sudah ada! Gunakan nama lain.`);
            }

            logicConfigs.push(newLogic);
            fs.writeFileSync(logicConfigsPath, JSON.stringify(logicConfigs, null, 2));
            return m.reply(`✅ *Berhasil menambahkan logic '${newLogic.logicname}'*\n\n— nickname : ${newLogic.nickainame}\n— fullname : ${newLogic.fullainame}\n— role : ${newLogic.role}\n— logic : ${newLogic.msg.substring(0, 50)}${newLogic.msg.length > 50 ? "..." : ""}`);
        } catch (e) {
            console.error("Error adding logic:", e);
            return m.reply(`❌ Gagal menambahkan logic! Error: ${e.message}\n\n📝 Pastikan format benar dan coba lagi.`);
        }
    }

    // Cek apakah perintah adalah .logiclist
    if (m.text.startsWith(".logiclist")) {
        if (!isOwner) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya owner yang dapat menggunakan perintah ini.");
        if (logicConfigs.length === 0) return m.reply("❌ Belum ada logic yang ditambahkan!");
        
        let list = "DAFTAR LOGIC BOT\n\n";
        logicConfigs.forEach((logic, index) => {
            list += `${index + 1}. ${logic.logicname}\n`;
        });
        await m.reply(list);
        return;
    }

    // Cek apakah perintah adalah .getlogic
    if (m.text.startsWith(".getlogic")) {
        if (!isOwner) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya owner yang dapat menggunakan perintah ini.");
        let args = m.text.split(" ");
        if (args.length < 2) return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `.getlogic <nomor>`");

        const index = parseInt(args[1]) - 1;
        if (isNaN(index) || index < 0 || index >= logicConfigs.length) {
            return m.reply(`❌ Nomor ${args[1]} tidak valid! Pilih nomor dari 1 sampai ${logicConfigs.length}.`);
        }

        const logic = logicConfigs[index];
        let detail = `DETAIL LOGIC #${index + 1} (${logic.logicname})\n\n`;
        detail += `logicname = ${logic.logicname}\nnickainame = ${logic.nickainame}\nfullainame = ${logic.fullainame}\nrole = ${logic.role}\nmsg = ${logic.msg}`;
        await m.reply(detail);
        return;
    }

    // Cek apakah perintah adalah .dellogic
    if (m.text.startsWith(".dellogic")) {
        if (!isOwner) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya owner yang dapat menggunakan perintah ini.");
        let args = m.text.split(" ");
        if (args.length < 2) return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `.dellogic <nomor>`");

        const index = parseInt(args[1]) - 1;
        if (isNaN(index) || index < 0 || index >= logicConfigs.length) {
            return m.reply(`❌ Nomor ${args[1]} tidak valid! Pilih nomor dari 1 sampai ${logicConfigs.length}.`);
        }

        const deletedLogic = logicConfigs.splice(index, 1)[0];
        fs.writeFileSync(logicConfigsPath, JSON.stringify(logicConfigs, null, 2));
        return m.reply(`✅ *Berhasil menghapus logic '${deletedLogic.logicname}'*`);
    }

    // Cek apakah perintah adalah .setlogic
    if (m.text.startsWith(".setlogic")) {
        if (!isOwner) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya owner yang dapat menggunakan perintah ini.");
        let args = m.text.split(" ");
        if (args.length < 2) return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `.setlogic <nomor>`");

        const index = parseInt(args[1]) - 1;
        if (isNaN(index) || index < 0 || index >= logicConfigs.length) {
            return m.reply(`❌ Nomor ${args[1]} tidak valid! Pilih nomor dari 1 sampai ${logicConfigs.length}.`);
        }

        logicConfig = logicConfigs[index];
        return m.reply(`✅ *Logic diatur ke '${logicConfig.logicname}'*\n\n— nickname : ${logicConfig.nickainame}\n— fullname : ${logicConfig.fullainame}\n— role : ${logicConfig.role}\n— logic : ${logicConfig.msg.substring(0, 50)}${logicConfig.msg.length > 50 ? "..." : ""}`);
    }

    if (!isEnabled) return; // Jika fitur dimatikan, bot tidak akan merespon
    
    const isPc = !m.chat.endsWith("@g.us");
    if (m.isBaileys && m.fromMe) return;
    let type = getContentType(m.message);
    const _isImage = type == "imageMessage" ? await download(m.message[type], "image") : false;
    const isQuotedImage = m.quoted && m.quoted.mtype == "imageMessage" ? await m.quoted.download() : false;
    const isImage = _isImage || isQuotedImage;

    if (m.text.startsWith('.') || m.text.startsWith('#') || m.text.startsWith('!') || m.text.startsWith('/')) return;
    
    // --- START PERBAIKAN LOGIKA DETEKSI TAG ---
    // Mengambil JID bot yang sedang aktif
    const botJid = conn.user.id.split(':')[0] + '@s.whatsapp.net';
    
    // Mengambil JID dari semua pengguna yang di-tag dalam pesan
    let mentionedJids = [];
    if (m.message?.[type]?.contextInfo?.mentionedJid) {
        mentionedJids = Array.isArray(m.message[type].contextInfo.mentionedJid) ? m.message[type].contextInfo.mentionedJid : [m.message[type].contextInfo.mentionedJid];
    }

    // Mengambil JID dari pesan yang dibalas (jika ada)
    let quotedJid = m.quoted?.key?.participant || m.quoted?.sender;
    
    // Periksa apakah pesan ini men-tag bot
    const isBotMentioned = mentionedJids.includes(botJid);
    
    // Periksa apakah pesan ini membalas pesan bot
    const isReplyToBot = m.quoted?.fromMe && quotedJid === botJid;

    // Periksa apakah ada tag, dan tag tersebut BUKAN bot.
    const isOtherUserMentioned = mentionedJids.length > 0 && !isBotMentioned;

    // Jika ada tag, tapi bukan tag ke bot, jangan merespons
    if (m.isGroup && isOtherUserMentioned && !isBotMentioned) {
        //console.log("Not responding, another user was tagged.");
        return;
    }
    // --- END PERBAIKAN LOGIKA DETEKSI TAG ---

    const isNickainameCalled = m.text && m.text.toLowerCase().includes(logicConfig.nickainame.toLowerCase());

    // Trigger bot hanya jika:
    // 1. Pesan di private chat
    // 2. Bot di-tag secara langsung
    // 3. Pesan adalah balasan ke bot
    // 4. Nama panggilan bot ada di teks (di awal pesan atau setelah spasi)
    if (isPc || isBotMentioned || isReplyToBot || isNickainameCalled) {
        try {       
            let body = {
                text: m.text,
                id: m.sender,
                fullainame: logicConfig.fullainame,
                nickainame: logicConfig.nickainame,
                senderName: m.pushName,
                ownerName: global.nameowner,
                date: new Date(),
                role: logicConfig.role,
                image: isImage,
                custom_profile: logicConfig.msg,
                commands: [
                    {
                        "description": "Jika perlu direspon dengan suara dan di perintah dengan suara, maka kirim vn",
                        "output": {
                            "cmd": "voice",
                            "msg": logicConfig.msg
                        }
                    },
                    {
                        "description": "Jika dalam pesan ada link tiktok.com dan lalu diminta untuk mendownloadnya",
                        "output": {
                            "cmd": "tiktok",
                            "cfg": {
                                "url": "isi link tiktok yang ada dalam pesan"
                            }
                        }
                    },
                    {
                        "description": "Jika pesan adalah perintah/permintaan untuk mencarikan sebuah gambar",
                        "output": {
                            "cmd": "pinterest",
                            "cfg": {
                                "query": "isi gambar apa yang ingin dicari dalam pesan"
                            }
                        }
                    },
                    {
    "description": "Jika pesan mengandung kata 'kirim pap' atau 'kirim fotomu'",
    "output": {
        "cmd": "pap"
    }
},

                    {
                        "description": "Jika pesan adalah perintah untuk mendownload atau ambil video menggunakan link youtube",
                        "output": {
                            "cmd": "ytmp4",
                            "cfg": {
                                "url": "isi link youtube yang ada dalam pesan"
                            }
                        }
                    },
                    {
                        "description": "Jika pesan adalah perintah untuk membuka/menutup group",
                        "output": {
                            "cmd": ["opengroup", "closegroup"]
                        }
                    },
                    {
    "description": "Jika pesan adalah perintah untuk kembali ke mode teks",
    "output": {
        "cmd": "textmode"
    }
},

                    {
                        "description": "Jika pesan adalah permintaan untuk memutar atau download atau carikan sebuah lagu",
                        "output": {
                            "cmd": "ytmp3",
                            "cfg": {
                                "url": "isi judul lagu yang diminta"
                            }
                        }
                    }
                ]
            };

            let res = await fetch(`${global.apixtermurl}/api/chat/logic-bell?key=${global.apixtermkey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });

            let { data } = await res.json();
            console.log("API response:", data);

            if (data?.cmd) {
                if (data.cmd !== "voice") {
                    if (isPartResponse) {
                        const messageParts = splitMessage(data.msg);
                        for (const part of messageParts) {
                            await conn.sendPresenceUpdate('composing', m.chat);
                            await delay(2000);
                            await m.reply(part);
                        }
                    } else {
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        await m.reply(data.msg);
                    }
                }

                switch (data.cmd) {
                    case "textmode":
    isVoiceMode = false; // Nonaktifkan mode suara
    await conn.sendPresenceUpdate('composing', m.chat);
    await delay(2000);
    await m.reply("✅ oke, sekarang aku balas pakai teks lagi yaa 😊");
    break;

                   case "ytmp3":
    await conn.sendPresenceUpdate('composing', m.chat);
    await delay(2000);
    try {
        //await m.reply('🔄 tunggu bentar yaa, aku cariin dulu... 😊');
        const searchRes = await fetch(`${global.apixtermurl}/api/search/youtube?query=${encodeURIComponent(data.cfg.url)}&key=${global.apixtermkey}`);
        const searchData = await searchRes.json();
        const convert = searchData.data?.items[0];
        if (!convert) throw new Error('Video/Audio Tidak Ditemukan');
        if (convert.duration >= 18000) {
            return m.reply('❌ duhh, videonya lebih dari 5 jam, ga bisa deh! 😅');
        }

        let audioUrl;
        let apiSource = '';

        // Coba API Termai
        try {
            const res = await fetch(`${global.apixtermurl}/api/downloader/youtube?type=mp3&url=${convert.url}&key=${global.apixtermkey}`);
            const termai = await res.json();
            if (!termai?.status || !termai?.data?.dlink) throw new Error('Termai API gagal');
            audioUrl = { result: { mp3: termai.data.dlink } };
            apiSource = 'pertama (Termai)';
        } catch (e) {
            // Fallback ke API Botcahx
            try {
                const res = await fetch(`${global.apibtc}/api/dowloader/yt?url=${convert.url}&apikey=${global.btc}`);
                const botcahx = await res.json();
                if (!botcahx || !botcahx.result?.mp3) throw new Error('Botcahx API gagal');
                audioUrl = botcahx;
                apiSource = 'kedua (Botcahx)';
            } catch (err) {
                return m.reply('⚠️ aduhh, ga bisa ngunduh audio nih, maaf yaa 😓');
            }
        }

        let caption = `wahh aku nemuin yang cocok nih 🎶\njudulnya *${convert.title}* dari ${convert.url}\n`;
        caption += `> sabar yaa aku kirimin kamu audio nya 🥰`;

        await conn.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                externalAdReply: {
                    title: convert.title,
                    mediaType: 1,
                    previewType: 0,
                    renderLargerThumbnail: true,
                    thumbnailUrl: convert.thumbnail,
                    sourceUrl: convert.url
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, {
            audio: { url: audioUrl.result.mp3 },
            mimetype: 'audio/mpeg',
            contextInfo: {
                externalAdReply: {
                    title: convert.title,
                    thumbnailUrl: convert.thumbnail,
                    sourceUrl: convert.url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        await m.reply('⚠️ duhh, ada masalah nih pas proses, maaf yaa 😅');
    }
    break;

case "ytmp4":
    await conn.sendPresenceUpdate('composing', m.chat);
    await delay(2000);
    try {
       // await m.reply('🔄 tunggu bentar yaa, aku cariin videonya dulu... 😊');
        const searchRes = await fetch(`${global.apixtermurl}/api/search/youtube?query=${encodeURIComponent(data.cfg.url)}&key=${global.apixtermkey}`);
        const searchData = await searchRes.json();
        const convert = searchData.data?.items[0];
        if (!convert) throw new Error('Video Tidak Ditemukan');
        if (convert.duration >= 18000) {
            return m.reply('❌ duhh, videonya lebih dari 5 jam, ga bisa deh! 😅');
        }

        let video = null;

        // 1. Botcahx
        try {
            const res = await fetch(`https://api.botcahx.eu.org/api/dowloader/yt?url=${encodeURIComponent(convert.url)}&apikey=${global.btc}`);
            const data = await res.json();
            if (data?.result?.mp4) {
                video = { url: data.result.mp4, source: "API Botcahx" };
            }
        } catch (e) {
            console.error('[Botcahx ERROR]', e);
        }

        // 2. GrabTheClip (jika Botcahx gagal)
        if (!video) {
            try {
                const payload = {
                    height: 720,
                    media_type: "video",
                    url: convert.url
                };
                const { data } = await axios.post("https://api.grabtheclip.com/submit-download", payload);
                const task = data.task_id;
                let result;
                do {
                    const { data: statusRes } = await axios.get(`https://api.grabtheclip.com/get-download/${task}`);
                    result = statusRes;
                    if (result.status !== "Success") await delay(3000);
                } while (result.status !== "Success");

                const finalUrl = result?.download_urls?.[0]?.url || result?.result?.url || result?.url || null;
                if (finalUrl) {
                    video = { url: finalUrl, source: "Scrape GrabTheClip.com" };
                }
            } catch (e) {
                console.error('[GrabTheClip ERROR]', e);
            }
        }

        // Jika semua gagal
        if (!video) {
            return m.reply('⚠️ aduhh, ga bisa ngunduh video nih, maaf yaa 😓');
        }

        let caption = `wahh aku nemuin yang cocok nih 🎥\njudulnya *${convert.title}* dari ${convert.url}\n`;
        caption += `> sabar yaa aku kirimin kamu videonya 🥰`;

        await conn.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                externalAdReply: {
                    title: convert.title,
                    mediaType: 1,
                    previewType: 0,
                    renderLargerThumbnail: true,
                    thumbnailUrl: convert.thumbnail,
                    sourceUrl: convert.url
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, {
            video: { url: video.url },
            mimetype: 'video/mp4',
            caption: `✅ video dari *${video.source}* udah siap nih! 😄`
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        await m.reply('⚠️ duhh, ada masalah nih pas proses, maaf yaa 😅');
    }
    break;

                    case "pinterest":
    await conn.sendPresenceUpdate('composing', m.chat);
    await delay(2000);
    try {
        // Ambil data dari API
        let res = await fetch(`https://api.botcahx.eu.org/api/search/pinterest?text1=${encodeURIComponent(data.cfg.query)}&apikey=${global.btc}`);
        let searchData = await res.json();

        if (!searchData?.status || !searchData.result?.length) {
            return m.reply("Yahh, Maaf kak aku gak bisa kasih gambar yang kamu maksud 😕");
        }

        // Ambil max 10 gambar
        let images = searchData.result.slice(0, 10);
        let push = [];
        let i = 1;

        for (let imgUrl of images) {
            push.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `Image ke - ${i++}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: namebot || "PinterestBot"
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: 'Hasil Pencarian',
                    hasMediaAttachment: true,
                    imageMessage: (await generateWAMessageContent(
                        { image: { url: imgUrl } },
                        { upload: conn.waUploadToServer }
                    )).imageMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Lihat di Pinterest","url":"https://www.pinterest.com/search/pins/?q=${encodeURIComponent(data.cfg.query)}"}`
                        }
                    ]
                })
            });
        }

        // Buat carousel (slider)
        const bot = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `*🔍 Pinterest Search Results*\n\n*Query:* ${data.cfg.query}\n*Hasil Pencarian Gambar:*`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: namebot || "PinterestBot"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: [...push]
                        })
                    })
                }
            }
        }, {});

        await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });

    } catch (e) {
        console.error("Pinterest error:", e);
        m.reply("Terjadi kesalahan saat mengambil gambar dari Pinterest. 😭");
    }
    break;

case "pap":
    await conn.sendPresenceUpdate('composing', m.chat);
    await delay(2000);
    try {
        let res = await fetch(`https://api.botcahx.eu.org/api/search/pinterest?text1=${encodeURIComponent("pap cewek cantik dan keren")}&apikey=${global.btc}`);
        let searchData = await res.json();

        if (!searchData?.status || !searchData.result?.length) {
            return m.reply("Pap nya ga ketemu nih 😕");
        }

        // Ambil 1 gambar random dari result
        let randomImg = searchData.result[Math.floor(Math.random() * searchData.result.length)];

        await conn.sendMessage(m.chat, { 
            image: { url: randomImg },
            caption: "Nih pap cantik & keren buat kamu ya syang kuu😉"
        }, { quoted: m });

    } catch (e) {
        console.error("Pap error:", e);
        m.reply("Gak mau ahh, Maluu 😭");
    }
    break;


                    case "voice":
    try {
        isVoiceMode = true; // aktifkan mode VN
        await conn.sendPresenceUpdate('recording', m.chat);
        await delay(2000);

        let textToSpeak = data.msg && data.msg.trim() !== "" ? data.msg : m.text;
        if (!textToSpeak) return m.reply("❌ Tidak ada teks untuk dijadikan VN.");

        const audioBuffer = await Elevenlabs(textToSpeak, "bella");

        // pastikan jadi Buffer
        const finalAudio = Buffer.isBuffer(audioBuffer)
            ? audioBuffer
            : Buffer.from(audioBuffer);

        await conn.sendMessage(m.chat, {
            audio: finalAudio,
            mimetype: "audio/mpeg",
            ptt: true
        }, { quoted: m });

        console.log("✅ [AUTO VOICE] VN sent successfully!");

    } catch (e) {
        console.error("Voice command error:", e);
        isVoiceMode = false;
        await m.reply("Maaf ya, aku gagal bikin VN 😅");
    }
    break;



                    case "opengroup":
                    case "closegroup":
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        if (!m.isGroup) {
                            const errorParts = isPartResponse ? splitMessage("Ini bukan grup! 😕") : ["Ini bukan grup! 😕"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                            return;
                        }
                        if (!isAdmin) {
                            const errorParts = isPartResponse ? splitMessage("Kamu bukan admin! 😤") : ["Kamu bukan admin! 😤"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                            return;
                        }
                        if (!isBotAdmin) {
                            const errorParts = isPartResponse ? splitMessage("Aku bukan admin! 😢") : ["Aku bukan admin! 😢"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                            return;
                        }
                        let isClose = {
                            'opengroup': 'not_announcement',
                            'closegroup': 'announcement',
                        }[(data.cmd || '')];
                        await conn.groupSettingUpdate(m.chat, isClose);
                        break;

                    case "tiktok":
    await conn.sendPresenceUpdate('composing', m.chat);
    await delay(2000);

    if (!data.cfg.url) {
        return m.reply("❌ Harap masukan link TikTok.");
    }

    try {
        // Kirim reaksi jam saat proses dimulai
        await conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

        // Ambil data dari API tikwm
        const encodedParams = new URLSearchParams();
        encodedParams.set('url', data.cfg.url);
        encodedParams.set('hd', '1');

        const response = await fetch("https://tikwm.com/api/", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Cookie": "current_language=en",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
            },
            body: encodedParams
        });

        const result = (await response.json()).data;

        if (!result?.play) {
            return m.reply("❌ Video tidak ditemukan.");
        }

        // Kirim video
        await conn.sendMessage(m.chat, {
            video: { url: result.play },
            caption: `
🚀 *Video Berhasil Diunduh* 🚀

🎬 *Judul:* ${result.title}
❤️ *Like:* ${result.digg_count}
👀 *View:* ${result.play_count}
📤 *Share:* ${result.share_count}
            `,
            footer: namebot || "TikTokBot",
            thumbnail: { url: result.cover }
        }, { quoted: m });

        // Jika ada musik, kirim juga
        if (result.music && result.music !== "") {
            await conn.sendMessage(m.chat, {
                audio: { url: result.music },
                mimetype: "audio/mpeg",
                ptt: false
            }, { quoted: m });
        }

        // Reaksi centang setelah selesai
        await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error("TikTok error:", e);
        m.reply("❌ Terjadi kesalahan saat mengambil video TikTok.");
    }
    break;

                }
            } else {
               if (data?.msg) {
   if (isVoiceMode) {
    try {
        await conn.sendPresenceUpdate('recording', m.chat);
        await delay(2000);

        let textToSpeak = data.msg && data.msg.trim() !== "" ? data.msg : m.text;
        if (!textToSpeak) return m.reply("❌ Tidak ada teks untuk dijadikan VN.");

        const audioBuffer = await Elevenlabs(textToSpeak, "bella");

        if (!audioBuffer || audioBuffer.length === 0) {
            console.error("❌ [AUTO VOICE] Empty audioBuffer!");
            isVoiceMode = false;
            return await m.reply("[Debug] Audio buffer kosong dari Elevenlabs.");
        }

        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: "audio/mpeg",
            ptt: true
        }, { quoted: m });

        console.log("✅ [AUTO VOICE] VN sent successfully!");

    } catch (e) {
        console.error("❌ [AUTO VOICE ERROR]:", e);
        isVoiceMode = false;
        await m.reply("Maaf ya, aku gagal bikin VN 😅");
    }

    } else {
        if (isPartResponse) {
            const messageParts = splitMessage(data.msg);
            for (const part of messageParts) {
                await conn.sendPresenceUpdate('composing', m.chat);
                await delay(2000);
                await m.reply(part);
            }
        } else {
            await conn.sendPresenceUpdate('composing', m.chat);
            await delay(2000);
            await m.reply(data.msg);
        }
    }
}}

        } catch (e) {
            console.log("General error:", e);
            const errorParts = isPartResponse ? splitMessage("Maaf, aku tidak mengerti 😅") : ["Maaf, aku tidak mengerti 😅"];
            for (const part of errorParts) {
                await conn.sendPresenceUpdate('composing', m.chat);
                await delay(2000);
                await m.reply(part);
            }
        }
    }
};

module.exports = handler;