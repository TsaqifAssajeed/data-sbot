let handler = async (m, { conn, args, usedPrefix, command }) => {
  conn.tebaksuku = conn.tebaksuku || {}
  let id = m.chat

  // Fitur menyerah
  if (command === 'gatau') {
    if (!(id in conn.tebaksuku)) return conn.reply(m.chat, '❌ Tidak ada soal yang sedang berlangsung.', m)
    let [_, soal] = conn.tebaksuku[id]
    conn.reply(m.chat, `*🏳️ Kamu Menyerah!*\nJawaban yang benar adalah: *${soal.answer}*\nCoba lagi nanti ya.`, m)
    clearTimeout(conn.tebaksuku[id][3])
    delete conn.tebaksuku[id]
    return
  }

  if (id in conn.tebaksuku) return conn.reply(m.chat, '⚠️ Soal sebelumnya belum terjawab!', conn.tebaksuku[id][0])

  let soal = pickRandom(soalSuku)
  conn.tebaksuku[id] = [
    await conn.reply(m.chat, `*┌〔 🌏 Tebak Suku Nasional 〕┐*\n├ 📍 *Pertanyaan:* _${soal.question}_\n├ ⏱️ *Waktu:* 90 detik\n├ 🎁 *Hadiah:* +1500 Money & +500 Exp\n├ ⚠️ Jawab langsung tanpa reply!\n└ 🏳️ Menyerah? ketik *.gatau*`, m),
    soal, 4,
    setTimeout(() => {
      if (conn.tebaksuku[id]) conn.reply(m.chat, `*⏰ Waktu Habis!*\nWaktumu sudah habis!\nJawaban yang benar adalah: *${soal.answer}*`, conn.tebaksuku[id][0])
      delete conn.tebaksuku[id]
    }, 90000) // 90 detik
  ]
}
handler.help = ['tebaksuku', 'gatau']
handler.tags = ['game']
handler.command = /^tebaksuku|gatau$/i
handler.group = true

handler.register = true
handler.limit = true
module.exports = handler

// Cek jawaban user
let before = async (m, { conn }) => {
  conn.tebaksuku = conn.tebaksuku || {}
  let id = m.chat
  if (!(id in conn.tebaksuku)) return
  let [msg, soal] = conn.tebaksuku[id]
  if (m.text.toLowerCase() === soal.answer.toLowerCase()) {
    global.db.data.users[m.sender].money += 1500
    global.db.data.users[m.sender].exp += 500
    conn.reply(m.chat, `*✅ Jawaban kamu benar!*\n🎉 Kamu mendapatkan:\n• 💰 *+1500 Money*\n• ✨ *+500 Exp*`, m)
    clearTimeout(conn.tebaksuku[id][3])
    delete conn.tebaksuku[id]
  }
}
module.exports.before = before

// List soal Tebak Suku
const soalSuku = [
  { question: "Suku asli dari daerah Papua, dikenal sebagai pemburu dan peramu handal.", answer: "Asmat" },
  { question: "Suku di Kalimantan Tengah yang terkenal dengan seni ukir dan rumah betang.", answer: "Dayak" },
  { question: "Suku dari pulau Sumatra yang memiliki adat merantau dan bahasa khas.", answer: "Minang" },
  { question: "Suku dari Pulau Bali yang terkenal dengan upacara Ngaben.", answer: "Bali" },
  { question: "Suku di Sulawesi Selatan yang dikenal sebagai pelaut ulung.", answer: "Bugis" },
  { question: "Suku yang berasal dari daerah Tapanuli, Sumatra Utara.", answer: "Batak" },
  { question: "Suku yang tinggal di daerah ujung timur Indonesia.", answer: "Papua" },
  { question: "Suku yang terkenal dengan tarian Cakalele dari Maluku.", answer: "Ambon" },
  { question: "Suku dari daerah Madura, dikenal dengan karapan sapinya.", answer: "Madura" },
  { question: "Suku mayoritas di Jawa Tengah dan Jawa Timur.", answer: "Jawa" },
  { question: "Suku yang menggunakan bahasa Sunda.", answer: "Sunda" },
  { question: "Suku dari Thailand yang dikenal sebagai penggembala dan tinggal di pegunungan.", answer: "Karen" },
  { question: "Suku tradisional dari Jepang.", answer: "Ainu" },
  { question: "Suku nomaden di Mongolia.", answer: "Mongol" },
  { question: "Suku asli dari Amerika Utara, dikenal dengan tipi dan bulu hias.", answer: "Apache" },
  { question: "Suku asli dari Amerika Selatan yang membangun kota Machu Picchu.", answer: "Inca" },
  { question: "Suku asli Australia.", answer: "Aborigin" },
  { question: "Suku asli dari Afrika Tengah yang tinggal di hutan-hutan hujan tropis.", answer: "Pigmi" },
  { question: "Suku di Afrika Selatan yang terkenal karena tarian perang dan sejarah Zulu.", answer: "Zulu" },
  { question: "Suku di Tibet yang hidup di daerah pegunungan tinggi.", answer: "Sherpa" },
  { question: "Suku pedalaman dari Kalimantan Timur.", answer: "Kutai" },
  { question: "Suku yang berasal dari daerah Sulawesi Tengah.", answer: "Kaili" },
  { question: "Suku yang tinggal di sekitar Danau Toba.", answer: "Batak Toba" },
  { question: "Suku yang dikenal dengan rumah panggung dan kain tenun di Nusa Tenggara Timur.", answer: "Savu" },
  { question: "Suku di pesisir barat Sumatra yang memiliki budaya Minangkabau.", answer: "Padang" },
  { question: "Suku terkenal dari Filipina yang tinggal di pegunungan Luzon.", answer: "Igorot" },
  { question: "Suku di Kalimantan Barat yang punya tradisi naik rumah betang.", answer: "Iban" },
  { question: "Suku dari Nigeria yang merupakan kelompok etnis terbesar di sana.", answer: "Hausa" },
  { question: "Suku dari Ethiopia dengan tradisi mewarnai tubuh dan wajah.", answer: "Mursi" },
  { question: "Suku dari Sudan Selatan yang dikenal dengan tinggi badannya.", answer: "Dinka" },
  { question: "Suku di Nusa Tenggara Barat yang tinggal di Lombok.", answer: "Sasak" },
  { question: "Suku dari Kepulauan Mentawai, Sumatra Barat.", answer: "Mentawai" },
  { question: "Suku dari Sulawesi Tenggara yang dikenal dengan rumah panggung.", answer: "Tolaki" },
  { question: "Suku dari Pulau Sumba, Nusa Tenggara Timur.", answer: "Sumba" },
  { question: "Suku di Kalimantan yang sering disebut 'Orang Gunung'.", answer: "Punan" },
  { question: "Suku dari Kepulauan Riau yang hidup di laut.", answer: "Orang Laut" },
  { question: "Suku dari Sumatra Selatan yang terkenal dengan kain songket.", answer: "Palembang" },
  { question: "Suku dari Iran kuno yang menyembah api.", answer: "Zoroaster" },
  { question: "Suku dari Israel kuno.", answer: "Yahudi" },
  { question: "Suku yang berasal dari Papua dengan tradisi bakar batu?", answer: "Dani" },
  { question: "Suku terkenal di Sumatera Utara yang menganut adat patrilineal?", answer: "Batak" },
  { question: "Suku dari Jepang yang dikenal memiliki budaya unik dan berbeda dari mayoritas Jepang?", answer: "Ainu" },
  { question: "Suku Dayak terkenal berasal dari pulau?", answer: "Kalimantan" },
  { question: "Suku yang terkenal di Sulawesi Selatan dan ahli dalam pelayaran?", answer: "Bugis" }
]

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}