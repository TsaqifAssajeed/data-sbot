let handler = async (m, { conn }) => {
let capt = `
╔═════════════════❑
║     🤖 *JADI OWNER* 🤖
╟────────────────
║ Jadi Owner *30K* Sebulan Guys 😋 
║ Sebelum Jadi Owner Tau Dulu Ya 
║ Apa Aja Sih Keuntungan Owner? 
║ Sini Sini Ruby Jelasin 🍒
║ *Manfaat Owner* :
║ 
║ *•Akses Semua Fitur*😎
║ *•Bisa Open Sewa Bot*🥰
║ *•Bisa Open Premiumin Orang*😍
║ *•Unlimited Limit*😀
║ *•Full Kendali Di Tangan Mu*😋
║ 
║ Menarik Kan? Yuk Jadi Owner😀
║ Ketik *.owner* Untuk Membeli 
║ Akses Owner Di Owner Utama :)
╚═════════════════❏
`;

conn.sendMessage(m.chat, {
      text: capt,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true,
      title: `Jadi Owner ${namebot}`,
      body: author,
      thumbnailUrl: thumb,
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}, { quoted: m })
}
handler.help = ['jadiowner']
handler.tags = ['info']
handler.command = /^(manfaat|jadiowner|apaituowner|own)$/i

handler.register = true

module.exports = handler