// 📝 plugin downloader - ttaudio

const axios = require('axios');

// Handler utama
let handler = async (m, { conn, text }) => {
  if (!text) return m.reply(`‼️ Harap masukkan link TikTok`);

  try {
    // Kirim reaksi jam saat proses dimulai
    await conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

    const result = await tiktok2(text);

    if (!result.music) return m.reply("❌ Audio tidak ditemukan.");

    // Kirim audio hanya sekali
    await conn.sendMessage(m.chat, {
      audio: { url: result.music },
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: m });

    // Reaksi centang setelah audio terkirim
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error(error);
    m.reply("❌ Terjadi kesalahan: " + error.message);
  }
};

handler.help = ["ttaudio"];
handler.tags = ["downloader"];
handler.command = /^ttaudio$/i;

handler.register = true
handler.limit = true
module.exports = handler;

// Fungsi ambil data dari API TikTok
async function tiktok2(query) {
  try {
    const encodedParams = new URLSearchParams();
    encodedParams.set('url', query);
    encodedParams.set('hd', '1');

    const response = await axios({
      method: 'POST',
      url: 'https://tikwm.com/api/',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': 'current_language=en',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
      },
      data: encodedParams
    });

    const video = response.data.data;

    return {
      title: video.title,
      music: video.music
    };
  } catch (error) {
    console.error('Error fetching TikTok audio:', error);
    throw new Error('Gagal mengambil audio dari TikTok.');
  }
}