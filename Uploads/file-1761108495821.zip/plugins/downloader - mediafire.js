const { lookup } = require('mime-types')

async function mediafireDownloader(url, retry = true) {
    if (!url.includes('www.mediafire.com')) throw new Error('❌ URL tidak valid.')

    const apiUrl = `${global.alyachan}/api/mediafire?apikey=${global.alyachankey}&url=${encodeURIComponent(url)}`
    
    try {
        const response = await fetch(apiUrl, {
            headers: {
                "accept": "application/json"
            }
        })
        if (!response.ok) throw new Error(`${response.status} ${response.statusText}`)

        const data = await response.json()
        console.log('API Response:', JSON.stringify(data)) // Debug log

        if (!data || typeof data.status !== 'boolean' || !data.status) {
            throw new Error('⚠️ Gagal mendapatkan data dari API atau status tidak valid')
        }

        const { filename, size, url: download_url } = data.data
        if (!filename || !download_url) throw new Error('⚠️ Data API tidak lengkap')

        // Extract file extension and determine mimetype
        const ext = filename.split('.').pop()?.toLowerCase() || ''
        const mimetype = lookup(ext) || 'application/octet-stream'
        
        // Use placeholders for fields not provided by the API
        const fileSize = size || '(no file size)'
        const fileType = ext ? `${ext.toUpperCase()} File` : '(no ext)'
        const uploaded = '(no date)'
        const titleExt = filename.split('.')[0] || '(no title)'
        const descriptionExt = '(no description)'

        return {
            filename,
            fileSize,
            mimetype,
            uploaded,
            fileType,
            titleExt,
            descriptionExt,
            download_url
        }
    } catch (err) {
        console.error('Error in mediafireDownloader:', err)
        if (retry) {
            console.log('Retrying API request...')
            return mediafireDownloader(url, false) // Retry once
        }
        throw err
    }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `❌ Masukkan URL MediaFire!\n\nContoh:\n${usedPrefix + command} https://www.mediafire.com/file/wuz10n7dzq698p9/znxinvasion-main.zip/file`

    try {
        await m.reply('⏳ Sedang memproses link MediaFire...')

        const scraped = await mediafireDownloader(args[0])
        const { filename, fileSize, mimetype, fileType, download_url } = scraped

        const caption = `*📥 MediaFire Downloader*\n\n` +
                       `📄 *Nama:* ${filename}\n` +
                       `📦 *Ukuran:* ${fileSize}\n` +
                       `📋 *Tipe:* ${fileType}\n`;

        // Debug log untuk memastikan semua variabel valid
        console.log('Scraped data:', scraped)
        console.log('Caption:', caption)

        // Kirim file langsung via WhatsApp
        await conn.sendMessage(m.chat, {
            document: { url: download_url },
            fileName: filename,
            mimetype: mimetype,
            caption: caption
        }, { quoted: m })

        await m.reply('✅ File berhasil dikirim.')
    } catch (err) {
        console.error('Handler error:', err)
        throw `❌ Gagal memproses link MediaFire: ${err.message}. Coba beberapa saat lagi.`
    }
}

handler.help = ['mediafire <url>']
handler.tags = ['downloader']
handler.command = /^(mediafire|mf(dl)?|mfdl)$/i
handler.limit = 10
handler.register = true

module.exports = handler