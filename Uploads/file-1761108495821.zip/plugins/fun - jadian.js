let toM = a => '@' + a.split('@')[0];

function handler(m, { conn, groupMetadata }) {
  // Gunakan jid dari participants untuk menghindari LID
  let ps = groupMetadata.participants.map(v => v.jid || conn.decodeJid(v.id, groupMetadata));
  let a, b;

  // Jika ada mentionedJid, gunakan sebagai target pertama
  a = m.mentionedJid && m.mentionedJid[0] ? conn.decodeJid(m.mentionedJid[0], groupMetadata) : m.fromMe ? conn.user.jid : conn.decodeJid(m.sender, groupMetadata);

  // Pilih target kedua secara acak, pastikan berbeda dengan target pertama
  do {
    b = ps[Math.floor(Math.random() * ps.length)];
  } while (b === a || !b);

  // Pastikan kedua target adalah JID yang valid
  if (!a.endsWith('@s.whatsapp.net') || !b.endsWith('@s.whatsapp.net')) {
    console.log('Debug: Invalid JID - a:', a, 'b:', b);
    return conn.reply(m.chat, '🚩 Pengguna tidak valid!', m);
  }

  // Debugging
  console.log('Debug: a:', a, 'b:', b, 'm.mentionedJid:', m.mentionedJid, 'm.sender:', m.sender);

  conn.reply(m.chat, `${toM(a)} ❤️ ${toM(b)}`, null, {
    mentions: [a, b]
  });
}

handler.help = ['jadian [@tag]'];
handler.tags = ['fun'];
handler.command = ['jadian'];
handler.limit = true;
handler.group = true;

handler.register = true
module.exports = handler;