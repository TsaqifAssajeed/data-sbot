const handler = async (m, { conn, text, args }) => {
  let txt = m.quoted ? m.quoted.text : args.join(" ");
  let groupMetadata = await conn.groupMetadata(m.chat);
  let mem = groupMetadata.participants.map((a) => a.id);
  conn.sendMessage(m.chat, {
    text: `@${m.chat} ${txt || ''}`,
    contextInfo: {
      mentionedJid: mem,
      groupMentions: [{ groupSubject: 'everyone', groupJid: m.chat }]
    }
  });
};

handler.help = ["everyone [Input text/reply]"];
handler.tags = ["group"];
handler.customPrefix = /^(@everyone|everyone)$/;
handler.command = new RegExp;
handler.fail = null;
handler.group = true;
handler.admin = true;

handler.register = true
handler.limit = true
module.exports = handler;