const { google } = require("googleapis");
const moment = require("moment-timezone");
const path = require("path");

const auth = new google.auth.GoogleAuth({
   keyFile: path.join(__dirname, "../function/sheet.json"),
   scopes: ["https://www.googleapis.com/auth/spreadsheets"],
});

const SHEET_ID = "1lq6nwFfFQ-3N927nNuJu4t9yZNacZ1Yr1u_zxjYL2uk";
const TRANSACTION_SHEET = "Sheet1";

async function appendToSheet(nama, tanggal, masuk, keluar, hutang) {
   const client = await auth.getClient();
   const sheets = google.sheets({ version: "v4", auth: client });

   try {
      // Ambil data untuk menentukan nomor urut
      const range = `${TRANSACTION_SHEET}!A5:F`;
      const response = await sheets.spreadsheets.values.get({
         spreadsheetId: SHEET_ID,
         range: range,
      });

      const values = response.data.values || [];
      const nomorUrut = values.length + 1; // Nomor urut berikutnya

      console.log("Sending to Sheet:", [nomorUrut, nama, tanggal, masuk, keluar, hutang]);
      const appendResponse = await sheets.spreadsheets.values.append({
         spreadsheetId: SHEET_ID,
         range: `${TRANSACTION_SHEET}!A5:F`,
         valueInputOption: "USER_ENTERED",
         insertDataOption: "INSERT_ROWS",
         requestBody: {
            values: [[nomorUrut, nama, tanggal, masuk || "", keluar || "", hutang || ""]],
         },
      });
      console.log("API Response:", appendResponse.data);
      return true;
   } catch (error) {
      console.error("Error appending to sheet:", error);
      return false;
   }
}

let handler = async (m, { command, text }) => {
   try {
      console.log("Received Command:", command);
      const [nama, nominal] = text.trim().split("|").map(item => item.trim());
      console.log("Debug - Nama:", nama, "Nominal:", nominal);
      if (!nama || !nominal || isNaN(parseInt(nominal))) {
         return m.reply("Format salah! Contoh: .masuk panel|10000 atau .keluar makan|20000 atau .hutang jono|50000");
      }

      const tanggal = moment().tz("Asia/Makassar").format("DD/MM/YYYY HH:mm:ss");
      let masuk = "";
      let keluar = "";
      let hutang = "";
      const cmd = command.startsWith('.') ? command : `.${command}`;
      if (cmd === ".masuk") {
         masuk = nominal;
      } else if (cmd === ".keluar") {
         keluar = nominal;
      } else if (cmd === ".hutang") {
         hutang = nominal;
      } else {
         return m.reply("Perintah tidak dikenali. Gunakan .masuk, .keluar, atau .hutang.");
      }

      const success = await appendToSheet(nama, tanggal, masuk, keluar, hutang);
      if (success) {
         m.reply(`✅ Data dicatat:\n📌 ${cmd === ".masuk" ? "Masuk" : cmd === ".keluar" ? "Keluar" : "Hutang"}: Rp${parseInt(nominal).toLocaleString()}\n📅 Tanggal: ${tanggal}`);
      } else {
         m.reply("❌ Gagal mencatat ke Google Sheets. Periksa koneksi atau kredensial.");
      }
   } catch (e) {
      console.error("Error in handler:", e);
      m.reply("❌ Terjadi kesalahan. Coba lagi nanti.");
   }
};

handler.help = ["masuk", "keluar", "hutang"];
handler.tags = ["tools"];
handler.command = ["masuk", "keluar", "hutang"];
handler.rowner = true;

handler.register = true
handler.limit = true
module.exports = handler;