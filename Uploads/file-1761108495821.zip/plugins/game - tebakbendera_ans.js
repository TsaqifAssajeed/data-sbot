let poinReward = 10000
const similarity = require('similarity')
const threshold = 0.72
let handler = m => m
handler.before = async function (m, { conn, usedPrefix }) {
    conn.tebakbendera2 = conn.tebakbendera2 ? conn.tebakbendera2 : {}
    let id = m.chat
    let users = global.db.data.users[m.sender]
    
    if (!m.text || m.fromMe || !(id in conn.tebakbendera2)) return // Hindari balasan bot sendiri
    
    let jawabanBenar = conn.tebakbendera2[id].jawaban
    let jawabanUser = m.text.trim().toLowerCase()
    let sisaWaktu = Math.floor((conn.tebakbendera2[id].timeoutValue - (Date.now() - conn.tebakbendera2[id].startTime)) / 1000)

    // Cek jawaban
    if (jawabanUser === jawabanBenar) {
        users.exp += conn.tebakbendera2[id].poin
        users.money += poinReward
        conn.reply(m.chat, `*🎉 KEREN BANGET!*\n+${conn.tebakbendera2[id].poin} Kredit Sosial 💰`, m)
        clearTimeout(conn.tebakbendera2[id].timeout)
        delete conn.tebakbendera2[id]
    } else if (similarity(jawabanUser, jawabanBenar) >= threshold) {
        conn.reply(m.chat, `*✨ Dikiiiit Lagi Nih!*`, m)
    } else {
        await conn.reply(m.chat, `*❌ SALAH BRO! Coba lagi ya! 😜*`, m)
        setTimeout(async () => {
            await conn.sendMessage(m.chat, { delete: m.key }) // Hapus pesan jawaban user
            let newCaption = `
${conn.tebakbendera2[id].message.text.split('\n')[0]} 

┌─⊷ *🌟 TEBAK BENDERA 🌟*
▢ ⏰ Sisa waktu: *${sisaWaktu > 0 ? sisaWaktu : 0} detik*
▢ 💡 Ketik ${usedPrefix}teii untuk petunjuk
▢ 🎁 Bonus: *${conn.tebakbendera2[id].poin} Kredit Sosial*
▢ ✏️ *Kirim jawaban langsung tanpa reply soal ini!*
└──────────────
`.trim()
            conn.tebakbendera2[id].message = await conn.reply(m.chat, newCaption, m)
        }, 1000) // Delay 1 detik sebelum hapus pesan user dan kirim ulang soal
    }
    
    return !0
}
handler.exp = 0

handler.register = true
handler.limit = true
module.exports = handler