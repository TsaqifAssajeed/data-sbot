let handler = async (m, { usedPrefix, text }) => {
    let id = m.chat
    conn.absen = conn.absen || {}

    if (!(id in conn.absen)) {
        throw `_*Tidak ada absen berlangsung di grup ini!*_\n\nKetik *${usedPrefix}mulaiabsen* untuk memulai absen`
    }

    let absen = conn.absen[id][1]
    let senderId = m.sender

    // Cek apakah pengirim sudah absen
    if (absen.some(participant => participant.sender === senderId)) {
        let buttonMessage = {
            text: `_*Anda sudah absen!*_ Klik tombol di bawah untuk mengecek daftar absen.`,
            footer: `_${namebot}_`,
            buttons: [
                { buttonId: `${usedPrefix}cekabsen`, buttonText: { displayText: 'Cek Absen' }, type: 1 }
            ],
            headerType: 4
        }
        await conn.sendMessage(m.chat, buttonMessage, { quoted: m })
        return
    }

    // Pisahkan nama dari teks input menggunakan koma sebagai pemisah
    let names = text.split(',').map(name => name.trim())

    // Tambahkan setiap nama ke dalam daftar absen bersama ID pengirim pesan
    names.forEach(name => {
        absen.push({ sender: senderId, name }) // Simpan objek dengan ID pengirim dan nama
    })

    let d = new Date()
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })

    // Membuat teks daftar absen berdasarkan nama yang sudah disimpan
    let list = absen.map((participant, index) => {
        return `│ ${index + 1}. ${participant.name} - @${participant.sender.split('@')[0]}`
    }).join('\n')

    conn.reply(m.chat, `*「 ABSEN 」*\n\nTanggal: ${date}\n\n${conn.absen[id][2]}\n\n┌ *Yang sudah absen:*\n│ \n│ Total: ${absen.length}\n${list}\n│ \n└────\n\n_${namebot}_`, m)
}

handler.help = ['absen nama']
handler.tags = ['absen']
handler.command = /^(absen|hadir)$/i
handler.group = true
handler.register = true
handler.limit = true
module.exports = handler