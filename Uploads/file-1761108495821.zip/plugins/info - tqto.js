const { prepareWAMessageMedia, generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

let handler = async (m, { conn }) => {
const messa = await prepareWAMessageMedia(
    { image: { url: "https://png.pngtree.com/thumb_back/fh260/background/20220104/pngtree-thank-you-appreciation-greeting-black-photo-image_4807988.jpg" } },
    { upload: conn.waUploadToServer }
);

const catalog = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    "productMessage": {
        "product": {
            "productImage": messa.imageMessage, 
            "productId": "",
            "title": "THANKS TO JAGOAN PROJECT",
            "description": "DASBOARD TQTO",
            "currencyCode": "IDR",
            "bodyText": namebot,
            "footerText": "Klik disini: https://wa.me/62895362282300",
            "priceAmount1000": 100000,
            "productImageCount": 1,
            "firstImageId": 1,
            "salePriceAmount1000": 1000000,
            "retailerId": namebot,
            "url": "https://wa.me/p/9198080290308055/62895362282300'"
        },
        "businessOwnerJid": "62895362282300@s.whatsapp.net"
    }
}), { userJid: m.chat, quoted: m });

await conn.relayMessage(m.chat, catalog.message, { messageId: catalog.key.id });
}

handler.help = ['thanks to', 'tqto']
handler.tags = ['info']
handler.command = /^(tqto)$/i;

handler.register = true

module.exports = handler;