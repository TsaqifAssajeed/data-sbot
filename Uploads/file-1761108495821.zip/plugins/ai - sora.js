/**
 * CR Jagoan Project (Final Version)
 * CH: https://whatsapp.com/channel/0029VagslooA89MdSX0d1X1z
 * PLUGIN: ai - sora.js
 * DESC: Generate AI Video (Bylo API, Sora2 model)
 */

const axios = require('axios')
const crypto = require('crypto')

async function sora(prompt, { ratio = 'landscape', apiKey = process.env.BYLO_API_KEY } = {}) {
    try {
        if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0)
            throw new Error('Prompt harus berupa teks yang valid dan tidak kosong.')
        if (!['portrait', 'landscape'].includes(ratio))
            throw new Error('Ratio hanya boleh "portrait" atau "landscape".')

        const headers = {
            accept: 'application/json, text/plain, */*',
            'content-type': 'application/json; charset=UTF-8',
            origin: 'https://bylo.ai',
            referer: 'https://bylo.ai/features/sora-2',
            'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36',
            uniqueId: crypto.randomUUID().replace(/-/g, '')
        }

        if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`

        const api = axios.create({
            baseURL: 'https://api.bylo.ai/aimodels/api/v1/ai',
            headers
        })

        // 🔹 Buat Task Video
        const { data: task } = await api.post('/video/create', {
            prompt: prompt + " Dengan bahasa Indonesia yang baik dan benar",
            channel: 'SORA2',
            pageId: 536,
            source: 'bylo.ai',
            watermarkFlag: false,
            privateFlag: false,
            isTemp: true,
            vipFlag: false,
            model: 'sora_video2',
            videoType: 'text-to-video',
            aspectRatio: ratio
        })

        console.log("[🎬 Task Created] Task ID:", task.data)

        // 🔁 Polling Status
        const maxAttempts = 120 // 120 x 15 detik = 30 menit
        let attempts = 0

        while (attempts < maxAttempts) {
            attempts++
            const { data } = await api.get(`/${task.data}?channel=SORA2`)

            console.log(`[⌛ Attempt ${attempts}] Status: ${data.data.state}, Complete Data:`, data.data.completeData)

            // ✅ Jika status sudah complete
            if (data.data.state > 0) {
                let result
                try {
                    result = JSON.parse(data.data.completeData)
                } catch (e) {
                    throw new Error("Gagal mem-parsing completeData: " + e.message)
                }

                // 🔹 Prioritaskan hasil tanpa watermark
                const videoUrl =
                    result?.data?.result_object?.no_watermark_urls?.[0] ||
                    result?.data?.result_urls?.[0] ||
                    result?.data?.result_object?.watermark_urls?.[0]

                if (videoUrl) {
                    console.log("[✅ Success] Video ready:", videoUrl)
                    return { url: videoUrl }
                } else {
                    throw new Error("Tidak ada URL video di hasil. Complete Data: " + JSON.stringify(result))
                }
            }

            // ⏱️ Delay 15 detik
            await new Promise(res => setTimeout(res, 15000))
        }

        throw new Error("Timeout: Proses pembuatan video terlalu lama (lebih dari 30 menit)")
    } catch (error) {
        console.error("[❌ Error]", error.message, error.response?.data || error.stack)
        if (error.response?.status === 403) {
            if (error.response?.data?.message?.includes('Unable to determine domain')) {
                throw new Error("Akses ditolak (403): 'Unable to determine domain'. API bylo.ai mungkin memerlukan akses dari domain resmi.")
            }
            throw new Error("Akses ditolak (403). Pastikan kunci API valid di https://bylo.ai.")
        }
        throw new Error("Gagal membuat video: " + error.message)
    }
}

// 🔁 Fallback sementara
async function fallbackVideo(prompt, ratio = 'landscape') {
    console.log("[🔄 Fallback] Mencoba API alternatif...")
    throw new Error("Fallback belum diimplementasikan. Gunakan RunwayML, Kaiber, atau Pika Labs.")
}

// 🧠 Handler utama
let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text)
        return m.reply(`❌ Gunakan format:\n*${usedPrefix + command} [portrait|landscape]|<prompt>*\nContoh:\n• *${usedPrefix + command} portrait|seorang wanita di padang bunga*\n• *${usedPrefix + command} seorang pria berjalan di hutan* (default landscape)`)

    let ratio = 'landscape'
    let prompt = text.trim()

    // 🔹 Deteksi jika user menulis format ratio|prompt
    if (text.includes('|')) {
        const parts = text.split('|').map(s => s.trim())
        if (['portrait', 'landscape'].includes(parts[0].toLowerCase())) {
            ratio = parts[0].toLowerCase()
            prompt = parts.slice(1).join('|').trim()
        }
    }

    await m.reply(`🧠 Membuat video AI dengan teknologi Sora AI...\n> Orientasi: *${ratio.toUpperCase()}*\n> Harap bersabar, proses ini bisa memakan waktu hingga 30 menit.\n> Limit berkurang 70`)

    try {
        const result = await sora(prompt, { ratio })

        if (result?.url) {
            await conn.sendMessage(m.chat, {
                video: { url: result.url },
                caption: `✅ Video berhasil dibuat dari prompt: *${prompt}*\n📐 Orientasi: *${ratio.toUpperCase()}*`
            }, { quoted: m })
        } else {
            throw new Error('Tidak ada URL video ditemukan')
        }
    } catch (e) {
        console.error("[Sora AI Error]", e.message)
        let errorMessage = `❌ Gagal membuat video: ${e.message}\n`
        if (e.message.includes('Unable to determine domain')) {
            errorMessage += `🔗 API bylo.ai tampaknya tidak mendukung akses eksternal.\n`
            errorMessage += `• Coba manual di: https://bylo.ai/features/sora-2\n`
            errorMessage += `• Atau gunakan RunwayML, Kaiber, Pika Labs.\n`
        } else if (e.message.includes('403')) {
            errorMessage += `🔐 Cek kunci API di https://bylo.ai atau aktifkan akun VIP.\n`
        }
        errorMessage += `\n💡 Tips: gunakan prompt lebih sederhana atau coba perintah .sora`
        m.reply(errorMessage)
    }
}

handler.command = /^sora$/i
handler.tags = ['ai']
handler.limit = 50
handler.register = true
module.exports = handler
