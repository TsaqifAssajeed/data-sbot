/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const { generateWAMessageContent, generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys")
const axios = require('axios')

let handler = async (m, { conn, usedPrefix, command, text }) => {
  // Handler untuk ig (download Instagram media dan story)
  if (command === 'ig') {
    if (!text) return m.reply(`Masukkan link Instagram!\nContoh: ${usedPrefix}ig https://www.instagram.com/p/CK0tLXyAzEI\nUntuk Story: ${usedPrefix}ig https://www.instagram.com/stories/username/123456789`)

    // Kirim pesan "Sedang diproses..."
    await conn.sendMessage(m.chat, { text: 'Sedang diproses...' }, { quoted: m })

    try {
      let response
      let username = 'unknown' // Default username jika tidak ditemukan

      // Cek apakah link adalah Instagram Story
      if (text.includes('/stories/')) {
        // Ekstrak username dari link story
        const usernameMatch = text.match(/instagram\.com\/stories\/([^/]+)/)
        if (!usernameMatch) return m.reply('Link story tidak valid. Pastikan format benar, contoh: https://www.instagram.com/stories/username/123456789')
        username = usernameMatch[1]

        response = await axios.get(`${global.alyachan}/api/igs`, {
          params: {
            q: username,
            apikey: global.alyachankey
          }
        })
      } else {
        // Untuk post/reels
        response = await axios.get(`${global.alyachan}/api/ig`, {
          params: {
            url: text,
            apikey: global.alyachankey
          }
        })
        // Ambil username dari respons API jika tersedia
        if (response.data.data && response.data.data[0] && response.data.data[0].username) {
          username = response.data.data[0].username
        }
      }

      const data = response.data
      if (!data.status || !data.data || data.data.length === 0) {
        return m.reply('Maaf, media Instagram (foto/video/story) tidak ditemukan')
      }

      let user = global.db.data.users[m.sender]
      if (!user) {
        user = global.db.data.users[m.sender] = { limit: 100 } // Default limit jika user belum terdaftar
      }
      if (user.limit < 10) {
        return m.reply('Maaf, limit kamu tidak cukup! Minimal 10 limit dibutuhkan untuk menggunakan perintah ini.')
      }

      // Kurangi limit sebesar 10
      user.limit -= 10

      // Pisahkan gambar dan video
      const images = data.data.filter(media => media.type === 'image')
      const videos = data.data.filter(media => media.type === 'video')

      // Kirim gambar dalam carousel
      if (images.length > 0) {
        let push = []
        let i = 1

        for (let media of images) {
          const caption = text.includes('/stories/')
            ? `📸 *Instagram Story*\n👤 *Username*: ${username}\n📅 *Tanggal*: ${media.taken_at}`
            : `📸 *${media.title || 'Instagram Media'}*\n👤 *Username*: ${username}\n📅 *Tanggal*: ${media.taken_at}\n❤️ *Likes*: ${media.like_count || 'N/A'}\n💬 *Komentar*: ${media.comment_count || 'N/A'}`

          push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: `Gambar ke-${i++}`
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
              text: namebot
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
              title: text.includes('/stories/') ? 'Instagram Story' : 'Instagram Post/Reels',
              hasMediaAttachment: true,
              imageMessage: (await generateWAMessageContent({ image: { url: media.url } }, { upload: conn.waUploadToServer })).imageMessage
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: `{"display_text":"Lihat di Instagram","url":"${text}"}`
                }
              ]
            })
          })
        }

        const carouselMsg = generateWAMessageFromContent(m.chat, {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2
              },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.create({
                  text: `🔍 *Hasil Instagram*\n\n*Query:* ${text}\n*Jumlah Gambar:* ${images.length}\n\nSisa limit kamu: ${user.limit}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: 'Buy limit? ketik .buy'
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  hasMediaAttachment: false
                }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                  cards: [...push]
                })
              })
            }
          }
        }, { userJid: m.chat, quoted: m })

        await conn.relayMessage(m.chat, carouselMsg.message, { messageId: carouselMsg.key.id })
      }

      // Kirim video secara terpisah
      for (const media of videos) {
        const fileExtension = 'mp4'
        const fileName = text.includes('/stories/') 
          ? `story_${media.taken_at.replace(/\s/g, '_')}.${fileExtension}`
          : `instagram_${media.shortcode || Date.now()}.${fileExtension}`
        
        const caption = text.includes('/stories/')
          ? `📹 *Instagram Story*\n👤 *Username*: ${username}\n📅 *Tanggal*: ${media.taken_at}`
          : `📹 *${media.title || 'Instagram Media'}*\n👤 *Username*: ${username}\n📅 *Tanggal*: ${media.taken_at}\n❤️ *Likes*: ${media.like_count || 'N/A'}\n💬 *Komentar*: ${media.comment_count || 'N/A'}`

        await conn.sendFile(m.chat, media.url, fileName, caption, m)
      }

      // Jika tidak ada gambar maupun video
      if (images.length === 0 && videos.length === 0) {
        return m.reply('Maaf, tidak ada media yang dapat ditampilkan.')
      }
    } catch (e) {
      console.log(e)
      m.reply('Maaf, gagal mengunduh media Instagram. Pastikan link valid atau coba lagi nanti.')
    }
    return
  }

  // Handler untuk menu Instagram
  let user = global.db.data.users[m.sender]
  if (!user) {
    user = global.db.data.users[m.sender] = { limit: 100 } // Default limit jika user belum terdaftar
  }
  if (user.limit < 10) {
    return m.reply('Maaf, limit kamu tidak cukup! Minimal 10 limit dibutuhkan untuk menggunakan perintah ini.')
  }

  // Fetch group profile picture
  let profilePicUrl
  try {
    profilePicUrl = await conn.profilePictureUrl(m.chat, 'image')
  } catch (e) {
    console.error('Failed to fetch group profile picture:', e)
    profilePicUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.jpg' // Fallback image URL
  }

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `⚠ Fitur ini akan memakan limit 10 sekali kirim, pertimbangkan agar limit kami tidak boros.!!\n\nSisa limit kamu: ${user.limit}\n\nMasukkan link Instagram dengan perintah: ${usedPrefix}ig <link>\nContoh:\n- Post/Reels: ${usedPrefix}ig https://www.instagram.com/p/CK0tLXyAzEI\n- Story: ${usedPrefix}ig https://www.instagram.com/stories/username/123456789`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'Buy limit? ketik .buy'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: namebot,
            hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: profilePicUrl } }, { upload: conn.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: []
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: m })

  // Kurangi limit sebesar 10
  user.limit -= 10
  await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
}

handler.help = ['ig <link>']
handler.tags = ['downloader']
handler.command = /^(ig|instagram)$/i
handler.owner = false
handler.premium = false
handler.group = true // Restrict to group chats to ensure profile picture fetching works
handler.private = false
handler.limit = true // Aktifkan limit untuk perintah ig

handler.register = true
module.exports = handler