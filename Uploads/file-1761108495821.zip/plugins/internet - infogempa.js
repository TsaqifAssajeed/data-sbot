const axios = require('axios');

// Module for fetching earthquake data using BMKG API
const infogempa = {
    get url() {
        return {
            api_gempa: `https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json`
        };
    },

    mintaJson: async function (description, url, fetchOptions = {}) {
        try {
            const { data } = await axios.get(url, fetchOptions);
            if (!data.Infogempa || !data.Infogempa.gempa) {
                throw new Error(`Invalid earthquake data structure`);
            }
            return data;
        } catch (error) {
            throw new Error(`Failed to fetch JSON for ${description}: ${error.message}`);
        }
    },

    formatGempa: function (gempa, placeName = '') {
        const namaTempat = placeName.trim().length ? `📌 Nama: ${placeName}\n` : '';
        let hasil = `🌍 *Info Gempa BMKG*\n\n`;
        hasil += namaTempat;
        hasil += `📅 Tanggal: *${gempa.Tanggal || "N/A"}*\n`;
        hasil += `⏰ Jam: *${gempa.Jam || "N/A"}*\n`;
        hasil += `📏 Magnitude: *${gempa.Magnitude || "N/A"} SR*\n`;
        hasil += `📍 Lokasi: *${gempa.Wilayah || "N/A"}*\n`;
        hasil += `🌊 Kedalaman: *${gempa.Kedalaman || "N/A"}*\n`;
        hasil += `📍 Koordinat: *${gempa.Lintang || "N/A"}, ${gempa.Bujur || "N/A"}*\n`;
        hasil += gempa.Potensi ? `⚠️ *${gempa.Potensi}*\n` : '';
        hasil += gempa.Dirasakan ? `👀 Dirasakan: *${gempa.Dirasakan}*\n` : '';
        hasil += `🔗 BMKG: https://www.bmkg.go.id`;

        return hasil.trim();
    },

    getGempa: async function () {
        const gempaJson = await this.mintaJson('gempa', this.url.api_gempa);
        const gempa = gempaJson.Infogempa.gempa;
        return this.formatGempa(gempa);
    },

    run: async function (lokasiKamu = '') {
        return await this.getGempa();
    }
};

// Handler for manual earthquake info command
let handler = async (m, { text, usedPrefix, command }) => {
    try {
        const result = await infogempa.run(text);
        m.reply(result);
    } catch (error) {
        m.reply(`❌ Error: ${error.message}`);
    }
};

// Polling mechanism to check for earthquake updates
let lastGempaDateTime = null;

async function checkGempaUpdate(conn) {
    try {
        const gempaJson = await infogempa.mintaJson('gempa update', infogempa.url.api_gempa);
        const gempa = gempaJson.Infogempa.gempa;
        const currentDateTime = gempa.DateTime;

        if (lastGempaDateTime !== currentDateTime) {
            lastGempaDateTime = currentDateTime;
            const message = await infogempa.formatGempa(gempa);

            // Send update to all groups with notifgempa enabled
            const chats = Object.entries(global.db.data.chats);
            for (const [chatId, chat] of chats) {
                if (chat.isGroup && chat.notifgempa && chatId.endsWith('@g.us')) {
                    try {
                        await conn.sendMessage(chatId, { text: message });
                        console.log(`✅ Sent earthquake update to group ${chatId}`);
                    } catch (error) {
                        console.error(`❌ Failed to send earthquake update to ${chatId}: ${error.message}`);
                    }
                }
            }
        }
    } catch (error) {
        console.error(`❌ Error checking earthquake update: ${error.message}`);
    }
}

// Start polling every 5 minutes
setInterval(() => checkGempaUpdate(conn), 5 * 60 * 1000);

handler.help = ['infogempa'];
handler.tags = ['internet','tools'];
handler.command = /^infogempa$/i;


handler.register = true
module.exports = handler;