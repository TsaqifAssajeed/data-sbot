let handler = m => m

handler.before = async function (m, { conn }) {
    conn.tebakgambar = conn.tebakgambar ? conn.tebakgambar : {}
    let id = m.chat
    if (!m.text || m.fromMe || !(id in conn.tebakgambar)) return

    let game = conn.tebakgambar[id]
    let jawabanUser = m.text.toLowerCase().trim()
    const threshold = 0.72

    if (jawabanUser === game.jawaban) {
        global.db.data.users[m.sender].exp += game.poin
        global.db.data.users[m.sender].tiketcoin += 1
        global.db.data.users[m.sender].money += game.poin
        conn.reply(m.chat, `🎉 *Benar!* 🏆\n+${game.poin} money 💸`, m)
        clearTimeout(game.timeout)
        delete conn.tebakgambar[id]
    } else if (similarity(jawabanUser, game.jawaban) >= threshold) {
        conn.reply(m.chat, `✨ *Dikit Lagi!* 🔥 Coba lagi ya!`, m)
    } else {
        conn.reply(m.chat, `❌ *Salah!* 😔 Coba lagi yuk!`, m)
    }
}

function similarity(s1, s2) {
    let longer = s1.length > s2.length ? s1 : s2
    let shorter = s1.length > s2.length ? s2 : s1
    let longerLength = longer.length
    if (longerLength === 0) return 1.0
    return (longerLength - editDistance(longer, shorter)) / parseFloat(longerLength)
}

function editDistance(s1, s2) {
    s1 = s1.toLowerCase()
    s2 = s2.toLowerCase()
    let costs = []
    for (let i = 0; i <= s1.length; i++) {
        let lastValue = i
        for (let j = 0; j <= s2.length; j++) {
            if (i === 0) costs[j] = j
            else if (j > 0) {
                let newValue = costs[j - 1]
                if (s1.charAt(i - 1) !== s2.charAt(j - 1))
                    newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1
                costs[j - 1] = lastValue
                lastValue = newValue
            }
        }
        if (i > 0) costs[s2.length] = lastValue
    }
    return costs[s2.length]
}

handler.exp = 0

handler.register = true
handler.limit = true
module.exports = handler