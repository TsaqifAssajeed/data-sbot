const axios = require('axios')
const fs = require("fs")
const path = require("path")
const uploadImage = require("../lib/uploadImage")

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || q.mediaType || ''

  if (!text) {
    return m.reply(`Harap sertakan nama orangnya! Contoh: *${usedPrefix + command} Budi*`)
  }

  if (/image\/(png|jpe?g|gif)/.test(mime) && !/webp/.test(mime)) {
    await conn.reply(m.chat, 'Tunggu sebentar, sedang memproses...', m)
    try {
      const img = await q.download?.()
      if (!img) throw new Error('Gagal mengunduh gambar.')

      // Upload ke CDN untuk mendapatkan URL
      const uploadedUrl = await uploadImage(img)

      const prompt = `Take the main character in the picture, make the character as detailed as possible from his facial expression, his facial expression should be 100% similar, from that character then make a Pixar style movie poster inspired by Finding Nemo, underwater sea background, colorful corals and fish, cinematic lighting. The character's body becomes a mermaid swimming. The text on the poster should say "Finding ${text}" with bold Pixar style font.`

      const old = new Date()

      // Panggil API AlyaChan
      const response = await axios.get(`${global.alyachan}/api/ai-edit`, {
        params: {
          image: uploadedUrl,
          prompt: prompt,
          apikey: global.alyachankey
        }
      })

      const images = response.data.data.images
      if (!images || images.length === 0) {
        throw new Error("❌ Tidak ada gambar yang dihasilkan dari API")
      }

      // Tunggu 10 detik sebelum mengirim hasil
      await new Promise(resolve => setTimeout(resolve, 10000))

      // Proses dan kirim kedua gambar
      for (let i = 0; i < Math.min(images.length, 2); i++) {
        const imageUrl = images[i].url
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' })
        const resultImage = Buffer.from(imageResponse.data)

        // Simpan hasil sementara
        const tempPath = path.join(
          process.cwd(),
          "tmp",
          `finding_${Date.now()}_${i}.png`
        )
        fs.writeFileSync(tempPath, resultImage)

        // Kirim gambar
        await conn.sendMessage(
          m.chat,
          {
            image: resultImage,
            caption: `🍟 *Finding ${text}* selesai dalam: ${new Date() - old} ms. Gambar ${i + 1})`
          },
          { quoted: m }
        )

        // Cleanup
        setTimeout(() => {
          try {
            if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath)
          } catch (err) {
            console.error("Cleanup error:", err)
          }
        }, 30000)
      }
    } catch (e) {
      console.error('Error:', e)
      m.reply(`❌ Terjadi error saat memproses: ${e.message || e}\nCoba lagi nanti atau pastikan gambar valid (PNG/JPEG/GIF)!`)
    }
  } else {
    m.reply(
      `Kirim gambar (PNG/JPEG/GIF) dengan caption *${usedPrefix + command} nama_orang* atau reply gambar dengan *${usedPrefix + command} nama_orang*`
    )
  }
}

handler.help = ['finding <nama>']
handler.command = ['finding']
handler.tags = ['ai', 'maker']
handler.premium = true
handler.limit = 5
handler.register = true

module.exports = handler