const axios = require('axios')

let handler = async (m, { conn, args }) => {
  let kota = (args[0]?.toLowerCase() || 'jakarta')

  try {
    const { data } = await axios.get(`${global.apibtc}/api/tools/jadwalshalat?kota=${kota}&apikey=${global.btc}`)

    if (!data || !data.result || !data.result.data || !data.result.data.length) {
      return conn.reply(m.chat, 'Jadwal sholat tidak ditemukan. Pastikan nama kota sesuai.', m)
    }

    let info = data.result.data[0]
    let t = info.timings
    let d = info.date

    let teks = `
*📅 Tanggal:* ${d.readable}
*🏙️ Kota:* ${kota.charAt(0).toUpperCase() + kota.slice(1)}

╭───〔 *Jadwal Sholat* 〕───✧
├ Imsak    : ${t.Imsak}
├ Subuh    : ${t.Fajr}
├ Terbit   : ${t.Sunrise}
├ Dzuhur   : ${t.Dhuhr}
├ Ashar    : ${t.Asr}
├ Maghrib  : ${t.Maghrib}
├ Isya     : ${t.Isha}
╰────────────•`.trim()

    await conn.sendMessage(m.chat, {
      text: teks,
      contextInfo: {
        externalAdReply: {
          title: `Jadwal Sholat ${kota.charAt(0).toUpperCase() + kota.slice(1)}`,
          body: "Waktu terbaik untuk mendekatkan diri pada-Nya 🤲",
          thumbnailUrl: "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/Warna-Cat-Masjid-yang-Bagus.jpg",
          sourceUrl: "https://botcahx.eu.org",
          mediaType: 1,
          renderLargerThumbnail: true, // ini yang bikin image besar
        }
      }
    }, { quoted: m })
  } catch (e) {
    console.error(e)
    await conn.reply(m.chat, 'Terjadi kesalahan saat mengambil jadwal sholat.', m)
  }
}

handler.help = ['jadwalsholat <kota>']
handler.tags = ['islami']
handler.command = /^((jadwal)?sh?[oa]lat)$/i

handler.register = true
handler.limit = true
module.exports = handler
