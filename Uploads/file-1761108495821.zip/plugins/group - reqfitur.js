/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const fs = require('fs');
const path = require('path');

// Path untuk menyimpan data request, akses, dan error
const databaseDir = path.resolve(__dirname, '../lib');
const dataRequestPath = path.resolve(databaseDir, 'datarequest.json');
const dataAksesPath = path.resolve(databaseDir, 'DataAksesRequest.json');
const dataErrorPath = path.resolve(databaseDir, 'dataError.json');

// Fungsi untuk menginisialisasi direktori dan file
function initializeFiles() {
  try {
    if (!fs.existsSync(databaseDir)) {
      fs.mkdirSync(databaseDir, { recursive: true });
      console.log('Direktori lib dibuat:', databaseDir);
    }
    if (!fs.existsSync(dataRequestPath)) {
      fs.writeFileSync(dataRequestPath, JSON.stringify({ requests: [] }, null, 2));
      console.log('File datarequest.json dibuat:', dataRequestPath);
    }
    if (!fs.existsSync(dataAksesPath)) {
      fs.writeFileSync(dataAksesPath, JSON.stringify({ groups: [] }, null, 2));
      console.log('File DataAksesRequest.json dibuat:', dataAksesPath);
    }
    if (!fs.existsSync(dataErrorPath)) {
      fs.writeFileSync(dataErrorPath, JSON.stringify({ errors: [] }, null, 2));
      console.log('File dataError.json dibuat:', dataErrorPath);
    }
  } catch (e) {
    console.error('Gagal menginisialisasi file:', e);
    throw new Error('Gagal menginisialisasi file: ' + e.message);
  }
}

initializeFiles();

function loadDataRequest() {
  try {
    const rawData = fs.readFileSync(dataRequestPath);
    const data = JSON.parse(rawData);
    return { requests: Array.isArray(data.requests) ? data.requests : [] };
  } catch (e) {
    console.error('Gagal memuat data request:', e);
    return { requests: [] }; 
  }
}

function loadDataAkses() {
  try {
    const rawData = fs.readFileSync(dataAksesPath);
    const data = JSON.parse(rawData);
    return { groups: Array.isArray(data.groups) ? data.groups : [] };
  } catch (e) {
    console.error('Gagal memuat data akses:', e);
    return { groups: [] }; 
  }
}

function loadDataError() {
  try {
    const rawData = fs.readFileSync(dataErrorPath);
    const data = JSON.parse(rawData);
    return { errors: Array.isArray(data.errors) ? data.errors : [] };
  } catch (e) {
    console.error('Gagal memuat data error:', e);
    return { errors: [] }; 
  }
}

let dataRequest = loadDataRequest();
let dataAkses = loadDataAkses();
let dataError = loadDataError();

function saveDataRequest() {
  fs.writeFileSync(dataRequestPath, JSON.stringify(dataRequest, null, 2));
}

function saveDataAkses() {
  fs.writeFileSync(dataAksesPath, JSON.stringify(dataAkses, null, 2));
}

function saveDataError() {
  fs.writeFileSync(dataErrorPath, JSON.stringify(dataError, null, 2));
}

function isGroupAllowed(chatId) {
  return dataAkses.groups.includes(chatId);
}

function capital(str) {
  return str.replace(/\b\w/g, char => char.toUpperCase());
}

let handler = async (m, { conn, text, command, isOwner }) => {

  const Reply = (msg) => conn.reply(m.chat, msg, m);

  const mess = { owner: `‼️ *AKSES DITOLAK*\n\n> Mohon maaf, perintah ini hanya bisa digunakan oleh owner.` };

  if (!isOwner && ['akses', 'delakses'].includes(command.toLowerCase())) {
    return Reply(mess.owner);
  }

  switch (command.toLowerCase()) {
    case 'akses': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (isGroupAllowed(m.chat)) return Reply('✅ *Grup ini sudah memiliki akses.*');
      dataAkses.groups.push(m.chat);
      saveDataAkses();
      Reply('✅ *Berhasil menambahkan akses untuk grup ini.*');
      break;
    }

    case 'delakses': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (!isGroupAllowed(m.chat)) return Reply('‼️ *Grup ini belum memiliki akses.*');
      dataAkses.groups = dataAkses.groups.filter(g => g !== m.chat);
      saveDataAkses();
      Reply('✅ *Berhasil mencabut akses untuk grup ini.*');
      break;
    }

    case 'req': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (!isGroupAllowed(m.chat)) return Reply(`‼️ *AKSES DITOLAK*\n\n> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.akses*.`);
      if (!text) return Reply('‼️ *FORMAT TIDAK LENGKAP*\n\n– Contoh penggunaan :\n> .req fitur fake notif dana');

      const requestText = text.trim();
      const username = `@${m.sender.split('@')[0]}`;
      dataRequest.requests.push({ id: dataRequest.requests.length + 1, feature: requestText, user: username });
      saveDataRequest();
      
      await conn.sendMessage(m.chat, {
        text: `✅ *BERHASIL REQUEST FITUR*\n\n– ${requestText}`,
        mentions: [m.sender],
        buttons: [
          { buttonId: `.reqlist`, buttonText: { displayText: '📋 LIHAT LIST' }, type: 1 }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      break;
    }

    case 'error': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (!isGroupAllowed(m.chat)) return Reply(`‼️ *AKSES DITOLAK*\n\n> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.akses*.`);
      if (!text) return Reply('‼️ *FORMAT TIDAK LENGKAP*\n\n– Contoh penggunaan :\n> .error fitur notif dana gagal kirim');

      const errorText = text.trim();
      const username = `@${m.sender.split('@')[0]}`;
      dataError.errors.push({ id: dataError.errors.length + 1, error: errorText, user: username });
      saveDataError();
      
      // Mengirim pesan dengan button untuk melihat reqlist
      await conn.sendMessage(m.chat, {
        text: `✅ *BERHASIL LAPOR ERROR*\n\n– ${errorText}`,
        mentions: [m.sender],
        buttons: [
          { buttonId: `.reqlist`, buttonText: { displayText: '📋 LIHAT LIST' }, type: 1 }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      break;
    }

    case 'reqlist': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (!isGroupAllowed(m.chat)) return Reply(`‼️ *AKSES DITOLAK*\n\n> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.akses*.`);

      let listText = '*‼️ REQUEST FITUR DAN LAPOR ERROR*\n\n';

      // Daftar Request Fitur
      listText += '*REQUEST FITUR :*\n\n';
      if (dataRequest.requests.length === 0) {
        listText += 'tidak ada request fitur saat ini.\n';
      } else {
        dataRequest.requests.forEach(req => {
          listText += `${req.id}. ${req.feature} ${req.user}\n`;
        });
      }

      // Daftar Error
      listText += '\n*FITUR ERROR :*\n\n';
      if (dataError.errors.length === 0) {
        listText += 'tidak ada laporan error saat ini.\n';
      } else {
        dataError.errors.forEach(err => {
          listText += `${err.id}. ${err.error} ${err.user}\n`;
        });
      }

      Reply(listText);
      break;
    }

    case 'delreq': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (!isGroupAllowed(m.chat)) return Reply(`‼️ *AKSES DITOLAK*\n\n> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.akses*.`);
      if (!text) return Reply('‼️ *FORMAT TIDAK LENGKAP*\n\n– Contoh penggunaan :\n> .delreq 1');

      const reqId = parseInt(text.trim());
      const requestIndex = dataRequest.requests.findIndex(req => req.id === reqId);
      if (requestIndex === -1) return Reply(`‼️ Request dengan ID ${reqId} tidak ditemukan.`);

      const removedRequest = dataRequest.requests.splice(requestIndex, 1)[0];
      // Reassign IDs to maintain sequential order
      dataRequest.requests.forEach((req, index) => {
        req.id = index + 1;
      });
      saveDataRequest();
      
      // Mengirim pesan dengan button untuk melihat reqlist
      await conn.sendMessage(m.chat, {
        text: `✅ *Request "${removedRequest.feature}" berhasil dihapus.*`,
        mentions: [m.sender],
        buttons: [
          { buttonId: `.reqlist`, buttonText: { displayText: '📋 LIHAT LIST' }, type: 1 }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      break;
    }

    case 'delerror': {
      if (!m.isGroup) return Reply('Perintah ini hanya bisa digunakan di grup!');
      if (!isGroupAllowed(m.chat)) return Reply(`‼️ *AKSES DITOLAK*\n\n> Grup ini belum memiliki akses, minta pada owner untuk menambahkan akses grup dengan *.akses*.`);
      if (!text) return Reply('‼️ *FORMAT TIDAK LENGKAP*\n\n– Contoh penggunaan :\n> .delerror 1');

      const errorId = parseInt(text.trim());
      const errorIndex = dataError.errors.findIndex(err => err.id === errorId);
      if (errorIndex === -1) return Reply(`‼️ Error dengan ID ${errorId} tidak ditemukan.`);

      const removedError = dataError.errors.splice(errorIndex, 1)[0];
      // Reassign IDs to maintain sequential order
      dataError.errors.forEach((err, index) => {
        err.id = index + 1;
      });
      saveDataError();
      
      // Mengirim pesan dengan button untuk melihat reqlist
      await conn.sendMessage(m.chat, {
        text: `✅ *Error "${removedError.error}" berhasil dihapus.*`,
        mentions: [m.sender],
        buttons: [
          { buttonId: `.reqlist`, buttonText: { displayText: '📋 LIHAT LIST' }, type: 1 }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
      break;
    }

    default:
      Reply('Perintah tidak dikenali.');
      break;
  }
};

handler.help = [
  'akses',
  'delakses',
  'req <teks>',
  'error <teks>',
  'reqlist',
  'delreq <nomor>',
  'delerror <nomor>'
];
handler.tags = ['group'];
handler.command = /^(akses|delakses|req|error|reqlist|delreq|delerror)$/i;
handler.group = true;

handler.register = true
handler.limit = true
module.exports = handler;