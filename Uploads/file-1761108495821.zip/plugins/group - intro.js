const fs = require('fs').promises;
const path = require('path');

// Default intro
const defaultIntro = `╭── 「 🌟 Kartu Intro 」 ──╮
│ 👤 Nama        : 
│ 🎂 Umur        : 
│ 🎓 Kelas       : 
│ 🏙️ Kota        : 
│ 🎯 Tujuan Join : 
╰───────────────────────╯
`;

// Path to database file
const dbPath = path.join(__dirname, '../database/intro.json');

// Ensure database file exists and is valid
async function ensureDbFile() {
    try {
        await fs.access(dbPath);
        // Check if file is empty or invalid
        const data = await fs.readFile(dbPath, 'utf8');
        if (!data || data.trim() === '') {
            await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
        }
        // Try parsing to ensure valid JSON
        JSON.parse(data);
    } catch (error) {
        console.log('Membuat file database baru:', error.message);
        await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
    }
}

// Load database
async function loadDb() {
    await ensureDbFile();
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error membaca database:', error.message);
        return {};
    }
}

// Save database
async function saveDb(data) {
    try {
        await fs.writeFile(dbPath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error menyimpan database:', error.message);
    }
}

let handler = async (m, { text, conn }) => {
    // Log untuk debugging
    console.log('Objek m:', m);

    // Pastikan m ada
    if (!m) {
        console.error('Objek m tidak ditemukan');
        return conn.reply(m.chat, 'Terjadi kesalahan. Silakan coba lagi.', m);
    }

    const groupId = m.chat;

    // Ekstrak perintah dari m.text jika m.command tidak ada
    let command = '';
    if (m.command) {
        command = m.command.toLowerCase();
    } else if (m.text && typeof m.text === 'string') {
        // Ambil perintah tanpa prefix (misalnya, '.' atau '/')
        command = m.text.replace(/^[./!#]/, '').split(' ')[0].toLowerCase();
    }

    // Handle .intro command
    if (command === 'intro') {
        const db = await loadDb();
        const introText = db[groupId] || defaultIntro;
        return conn.reply(m.chat, introText, m);
    }

    // Handle .setintro command
    if (command === 'setintro') {
        if (!text) {
            return conn.reply(m.chat, 'Silakan masukkan teks intro baru untuk grup ini.', m);
        }

        const newIntro = text.trim();
        const db = await loadDb();
        db[groupId] = newIntro;
        await saveDb(db);

        return conn.reply(m.chat, `Intro untuk grup ini berhasil diatur menjadi:\n\n${newIntro}\n\n> ketik .intro untuk melihat preview nya`, m);
    }

    // Jika perintah tidak dikenali
    return conn.reply(m.chat, 'Perintah tidak valid. Gunakan .intro atau .setintro.', m);
};

handler.command = /^(intro|setintro)$/i;

handler.register = true
handler.limit = true
module.exports = handler;