let handler = (m) => m;

handler.before = async function (m, { isAdmin, isBotAdmin }) {
    // Validasi awal
    if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) {
        return true;
    }

    let chat = global.db.data.chats[m.chat] || {};
    if (!chat.antiupsw) {
        return true;
    }

    // Deteksi GroupStatusMention
    const isGroupStatusMention = 
        m.message?.groupStatusMentionMessage || 
        (m.type === "groupStatusMentionMessage") ||
        (m.message?.extendedTextMessage?.contextInfo?.isGroupStatusMention);

    if (!isGroupStatusMention) {
        return true;
    }

    let sender = m.participant || m.key.participant || m.key.remoteJid;

    // Jika pengirim adalah admin, hanya peringatan teks
    if (isAdmin) {
        await this.sendMessage(m.chat, { 
            text: `ℹ️ @${sender.split('@')[0]} (Admin) terdeteksi mengirim UpSW, tetapi admin bebas.`,
            contextInfo: { mentionedJid: [sender] }
        }, { quoted: m });
        return true;
    }

    // Jika bot bukan admin, beri peringatan saja
    if (!isBotAdmin) {
        await this.sendMessage(m.chat, { 
            text: `⁉️ Saya bukan admin, jadi tidak bisa menghapus pesan atau menendang pengguna ini.`
        }, { quoted: m });
        return true;
    }

    // Ambil jumlah peringatan pengguna
    let warn = global.db.data.users[sender].warn || 0;
    const maxWarn = 3; // Setel batas peringatan menjadi 2

    if (warn < maxWarn) {
        // Menambah peringatan
        global.db.data.users[sender].warn += 1;
        await this.sendMessage(m.chat, { 
            text: `⚠️ *PERINGATAN PELANGGARAN!* ⚠️\n\n` +
                  `*Nama:* @${sender.split('@')[0]}\n` +
                  `*Pelanggaran:* Mengunggah status yang menandai grup ini!\n` +
                  `Anda telah menerima peringatan *${warn + 1}/${maxWarn}*. Jika mencapai *${maxWarn}*, Anda akan dikeluarkan.`,
            contextInfo: { mentionedJid: [sender] }
        }, { quoted: m });

        // Menghapus pesan yang mengandung groupStatusMentionMessage
        try {
            await this.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: m.key.id, 
                    participant: sender 
                }
            });
        } catch (error) {
            console.error('❌ Gagal menghapus pesan UpSW:', error);
        }

    } else {
        // Reset peringatan dan keluarkan pengguna
        global.db.data.users[sender].warn = 0;
        await this.sendMessage(m.chat, { 
            text: `⛔ *PENGGUNA DIHAPUS!* ⛔\n\n` +
                  `*Nama:* @${sender.split('@')[0]}\n` +
                  `*Pelanggaran:* Sudah mencapai batas peringatan ${maxWarn}. Pengguna akan dikeluarkan dari grup.`
        }, { quoted: m });

        // Menghapus pesan yang mengandung groupStatusMentionMessage
        try {
            await this.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: m.key.id, 
                    participant: sender 
                }
            });
        } catch (error) {
            console.error('❌ Gagal menghapus pesan UpSW:', error);
        }

        // Tunggu 1 detik lalu kick
        await new Promise(resolve => setTimeout(resolve, 1000));
        try {
            await this.groupParticipantsUpdate(m.chat, [sender], 'remove');
        } catch (error) {
            console.error(`❌ Gagal mengeluarkan ${sender} dari grup:`, error);
        }
    }

    return true;
};

handler.help = ['on antiupsw'];
handler.tags = ['group'];
handler.group = true;

handler.register = true

module.exports = handler;
