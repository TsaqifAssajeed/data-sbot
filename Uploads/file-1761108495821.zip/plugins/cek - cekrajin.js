let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.rajin)}”`, m)
}
handler.help = ['cekrajin']
handler.tags = ['cek']
handler.command = /^(cekrajin)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.rajin = [
'enggak rajin', 'rajin kalo gak di suruh', 'biasa aja rajin nya', 'lu rajin bgt njir ampe seluruh rumah pun mau lu bersihin', 'rajin sih cuma lu lgbt', 'rajin banget sampe rumah tetangga pun mau di bersihin njir', 'lu nggak rajin, lu malasss 🧢', 'rajin', 'lu rajin bgt njir', 'rajin banget sampe sampe rumah bening tiap hari gara gara elu', 'lu pemalas cok, diluar lagi kiamat pun lu gak lari menyelamatkan diri saking malasnya',
]