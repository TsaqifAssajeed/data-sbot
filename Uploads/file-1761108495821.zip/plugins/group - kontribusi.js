// ✨ Plugin group - kontribusi ✨

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../database/kontribusiGC.json');
if (!fs.existsSync(path.dirname(DB_PATH))) fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

let DB = {};
try { DB = JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); } catch { DB = {}; }

const saveDB = () => fs.writeFileSync(DB_PATH, JSON.stringify(DB, null, 2));

function normalizeJid(jid = '') {
  return String(jid).replace(/[^0-9]/g, '') + '@s.whatsapp.net';
}

function ensure(gid, uid) {
  uid = normalizeJid(uid);
  if (!DB[gid]) DB[gid] = {};
  if (!DB[gid][uid]) DB[gid][uid] = { pesan: 0, kata: 0, media: 0, stiker: 0, tambah: 0, kick: 0 };
  return DB[gid][uid];
}

function getOwnerJids() {
  const raw = global.owner || [];
  let nums = [];
  for (const v of raw) {
    if (!v) continue;
    if (Array.isArray(v)) nums.push(v[0]);
    else nums.push(v);
  }
  nums = nums.map(n => String(n).replace(/[^0-9]/g, '')).filter(Boolean);
  return nums.map(n => n + '@s.whatsapp.net');
}

function score(d) {
  return d.pesan * 1 + d.kata * 0.1 + d.media * 5 + d.stiker * 3 + d.tambah * 15 + d.kick * 10;
}

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Khusus grup.');

  const gid = m.chat;
  const cmd = (command || '').toLowerCase();

  if (cmd === 'resetkontribusi') {
    const ownerJids = getOwnerJids();
    const allowed = isAdmin || isOwner || ownerJids.includes(normalizeJid(m.sender));
    if (!allowed) return m.reply('❌ Hanya admin atau owner bot yang bisa mereset.');
    DB[gid] = {};
    saveDB();
    return m.reply('✅ Data kontribusi grup ini sudah direset.');
  }

  if (!DB[gid] || !Object.keys(DB[gid]).length) return m.reply('ℹ️ Belum ada data kontribusi di grup ini.');

  // Gabung duplikat JID (lid -> jid)
  const merged = {};
  for (const [id, data] of Object.entries(DB[gid])) {
    const normId = normalizeJid(id);
    if (!merged[normId]) merged[normId] = { ...data };
    else {
      merged[normId].pesan += data.pesan;
      merged[normId].kata += data.kata;
      merged[normId].media += data.media;
      merged[normId].stiker += data.stiker;
      merged[normId].tambah += data.tambah;
      merged[normId].kick += data.kick;
    }
  }
  DB[gid] = merged; // Simpan kembali DB yang sudah dibersihkan
  saveDB();

  const rows = Object.entries(merged)
    .map(([id, d]) => ({ id, ...d, skor: score(d) }))
    .sort((a, b) => b.skor - a.skor);

  let txt = `👑 *Papan Peringkat Kontribusi Admin* 👑\n\n`;
  txt += `Berikut adalah peringkat kontribusi para admin di grup ini:\n\n`;
  for (let i = 0; i < rows.length; i++) {
    const u = rows[i];
    txt += `*${i + 1}.* @${u.id.split('@')[0]}\n`;
    txt += `   ✨ *Skor Kontribusi: ${u.skor.toFixed(1)}*\n`;
    txt += `   --------------------\n`;
    txt += `   💬 Pesan: *${u.pesan}*\n`;
    txt += `   ✍️ Kata: *${u.kata}*\n`;
    txt += `   🖼️ Media: *${u.media}*\n`;
    txt += `   🧩 Stiker: *${u.stiker}*\n`;
    txt += `   ➕ Tambah Anggota: *${u.tambah}*\n`;
    txt += `   ➖ Keluarkan Anggota: *${u.kick}*\n\n`;
  }
  txt += `_Skor: Pesan (1), Kata (0.1), Media (5), Stiker (3), Tambah (15), Kick (10)_`;

  await conn.sendMessage(m.chat, { text: txt, mentions: rows.map(u => u.id) }, { quoted: m });
};

handler.help = ['kontribusi', 'resetkontribusi'];
handler.tags = ['group'];
handler.command = /^(kontribusi|resetkontribusi)$/i;
handler.group = true;

handler.all = async function (m) {
  if (!m.isGroup) return;

  let meta;
  try { meta = await this.groupMetadata(m.chat); } catch { return; }
  if (!meta?.participants) return;

  const ownerJids = new Set(getOwnerJids());
  const botJid = normalizeJid(this.user?.id);

  // ✅ Ambil admin pakai jid (bukan lid)
  const adminSet = new Set(
    meta.participants
      .filter(p => p.admin)
      .map(p => normalizeJid(p.jid || p.id))
  );

  // Tambah owner & bot ke daftar admin
  for (const o of ownerJids) adminSet.add(o);
  if (botJid) adminSet.add(botJid);

  // Cek siapa aktor pesan/event
  let actor = m.sender;
  if ([27, 28].includes(m.messageStubType)) {
    actor = m.participant || m.key?.participant || m.sender;
  }

  // ✅ Kalau actor ada di participant, ambil nomor WA asli
  const partData = meta.participants.find(p => p.id === actor || p.jid === actor || p.lid === actor);
  if (partData) actor = partData.jid || partData.id;

  actor = normalizeJid(actor);

  // Kalau bukan admin/superadmin/owner, skip
  if (!adminSet.has(actor)) return;

  const d = ensure(m.chat, actor);

  const text = (m.text || m.msg?.text || '').toString();
  if (text) {
    d.pesan += 1;
    const wc = text.trim().split(/\s+/).filter(Boolean).length;
    d.kata += wc;
   // console.log(`[KONTRIBUSI] ${actor} +Pesan(+1), +Kata(+${wc}) @ ${m.chat}`);
  }

  if (m.mtype === 'stickerMessage') {
    d.stiker += 1;
   // console.log(`[KONTRIBUSI] ${actor} +Stiker(+1) @ ${m.chat}`);
  }

  if (['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage'].includes(m.mtype)) {
    d.media += 1;
   // console.log(`[KONTRIBUSI] ${actor} +Media(+1) @ ${m.chat}`);
  }

  if (m.messageStubType === 27) {
    d.tambah += 1;
   // console.log(`[KONTRIBUSI] ${actor} +Tambah(+1) @ ${m.chat}`);
  } else if (m.messageStubType === 28) {
    d.kick += 1;
    //console.log(`[KONTRIBUSI] ${actor} +Kick(+1) @ ${m.chat}`);
  }

  saveDB();
};

handler.register = true

module.exports = handler;