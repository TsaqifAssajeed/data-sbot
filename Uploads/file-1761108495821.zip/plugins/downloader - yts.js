let yts = require('yt-search');
let fetch = require('node-fetch');
let { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, usedPrefix, text, command }) => {
  if (!text) {
    console.log('No query provided');
    throw `*• Example:* ${usedPrefix + command} You are the reason`;
  }

  try {
    console.log('Starting YouTube search for:', text);
    let results = await yts(text);
    let videos = results.all.filter(v => v.type === 'video');

    if (!videos.length) {
      console.log('No videos found');
      throw 'No videos found for your query!';
    }

    // Prepare list message sections
    let sections = [];
    let textFallback = `🔍 *YouTube Search Results for "${text}"*\n\nReply with a number to select:\n`;

    videos.slice(0, 5).forEach((v, i) => { // Limit to 5 for simplicity
      const index = i + 1;
      sections.push({
        title: v.title.length > 20 ? v.title.substring(0, 17) + '...' : v.title,
        rows: [
          {
            title: '🎵 Download Audio',
            description: `Duration: ${v.timestamp} | ${v.views} views`,
            id: `.play ${v.url}`
          },
          {
            title: '🎥 Download Video',
            description: `Duration: ${v.timestamp} | ${v.views} views`,
            id: `.ytmp4 ${v.url}`
          }
        ]
      });
      textFallback += `${index}a. ${v.title} (Audio) [${v.timestamp}]\n${index}v. ${v.title} (Video) [${v.timestamp}]\n──────────\n`;
    });

    // Try sending interactive list message
    try {
      console.log('Attempting to send interactive message');
      let listMessage = {
        title: 'Click here!',
        sections
      };
      let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `🔍 *YouTube Search Results for "${text}"*\n\nSelect an option to download:`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: '_YouTube Downloader_'
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                title: '✨ YouTube Search ✨'
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify(listMessage)
                  }
                ]
              })
            })
          }
        }
      }, { userJid: m.chat, quoted: m });
      await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
      console.log('Interactive message sent successfully');
    } catch (e) {
      console.error('Interactive message failed:', e);
      // Fallback to text message
      textFallback += `Example: Reply "1a" for audio or "1v" for video`;
      await m.reply(textFallback);
    }

  } catch (e) {
    console.error('Search error:', e);
    m.reply('An error occurred while searching. Please try again.');
  }
};

// Handle text reply for fallback
handler.all = async (m, { conn }) => {
  if (!m.text || !m.quoted || !m.quoted.text.includes('YouTube Search Results')) return;

  let selection = m.text.trim().toLowerCase();
  let match = selection.match(/^(\d+)(a|v)$/);
  if (!match) return;

  let index = parseInt(match[1]) - 1;
  let type = match[2] === 'a' ? 'audio' : 'video';

  try {
    console.log('Processing text selection:', selection);
    let results = await yts(m.quoted.text.split('"')[1]); // Extract query from quoted message
    let videos = results.all.filter(v => v.type === 'video');
    if (!videos[index]) throw 'Invalid selection!';

    let video = videos[index];
    let url = video.url;

    await m.reply('⏳ Please wait, downloading...');
    const btc = 'your_api_key_here'; // Replace with actual API key
    const response = await fetch(`https://api.botcahx.eu.org/api/dowloader/yt?url=${encodeURIComponent(url)}&apikey=${btc}`);
    const result = await response.json();

    if (!result.status || !result.result) throw 'Error: Unable to fetch download link';

    if (type === 'audio') {
      if (result.result.mp3) {
        await conn.sendMessage(m.chat, {
          audio: { url: result.result.mp3 },
          mimetype: 'audio/mpeg'
        }, { quoted: m });
      } else {
        throw 'Error: Audio download link not available';
      }
    } else if (type === 'video') {
      if (result.result.mp4) {
        await conn.sendMessage(m.chat, {
          video: { url: result.result.mp4 },
          mimetype: 'video/mp4'
        }, { quoted: m });
      } else {
        throw 'Error: Video download link not available';
      }
    }
  } catch (e) {
    console.error('Download error:', e);
    m.reply('An error occurred while downloading. Please try again.');
  }
};

// Handle button selection
handler.button = async (m, { conn }) => {
  let id = m.msg.selectedRowId;
  if (!id || !id.startsWith('.ytsselect')) return;

  let [_, type, videoId, url] = id.split('_');
  try {
    console.log('Processing button selection:', id);
    await m.reply('⏳ Please wait, downloading...');
    //const btc = 'your_api_key_here'; // Replace with actual API key
    const response = await fetch(`https://api.botcahx.eu.org/api/dowloader/yt?url=${encodeURIComponent(url)}&apikey=${btc}`);
    const result = await response.json();

    if (!result.status || !result.result) throw 'Error: Unable to fetch download link';

    if (type === 'audio') {
      if (result.result.mp3) {
        await conn.sendMessage(m.chat, {
          audio: { url: result.result.mp3 },
          mimetype: 'audio/mpeg'
        }, { quoted: m });
      } else {
        throw 'Error: Audio download link not available';
      }
    } else if (type === 'video') {
      if (result.result.mp4) {
        await conn.sendMessage(m.chat, {
          video: { url: result.result.mp4 },
          mimetype: 'video/mp4'
        }, { quoted: m });
      } else {
        throw 'Error: Video download link not available';
      }
    }
  } catch (e) {
    console.error('Button download error:', e);
    m.reply('An error occurred while downloading. Please try again.');
  }
};

handler.help = ['', 'earch'].map(v => 'yts' + v + ' *[query]*');
handler.tags = ['tools', 'downloader'];
handler.command = /^yts(earch)?$/i;
handler.register = true;

handler.limit = true
module.exports = handler;