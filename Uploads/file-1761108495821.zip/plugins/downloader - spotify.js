// ✨ Plugin downloader - spotify ✨

const fetch = require("node-fetch");

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `*🚩 Masukkan URL Spotify!*\n\nExample:\n${usedPrefix + command} https://open.spotify.com/track/3zakx7RAwdkUQlOoQ7SJRt`;
  
  if (args[0].match(/https:\/\/open.spotify.com/gi)) {
    m.reply(wait);
    try {
      const res = await fetch(`${global.alyachan}/api/spotify-dl?apikey=${global.alyachankey}&url=${args[0]}`);
      let json = await res.json();
      
      if (!json.status) throw new Error(json.message || 'API error');
      
      const result = json.data;
      const {
        thumbnail = 'https://www.scdn.co/i/_global/open-graph-default.png',
        title,
        artist = 'Unknown Artist',
        duration,
        popularity,
        publish,
        url: audio
      } = result;
      
      let captionvid = ` ∘ Title: ${title}\n∘ Artist: ${artist}\n∘ Duration: ${duration}\n∘ Popularity: ${popularity}\n∘ Publish: ${publish}`;
      
      let pesan = await conn.sendMessage(m.chat, {
        text: captionvid,
        contextInfo: {
          externalAdReply: {
            title: "Spotify Downloader",
            body: "",
            thumbnailUrl: thumbnail,
            sourceUrl: args[0],
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      });
      
      await conn.sendMessage(m.chat, {
        audio: {
          url: audio
        },
        mimetype: 'audio/mpeg',
        contextInfo: {
          externalAdReply: {
            title: title,
            body: "",
            thumbnailUrl: thumbnail,
            sourceUrl: args[0],
            mediaType: 1,
            renderLargerThumbnail: false
          }
        }
      }, {
        quoted: m
      });
    } catch (e) {
      throw `🚩 Error: ${e.message || eror}. Pastikan apikey AlyaChan valid!`;
    }
  } else {
    throw `*🚩 Input harus URL Spotify! Contoh: ${usedPrefix + command} https://open.spotify.com/track/3zakx7RAwdkUQlOoQ7SJRt*`;
  }
};

handler.help = ['spotify'];
handler.command = /^(spotify)$/i;
handler.tags = ['downloader'];
handler.limit = true;
handler.register = true;
module.exports = handler;