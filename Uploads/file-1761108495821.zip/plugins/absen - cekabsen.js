let handler = async (m, { conn, usedPrefix }) => {
    let id = m.chat
    conn.absen = conn.absen || {}

    if (!(id in conn.absen)) {
        throw `_*Tidak ada absen berlangsung di grup ini!*_\n\nKetik *${usedPrefix}mulaiabsen* untuk memulai absen`
    }

    let d = new Date()
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })

    let absen = conn.absen[id][1]
    // Membuat teks daftar absen berdasarkan nama yang sudah disimpan
    let list = absen.map((participant, index) => {
        return `│ ${index + 1}. ${participant.name} - @${participant.sender.split('@')[0]}`
    }).join('\n')

    // Mengumpulkan ID pengirim untuk mention
    let mentions = absen.map(participant => participant.sender)

    let buttonMessage = {
        text: `*「 ABSEN 」*\n\nTanggal: ${date}\n\n${conn.absen[id][2]}\n\n┌ *Yang sudah absen:*\n│ \n│ Total: ${absen.length}\n${list}\n│ \n└────`,
        footer: `_${namebot}_`,
        buttons: [
            { buttonId: `${usedPrefix}hapusabsen`, buttonText: { displayText: 'Hapus Absen' }, type: 1 }
        ],
        headerType: 4,
        mentions: mentions // Menambahkan daftar ID pengirim untuk mention
    }
    await conn.sendMessage(m.chat, buttonMessage, { quoted: m })
}

handler.help = ['cekabsen']
handler.tags = ['absen']
handler.command = /^cekabsen$/i
handler.group = true
handler.admin = true
handler.register = true
handler.limit = true
module.exports = handler