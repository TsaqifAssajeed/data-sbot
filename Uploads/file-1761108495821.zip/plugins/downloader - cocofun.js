/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const axios = require('axios')

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`Masukkan link Cocofun!\nContoh: ${usedPrefix}cocofun http://www.icocofun.com/share/post/457616496291?lang=id&pkg=id&share_to=copy_link`)

  // Cek limit pengguna
  let user = global.db.data.users[m.sender]
  if (!user) {
    user = global.db.data.users[m.sender] = { limit: 100 } // Default limit jika user belum terdaftar
  }
  if (user.limit < 10) {
    return m.reply('Maaf, limit kamu tidak cukup! Minimal 10 limit dibutuhkan untuk menggunakan perintah ini.')
  }

  // Kirim pesan "Sedang diproses..."
  await conn.sendMessage(m.chat, { text: '❇️ Sedang diproses...' }, { quoted: m })

  try {
    // Panggil API Cocofun
    const response = await axios.get(`${global.alyachan}/api/cocofun`, {
      params: {
        url: text,
        apikey: global.alyachankey
      }
    })

    const data = response.data
    if (!data.status || !data.data) {
      return m.reply('Maaf, video Cocofun tidak ditemukan')
    }

    // Kurangi limit sebesar 10
    user.limit -= 10

    // Kirim video
    const media = data.data
    const fileName = `cocofun_${Date.now()}.mp4`
    const caption = `📹 *${media.title || 'Cocofun Video'}*\n📝 *Deskripsi*: ${media.desc || 'N/A'}\n❤️ *Likes*: ${media.like || 'N/A'}\n▶️ *Putar*: ${media.play_count || 'N/A'}\n📤 *Share*: ${media.shared || 'N/A'}\n📏 *Resolusi*: ${media.resolution || 'N/A'}\n⏱️ *Durasi*: ${media.duration || 'N/A'} detik`

    await conn.sendFile(m.chat, media.url, fileName, caption, m)
  } catch (e) {
    console.log(e)
    m.reply('Maaf, gagal mengunduh video Cocofun. Pastikan link valid atau coba lagi nanti.')
  }
}

handler.help = ['cocofun <link>']
handler.tags = ['downloader']
handler.command = /^cocofun$/i
handler.owner = false
handler.premium = false
//handler.group = true // Restrict to group chats
handler.private = false
handler.limit = true // Aktifkan limit untuk perintah cocofun

handler.register = true
module.exports = handler