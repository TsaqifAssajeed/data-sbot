/**
 * INFO LOKER - Jobstreet
 * Author: gienetic
 * Base: https://play.google.com/store/apps/details?id=com.jobstreet.jobstreet
 */

const axios = require('axios');
const dayjs = require('dayjs');

const infoloker = {
  cariLoker: async (pekerjaan, kota, jumlah = 10) => {
    const url = "https://jobsearch-api.cloud.seek.com.au/v5/search";
    const params = {
      keywords: pekerjaan,
      where: kota,
      sitekey: "ID",
      sourcesystem: "houston",
      pageSize: jumlah,
      page: 1,
      locale: "id-ID",
    };

    try {
      const res = await axios.get(url, { params });
      const jobs = res.data.data || [];

      if (jobs.length === 0) {
        return { message: "❌ Tidak ada lowongan ditemukan." };
      }

      const hasil = jobs.map((job, i) => {
        const judul = job.title || "-";
        const perusahaan = job.companyName || "-";
        const lokasi = job.locations?.[0]?.label || "-";
        const tanggal = job.listingDate ? dayjs(job.listingDate).format("DD MMM YYYY") : "-";
        const gaji = job.salaryLabel || "❌ Tidak dicantumkan";
        const deskripsi = job.teaser || "-";
        const logo = job.branding?.serpLogoUrl || "-";
        const tautan = `https://id.jobstreet.com/job/${job.id}`;

        return {
          judul,
          perusahaan,
          lokasi,
          tanggal,
          gaji,
          deskripsi,
          logo,
          tautan
        };
      });

      return {
        total: jobs.length,
        jobs: hasil
      };
    } catch (err) {
      throw new Error(`Terjadi kesalahan: ${err.response?.status} - ${err.response?.statusText}`);
    }
  }
};

const handler = async (m, { args, command, conn }) => {
  if (command === 'infoloker' || command === 'loker') {
    if (args.length < 2) {
      return m.reply('Silakan masukkan pekerjaan dan kota, contoh: .infoloker welder Sukabumi');
    }

    // Kirim reaksi proses
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const pekerjaan = args[0];
    const kota = args.slice(1).join(' ');
    try {
      const { total, jobs } = await infoloker.cariLoker(pekerjaan, kota, 10);
      
      // Menambahkan context info langsung ke pesan
      let message = `Ditemukan Loker berjumlah *${total}*\n🔍 Sebagai *${pekerjaan}* di *${kota}*\n\n`;
 
      jobs.slice(0, 10).forEach((job, i) => {
        message += `*${i + 1}. ${job.judul}*\n`;
        message += `🏢 Perusahaan : ${job.perusahaan}\n`;
        message += `📍 Lokasi     : ${job.lokasi}\n`;
        message += `🗓️ Tanggal   : ${job.tanggal}\n`;
        message += `💰 Gaji      : ${job.gaji}\n`;
        message += `📄 Deskripsi : ${job.deskripsi}\n`;
        message += `🔗 Link      : ${job.tautan}\n`;
        message += `───────────────────────────────\n`;
      });

      // Kirim hasil dengan quoted
      await conn.sendMessage(
        m.chat,
        {
          text: message,
          caption: '✅ Pencarian lowongan kerja berhasil.\n> Limit -1'
        },
        {
          quoted: {
            key: {
              fromMe: false,
              participant: '0@s.whatsapp.net',
              remoteJid: 'status@broadcast'
            },
            message: { conversation: 'Info Loker Jobstreet' }
          }
        }
      );

      // Kirim reaksi selesai
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
      // Kirim reaksi gagal
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      m.reply(`gagal: ${error.message}`);
    }
  }
};

handler.command = ['infoloker', 'loker'];
handler.tags = ['internet'];
handler.help = ['loker <pekerjaan> <kota>'];
handler.register = true;
handler.limit = true;

module.exports = handler;