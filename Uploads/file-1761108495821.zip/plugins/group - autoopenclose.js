const schedule = require('node-schedule');
const moment = require('moment-timezone');

// Pengaturan zona waktu
const TIMEZONE_SETTINGS = {
    WIB: {
        enabled: false,
        timezone: 'Asia/Jakarta',
        label: 'WIB'
    },
    WITA: {
        enabled: true,
        timezone: 'Asia/Makassar',
        label: 'WITA'
    },
    WIT: {
        enabled: false,
        timezone: 'Asia/Jayapura',
        label: 'WIT'
    }
};

// Validasi zona waktu
const ACTIVE_TIMEZONE = Object.keys(TIMEZONE_SETTINGS).find(zone => TIMEZONE_SETTINGS[zone].enabled);
if (!ACTIVE_TIMEZONE) throw new Error('Tidak ada zona waktu yang diaktifkan di TIMEZONE_SETTINGS!');
const TIMEZONE = TIMEZONE_SETTINGS[ACTIVE_TIMEZONE].timezone;
const TIMEZONE_LABEL = TIMEZONE_SETTINGS[ACTIVE_TIMEZONE].label;

// Validasi apakah zona waktu valid di moment-timezone
if (!moment.tz.zone(TIMEZONE)) {
   // console.error(`[GCAuto Init] Zona waktu ${TIMEZONE} tidak valid di moment-timezone!`);
    throw new Error(`Zona waktu ${TIMEZONE} tidak valid di moment-timezone!`);
}

// Membersihkan pengaturan waktu tidak valid di database saat inisialisasi
for (const id in global.db.data.chats) {
    const chat = global.db.data.chats[id];
    if (chat.security && (
        chat.security.openHour == null ||
        chat.security.openMinute == null ||
        chat.security.closeHour == null ||
        chat.security.closeMinute == null ||
        isNaN(chat.security.openHour) ||
        isNaN(chat.security.openMinute) ||
        isNaN(chat.security.closeHour) ||
        isNaN(chat.security.closeMinute)
    )) {
       // console.warn(`[GCAuto Init] Menghapus pengaturan tidak valid untuk grup ${id}`);
        chat.security = null;
    }
}

const handler = async (m, { conn, args }) => {
    let chat = global.db.data.chats[m.chat];

    // Jika argumen tidak diberikan, tampilkan contoh
    if (!args[0]) {
        throw `📜 *Contoh:* .gcauto 05:00|21:00\n\n✨ *Artinya:*\n- Grup akan *🔓 Dibuka* jam 05:00 ${TIMEZONE_LABEL}\n- Grup akan *🔒 Ditutup* jam 21:00 ${TIMEZONE_LABEL}\n\n🎯 *Gunakan:*\n- .gcauto off → untuk mematikan fitur\n- .gcauto status → untuk cek status\n- .gcauto 05:00|21:00 | Pesan buka | Pesan tutup`;
    }

    let arg = args.join(' ').trim();

    // Matikan fitur gcauto dan hapus semua pengaturan terkait
    if (arg.toLowerCase() === 'off') {
        if (chat.security) {
            chat.security = null; // Menghapus seluruh objek security
        }
        if (chat.lastSecurityAction) {
            delete chat.lastSecurityAction;
        }
        global.db.data.chats[m.chat] = chat;
        return m.reply('🚨 *Fitur GCAuto dimatikan!* Semua pengaturan otomatis telah dihapus dan kunci dilepas! 🔓');
    }

    if (arg.toLowerCase() === 'status') {
        if (!chat.security) return m.reply('❌ *GCAuto belum aktif!* Yuk, atur dulu kunci grupnya! 🔑');
        let { openHour, openMinute, closeHour, closeMinute, openMsg, closeMsg } = chat.security;
        if (
            openHour == null ||
            openMinute == null ||
            closeHour == null ||
            closeMinute == null ||
            isNaN(openHour) ||
            isNaN(openMinute) ||
            isNaN(closeHour) ||
            isNaN(closeMinute)
        ) {
            //console.error(`[GCAuto Handler] Pengaturan waktu tidak valid untuk grup ${m.chat}:`, chat.security);
            chat.security = null;
            global.db.data.chats[m.chat] = chat;
            return m.reply('❌ *Pengaturan GCAuto tidak valid!* Pengaturan telah direset. Silakan atur ulang dengan .gcauto <jam_buka|jam_tutup>');
        }
        return m.reply(`✅ *GCAuto Aktif!* 🎉\n- 🔓 *Buka Grup:* ${pad(openHour)}:${pad(openMinute)} ${TIMEZONE_LABEL}\n- 🔒 *Tutup Grup:* ${pad(closeHour)}:${pad(closeMinute)} ${TIMEZONE_LABEL}\n\n📢 *Pesan Buka:* ${openMsg || 'default'}\n📢 *Pesan Tutup:* ${closeMsg || 'default'}`);
    }

    let [openTime, closeTime, openMsg, closeMsg] = arg.split('|').map(v => v.trim());
    if (!openTime || !closeTime) {
        throw '⚠️ *Format salah!* Gunakan: .gcauto 05:00|21:00 | [pesan buka] | [pesan tutup]';
    }

    if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(openTime) || !/^([01]?\d|2[0-3]):[0-5]\d$/.test(closeTime)) {
        throw `⏰ *Waktu salah!* Pakai format HH:MM, contoh: .gcauto 05:00|21:00 (${TIMEZONE_LABEL})`;
    }

    let [openHour, openMinute] = openTime.split(':').map(Number);
    let [closeHour, closeMinute] = closeTime.split(':').map(Number);

    // Validasi nilai waktu
    if (
        openHour == null ||
        openMinute == null ||
        closeHour == null ||
        closeMinute == null ||
        isNaN(openHour) ||
        isNaN(openMinute) ||
        isNaN(closeHour) ||
        isNaN(closeMinute)
    ) {
        //console.error(`[GCAuto Handler] Nilai waktu tidak valid untuk grup ${m.chat}:`, { openHour, openMinute, closeHour, closeMinute });
        throw '⚠️ *Nilai waktu tidak valid!* Pastikan format waktu benar (HH:MM).';
    }

    chat.security = {
        openHour,
        openMinute,
        closeHour,
        closeMinute,
        openMsg: openMsg || `🔓 Grup dibuka otomatis jam ${pad(openHour)}:${pad(openMinute)} ${TIMEZONE_LABEL}! Selamat beraktivitas!`,
        closeMsg: closeMsg || `🔒 Grup ditutup otomatis jam ${pad(closeHour)}:${pad(closeMinute)} ${TIMEZONE_LABEL}! Waktunya istirahat! 🌙`
    };

    chat.lastSecurityAction = null;
    global.db.data.chats[m.chat] = chat;

    return m.reply(`🎉 *GCAuto Aktif!* ✨\n\n- 🔓 *Grup Dibuka:* ${pad(openHour)}:${pad(openMinute)} ${TIMEZONE_LABEL}\n- 🔒 *Grup Ditutup:* ${pad(closeHour)}:${pad(closeMinute)} ${TIMEZONE_LABEL}`);
};

// Fungsi untuk memastikan format waktu selalu dua digit
function pad(n) {
    if (n == null || isNaN(n) || typeof n !== 'number') {
       // console.error(`[GCAuto] Nilai waktu tidak valid: ${n}`);
        return '00'; // Nilai default untuk mencegah error
    }
    return n.toString().padStart(2, '0');
}

// Objek untuk melacak waktu pemrosesan terakhir per grup
const lastProcessed = {};

// Penjadwalan menggunakan node-schedule
const job = schedule.scheduleJob({ rule: '* * * * *', tz: TIMEZONE }, async () => {
    try {
        const now = moment.tz(TIMEZONE);
        if (!now.isValid()) {
           // console.error(`[GCAuto Schedule] Waktu tidak valid untuk zona waktu ${TIMEZONE}`);
            return;
        }

        const hour = now.hour();
        const minute = now.minute();

       // console.log(`[GCAuto Debug] Waktu saat ini: ${now.format('YYYY-MM-DD HH:mm:ss')} ${TIMEZONE}, hour: ${hour}, minute: ${minute}, valid: ${now.isValid()}`);

        if (hour == null || minute == null || isNaN(hour) || isNaN(minute) || typeof hour !== 'number' || typeof minute !== 'number') {
           // console.error('[GCAuto Schedule] Nilai hour atau minute tidak valid:', { hour, minute, TIMEZONE });
            return;
        }

        const currentTimeStr = `${pad(hour)}:${pad(minute)}`;
        const chats = global.db.data.chats || {};

        //console.log(`[GCAuto Debug] Jumlah grup di chats: ${Object.keys(chats).length}`);

        for (const id in chats) {
            if (!id.endsWith('@g.us')) continue; // Pastikan hanya grup yang diproses
            const chat = chats[id];
            const setting = chat.security;
            if (!setting) continue; // Lewati grup yang tidak memiliki pengaturan

            // Validasi pengaturan waktu
            if (
                setting.openHour == null ||
                setting.openMinute == null ||
                setting.closeHour == null ||
                setting.closeMinute == null ||
                isNaN(setting.openHour) ||
                isNaN(setting.openMinute) ||
                isNaN(setting.closeHour) ||
                isNaN(setting.closeMinute)
            ) {
               // console.error(`[GCAuto Schedule] Pengaturan waktu tidak valid untuk grup ${id}:`, setting);
                chat.security = null; // Reset pengaturan tidak valid
                continue; // Lewati grup dengan pengaturan tidak valid
            }

            const openTimeStr = `open-${pad(setting.openHour)}:${pad(setting.openMinute)}`;
            const closeTimeStr = `close-${pad(setting.closeHour)}:${pad(setting.closeMinute)}`;

            // Cek apakah grup sudah diproses pada menit ini
            if (lastProcessed[id] === currentTimeStr) continue;

            try {
                if (
                    hour === setting.openHour &&
                    minute === setting.openMinute &&
                    chat.lastSecurityAction !== openTimeStr
                ) {
                    //console.log(`[GCAuto Debug] Membuka grup ${id} pada ${openTimeStr}`);
                    await global.conn.groupSettingUpdate(id, 'not_announcement');
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Delay 1 detik
                    await global.conn.sendMessage(id, { text: setting.openMsg });
                    chat.lastSecurityAction = openTimeStr;
                    lastProcessed[id] = currentTimeStr;
                } else if (
                    hour === setting.closeHour &&
                    minute === setting.closeMinute &&
                    chat.lastSecurityAction !== closeTimeStr
                ) {
                   // console.log(`[GCAuto Debug] Menutup grup ${id} pada ${closeTimeStr}`);
                    await global.conn.groupSettingUpdate(id, 'announcement');
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Delay 1 detik
                    await global.conn.sendMessage(id, { text: setting.closeMsg });
                    chat.lastSecurityAction = closeTimeStr;
                    lastProcessed[id] = currentTimeStr;
                }
            } catch (e) {
              //  console.error(`[GCAuto Schedule] Gagal update grup ${id}: ${e.message}`);
                if (e.message === 'rate-overlimit') {
                    await new Promise(resolve => setTimeout(resolve, 5000)); // Delay 5 detik untuk retry
                }
            }
        }
    } catch (e) {
       // console.error('[GCAuto Schedule] Kesalahan pada job penjadwalan:', e.message, e.stack);
    }
});

// Mengatur bantuan untuk perintah .gcauto
handler.help = ['gcauto <jam_buka|jam_tutup> | [pesan buka] | [pesan tutup]', 'gcauto off', 'gcauto status'];
handler.tags = ['group'];
handler.command = /^gcauto$/i;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;