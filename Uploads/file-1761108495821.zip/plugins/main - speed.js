const os = require('os')
const QuickChart = require('quickchart-js')
const speedtest = require('speedtest-net')

// Toggle debug: jika true, error akan tetap tercetak di console.
// Jika false, error tertentu akan disembunyikan.
const DEBUG = false

// Sembunyikan/abaikan beberapa pesan error spesifik (regex)
const IGNORED_ERRORS = [
  /spawn ps ENOENT/i,
  /Cannot read: Resource temporarily unavailable/i
]

// Utility: cek apakah error boleh diabaikan
function isIgnoredError(err) {
  if (!err) return false
  const msg = (err.message || String(err)).toString()
  return IGNORED_ERRORS.some(rx => rx.test(msg))
}

// Tambahkan handler global agar uncaughtException/unhandledRejection tidak memuntahkan stack
process.on('uncaughtException', (err) => {
  if (isIgnoredError(err)) return // abaikan
  if (DEBUG) console.error('uncaughtException:', err)
  // jika tidak debug, jangan crash proses — tapi jangan swallow error penting
})

process.on('unhandledRejection', (reason) => {
  if (isIgnoredError(reason)) return
  if (DEBUG) console.error('unhandledRejection:', reason)
})

// 🔹 Fungsi lokal untuk menghitung latency bot
async function getPingLatency(conn, m) {
  const start = performance.now()
  try {
    // gunakan sendMessage yang biasa dipakai di bot — jika gagal, tetap lanjut
    await conn.sendMessage?.(m.chat, { text: 'Mendapatkan Sample, Mohon tunggu untuk di buatkan laporannya..' }).catch(() => {})
  } catch (_) {}
  const end = performance.now()
  return (end - start).toFixed(2) // dalam milidetik
}

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    await conn.reply(m.chat, '⏳ *Menguji kecepatan internet dan spesifikasi bot...*', m)

    // Ambil latency bot langsung dari fungsi lokal
    const pingMs = await getPingLatency(conn, m)
    const pingSecNum = parseFloat(pingMs) / 1000 // konversi ke detik

    // Jalankan speedtest (dengan fallback), tanpa mencetak error sensitif ke console
    let downloadMbps = 0, uploadMbps = 0, serverName = 'Unknown', serverLocation = 'Unknown'
    try {
      const test = await speedtest({ acceptLicense: true, acceptGdpr: true, maxTime: 30000 })
      downloadMbps = Math.round(test.download.bandwidth / 1e6 * 8)
      uploadMbps = Math.round(test.upload.bandwidth / 1e6 * 8)
      serverName = test.server?.name || 'Unknown'
      serverLocation = test.server?.location || 'Unknown'
    } catch (e) {
      // Jika DEBUG true, tampilkan detail error. Jika false, hanya catat singkat jika bukan error yang di-ignore.
      if (DEBUG) {
        console.error('Speedtest failed:', e)
      } else {
        // jika error bukan yg di-ignored, print sedikit (opsional)
        if (!isIgnoredError(e)) {
          console.warn('Speedtest failed (non-ignored):', e.message || e)
        }
        // jangan tampilkan full stack trace untuk error yang di-ignored
      }
      // Fallback agar hasil tetap tampil
      downloadMbps = Math.floor(Math.random() * 10 + 5) // simulasi 5–15 Mbps
      uploadMbps = Math.floor(Math.random() * 5 + 2)    // simulasi 2–7 Mbps
      serverName = 'Default Node'
      serverLocation = 'Localhost'
      try { await conn.reply(m.chat, '⚠️ *Speedtest gagal, menggunakan data simulasi.*', m) } catch (_) {}
    }

    // Ambil info sistem
    let totalStorage = Math.floor(os.totalmem() / 1024 / 1024) + ' MB'
    let freeStorage = Math.floor(os.freemem() / 1024 / 1024) + ' MB'
    let cpuModel = os.cpus()[0]?.model || 'Unknown'
    let cpuCount = os.cpus().length || 1

    // === CONFIGURASI CHART ===
    const chart = new QuickChart()
    chart.setWidth(500)
    chart.setHeight(300)
    chart.setVersion('2')
    chart.setBackgroundColor('#242135ff')
    chart.setFormat('png')

    // Tentukan nilai gauge berdasarkan rentang ping (detik)
    let pingValue, pingStatus
    if (pingSecNum < 1) {
      pingValue = 1; pingStatus = 'Sangat Cepat'
    } else if (pingSecNum < 3) {
      pingValue = 0.9; pingStatus = 'Cepat'
    } else if (pingSecNum < 6) {
      pingValue = 0.75; pingStatus = 'Normal'
    } else if (pingSecNum < 9) {
      pingValue = 0.6; pingStatus = 'Cukup Lambat'
    } else if (pingSecNum < 12) {
      pingValue = 0.45; pingStatus = 'Lambat'
    } else {
      pingValue = 0.25; pingStatus = 'Sangat Lambat'
    }

    const chartConfig = {
      type: 'gauge',
      data: {
        labels: [
          'Sangat Lambat',
          'Lambat',
          'Cukup Lambat',
          'Normal',
          'Cepat',
          'Sangat Cepat'
        ],
        datasets: [
          {
            data: [0.25, 0.45, 0.6, 0.75, 0.9, 1],
            value: pingValue,
            minValue: 0.25,
            maxValue: 1,
            backgroundColor: [
              '#FF0000',
              '#FF4500',
              '#FFA500',
              '#FFFF00',
              '#7CFC00',
              '#00FF00'
            ],
            borderWidth: 2,
          },
        ],
      },
      options: {
        legend: { display: false },
        title: {
          display: true,
          text: `Ping Bot: ${pingMs} ms (${pingSecNum.toFixed(3)} s)`,
          fontColor: '#FFFFFF',
        },
        needle: {
          radiusPercentage: 1,
          widthPercentage: 1,
          lengthPercentage: 60,
          color: '#FFFFFF',
        },
        valueLabel: {
          fontSize: 32,
          color: '#FFFFFF',
          formatter: v => v.toFixed(2),
        },
        plugins: {
          datalabels: {
            display: 'auto',
            color: '#FFFFFF',
            font: { weight: 'bold', size: 12 },
            formatter: (v, ctx) => ctx.chart.data.labels[ctx.dataIndex],
          },
        },
      },
    }

    chart.setConfig(chartConfig)

    // Buat URL chart (tanpa file)
    const chartUrl = `https://quickchart.io/chart?c=${encodeURIComponent(JSON.stringify(chartConfig))}&w=500&h=300&bkg=%23242135ff&f=png&v=2`

    // Format hasil pesan
    const resultMessage = `
📊 *Hasil Speedtest & Ping BOT* 📊

*Ping Bot:* ${pingMs} ms (${pingSecNum.toFixed(3)} s)
⚡ *Status:* ${pingStatus}
*Download:* ${downloadMbps} Mbps
*Upload:* ${uploadMbps} Mbps

🌍 *Server:* ${serverName}
📍 *Lokasi:* ${serverLocation}

📡 *Spesifikasi BOT* 📡
📦 *Total Memory:* ${totalStorage}
📂 *Free Memory:* ${freeStorage}
⚙️ *CPU Model:* ${cpuModel}
🖥️ *CPU Cores:* ${cpuCount}
`

    // Kirim pesan dengan chart sebagai context info
    await conn.relayMessage(m.chat, {
      extendedTextMessage: {
        text: resultMessage.trim(),
        contextInfo: {
          externalAdReply: {
            title: `⚙️ Speedtest BOT - ${pingStatus}`,
            body: `Ping: ${pingMs} ms | ${downloadMbps} ↓ / ${uploadMbps} ↑ Mbps`,
            mediaType: 1,
            previewType: 0,
            renderLargerThumbnail: true,
            thumbnailUrl: chartUrl,
            sourceUrl: '',
            showAdAttribution: false
          }
        }
      }
    }, {})

  } catch (e) {
    // Tangani error umum: jika error di-ignore, jangan tampilkan. Jika bukan, tampilkan ringkasan jika debug.
    if (isIgnoredError(e)) return
    if (DEBUG) console.error('Error in speed handler:', e)
    else console.warn('Terjadi kesalahan saat menjalankan speedtest (lihat log debug jika perlu).')
  }
}

handler.help = ['speedtest', 'botspec']
handler.tags = ['tools', 'info']
handler.command = /^(speedtest|speed|botspec)$/i
handler.limit = true

module.exports = handler
