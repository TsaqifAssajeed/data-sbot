// plugins/group - votekick.js
const fs = require('fs').promises;
const path = require('path');

const voteFile = path.join(__dirname, '../database/votekick.json');
const storeVote = {}; // cache sementara

async function loadVoteData() {
  try {
    const data = await fs.readFile(voteFile, 'utf8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}
async function saveVoteData(data) {
  await fs.writeFile(voteFile, JSON.stringify(data, null, 5));
}

const pertahankanEmoji = ['❤', '❤️'];
const kickEmoji = ['👍', '👍🏻', '👍🏼', '👍🏽', '👍🏾', '👍🏿'];

let handler = async (m, { conn, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply(`*[ ! ] Perintah ini hanya bisa digunakan di grup.*`);
  if (!isAdmin) return m.reply('🚩 Hanya admin yang bisa memulai voting!');
  if (!isBotAdmin) return m.reply('🚩 Bot bukan admin!');

  let who = m.mentionedJid?.[0] || (m.quoted ? m.quoted.sender : null);
  if (!who) throw `*• Contoh :* ${usedPrefix}${command} *[@user]*`;

  const metadata = await conn.groupMetadata(m.chat);
  const pesertaTarget = metadata.participants.find(p => p.id === who) || {};

  const targetIsAdmin =
    pesertaTarget?.admin === 'admin' ||
    pesertaTarget?.admin === 'superadmin' ||
    pesertaTarget?.isAdmin === true;

  if (targetIsAdmin || who === conn.user.id)
    return m.reply('*[ ! ] Tidak bisa vote kick admin/bot.*');

  const voteData = await loadVoteData();
  const groupId = m.chat;
  if (!voteData[groupId]) voteData[groupId] = {};

  // ✅ Cek jika ada vote aktif di grup ini
  let voteAktif = null;
  for (const [jid, data] of Object.entries(voteData[groupId])) {
    if (data && typeof data === 'object') {
      voteAktif = data;
      break;
    }
  }

  if (voteAktif) {
    if (voteAktif.target === who) {
      return m.reply(
        `⚠️ Voting untuk @${who.split('@')[0]} sudah berlangsung.\nSelesaikan vote ini atau reset dengan *.votereset*.`,
        { mentions: [who] }
      );
    } else {
      return m.reply(
        `⚠️ Sedang ada voting lain di grup ini untuk @${voteAktif.target.split('@')[0]}.\nGunakan *.votereset* untuk membatalkan vote sebelumnya.`,
        { mentions: [voteAktif.target] }
      );
    }
  }

  const allMembers = metadata.participants.map(p => p.id);
  const voteMsg = await conn.sendMessage(
    m.chat,
    {
      text: `Silahkan *React pesan ini* untuk voting.\n${pertahankanEmoji[1]} = Pertahankan\n👍🏻 = Kick\n\nTarget: @${who.split("@")[0]}\n> Jika bot tidak merespon, artinya sedang ada vote berlangsung, pilihannya dua, selesaikan voting atau .resetvote\n> Vote per orang hanya sekali react, pertahankan atau kick\n> jika mencapai 5 vote maka user target akan di kick`,
      mentions: [...allMembers, who]
    },
    { quoted: m }
  );

  // Simpan ke database
  voteData[groupId][who] = {
    message_id: voteMsg.key.id,
    target: who,
    kick_votes: 0,
    voters: []
  };
  await saveVoteData(voteData);

  // Simpan ke cache
  storeVote[voteMsg.key.id] = {
    chatId: m.chat,
    target: who,
    kick_votes: 0,
    voters: []
  };
};

// Handler reaction
handler.before = async function (m, { conn }) {
  if (m.mtype !== 'reactionMessage') return;
  if (!m.isGroup) return;

  const emoji = m.msg.text;
  const reactedToId = m.msg.key.id;
  if (![...pertahankanEmoji, ...kickEmoji].includes(emoji)) return;

  const info = storeVote[reactedToId];
  if (!info) return;

  const voter = m.key.participant || m.key.remoteJid;
  if (info.voters.includes(voter)) {
    return conn.sendMessage(info.chatId, {
      text: `*[ ! ] @${voter.split('@')[0]} sudah vote untuk @${info.target.split('@')[0]}. dan hanya bisa sekali vote*`,
      mentions: [voter, info.target]
    });
  }

  if (kickEmoji.includes(emoji)) {
    info.kick_votes += 1;
    info.voters.push(voter);

    if (info.kick_votes >= 5) {
      try {
        await conn.groupParticipantsUpdate(info.chatId, [info.target], 'remove');
        await conn.sendMessage(info.chatId, {
          text: `*[ VOTE KICK MEMBER @${info.target.split("@")[0]} ]*\nSUKSES DIKICK (mencapai 5 vote).`,
          mentions: [info.target]
        });
      } finally {
        // Hapus cache & database
        delete storeVote[reactedToId];
        const voteData = await loadVoteData();
        if (voteData[info.chatId]) delete voteData[info.chatId][info.target];
        await saveVoteData(voteData);
      }
    } else {
      info.voters.push(voter);
      await conn.sendMessage(info.chatId, {
        text: `*[ KICK MEMBER ]*\n@${voter.split('@')[0]} memilih untuk *kick* @${info.target.split('@')[0]}\n> Tersisa*(${info.kick_votes}/5)* Vote lagi untuk kick.`,
        mentions: [info.target]
      });
    }
  } else if (pertahankanEmoji.includes(emoji)) {
    info.voters.push(voter);
    await conn.sendMessage(info.chatId, {
      text: `*[ PERTAHANKAN MEMBER ]* @${voter.split('@')[0]} memilih untuk *Mempertahankan* @${info.target.split('@')[0]}.`,
      mentions: [voter, info.target]
    });
  }
};

handler.help = ["votekick *[@user]*"];
handler.tags = ["group"];
handler.command = ["votekick"];
handler.botAdmin = true;
handler.group = true;

handler.register = true
handler.limit = true
module.exports = handler;
