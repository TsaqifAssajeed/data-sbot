const axios = require("axios");
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");



let handler = async (m, { conn, args, usedPrefix, command }) => {
// Validasi input URL
    if (!args[0]) throw `Usage: ${usedPrefix + command} <url>\n*Contoh*: ${usedPrefix + command} https://www.bilibili.tv/id/video/4793141561528832 atau https://bili.im/njkOabV`;
    if (!args[0].includes("bilibili.tv") && !args[0].includes("bili.im")) {
        throw "URL tidak valid! Gunakan URL dari bilibili.tv atau bili.im";
    }

    // Pastikan direktori tmp ada
    if (!fs.existsSync("tmp")) fs.mkdirSync("tmp");

    await m.reply("Tunggu sebentar kak....");

    try {
        // Validasi API key
        if (!global.alyachankey) throw "API Key tidak diatur!";

        console.log("Mengambil data dari API...");
        let response = await axios.get(`https://api.alyachan.dev/api/bstation-dl?apikey=${global.alyachankey}&url=${encodeURIComponent(args[0])}`);
        let data = response.data;
       // console.log("Respons API:", JSON.stringify(data, null, 2));

        // Validasi struktur respons API
        if (!data.status) throw "Gagal mengambil data video dari API!";
        if (!data.data || !data.data.playurl || !data.data.playurl.video || !data.data.playurl.audio_resource) {
            throw "Struktur respons API tidak sesuai!";
        }

        let { playurl } = data.data;
        let duration = playurl.duration;
        let videoList = playurl.video;
        let audioList = playurl.audio_resource;
        let video = videoList[0]; // Ambil video kualitas tertinggi pertama
        let audio = audioList[0]; // Ambil audio kualitas tertinggi pertama

        // Periksa deadline URL
        let videoUrl = video.video_resource.url;
        const deadline = new URL(videoUrl).searchParams.get("deadline");
        if (Date.now() / 1000 > parseInt(deadline)) {
            console.log("URL kadaluarsa, memanggil ulang API...");
            response = await axios.get(`https://api.alyachan.dev/api/bstation-dl?apikey=${global.alyachankey}&url=${encodeURIComponent(args[0])}`);
            data = response.data;
            videoUrl = data.data.playurl.video[0].video_resource.url;
            audioUrl = data.data.playurl.audio_resource[0].url;
        } else {
            audioUrl = audio.url;
        }

        console.log("URL Video:", videoUrl);
        console.log("URL Audio:", audioUrl);

        let tempVideoPath = path.resolve("tmp", `${Date.now()}_video.m4s`);
        let tempAudioPath = path.resolve("tmp", `${Date.now()}_audio.m4s`);
        let tempProcessedPath = path.resolve("tmp", `${Date.now()}_processed.mp4`);

        // Download video
        console.log("Mengunduh video...");
        let videoResponse;
        const videoUrls = [video.video_resource.url, ...(video.video_resource.backup_url || [])];
        for (let url of videoUrls) {
            try {
                console.log(`Mencoba URL video: ${url}`);
                videoResponse = await axios({
                    method: "get",
                    url,
                    responseType: "stream",
                    headers: {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
                        "Referer": "https://www.bilibili.tv/",
                        "Origin": "https://www.bilibili.tv"
                    },
                });
                break;
            } catch (e) {
                console.log(`Gagal mengunduh dari ${url}: ${e.message}`);
                if (url === videoUrls[videoUrls.length - 1]) throw new Error("Semua URL video gagal: " + e.message);
            }
        }

        await new Promise((resolve, reject) => {
            let stream = fs.createWriteStream(tempVideoPath);
            videoResponse.data.pipe(stream);
            stream.on("finish", resolve);
            stream.on("error", reject);
        });

        // Download audio
        console.log("Mengunduh audio...");
        let audioResponse;
        const audioUrls = [audio.url, ...(audio.backup_url || [])];
        for (let url of audioUrls) {
            try {
                console.log(`Mencoba URL audio: ${url}`);
                audioResponse = await axios({
                    method: "get",
                    url,
                    responseType: "stream",
                    headers: {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
                        "Referer": "https://www.bilibili.tv/",
                        "Origin": "https://www.bilibili.tv"
                    },
                });
                break;
            } catch (e) {
                console.log(`Gagal mengunduh dari ${url}: ${e.message}`);
                if (url === audioUrls[audioUrls.length - 1]) throw new Error("Semua URL audio gagal: " + e.message);
            }
        }

        await new Promise((resolve, reject) => {
            let stream = fs.createWriteStream(tempAudioPath);
            audioResponse.data.pipe(stream);
            stream.on("finish", resolve);
            stream.on("error", reject);
        });

        // Merge video dan audio dengan ffmpeg
        console.log("Menggabungkan video dan audio...");
        try {
            execSync(`ffmpeg -i "${tempVideoPath}" -i "${tempAudioPath}" -c copy -metadata title="Bilibili Video" -metadata comment="Duration: ${Math.floor(duration / 1000)}s" "${tempProcessedPath}"`);
        } catch (ffmpegError) {
            throw `Gagal menggabungkan video dan audio: ${ffmpegError.message}`;
        }

        // Kirim video
        console.log("Mengirim video...");
        await conn.sendMessage(
            m.chat,
            {
                video: { url: tempProcessedPath },
                caption: `*Bilibili Video*\n*Duration:* ${Math.floor(duration / 1000)}s`,
            },
            { quoted: m }
        );

        // Hapus file temporary
        console.log("Menghapus file sementara...");
        try {
            fs.unlinkSync(tempVideoPath);
            fs.unlinkSync(tempAudioPath);
            fs.unlinkSync(tempProcessedPath);
        } catch (e) {
            console.error("Gagal menghapus file sementara:", e.message);
        }

    } catch (e) {
        console.error("Error:", e.message);
        throw `Error: ${e.message}`;
    }
};

handler.help = ["bstation <url>"];
handler.tags = ["downloader"];
handler.command = /^(bstation|bilibili)$/i;

handler.register = true
handler.limit = true
module.exports = handler;