// ✨ Plugin downloader - ttmusic ✨

// ✨ Plugin downloader - ttmusic ✨

const fetch = require('node-fetch');

let handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`📥 *Masukkan kata kunci pencarian!*\n\nContoh:\n.${command} naruto edit`);

  await m.reply('🔄 *Mengambil audio TikTok...*');

  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/search/tiktoks?query=${encodeURIComponent(text)}&apikey=${global.btc}`);
    const json = await res.json();

    if (!json.status || !json.result?.data || json.result.data.length === 0) {
      return m.reply('❌ Tidak ditemukan audio TikTok untuk kata kunci tersebut.');
    }

    const result = json.result.data[0];
    const audioUrl = result.music || result.music_url;
    const title = result.title || 'Tanpa Judul';
    const author = result.author?.nickname || 'Tidak Diketahui';
    const thumbnail = result.cover || null;

    if (!audioUrl) return m.reply('🚫 Audio tidak tersedia pada video ini.');

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg'
    }, {
      quoted: m,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: `👤 ${author}`,
          mediaType: 2,
          thumbnailUrl: thumbnail,
          renderLargerThumbnail: true,
          showAdAttribution: false,
          sourceUrl: 'https://tiktok.com'
        }
      }
    });

  } catch (err) {
    console.error('[TTMUSIC ERROR]', err);
    m.reply('⚠️ Gagal mengambil audio TikTok.');
  }
};

handler.command = /^ttmusic$/i;
handler.tags = ['downloader'];
handler.help = ['ttmusic <keyword>'];
handler.limit = true;

handler.register = true
module.exports = handler;