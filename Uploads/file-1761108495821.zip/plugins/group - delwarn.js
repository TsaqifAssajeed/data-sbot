const { normalizeJid } = require('../function/jid')

let handler = async (m, { conn, args, groupMetadata, usedPrefix, command }) => {
    let warnIndex = args[0] ? parseInt(args[0]) : null
    let who = m.isGroup ? (m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false) : m.chat

    // Cek jika perintah adalah 'all' untuk menghapus semua peringatan
    if (args[0] && args[0].toLowerCase() === 'all') {
        let users = Object.entries(global.db.data.users)
            .filter(([jid, user]) => user.warn > 0 || (user.warnReasons && user.warnReasons.length > 0))

        if (users.length === 0) {
            return m.reply('Tidak ada pengguna dengan riwayat peringatan di grup ini.')
        }

        // Reset semua warn dan warnReasons
        users.forEach(([jid, user]) => {
            user.warn = 0
            user.warnReasons = []
        })

        m.reply(`
*SEMUA PERINGATAN DIHAPUS*

✧ *Admin:* ${conn.getName(m.sender)}
✧ *Tindakan:* Menghapus semua riwayat peringatan untuk semua pengguna di grup *${groupMetadata.subject}*.
✧ *Jumlah pengguna yang direset:* ${users.length}
        `)
        return
    }

    // Cek jika tidak ada argumen atau penyebutan
    if (!warnIndex && !who) {
        throw `Gunakan format: ${usedPrefix + command} <nomor_urutan> atau ${usedPrefix + command} @user atau ${usedPrefix + command} all`
    }

    // Buat daftar pengguna dengan peringatan seperti di listwarn
    let users = Object.entries(global.db.data.users)
        .filter(([jid, user]) => user.warn > 0 || (user.warnReasons && user.warnReasons.length > 0))
        .map(([jid, user]) => {
            let userNumber = jid.split('@')[0].replace(/^\+/, '').replace(/[^0-9]/g, '')
            let name = conn.getName(jid) || 'Unknown'
            return {
                jid: normalizeJid(jid),
                name,
                userNumber,
                warn: user.warn,
                warnReasons: user.warnReasons || []
            }
        })

    if (warnIndex !== null && warnIndex >= 1) {
        // Mode penghapusan berdasarkan urutan dari daftar listwarn
        if (users.length === 0) {
            return m.reply('Tidak ada pengguna dengan riwayat peringatan di grup ini.')
        }
        if (warnIndex > users.length) {
            return m.reply(`Peringatan nomor ${warnIndex} tidak ditemukan. Hanya ada ${users.length} pengguna dengan riwayat peringatan.`)
        }

        let user = users[warnIndex - 1]
        let dbUser = global.db.data.users[user.jid]
        if (dbUser.warn === 0 && (!dbUser.warnReasons || dbUser.warnReasons.length === 0)) {
            return m.reply(`Pengguna ${user.name} (@${user.userNumber}) tidak memiliki peringatan atau riwayat alasan.`)
        }

        // Hapus peringatan terakhir
        dbUser.warn -= 1
        if (dbUser.warn < 0) dbUser.warn = 0 // Pastikan warn tidak negatif
        let removedReason = dbUser.warnReasons.length > 0 ? dbUser.warnReasons.pop() : 'Tidak ada alasan yang dicatat'

        m.reply(`
*PERINGATAN DIHAPUS*

✧ *Admin:* ${conn.getName(m.sender)}
✧ *Pengguna:* @${user.userNumber}
✧ *Peringatan dihapus:* Peringatan terakhir
✧ *Alasan peringatan:* ${removedReason}
✧ *Total peringatan sekarang:* ${dbUser.warn}/${global.maxwarn}`, null, { mentions: [user.jid] })

        m.reply(`Seorang admin menghapus peringatan Anda. Sekarang Anda memiliki *${dbUser.warn}* peringatan.`, user.jid)
    } else if (who) {
        // Mode penghapusan default dengan penyebutan pengguna
        who = normalizeJid(who)
        if (!(who in global.db.data.users)) throw `Pengguna tidak ditemukan di database saya`

        let dbUser = global.db.data.users[who]
        if (dbUser.warn === 0 && (!dbUser.warnReasons || dbUser.warnReasons.length === 0)) {
            return m.reply('Pengguna tidak memiliki peringatan atau riwayat alasan')
        }

        dbUser.warn -= 1
        if (dbUser.warn < 0) dbUser.warn = 0 // Pastikan warn tidak negatif
        let removedReason = dbUser.warnReasons.length > 0 ? dbUser.warnReasons.pop() : 'Tidak ada alasan yang dicatat'
        let userNumber = who.split('@')[0].replace(/^\+/, '').replace(/[^0-9]/g, '')
        let name = conn.getName(who) || 'Unknown'

        m.reply(`
*PERINGATAN DIHAPUS*

✧ *Admin:* ${conn.getName(m.sender)}
✧ *Pengguna:* @${userNumber}
✧ *Peringatan dihapus:* Peringatan terakhir
✧ *Alasan peringatan:* ${removedReason}
✧ *Total peringatan sekarang:* ${dbUser.warn}/${global.maxwarn}`, null, { mentions: [who] })

        m.reply(`Seorang admin menghapus peringatan Anda. Sekarang Anda memiliki *${dbUser.warn}* peringatan.`, who)
    }
}

handler.help = ['delwarn <nomor_urutan | @user | all>', 'unwarn <nomor_urutan | @user | all>']
handler.tags = ['group']
handler.command = ['delwarn', 'unwarn']

handler.rowner = true

handler.register = true
handler.limit = true
module.exports = handler