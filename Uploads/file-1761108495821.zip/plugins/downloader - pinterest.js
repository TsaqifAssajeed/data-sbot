const axios = require('axios');
const { generateWAMessageContent, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// Import handler dari pindl.js
const pindlHandler = require('./downloader - pindl.js');

let handler = async (m, ctx) => {
    let { conn, text, usedPrefix, command } = ctx;
    if (!text) return m.reply(`• *Example:* ${usedPrefix + command} kucing`);

    // Cek apakah text adalah link Pinterest
    if (/^https?:\/\/(www\.)?(pin\.it|pinterest\.com)\//i.test(text.trim())) {
        // Panggil langsung fungsi pindl.js
        return pindlHandler(m, {
            ...ctx,
            args: [text.trim()],
            command: 'pindl'
        });
    }

    await m.reply('*_`Loading...`_*');

    try {
        let { data } = await axios.get(`https://api.botcahx.eu.org/api/search/pinterest?text1=${encodeURIComponent(text)}&apikey=${btc}`);
       
        if (!data.status || !data.result.length) return m.reply('Tidak ada hasil yang ditemukan.');
        
        let images = data.result.slice(0, 10); 
        let push = [];
        let i = 1;

        for (let imgUrl of images) {
            push.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `Image ke - ${i++}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: namebot
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: 'Hasil Pencarian',
                    hasMediaAttachment: true,
                    imageMessage: (await generateWAMessageContent({ image: { url: imgUrl } }, { upload: conn.waUploadToServer })).imageMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "cta_url",
                            buttonParamsJson: `{"display_text":"Lihat di Pinterest","url":"https://www.pinterest.com/search/pins/?q=${encodeURIComponent(text)}"}`
                        }
                    ]
                })
            });
        }

        const bot = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `*🔍 Pinterest Search Results*\n\n*Query:* ${text}\n*Hasil Pencarian Gambar:*`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: namebot
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: [...push]
                        })
                    })
                }
            }
        }, {});

        await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat mengambil gambar dari Pinterest.');
    }
};

handler.help = ["pinterest", "pin"];
handler.tags = ["downloader"];
handler.command = /^(pinterest|pin)$/i;
handler.premium = false;

handler.register = true
handler.limit = true
module.exports = handler;
