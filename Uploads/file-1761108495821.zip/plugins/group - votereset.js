// plugins/group - votereset.js
const fs = require('fs').promises;
const path = require('path');

const voteFile = path.join(__dirname, '../database/votekick.json');

async function loadVoteData() {
  try {
    const data = await fs.readFile(voteFile, 'utf8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}
async function saveVoteData(data) {
  await fs.writeFile(voteFile, JSON.stringify(data, null, 4));
}

let handler = async (m, { isAdmin }) => {
  if (!m.isGroup) return m.reply(`*[ ! ] Perintah ini hanya bisa digunakan di grup.*`);
  if (!isAdmin) return m.reply('🚩 Hanya admin yang bisa mereset voting!');

  const voteData = await loadVoteData();
  const groupId = m.chat;

  if (!voteData[groupId] || Object.keys(voteData[groupId]).length === 0) {
    return m.reply('✅ Tidak ada voting yang berlangsung di grup ini.');
  }

  delete voteData[groupId];
  await saveVoteData(voteData);

  m.reply('♻️ Voting berhasil direset.');
};

handler.help = ["votereset"];
handler.tags = ["group"];
handler.command = ["votereset"];
handler.botAdmin = true;
handler.group = true;

handler.register = true
handler.limit = true
module.exports = handler;
