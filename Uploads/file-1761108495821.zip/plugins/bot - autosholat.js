// ✨ Plugin bot - autosholat ✨

// ✨ Plugin _autosholat ✨

const fs = require('fs');
const axios = require('axios');

module.exports = {
    before: async function (m) {
        this.autosholat = this.autosholat || {};
        let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? this.user.jid : m.sender;
        let id = m.chat;

        // Jadwal Sholat (WIB - Jakarta)
        let jadwalSholat = {
            Imsak: "04:45",
            Subuh: "04:55",
            Dhuhr: "12:10",
            Asr: "15:18",
            Maghrib: "18:15",
            Isha: "19:24"
        };

        // Daftar URL thumbnail acak
        const sholatThumbnails = [
            "https://images.pexels.com/photos/460680/pexels-photo-460680.jpeg?auto=compress&cs=tinysrgb&w=600",
            "https://images.pexels.com/photos/161276/moscow-cathedral-mosque-prospekt-mira-ramadan-sky-161276.jpeg?auto=compress&cs=tinysrgb&w=600",
            "https://images.pexels.com/photos/2406731/pexels-photo-2406731.jpeg?auto=compress&cs=tinysrgb&w=600"
        ];

        // Gunakan zona waktu Jakarta (WIB)
        const date = new Date((new Date).toLocaleString("en-US", { timeZone: "Asia/Makassar" }));
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
        let isActive = Object.values(this.autosholat).includes(true);

        if (id in this.autosholat && isActive) {
            return false;
        }

        for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu && !(id in this.autosholat)) {
                let caption = `Hai kak @${who.split`@`[0]},\nWaktu *${sholat}* telah tiba. Ambilah air wudhu dan segeralah shalat.\n\n*${waktu} WIB*\n\n"Sesungguhnya shalat pada waktu-waktu tertentu (siang dan malam) telah diwajibkan atas orang-orang yang beriman."\n(QS. 4:103)`;

                // Khusus Imsak
                if (sholat === "Imsak") {
                    caption = `Hai kak @${who.split`@`[0]},\nWaktu *Imsak* telah tiba! Segera hentikan makan dan minum.\nSelamat menunaikan ibadah puasa!\n\n*${waktu} WIB*`;
                }

                // Pilih thumbnail secara acak
                let imgUrl = sholatThumbnails[Math.floor(Math.random() * sholatThumbnails.length)];
                let audioUrl = (sholat === "Imsak" || sholat === "Subuh") 
                  ? "https://github.com/ChandraGO/Data-Jagoan-Project/raw/525643df448dada7f6edb076eb8b8665fa9db552/src/ayam.MP3" 
                  : "https://github.com/ChandraGO/Data-Jagoan-Project/raw/525643df448dada7f6edb076eb8b8665fa9db552/src/azan.MP3";

                this.autosholat[id] = [
                    this.reply(m.chat, caption, null, {
                        contextInfo: {
                            mentionedJid: [who],
                            externalAdReply: {
                                title: `Waktu Sholat ${sholat}`,
                                thumbnailUrl: imgUrl,
                                mediaType: 1,
                                renderLargerThumbnail: true,
                                sourceUrl: "https://Shalat Yuk.!"
                            }
                        }
                    })
                ];

                // Kirim audio
                if (sholat === "Imsak" || sholat === "Subuh") {
                    try {
                        const response = await axios.get(audioUrl, { responseType: 'arraybuffer' });
                        const audioBuffer = Buffer.from(response.data);
                        this.autosholat[id].push(
                            this.sendMessage(m.chat, {
                                audio: audioBuffer,
                                mimetype: 'audio/mpeg',
                                ptt: true
                            }, { quoted: m })
                        );
                    } catch (error) {
                        console.warn(`Gagal mengunduh audio dari: ${audioUrl}`, error);
                    }
                } else {
                    try {
                        const response = await axios.get(audioUrl, { responseType: 'arraybuffer' });
                        const audioBuffer = Buffer.from(response.data);
                        this.autosholat[id].push(
                            this.sendMessage(m.chat, {
                                audio: audioBuffer,
                                mimetype: 'audio/mpeg',
                                ptt: true
                            }, { quoted: m })
                        );
                    } catch (error) {
                        console.warn(`Gagal mengunduh audio dari: ${audioUrl}`, error);
                    }
                }

                this.autosholat[id].push(
                    setTimeout(() => {
                        delete this.autosholat[id];
                    }, 57000)
                );
            }
        }
    },
    disabled: false
};