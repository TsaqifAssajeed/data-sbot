// File: fetch.js
const fetch = require('node-fetch');
const util = require('util');


global.API = function (base, path = '/', query = {}, apikeyqueryname) {
  let q = new URLSearchParams(query);
  if (apikeyqueryname) q.append(apikeyqueryname, global.APIKeys?.[base] || ''); // masukkan API key jika ada
  return `${base}${path}?${q}`;
};


let handler = async (m, { text }) => {
  // Validasi apakah input URL diawali dengan http:// atau https://
  if (!/^https?:\/\//.test(text)) {
    throw 'Awali *URL* dengan http:// atau https://';
  }

  try {
    // Membuat objek URL dari input
    let _url = new URL(text);
    //console.log(`[DEBUG] Input URL: ${text}`);

    // Cek apakah URL adalah AWS S3 (berdasarkan parameter X-Amz-*)
    const isS3Url = _url.searchParams.has('X-Amz-Signature');
    let url = text; // Gunakan URL asli secara default
    if (!isS3Url && global.API) {
      // Hanya gunakan global.API jika bukan URL S3
      url = global.API(_url.origin, _url.pathname, Object.fromEntries(_url.searchParams.entries()), 'APIKEY');
    }
   // console.log(`[DEBUG] Constructed URL: ${url}`);

    // Cek waktu kedaluwarsa untuk URL S3
    if (isS3Url) {
      const amzDate = _url.searchParams.get('X-Amz-Date');
      const expires = parseInt(_url.searchParams.get('X-Amz-Expires') || '0');
      if (amzDate && expires) {
        const urlDate = new Date(
          parseInt(amzDate.slice(0, 4)), // Tahun
          parseInt(amzDate.slice(4, 6)) - 1, // Bulan (0-based)
          parseInt(amzDate.slice(6, 8)), // Hari
          parseInt(amzDate.slice(9, 11)), // Jam
          parseInt(amzDate.slice(11, 13)), // Menit
          parseInt(amzDate.slice(13, 15)) // Detik
        );
        const expireTime = urlDate.getTime() + expires * 1000;
        if (Date.now() > expireTime) {
          throw 'URL telah kedaluwarsa';
        }
      }
    }

    // Mengambil data dari URL
    let res = await fetch(url, { timeout: 30000 }); // Timeout 30 detik
    //console.log(`[DEBUG] Response Status: ${res.status} ${res.statusText}`);

    // Cek status respons
    if (!res.ok) {
      if (res.status === 403) {
        throw 'Akses ditolak (403 Forbidden). Periksa kredensial atau waktu kedaluwarsa URL.';
      }
      throw `Gagal mengambil data dari URL: ${res.status} ${res.statusText}`;
    }

    // Cek ukuran konten untuk mencegah file terlalu besar
    const contentLength = res.headers.get('content-length');
    if (contentLength && parseInt(contentLength) > 100 * 1024 * 1024 * 1024) {
      throw `Ukuran konten terlalu besar: ${contentLength} bytes`;
    }
    //console.log(`[DEBUG] Content-Length: ${contentLength || 'Tidak tersedia'}`);

    // Cek tipe konten
    const contentType = res.headers.get('content-type') || 'unknown';
   // console.log(`[DEBUG] Content-Type: ${contentType}`);

    // Jika tipe konten bukan text atau JSON, kirim sebagai file
    if (!/text|json/.test(contentType)) {
      try {
      //  console.log(`[DEBUG] Mengirim file dari URL: ${url}`);
        return await conn.sendFile(m.chat, url, 'file.mp4', text, m); // Menambahkan ekstensi .mp4
      } catch (e) {
      //  console.error(`[ERROR] Gagal mengirim file: ${e.stack || e}`);
        throw `Gagal mengirim file: ${e.message}`;
      }
    }

    // Ambil data sebagai buffer dan konversi ke string
    let txt = await res.buffer();
    //console.log(`[DEBUG] Buffer length: ${txt.length} bytes`);

    try {
      // Coba parse sebagai JSON
      txt = util.format(JSON.parse(txt.toString()));
     // console.log(`[DEBUG] Parsed as JSON`);
    } catch (e) {
      // Jika bukan JSON, gunakan sebagai string biasa
      txt = txt.toString();
      //console.log(`[DEBUG] Treated as plain text`);
    }

    // Kirim respons ke pengguna (batasi hingga 65536 karakter)
   // console.log(`[DEBUG] Mengirim respons ke pengguna`);
    await m.reply(txt.slice(0, 65536));
  } catch (error) {
    // Log error lengkap ke konsol untuk debugging
   // console.error(`[ERROR] Detail error: ${error.stack || error}`);
    // Kirim pesan error ke pengguna
    await m.reply(`Error: ${error.message || 'Terjadi kesalahan saat memproses permintaan'}`);
  }
};

// Informasi bantuan untuk perintah
handler.help = ['fetch', 'get'].map(v => v + ' <url>');
handler.tags = ['internet'];
handler.command = /^(fetch|get)$/i;

handler.register = true
handler.limit = true
module.exports = handler;