const fetch = require('node-fetch');
const fs = require("fs");
const { jidNormalizedUser } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    let template = (args[0] || '').toLowerCase();
    if (!args[0]) {
        let caption = `*Contoh Penggunaan* 😎

${usedPrefix + command} tai @user

*List Command*
⋆༺ anjing 
⋆༺ asu 
⋆༺ babi 
⋆༺ bajingan 
⋆༺ banci 
⋆༺ bangsat 
⋆༺ bego 
⋆༺ bejad 
⋆༺ bencong 
⋆༺ bolot 
⋆༺ brengsek 
⋆༺ budek 
⋆༺ buta 
⋆༺ geblek 
⋆༺ gembel 
⋆༺ gila 
⋆༺ goblok 
⋆༺ hina 
⋆༺ iblis 
⋆༺ idiot 
⋆༺ jablay 
⋆༺ jelek 
⋆༺ kampret 
⋆༺ kampungan 
⋆༺ kamseupay 
⋆༺ keparat 
⋆༺ kontol 
⋆༺ kunyuk 
⋆༺ memek 
⋆༺ monyet 
⋆༺ ngentot 
⋆༺ pecun 
⋆༺ perek 
⋆༺ sarap 
⋆༺ setan 
⋆༺ sinting 
⋆༺ sompret 
⋆༺ tai 
⋆༺ tolol 
⋆༺ udik 
`;
        await conn.reply(m.chat, caption, m, { mentions: conn.parseMention(caption) });
        return;
    }

    if (command) {
        switch (template) {
            case 'anjing':
            case 'asu':
            case 'babi':
            case 'bajingan':
            case 'banci':
            case 'bangsat':
            case 'bego':
            case 'bejad':
            case 'bencong':
            case 'bolot':
            case 'brengsek':
            case 'budek':
            case 'buta':
            case 'geblek':
            case 'gembel':
            case 'gila':
            case 'goblok':
            case 'iblis':
            case 'idiot':
            case 'jablay':
            case 'jelek':
            case 'kampret':
            case 'kampungan':
            case 'kamseupay':
            case 'keparat':
            case 'kontol':
            case 'kunyuk':
            case 'hina':
            case 'memek':
            case 'monyet':
            case 'ngentot':
            case 'pecun':
            case 'perek':
            case 'sarap':
            case 'setan':
            case 'sinting':
            case 'sompret':
            case 'tai':
            case 'tolol':
            case 'udik':
                let who;
                try {
                    if (m.isGroup) {
                        if (m.mentionedJid && m.mentionedJid[0]) {
                            who = jidNormalizedUser(m.mentionedJid[0]);
                        } else if (m.quoted) {
                            who = jidNormalizedUser(m.quoted.sender);
                        } else {
                            who = jidNormalizedUser(m.sender);
                        }
                    } else {
                        if (m.quoted) {
                            who = jidNormalizedUser(m.quoted.sender);
                        } else {
                            who = jidNormalizedUser(m.sender);
                        }
                    }

                    let name = await conn.getName(who) || 'Tidak ditemukan 😕';
                    const cek2 = cek1[Math.floor(Math.random() * cek1.length)];
                    let emoticon = '';
                    if (cek2 <= 20) emoticon = '😄👍';
                    else if (cek2 <= 50) emoticon = '😅👌';
                    else if (cek2 <= 80) emoticon = '😬⚠️';
                    else emoticon = '😱🔥';

                    let caption = `Tingkat *${template}an* 📊\nAtas nama *${name}* (@${who.split("@")[0]}) adalah *${cek2}%* ${emoticon}`;
                    
                    await conn.reply(m.chat, caption, m, { mentions: conn.parseMention(caption) });
                } catch (e) {
                    try {
                        who = jidNormalizedUser(m.quoted ? m.quoted.sender : m.sender);
                        let name = await conn.getName(who) || 'Tidak ditemukan 😕';
                        const cek2 = cek1[Math.floor(Math.random() * cek1.length)];
                        let emoticon = '';
                        if (cek2 <= 20) emoticon = '😄👍';
                        else if (cek2 <= 50) emoticon = '😅👌';
                        else if (cek2 <= 80) emoticon = '😬⚠️';
                        else emoticon = '😱🔥';

                        let caption = `Tingkat *${template}an* 📊\nAtas nama *${name}* (@${who.split("@")[0]}) adalah *${cek2}%* ${emoticon}`;
                        
                        await conn.reply(m.chat, caption, m, { mentions: conn.parseMention(caption) });
                    } catch {
                        await conn.reply(m.chat, `❌ Maaf, tidak bisa mengambil nama user 😢`, m);
                    }
                }
                break;
        }
    }
};

handler.help = ['cek <menu> <user>'];
handler.tags = ['cek'];
handler.command = /^cek$/i;
handler.register = true;
handler.limit = true;
module.exports = handler;

global.cek1 = Array.from({ length: 100 }, (_, i) => `${i + 1}`);