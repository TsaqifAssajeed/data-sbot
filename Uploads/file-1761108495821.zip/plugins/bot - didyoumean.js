let didyoumean = require('didyoumean');
let similarity = require('similarity');

let handler = m => m;

handler.before = async function (m, { conn, match, usedPrefix }) {
  if ((usedPrefix = (match[0] || '')[0])) {
    let noPrefix = m.text.replace(usedPrefix, '').trim();
    let alias = Object.values(global.features).filter(v => v.help && !v.disabled).map(v => v.help).flat(1);
    let mean = didyoumean(noPrefix, alias);
    let sim = similarity(noPrefix, mean);
    let similarityPercentage = parseInt(sim * 100);

    if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
      let response = `Perintah yang Anda masukkan tampaknya salah, berikut adalah perintah yang direkomendasikan untuk hal yang sama:\n\n⇝  ${usedPrefix + mean}\n⇝  Hasil Yang mendekati bang: ${similarityPercentage}%`;
      
      // Struktur pesan dengan tombol
      await conn.sendMessage(m.chat, {
        text: response,
        footer: namebot,
        buttons: [
          {
            buttonId: `${usedPrefix + mean}`,
            buttonText: {
              displayText: `Jalankan ${usedPrefix + mean}`
            },
            type: 1
          }
        ],
        headerType: 1,
        viewOnce: true
      }, { quoted: m });
    }
  }
};

module.exports = handler;