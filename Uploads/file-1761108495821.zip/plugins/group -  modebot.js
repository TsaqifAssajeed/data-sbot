let handler = async (m, { conn, text, usedPrefix, command }) => {
  let chat = global.db.data.chats[m.chat];
  if (m.isGroup) {
    switch (text) {
      case "off":
      case "mute":
        if (chat.mute) return m.reply("[ NOTICE ] Jagpro telah di mute dan sekarang offline");
        chat.mute = true;
        conn.reply(m.chat, "S u k s e s", m);
        break;
      case "on":
      case "unmute":
        if (!chat.mute) return m.reply("[ NOTICE ] Jagpro sudah di online kan :)");
        chat.mute = false;
        conn.reply(m.chat, "S u k s e s", m);
        break;
      default: {
        m.reply(
          `Format Salah!\n\nContoh:\n${usedPrefix + command} on\n${usedPrefix + command} off`,
        );
      }
    }
  }
};

handler.help = ["botmode"];
handler.tags = ["group"];
handler.command = /^(bot(mode)?)$/i;
handler.group = true;
handler.admin = true;

handler.register = true
handler.limit = true
module.exports = handler;