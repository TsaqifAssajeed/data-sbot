// ✨ Plugin group - playch ✨

const search = require('yt-search');
const fetch = require('node-fetch');
const axios = require('axios');

/*=========== SETTINGS CHANNEL ===========*/
let idch = "120363315304652958@newsletter"; // ID CH
const saluran = "120363315304652958@newsletter"; // LINK CH

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let ppUrl = global.thumb;
    let user = m.sender;
    let name = (await conn.getName(user)) || 'No Name';
    try {
        ppUrl = await conn.profilePictureUrl(user, 'image');
    } catch {
        ppUrl = global.thumb;
    }

    const contextInfoError = (title, msg) => ({
        text: msg,
        contextInfo: {
            externalAdReply: {
                title,
                body: '',
                thumbnailUrl: ppUrl,
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    });

    if (!text) {
        return conn.sendMessage(m.chat,
            contextInfoError('‼️ MASUKAN JUDUL',
                `– harap beri judul atau link youtube.\n> contoh : ${usedPrefix + command} Reckless`
            ), { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

    try {
        const look = await search(text);
        const convert = look.videos[0];

        if (!convert) throw '❌ Video/Audio tidak ditemukan!';
        if (convert.seconds >= 18000) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return conn.sendMessage(m.chat,
                contextInfoError('❌ Gagal Mengunduh',
                    'Video lebih dari 5 jam tidak dapat diproses.'
                ), { quoted: m });
        }

        let audioUrl, apiSource = '';
        try {
            const res = await fetch(`https://api.botcahx.eu.org/api/dowloader/yt?url=${convert.url}&apikey=${global.btc}`);
            audioUrl = await res.json();
            if (!audioUrl || !audioUrl.result?.mp3) throw new Error('API pertama gagal');
            apiSource = 'Botcahx';
        } catch {
            try {
                const res = await fetch(`${global.ptereodactyl}api/ytmp3?url=${convert.url}`);
                const fallback = await res.json();
                if (!fallback?.data?.status || !fallback?.data?.result?.audio_download) throw new Error('API kedua gagal');
                audioUrl = { result: { mp3: fallback.data.result.audio_download } };
                apiSource = 'Ptereodactyl';
            } catch {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return conn.sendMessage(m.chat,
                    contextInfoError('❌ Unduhan Gagal',
                        'Terjadi kesalahan saat mengunduh audio.'
                    ), { quoted: m });
            }
        }

        let date = new Date();
        let sendTime = new Intl.DateTimeFormat('id-ID', {
            timeZone: 'Asia/Jakarta',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
        }).format(date).replace(/\//g, '-').replace(/, /g, ' || ') + ' WIB';

        // 1️⃣ KIRIM INFO SINGKAT KE CHANNEL (lebih dulu)
        await conn.sendMessage(idch, {
            text: `🎧 *Title :* ${convert.title}\n⏱️ *Duration :* ${convert.timestamp}\n🧑‍🎤 *Author :* ${convert.author.name}`,
            contextInfo: {
                mentionedJid: [user],
                groupMentions: [],
                isForwarded: true,
                forwardingScore: 256,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: idch,
                    newsletterName: `Music Request By: ${name}`,
                    serverMessageId: -1
                },
                externalAdReply: {
                    title: `🎶 Lagu Telah Dikirim`,
                    body: convert.title,
                    thumbnailUrl: convert.image || ppUrl,
                    sourceUrl: convert.url,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    showAdAttribution: false
                }
            }
        });

        // 2️⃣ KIRIM AUDIO VN KE CHANNEL (tanpa contextInfo)
        await conn.sendMessage(idch, {
            audio: { url: audioUrl.result.mp3 },
            mimetype: 'audio/mpeg',
            ptt: true
        });

        // 3️⃣ KIRIM BALASAN KE USER
        let caption = `✅ *BERHASIL MENGIRIM LAGU KE CHANNEL*\n\n`;
        caption += `– haii @${user.split('@')[0]} lagu yang kamu minta telah dikirim ke saluran~\n\n`;
        caption += `🌐 *API Source :* ${apiSource}\n`;
        caption += `🎧 *Title :* ${convert.title}\n`;
        caption += `⏱️ *Duration :* ${convert.timestamp}\n`;
        caption += `👁️ *Views :* ${convert.views.toLocaleString()}\n`;
        caption += `📤 *Uploaded :* ${convert.ago}\n`;
        caption += `🧑‍🎤 *Author :* ${convert.author.name}\n`;
        caption += `🔗 *Link :* ${convert.url}`;

        await conn.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                mentionedJid: [user],
                groupMentions: [],
                isForwarded: true,
                forwardingScore: 256,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: idch,
                    newsletterName: 'PESAN TERKIRIM KE SALURAN',
                    serverMessageId: -1
                },
                externalAdReply: {
                    title: `Pengirim : ${name}`,
                    body: sendTime,
                    thumbnailUrl: ppUrl,
                    sourceUrl: saluran,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    showAdAttribution: false
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return conn.sendMessage(m.chat,
            contextInfoError('⚠️ Terjadi Kesalahan',
                `📄 *Logs error:* \n\`\`\`${err.message || err}\`\`\``
            ), { quoted: m });
    }
};

handler.command = handler.help = ['playch'];
handler.tags = ['group'];
handler.limit = true;
handler.rowner = true;


module.exports = handler;