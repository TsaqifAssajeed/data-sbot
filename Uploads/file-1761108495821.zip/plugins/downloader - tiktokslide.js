const fetch = require('node-fetch');
const { generateWAMessageContent, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, {
  conn,
  text,
  usedPrefix,
  command
}) => {
  if (command == 'tiktokslide' || command == 'ttslide') {
    if (!text) throw `Masukkan URL!\n\ncontoh: ${usedPrefix + command} https://vt.tiktok.com/ZS2qsMU1W/`;
    try {
      await m.reply('*_`Loading...`_*');
      const api = await fetch(`https://api.botcahx.eu.org/api/download/tiktokslide?url=${text}&apikey=${btc}`);
      const res = await api.json();
      
      if (!res.result || !res.result.images || !res.result.images.length) throw 'Tidak ada gambar yang ditemukan.';
      
      let images = res.result.images;
      let push = [];
      let i = 1;

      for (let imgUrl of images) {
        await sleep(3000); // Maintain delay to prevent flooding
        push.push({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: `Image ke - ${i++}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: namebot || 'TikTok Slide'
          }),
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `TikTok Slide`,
            hasMediaAttachment: true,
            imageMessage: (await generateWAMessageContent({ image: { url: imgUrl } }, { upload: conn.waUploadToServer })).imageMessage
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: `{"display_text":"Lihat di TikTok","url":"${text}"}`
              }
            ]
          })
        });
      }

      const bot = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `*🔍 TikTok Slide Results*\n\n*Title:* ${res.result.title}\n*Hasil Pencarian Gambar:*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: namebot || 'TikTok Slide'
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: [...push]
              })
            })
          }
        }
      }, {});

      await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });

      // Send audio after carousel
      if (res.result.audio && res.result.audio[0]) {
        await conn.sendMessage(m.chat, { audio: { url: res.result.audio[0] }, mimetype: 'audio/mpeg' }, { quoted: m });
      }
    } catch (e) {
      console.log(e);
      throw `🚩 *Terjadi kesalahan!*`;
    }
  }
  if (command == 'douyinslide' || command == 'douyinfoto') { 
    if (!text) throw `Masukkan URL!\n\ncontoh: ${usedPrefix + command} https://v.douyin.com/i2bPkLLo/`;
    try {
      await m.reply('*_`Loading...`_*');
      const api = await fetch(`https://api.botcahx.eu.org/api/download/douyinslide?url=${text}&apikey=${btc}`);
      const res = await api.json();
      
      if (!res.result || !res.result.images || !res.result.images.length) throw 'Tidak ada gambar yang ditemukan.';
      
      let images = res.result.images;
      let push = [];
      let i = 1;

      for (let imgUrl of images) {
        await sleep(3000); // Maintain delay to prevent flooding
        push.push({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: `Image ke - ${i++}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: namebot || 'Douyin Slide'
          }),
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `Douyin Slide`,
            hasMediaAttachment: true,
            imageMessage: (await generateWAMessageContent({ image: { url: imgUrl } }, { upload: conn.waUploadToServer })).imageMessage
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson: `{"display_text":"Lihat di Douyin","url":"${text}"}`
              }
            ]
          })
        });
      }

      const bot = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `*🔍 Douyin Slide Results*\n\n*Title:* ${res.result.title}\n*Hasil Pencarian Gambar:*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: namebot || 'Douyin Slide'
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: [...push]
              })
            })
          }
        }
      }, {});

      await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });

      // Send audio after carousel
      if (res.result.audio && res.result.audio[0]) {
        await conn.sendMessage(m.chat, { audio: { url: res.result.audio[0] }, mimetype: 'audio/mpeg' }, { quoted: m });
      }
    } catch (e) {
      console.log(e);
      throw `🚩 *Terjadi kesalahan!*`;
    }
  }
};

handler.help = ['ttslide', 'douyinslide'];
handler.tags = ['downloader'];
handler.limit = true;
handler.command = /^(tiktokslide|ttslide|douyinslide|douyinfoto)$/i;

handler.register = true
module.exports = handler;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}