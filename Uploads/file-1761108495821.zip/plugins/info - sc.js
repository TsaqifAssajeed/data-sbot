const axios = require('axios');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');
const sharp = require('sharp');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// Konfigurasi Pakasir di settings.js
const PROJECT = pakasirApi;
const API_KEY = pakasirKey;

// Konfigurasi
const GROUP_SC = "120363407877289729@g.us";
const PRICE_BUYSC = 80000;
const INVOICE_TTL_MS = 5 * 60 * 1000;
const INVITE_TTL_MS = 5 * 60 * 1000;
const CHECK_INTERVAL = 30 * 1000;
const CHECK_MAX_TRIES = 15;
const USE_UNIQUE_FEE = true;

// Fallback untuk nomor owner dan nama bot
const nomorown = global.nomorown || "62895362282300"; // Ganti dengan nomor default jika tidak ada
const namebot = global.namebot || "JagoanBot"; // Ganti dengan nama default jika tidak ada

// Inisialisasi global state jika belum ada
global.__BUYSC__ = global.__BUYSC__ || {
  pending: {},      // { userJid: {...} }
  paid: {},         // { userJid: {...} }
  inviteTimers: {}, // { userJid: Timeout }
};

// Path untuk menyimpan data sewa
const sewaPath = path.join(__dirname, '../lib/sewa.json');
let sewa = fs.existsSync(sewaPath) ? JSON.parse(fs.readFileSync(sewaPath)) : {};
function saveSewa() { fs.writeFileSync(sewaPath, JSON.stringify(sewa, null, 2)) }

// Utils
function getRandomFee() { return Math.floor(Math.random() * 150) + 1 }

async function sendCopyButton(conn, chatId, bodyText, codeToCopy, footerText = '') {
  const msg = generateWAMessageFromContent(
    chatId,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: bodyText }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: footerText }),
            header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: 'Salin Format .db',
                    copy_code: codeToCopy
                  })
                }
              ]
            })
          })
        }
      }
    },
    { userJid: chatId }
  );
  await conn.relayMessage(chatId, msg.message, { messageId: msg.key.id });
}

async function tryDeleteSentMessage(conn, chatId, sentMsgKey) {
  if (!sentMsgKey) return;
  try {
    if (typeof conn.deleteMessage === 'function') {
      const messageId = sentMsgKey.id || (sentMsgKey.key && sentMsgKey.key.id) || sentMsgKey?.key?.id;
      if (messageId) await conn.deleteMessage(chatId, messageId, {});
      return;
    }
    await conn.sendMessage(chatId, { delete: sentMsgKey }).catch(() => {});
  } catch (e) {}
}

async function sendGroupInviteWithAutoRevoke(conn, userJid) {
  const timers = global.__BUYSC__.inviteTimers;
  if (timers[userJid]) { clearTimeout(timers[userJid]); delete timers[userJid]; }

  let link;
  try {
    const code = await conn.groupInviteCode(GROUP_SC);
    link = `https://chat.whatsapp.com/${code}`;
  } catch (e) {
    await conn.sendMessage(userJid, { text: "⚠ Gagal membuat link grup, coba lagi beberapa saat." });
    return;
  }

  await conn.sendMessage(userJid, { text:
`🔗 Link grup SC (berlaku ${Math.floor(INVITE_TTL_MS/60000)} menit):
${link}

Jika tidak bergabung dalam ${Math.floor(INVITE_TTL_MS/60000)} menit, link akan dicabut.
Ketik .buysc lagi untuk meminta link baru (tanpa perlu bayar ulang).`
  });

  timers[userJid] = setTimeout(async () => {
    try { await conn.groupRevokeInvite(GROUP_SC); } catch {}
    await conn.sendMessage(userJid, { text: "⛔ Link grup kadaluarsa. Ketik .buysc untuk minta link baru." }).catch(() => {});
    delete timers[userJid];
  }, INVITE_TTL_MS);
}

async function sendInvoice(conn, chatId, userJid) {
  // Pastikan global.__BUYSC__.pending terinisialisasi
  if (!global.__BUYSC__.pending) global.__BUYSC__.pending = {};

  const fee = USE_UNIQUE_FEE ? getRandomFee() : 0;
  const total = PRICE_BUYSC + fee;
  const trxid = 'INV-' + Date.now();
  global.__BUYSC__.pending[userJid] = { trxid, fee, total, chatId, startedAt: Date.now() };

  try {
    let response = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
      project: PROJECT,
      order_id: trxid,
      amount: total,
      api_key: API_KEY
    });
    let data = response.data.payment;

    if (!data.payment_number) throw new Error('Payment number tidak ditemukan');

    let qrImageBuffer = await QRCode.toBuffer(data.payment_number, {
      type: 'png',
      errorCorrectionLevel: 'H',
      width: 900
    });

    const templateUrl = templateQRIS;
    const templateResponse = await axios.get(templateUrl, { responseType: 'arraybuffer' });
    const templateBuffer = Buffer.from(templateResponse.data);

    const resizedQrBuffer = await sharp(qrImageBuffer)
      .resize(953, 953)
      .toBuffer();
    const finalImage = await sharp(templateBuffer)
      .composite([{ input: resizedQrBuffer, top: 600, left: 230, fit: 'contain' }])
      .toBuffer();

    const caption = `┏━━━『 📜 BUY SCRIPT 』
┃ 📦 Item     : Script MD
┃ 💰 Harga    : Rp${PRICE_BUYSC.toLocaleString()}
┃ 🔢 Fee unik : Rp${fee.toLocaleString()}
┃ 💵 Total    : Rp${total.toLocaleString()}
┃ 🆔 TrxID    : ${trxid}
┃ ⏳ Berlaku ${Math.floor(INVOICE_TTL_MS/60000)} menit
┗━━━━━━━━━━━━`;

    const sent = await conn.sendMessage(chatId, { image: finalImage, caption }, { quoted: null });
    global.__BUYSC__.pending[userJid].sentMsgKey = sent?.key || null;

    await conn.relayMessage(
      chatId,
      {
        interactiveMessage: {
          header: { title: "🔗 Salin Nominal Pembayaran", hasMediaAttachment: false },
          body: { text: `Klik tombol di bawah untuk *menyalin* nominal total.\nNominal: Rp${total.toLocaleString()}` },
          footer: { text: "Gunakan nominal persis agar terdeteksi otomatis." },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: `Salin: ${total}`,
                  copy_code: String(total)
                })
              }
            ]
          }
        }
      },
      {}
    );

    cekPembayaran(conn, userJid);
  } catch (e) {
    console.error('Error generating QR:', e);
    await conn.sendMessage(chatId, { text: `❌ Gagal generate QR: ${e.message || 'Unknown error'}` });
    delete global.__BUYSC__.pending[userJid];
  }
}

async function cekPembayaran(conn, userJid) {
  const data = global.__BUYSC__.pending[userJid];
  if (!data) return;
  let tries = 0;
  const url = `https://app.pakasir.com/api/transactiondetail?project=${PROJECT}&amount=${data.total}&order_id=${data.trxid}&api_key=${API_KEY}`;

  const interval = setInterval(async () => {
    tries++;
    try {
      const res = await axios.get(url);
      const transaction = res.data.transaction;
      if (transaction.status === 'completed') {
        clearInterval(interval);
        const { chatId, sentMsgKey, total, trxid } = data;
        delete global.__BUYSC__.pending[userJid];
        try { await tryDeleteSentMessage(conn, chatId, sentMsgKey); } catch {}

        global.__BUYSC__.paid[userJid] = { trxid, total, paidAt: Date.now() };

        const sukses = `┏━━━『 ✅ PEMBAYARAN SUKSES 』
┃ 📦 Paket : Script MD
┃ 💵 Total : Rp${total.toLocaleString()}
┃ 🆔 TrxID : ${trxid}
┗━━━━━━━━━━━━

Klik tombol di bawah untuk menyalin format .db ke clipboard, lalu tempel & isi datanya.`;

        const formatDb = `.db Nama Asli :\nNomor Utama :\nNomor BOT :`;
        await sendCopyButton(conn, chatId, sukses, formatDb, 'Link grup akan dikirim via private chat setelah .db kamu diterima.');

        if (global.owner && Array.isArray(global.owner)) {
          const admin = `┏━━━『 📢 BUYSC NOTIF 』
┃ 👤 User  : ${userJid}
┃ 💵 Total : Rp${total.toLocaleString()}
┃ 🆔 TrxID : ${trxid}
┗━━━━━━━━━━━━`;
          for (const v of global.owner) {
            try {
              const ownerNum = Array.isArray(v) ? v[0] : v;
              const ownerJid = ownerNum.toString().replace(/[^0-9]/g, '') + '@s.whatsapp.net';
              await conn.sendMessage(ownerJid, { text: admin }).catch(() => {});
            } catch (e) {}
          }
        }
      }
    } catch (e) {
      console.error('cekPembayaran error:', e?.message || e);
    }

    if (tries >= CHECK_MAX_TRIES) {
      clearInterval(interval);
      const d = global.__BUYSC__.pending[userJid];
      if (d) {
        try { await tryDeleteSentMessage(conn, d.chatId, d.sentMsgKey); } catch {}
        delete global.__BUYSC__.pending[userJid];
        await conn.sendMessage(d.chatId, { text: "⏰ Waktu pembayaran habis. Ketik .buysc lagi untuk mendapatkan QR baru." });
      }
    }
  }, CHECK_INTERVAL);
}

// Handler utama
let handler = async (m, { conn, args, command }) => {
  const userJid = m.sender;
  const chatId = m.chat;
  const pushname = m.pushName || "Kawan"; // Ambil pushName seperti bot-autosapa.js

  if (/^(sc|sourcecode)$/i.test(command)) {
    let esce = `
𝗦𝗖𝗥𝗜𝗣𝗧 𝗕𝗢𝗧 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗥𝗜𝗕𝗨𝗔𝗡 𝗙𝗜𝗧𝗨𝗥 𝗚𝗥𝗔𝗧𝗜𝗦 𝗣𝗔𝗡𝗘𝗟 𝗟𝗔𝗚𝗜 ?😱

Hai ${pushname}! Kamu Mau Beli SC Ini? Sebelum beli, pastikan paham cara instalasi ya. Tonton cara install Script di sini: https://youtu.be/LkWie8a52N0
  
Script Jagoan Project ini memiliki banyak keuntungan:
✅ Free Konsultasi Penginstalan untuk buyer awam sekalipun, dijamin bisa pasang
✅ Free Panel Selama Sebulan (+15 hari)
✅ Masuk grup khusus Update dan Grup Diskusi (permanen)
✅ Type Plugin CJS – Bebas menambahkan fitur
✅ 100% NO ENC – Leluasa dimodifikasi
✅ Memakai Scrape dan API premium yang selalu diperpanjang
✅ Saat ini ada total 1200+ fitur
✅ Bebas Request Fitur, bebas lapor error.
  
Harga SC Saat Ini: _Rp. 80.000_ (Harga bisa bertambah seiring berkembangnya fitur-fitur, jadi jangan sampai beli di harga tinggi, ntar nyesel loh hehe)

Sung pm:
Admin 1: 62895362282300
Admin 2: 6282252509320
   
> Jagoan Project
`.trim();

    await conn.sendMessage(chatId, {
      text: esce,
      contextInfo: {
        externalAdReply: {
          title: `💎 Script Premium ${namebot}`,
          body: `Klik di sini untuk chat developer`,
          thumbnailUrl: await conn.profilePictureUrl(`${nomorown}@s.whatsapp.net`, 'image')
            .catch(_ => "https://d.uguu.se/GwVJexzf.jpg"),
          sourceUrl: `https://wa.me/${nomorown}`,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      },
      buttons: [
        {
          buttonId: '.buysc',
          buttonText: { displayText: '🛒 Beli SC Sekarang' },
          type: 1
        }
      ],
      headerType: 1
    }, { quoted: m });
  } else if (/^buysc$/i.test(command)) {
    if (global.__BUYSC__.paid[userJid]) {
      await conn.sendMessage(chatId, { text: "✅ Pembayaran kamu sudah terverifikasi. Link grup akan dikirim ke private chat sekarang." });
      await sendGroupInviteWithAutoRevoke(conn, userJid);
      return;
    }
    await sendInvoice(conn, chatId, userJid);
  } else if (/^db$/i.test(command)) {
    if (!global.__BUYSC__.paid[userJid]) {
      return m.reply("❌ Akses .db hanya untuk user yang sudah menyelesaikan pembayaran. Ketik .buysc untuk memulai.");
    }

    const text = (args && args.length) ? args.join(' ') : '';
    const raw = text || (m?.text?.slice(3).trim()) || '';
    if (!raw) {
      return m.reply(
`⚠️ Format belum diisi.

Silakan kirim:
.db Nama Asli :
Nomor Utama :
Nomor BOT :

Contoh:
.db Nama Asli : Rizal F
Nomor Utama : 62812xxxxxxx
Nomor BOT : 62857xxxxxxx`
      );
    }

    const namaMatch = raw.match(/Nama Asli\s*:\s*(.+)/i);
    const utamaMatch = raw.match(/Nomor Utama\s*:\s*(.+)/i);
    const botMatch = raw.match(/Nomor BOT\s*:\s*(.+)/i);

    if (!namaMatch || !utamaMatch || !botMatch) {
      return m.reply("❌ Format tidak lengkap. Pastikan tiga baris: Nama Asli, Nomor Utama, Nomor BOT.");
    }

    const namaAsli = namaMatch[1].trim();
    const nomorUtama = utamaMatch[1].trim();
    const nomorBot = botMatch[1].trim();

    const forwardText = `📥 *Data Pembeli Script*
• Nama Asli   : ${namaAsli}
• Nomor Utama : ${nomorUtama}
• Nomor BOT   : ${nomorBot}
• JID Pengirim: ${userJid}`;

    try {
      await conn.sendMessage(GROUP_SC, { text: forwardText });
    } catch (e) {
      return m.reply("⚠️ Gagal mengirim data ke grup. Coba lagi beberapa saat.");
    }

    await conn.sendMessage(chatId, { text: "✅ Data kamu sudah dikirim ke grup. Link grup akan dikirim ke *private chat* sekarang." });
    await sendGroupInviteWithAutoRevoke(conn, userJid);
  }
};

// Auto reset link on join
handler.participantsUpdate = async (conn, { id, participants, action }) => {
  try {
    if (id === GROUP_SC && action === 'add') {
      await conn.groupRevokeInvite(GROUP_SC);
    }
  } catch (e) {}
};

handler.groupParticipantsUpdate = handler.participantsUpdate;

handler.help = ['sc', 'script'];
handler.tags = ['info', 'store'];
handler.command = /^(sc|sourcecode|buysc|db)$/i;

handler.register = true

module.exports = handler;