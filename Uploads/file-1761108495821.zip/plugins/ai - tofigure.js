const axios = require('axios')
const { Sticker } = require("wa-sticker-formatter")
const fs = require("fs")
const path = require("path")
const uploadImage = require("../lib/uploadImage")
const uploadFile = require("../lib/uploadFile")

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ""

  if (!mime || !/image|webp/.test(mime)) {
    return m.reply(`📸 Balas gambar/stiker dengan caption *${usedPrefix}${command}* [prompt opsional]`)
  }

  // Download media
  const media = await q.download()
  if (!media) return m.reply("❌ Gagal mengunduh gambar.")

  // Upload ke CDN untuk mendapatkan URL
  const isTele = /image\/(png|jpe?g|gif)/.test(mime)
  const uploadedUrl = await (isTele ? uploadImage : uploadFile)(media)

  const prompt =
    text && text.length > 5
      ? text
      : `Buat figurine komersial skala 1/7 dari karakter di gambar yang mirip 100% dari gaya dan bentuk asli karakter dengan detail yang sama, dalam gaya realistis, di lingkungan nyata. Figurine diletakkan di atas meja komputer. Figurine memiliki alas akrilik transparan bulat tanpa teks. Konten di layar komputer menunjukkan proses pemodelan Zbrush dari figurine ini dengan proses masih abu-abu, belum ada warna. Di samping layar komputer ada kotak kemasan mainan gaya BANDAI dengan cetakan artwork asli. Kemasan menampilkan ilustrasi dua dimensi datar sesuai karakter utama.`

  try {
    m.reply("⏳ Lagi dibuatkan figurine AI, Harap sabar. jika gagal laporkan error ke owner.\n> Limit -15")

    // Panggil API AlyaChan
    const response = await axios.get(`${global.alyachan}/api/ai-edit`, {
      params: {
        image: uploadedUrl,
        prompt: prompt,
        apikey: global.alyachankey
      }
    })

    const images = response.data.data.images
    if (!images || images.length === 0) {
      throw new Error("❌ Tidak ada gambar yang dihasilkan dari API")
    }

    // Tunggu 10 detik sebelum mengirim hasil
    await new Promise(resolve => setTimeout(resolve, 10000))

    // Proses dan kirim kedua gambar
    for (let i = 0; i < Math.min(images.length, 2); i++) {
      const imageUrl = images[i].url
      const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' })
      const resultImage = Buffer.from(imageResponse.data)

      // Simpan hasil sementara
      const tempPath = path.join(
        process.cwd(),
        "tmp",
        `tofigure_${Date.now()}_${i}.png`
      )
      fs.writeFileSync(tempPath, resultImage)

      // Jika input adalah stiker, hasilnya juga stiker
      if (/webp/g.test(mime)) {
        const stikerResult = await createSticker(
          resultImage,
          false,
          "AI-Figurine",
          "Jagoan Project"
        )
        await conn.sendMessage(m.chat, { sticker: stikerResult }, { quoted: m })
      } else {
        // Jika input adalah gambar, kirim gambar
        await conn.sendMessage(
          m.chat,
          {
            image: resultImage,
            caption: `✅ Figurine AI selesai dibuat! Gambar ${i + 1})`
          },
          { quoted: m }
        )
      }

      // Cleanup
      setTimeout(() => {
        try {
          if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath)
        } catch (err) {
          console.error("Cleanup error:", err)
        }
      }, 30000)
    }
  } catch (e) {
    console.error("❌ Error di handler tofigure:", e)
    m.reply("❌ Gagal membuat figurine: " + e.message)
  }
}

async function createSticker(img, url, packName, authorName, quality = 20) {
  return new Sticker(img ? img : url, {
    type: "full",
    pack: packName,
    author: authorName,
    quality,
  }).toBuffer()
}

handler.help = ["tofigure"]
handler.tags = ["ai"]
handler.command = /^tofigure$/i
handler.limit = 15
handler.register = true

module.exports = handler