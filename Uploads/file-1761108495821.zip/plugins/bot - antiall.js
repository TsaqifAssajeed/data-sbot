// ✨ Plugin bot - antiall ✨

// ✨ Plugin _antiall ✨

// ✨ Plugin _antiall ✨

async function before(m, { conn }) {
    let chat = global.db.data.chats[m.chat]

    // kalau belum ada chat data → bikin default
    if (!chat) {
        global.db.data.chats[m.chat] = { antiall: false }
        chat = global.db.data.chats[m.chat]
    }

    // fitur OFF → stop
    if (!chat.antiall) return
    if (!m.isGroup) return

    // skip kalau pesan dari bot sendiri
    if (m.fromMe) return 

    // kalau bukan text → hapus
    if (!m.text) {
        try {
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            })

            // kasih notif sekali aja
            await conn.sendMessage(m.chat, {
                text: `🚫 *ANTI ALL MEDIA*\n@${m.sender.split('@')[0]} media kamu dihapus!`,
                mentions: [m.sender]
            })

            console.log(`[ANTIALL] Media dari ${m.sender} dihapus di ${m.chat}`)
        } catch (e) {
            console.error('❌ Error AntiAll:', e)
        }
    }
}

module.exports = { before }