/**
 * CR Jagoan Project (Sora2 Feature)
 * PLUGIN: ai - sora2.js
 * DESC: Generate AI Video from Image using Sora-2 model (Omegatech API)
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

/**
 * Validasi input untuk memastikan tipe data yang benar
 * @param {*} input
 * @returns {Buffer}
 */
const validateInput = (input) => {
  if (Buffer.isBuffer(input)) return input;
  if (input instanceof Uint8Array || input instanceof ArrayBuffer) {
    return Buffer.from(input);
  }
  if (typeof input === 'object' && input.data) {
    return Buffer.from(input.data);
  }
  throw new TypeError(`Expected input to be Uint8Array, Buffer, or ArrayBuffer, got ${typeof input}`);
};

/**
 * Upload file to https://qu.ax
 * @param {Buffer} buffer File Buffer
 * @returns {string|null|(string|null)[]}
 */
const quax = async (buffer) => {
  buffer = validateInput(buffer);
  let { ext, mime } = await fromBuffer(buffer) || { ext: 'bin', mime: 'application/octet-stream' };
  const form = new FormData();
  form.append('files[]', buffer, {
    filename: 'tmp.' + ext,
    contentType: mime,
  });
  form.append('expiry', '-1');

  const { data } = await axios.post(
    'https://qu.ax/upload.php',
    form,
    {
      headers: { ...form.getHeaders() },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    }
  );

  return data.files[0].url;
};

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // Validasi input prompt
    if (!text) {
        return m.reply(`❌ Gunakan format:\n*${usedPrefix + command} <prompt>*\nContoh:\n• *${usedPrefix + command} sedang strika baju lalu terbakar dan akhirnya meleleh gosong dan mengeluarkan api*`);
    }
    const prompt = text.trim();

    // Ambil media dari pesan yang di-reply atau pesan itu sendiri
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    // Validasi MIME type
    if (!mime || !/image\/(png|jpe?g|gif)/.test(mime)) {
        return m.reply(`📸 Kirim atau reply gambar (PNG, JPEG, atau GIF) dengan caption *${usedPrefix}${command} <prompt>*!`);
    }

    // Download media
    let media;
    try {
        media = await q.download();
        if (!media) throw new Error('Gagal mengunduh media.');
        console.log(`[DEBUG] Media berhasil diunduh, ukuran: ${media.length} bytes`);
    } catch (e) {
        console.error(`[ERROR] Gagal mengunduh media: ${e.message}`);
        return m.reply('❌ Gagal mengunduh gambar. Coba lagi nanti.');
    }

    // Simpan media sementara
    const tempImgPath = path.join(process.cwd(), 'tmp', `temp_image_${Date.now()}.jpg`);
    try {
        fs.writeFileSync(tempImgPath, media);
        console.log(`[DEBUG] Media disimpan di: ${tempImgPath}`);
    } catch (e) {
        console.error(`[ERROR] Gagal menyimpan media: ${e.message}`);
        return m.reply('❌ Gagal menyimpan gambar. Coba lagi nanti.');
    }

    // Upload gambar ke qu.ax
    let imageUrl;
    try {
        imageUrl = await quax(media);
        console.log(`[DEBUG] Gambar diunggah, URL: ${imageUrl}`);
    } catch (e) {
        console.error(`[ERROR] Gagal mengunggah gambar: ${e.message}`);
        // Cleanup
        if (fs.existsSync(tempImgPath)) fs.unlinkSync(tempImgPath);
        return m.reply('❌ Gagal mengunggah gambar ke server. Coba lagi nanti.');
    }

    // Kirim pesan proses
    await m.reply(`🧠 Membuat video AI dengan teknologi Sora-2...\n> Prompt: *${prompt}*\n> Harap bersabar, proses ini bisa memakan waktu hingga 20 menit.\n> Limit berkurang 70`);

    try {
        const headers = {
            'accept': 'application/json',
            'content-type': 'application/json',
            'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36',
        };

        const api = axios.create({
            baseURL: 'https://omegatech-api.dixonomega.tech/api/ai',
            headers
        });

        // Buat task video
        const { data: task } = await api.post('/Sora2-createv2', {
            prompt: prompt,
            imageUrl: imageUrl
        });

        console.log('[🎬 Task Created] Task ID:', task.taskId);

        // Timeout 20 menit (1200 detik)
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => {
                reject(new Error('Timeout: Proses pembuatan video terlalu lama (lebih dari 20 menit).'));
            }, 20 * 60 * 1000); // 20 menit dalam milidetik
        });

        // Polling status
        const maxAttempts = 120; // 120 x 10 detik = 20 menit
        let attempts = 0;

        const pollStatus = async () => {
            while (attempts < maxAttempts) {
                attempts++;
                const { data } = await api.get(`/sora2-status?id=${task.taskId}`);
                console.log(`[⌛ Attempt ${attempts}] Status: ${data.status}, Progress: ${data.progress}`);

                // Jika status sudah selesai
                if (data.status === 'completed') {
                    const videoUrl = data.videoUrl;
                    if (videoUrl) {
                        console.log('[✅ Success] Video ready:', videoUrl);
                        await conn.sendMessage(m.chat, {
                            video: { url: videoUrl },
                            caption: `✅ Video berhasil dibuat!\n> Prompt: *${prompt}*\n> Sumber: Omegatech API (@Omegatech-01)`
                        }, { quoted: m });
                        return true;
                    } else {
                        throw new Error('Tidak ada URL video di hasil.');
                    }
                }

                // Delay 10 detik
                await new Promise(res => setTimeout(res, 10000));
            }
            throw new Error('Timeout: Proses pembuatan video terlalu lama (lebih dari 20 menit).');
        };

        // Jalankan polling dengan timeout
        await Promise.race([pollStatus(), timeoutPromise]);

        // Cleanup
        setTimeout(() => {
            try {
                if (fs.existsSync(tempImgPath)) fs.unlinkSync(tempImgPath);
                console.log(`[DEBUG] File sementara dihapus: ${tempImgPath}`);
            } catch (err) {
                console.error(`[ERROR] Cleanup error: ${err.message}`);
            }
        }, 30000);

    } catch (error) {
        console.error('[❌ Error]', error.message, error.response?.data || error.stack);
        let errorMessage = `❌ Gagal membuat video: ${error.message}\n`;
        if (error.message.includes('Timeout')) {
            errorMessage = `❌ Timeout: Proses pembuatan video terlalu lama (lebih dari 20 menit). Silakan coba lagi nanti.\n`;
        } else if (error.response?.status === 403) {
            errorMessage += `🔐 Akses ditolak (403). Pastikan API key valid atau cek https://omegatech-api.dixonomega.tech.\n`;
        }
        errorMessage += `💡 Tips: Gunakan prompt yang jelas atau coba lagi nanti.`;

        // Cleanup
        if (fs.existsSync(tempImgPath)) fs.unlinkSync(tempImgPath);
        return m.reply(errorMessage);
    }
};

handler.command = /^sora2$/i;
handler.tags = ['ai'];
handler.limit = 70;
handler.register = true;

module.exports = handler;