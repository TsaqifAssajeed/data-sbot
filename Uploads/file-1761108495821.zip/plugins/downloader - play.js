
let search = require('yt-search');
let fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan link atau judul dari *youtube!*';
    try {
        await m.reply('🔄 Tunggu sebentar, sedang memproses...')
        const look = await search(text);
        const convert = look.videos[0];
        if (!convert) throw 'Video/Audio Tidak Ditemukan';
        if (convert.seconds >= 18000) {
            return conn.reply(m.chat, '❌ Video lebih dari 5 jam, tidak bisa!', m);
        }

        let audioUrl;
        let apiSource = '';

        // ==== API PERTAMA: BOTCAHX ====
        try {
            const res = await fetch(`${global.apibtc}/api/dowloader/yt?url=${convert.url}&apikey=${btc}`);
            const botcahx = await res.json();

            if (!botcahx || !botcahx.result?.mp3) throw new Error('Botcahx API gagal');

            audioUrl = botcahx;
            apiSource = 'pertama (Botcahx)';
        } catch (e) {
            // ==== FALLBACK KEDUA: TERMAI ====
            try {
                const res = await fetch(`${global.apixtermurl}/api/downloader/youtube?type=mp3&url=${convert.url}&key=${global.apixtermkey}`);
                const termai = await res.json();

                if (!termai?.status || !termai?.data?.dlink) throw new Error('Termai API gagal');

                audioUrl = {
                    result: { mp3: termai.data.dlink }
                };
                apiSource = 'kedua (Termai)';
            } catch (err) {
                conn.reply(m.chat, '⚠️ Terjadi kesalahan saat mengunduh audio (Botcahx & Termai gagal)', m);
                return;
            }
        }

        let caption = `> Hasil dari API: ${apiSource}\n\n`;
        caption += `∘ Title : ${convert.title}\n`;
        caption += `∘ ID : ${convert.videoId}\n`;
        caption += `∘ Duration : ${convert.timestamp}\n`;
        caption += `∘ Viewers : ${convert.views}\n`;
        //caption += `∘ Upload At : ${convert.ago}\n`;
        caption += `∘ Author : ${convert.author.name}\n`;
        caption += `∘ Channel : ${convert.author.url}\n`;
        caption += `∘ Url : ${convert.url}\n`;
        caption += `∘ Description : ${convert.description}\n`;
        caption += `∘ Thumbnail : ${convert.image}`;

        await conn.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                externalAdReply: {
                    title: convert.title,
                    mediaType: 1,
                    previewType: 0,
                    renderLargerThumbnail: true,
                    thumbnailUrl: convert.image,
                    sourceUrl: convert.url
                }
            }
        }, { quoted: m });

        // Kirim audio hasil API
        await conn.sendMessage(m.chat, {
            audio: {
                url: audioUrl.result.mp3
            },
            mimetype: 'audio/mpeg',
            contextInfo: {
                externalAdReply: {
                    title: convert.title,
                    thumbnailUrl: convert.image,
                    sourceUrl: convert.url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, '⚠️ Terjadi kesalahan saat memproses permintaan', m);
    }
};

handler.help = ['play / song'];
handler.command = ['play', 'song', 'ds'];
handler.tags = ['downloader'];
handler.limit = 10;

handler.register = true
module.exports = handler;
