const moment = require('moment-timezone');
const fs = require('fs');

// Path untuk database toxic
const toxicDbPath = './lib/datatoxic.json';

// Pastikan file database ada
if (!fs.existsSync(toxicDbPath)) {
    fs.writeFileSync(toxicDbPath, JSON.stringify([]));
}

// Maksimum peringatan sebelum kick
const maxWarn = 7;

const handler = async (m, { usedPrefix, text, command, isOwner, conn }) => {
    if (!conn) throw new Error('Koneksi bot (conn) tidak tersedia!');

    let toxicWords = JSON.parse(fs.readFileSync(toxicDbPath, 'utf8'));

    if (command === 'listtoxic') {
        if (!toxicWords.length) throw `⚠️ Belum ada kata toxic di database, nih! Tambah pake *${usedPrefix}addtoxic* yuk!`;

        const greetings = (() => {
            const hours = moment().tz('Asia/Makassar').hour();
            return hours < 6 ? '🌙 Selamat Malam' 
                 : hours < 12 ? '☀️ Selamat Pagi' 
                 : hours < 16 ? '🌞 Selamat Siang' 
                 : hours < 19 ? '🌅 Selamat Sore'
                 : '🌙 Selamat Malam';
        })();
        
        const userName = m.pushName || m.name || 'Sobat';
        const toxicList = toxicWords
            .sort((a, b) => a.localeCompare(b))
            .map(word => `🔹 ${word}`)
            .join('\n');

        const replyMessage = `${greetings}, ${userName}! ✨\n\n📜 Daftar kata toxic:\n${toxicList}\n\n💡 Gunakan *${usedPrefix}addtoxic* atau *${usedPrefix}deltoxic* buat kelola daftar!`;
        return conn.sendMessage(m.chat, { text: replyMessage });
    }

    if (command === 'addtoxic') {
        if (!isOwner) throw `🚫 Maaf, cuma *Owner* yang bisa nambah kata toxic!`;
        if (!text) throw `❓ Kata apa yang mau ditambah? Contoh: *${usedPrefix}${command} jelek*`;

        const newWord = text.trim().toLowerCase();
        if (toxicWords.includes(newWord)) {
            throw `⚠️ Kata *${newWord}* udah ada di daftar toxic, loh!`;
        }

        toxicWords.push(newWord);
        fs.writeFileSync(toxicDbPath, JSON.stringify(toxicWords, null, 2));
        return conn.sendMessage(m.chat, { text: `✅ Kata *${newWord}* berhasil ditambah ke daftar toxic! 🚀` });
    }

    if (command === 'deltoxic') {
        if (!isOwner) throw `🚫 Maaf, cuma *Owner* yang bisa hapus kata toxic!`;
        if (!text) throw `❓ Kata apa yang mau dihapus? Contoh: *${usedPrefix}${command} jelek*`;

        const wordToDelete = text.trim().toLowerCase();
        const wordIndex = toxicWords.indexOf(wordToDelete);

        if (wordIndex !== -1) {
            toxicWords.splice(wordIndex, 1);
            fs.writeFileSync(toxicDbPath, JSON.stringify(toxicWords, null, 2));
            return conn.sendMessage(m.chat, { text: `🗑️ Kata *${wordToDelete}* berhasil dihapus dari daftar toxic! 🎉` });
        } else {
            throw `❌ Kata *${wordToDelete}* nggak ada di daftar. Cek pake *${usedPrefix}listtoxic*!`;
        }
    }

    throw `⚡ Perintah salah! Coba: *${usedPrefix}listtoxic*, *${usedPrefix}addtoxic*, atau *${usedPrefix}deltoxic*`;
};

// Handler untuk mendeteksi kata toxic dan sistem peringatan
handler.all = async function (m, chatUpdate) {
    const conn = this;

    if (!conn) return;
    if (!m || !m.text || !m.chat || !m.key) return;
    if (m.fromMe) return;

    // Cek apakah fitur anti-toxic aktif di grup ini
    let chat = global.db.data.chats[m.chat];
    if (!chat || !chat.antiToxic) return;

    let toxicWords = JSON.parse(fs.readFileSync(toxicDbPath, 'utf8'));
    const messageText = m.text.toLowerCase();
    const who = m.sender;

    // Inisialisasi data pengguna jika belum ada
    if (!(who in global.db.data.users)) {
        global.db.data.users[who] = {
            warn: 0
        };
    }

    let warn = global.db.data.users[who].warn;

    for (const toxicWord of toxicWords) {
        const regex = new RegExp(`\\b${toxicWord}\\b`, 'i');
        if (regex.test(messageText)) {
            try {
                await conn.sendMessage(m.chat, { delete: m.key });

                if (warn < maxWarn) {
                    global.db.data.users[who].warn += 1;
                    
                    // Peringatan untuk grup dengan fakeReply dan thumbnail
                    const groupWarning = `🚨 *Peringatan Toxic* 🚨\n\n` +
                        `✧ *Pengguna:* @${who.split`@`[0]}\n` +
                        `✧ *Kata Toxic:* ${toxicWord}\n` +
                        `✧ *Peringatan:* ${warn + 1}/${maxWarn}\n` +
                        `Pesan telah dihapus!\n> Apabila Melampaui batas, user akan di kick dari grup`;
                    
                    await conn.sendMessage(m.chat, {
                        text: groupWarning,
                        contextInfo: {
                            externalAdReply: {
                                title: '‼️Toxic Detected',
                                body: '',
                                thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/antritoxic.png', // Thumbnail URL
                                sourceUrl: '',
                                mediaType: 1,
                                renderLargerThumbnail: false
                            },
                            mentionedJid: [who] // Pastikan mention aktif
                        }
                    }, { quoted: { key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' }, message: { conversation: 'Toxic Detected' } } });

    
                } else if (warn >= maxWarn) {
                    // Reset warning dan kick pengguna
                    global.db.data.users[who].warn = 0;
                    
                    // Notifikasi kick dengan fakeReply dan thumbnail
                    const kickMessage = `Upss.. @${who.split`@`[0]} telah melampaui batas ${maxWarn} peringatan karena berkata toxic! Akan di tendang dari grup!`;
                    
                    await conn.sendMessage(m.chat, {
                        text: kickMessage,
                        contextInfo: {
                            externalAdReply: {
                                title: '⛔ Toxic Detected',
                                body: '',
                                thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/antritoxic.png', // Thumbnail URL
                                sourceUrl: '',
                                mediaType: 1,
                                renderLargerThumbnail: false
                            },
                            mentionedJid: [who] // Pastikan mention aktif
                        }
                    }, { quoted: { key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' }, message: { conversation: 'Toxic Detected' } } });
                    
                    await time(3000); // Delay 3 detik sebelum kick
                    await conn.groupParticipantsUpdate(m.chat, [who], 'remove');
                    
                
                }
                return;
            } catch (err) {
                console.error('Gagal memproses peringatan toxic:', err);
            }
        }
    }
};

handler.help = ['listtoxic', 'addtoxic', 'deltoxic'];
handler.tags = ['group'];
handler.command = /^listtoxic|addtoxic|deltoxic$/i;
handler.owner = false;
handler.group = true;
handler.botAdmin = true;

handler.register = true
handler.limit = true
module.exports = handler;

const time = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};