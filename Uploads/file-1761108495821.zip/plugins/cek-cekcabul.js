let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.cabul)}”`, m)
}
handler.help = ['cekcabul']
handler.tags = ['cek']
handler.command = /^(cekcabul)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.cabul = [
'Cabul 1%\nAman Mas',
'Cabul 5%\nBoleh Lah',
'Cabul 10%\nNggak Cabul',
'Cabul 15%\nAman Kok',
'Cabul 20%\nHampir Aman',
'Cabul 25%\nWahh Udah Rada Rada Nih',
'Cabul 30%\n😨😨😨',
'Cabul 35%\nHentikan Nonton Bokep Sebelum Telat',
'Cabul 40%\nMulai Lu Mulai, Jangan Sampe Lu Ewe Pacar Orang Ya\nAwas Lu',
'Cabul 45%\nUdah Mau Setengah Cabul Njir',
'Cabul 50%\nWaduh Rek Setengah Loh Ya',
'Cabul 55%\nKadang Cabul Kadang Enggak',
'Cabul 60%\nGak Aman',
'Cabul 65%\nWaduh Loh Ya',
'Cabul 70%\nHadeh Bang, Jangan Kebanyakan Nonton Bokep Lah',
'Cabul 75%\nMenjauh Kau Cabul',
'Cabul 80%\nAduhh Bang Jangan Ewe Gw, Gw Cowok Bang',
'Cabul 85%\nColi Mulu Dia Nih',
'Cabul 90%\nLiat Porno Dikit Langsung Ngaceng',
'Cabul 95%\nNenek Nenek Pun Di Ewe Sama Dia Nih',
'Cabul 100%\n☠️☠️☠️☠️☠️',
'Cabul Pro\nHarus Di Basmi Dia Nih Woi',
'Inilah Cabul Tersebut\nBROO NO WAYY GAK NYANGKA GW LU SECABUL ITU',
'Cabul ProMax\nAnjir Lu Cok Segala Jenis Manusia Di Embat\nNenek Gw Pun Lu Embat',
]