const fetch = require('node-fetch')

const isValidWord = (text) => /^[a-zA-Z]{2,}$/.test(text)
const cleanInput = text => text
    .replace(/[\u{1F600}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
    .replace(/[^a-zA-Z]/g, '')
    .toLowerCase()

let timeout = 60000 // waktu timeout dalam milidetik

let handler = async (m, { conn, usedPrefix, command }) => {
    conn.sambungkata = conn.sambungkata || {}
    let id = m.chat

    if (command === 'sambungkata') {
        if (id in conn.sambungkata)
            return conn.reply(m.chat, '_Masih ada game yang belum selesai_', conn.sambungkata[id].message)

        let kataAwal = m.text.split(' ')[1]
        if (!kataAwal || m.text.trim().split(/\s+/).length > 2)
            return conn.reply(m.chat, `📝 Masukan kata awal :\n\nContoh: *${usedPrefix}sambungkata makan*`, m)

        kataAwal = cleanInput(kataAwal)

        if (!isValidWord(kataAwal)) return conn.reply(m.chat, `⚠️ Kata tidak valid!`, m)
        if (!(await cekKataKBBI(kataAwal))) return conn.reply(m.chat, `⚠️ Kata *${kataAwal}* tidak ditemukan di KBBI`, m)

        let caption = `🎮 *SAMBUNG KATA DIMULAI!* 🎮

*📝 PERATURAN :*

1️⃣ Kata pertama : *${kataAwal}*
2️⃣ Kata berikutnya dari huruf : *"${kataAwal.slice(-1).toUpperCase()}"*
3️⃣ Kata wajib sesuai *KBBI*
⏳ Waktu : *60 detik*
🎁 Hadiah: +3 limit & hingga Rp.3000 per jawaban benar
🔻 Penalti: -Rp.500 per jawaban salah

✨ Ketik *kata* tanpa reply chat ini!!

🏳️ Ingin menyerah? Host game harus mengetik .skipsk

> Selamat bermain 🎉`

        let sentMsg = await conn.reply(m.chat, caption, m)

        conn.sambungkata[id] = {
            message: sentMsg,
            kata: kataAwal,
            daftarKata: [kataAwal],
            players: {}, // Menyimpan data pemain: { userJid: { limit: number, money: number, lastAnswerTime: number } }
            startTime: Date.now(),
            timeout: setGameTimeout(conn, id, m),
            host: m.sender // Menyimpan JID host
        }
    }

    if (command === 'skipsk') {
        if (!(id in conn.sambungkata))
            return conn.reply(m.chat, '_Tidak ada game yang berjalan_', m)

        if (m.sender !== conn.sambungkata[id].host)
            return conn.reply(m.chat, '⚠️ Hanya host game yang dapat menghentikan permainan!', m)

        clearTimeout(conn.sambungkata[id].timeout)
        await sendGameSummary(conn, id, m)
        delete conn.sambungkata[id]
    }
}

function setGameTimeout(conn, id, m) {
    return setTimeout(async () => {
        if (conn.sambungkata[id]) {
            await sendGameSummary(conn, id, m)
            delete conn.sambungkata[id]
        }
    }, timeout)
}

async function sendGameSummary(conn, id, m) {
    const game = conn.sambungkata[id]
    let summary = `⏳ *Game Sambung Kata Berakhir!* ⏳\n📜 Kalimat terakhir: "${game.daftarKata.join(' ')}"\n\n🏆 *Ringkasan Pemain:*\n`
    
    for (const [userJid, data] of Object.entries(game.players)) {
        summary += `👤 @${userJid.split('@')[0]} mendapat limit: ${data.limit}, uang: Rp. ${data.money}\n`
    }
    
    await conn.reply(m.chat, summary, game.message, { mentions: Object.keys(game.players) })
}

handler.before = async (m, { conn }) => {
    conn.sambungkata = conn.sambungkata || {}
    let id = m.chat

    if (!m.text || m.fromMe || !(id in conn.sambungkata)) return

    // Abaikan jika input adalah perintah skipsk
    if (m.text.trim().toLowerCase().startsWith('.skipsk')) return

    let kataUser = m.text.trim()

    // Kalau lebih dari satu kata, abaikan tanpa respon
    if (kataUser.split(/\s+/).length > 1) return

    kataUser = cleanInput(kataUser)

    if (!kataUser || !isValidWord(kataUser)) return
    let game = conn.sambungkata[id]
    let hurufAwal = game.kata.slice(-1)

    // Cek apakah kata sudah digunakan
    if (game.daftarKata.includes(kataUser)) {
        global.db.data.users[m.sender].money -= 500
        return conn.reply(m.chat, `⚠️ Kata *${kataUser}* sudah digunakan sebelumnya! Lanjut dengan kata berawalan huruf *${hurufAwal.toUpperCase()}*! Uang -Rp.500`, m)
    }

    if (kataUser[0] !== hurufAwal) {
        global.db.data.users[m.sender].money -= 500
        return conn.reply(m.chat, `⚠️ Kata harus diawali huruf *${hurufAwal.toUpperCase()}*! Uang -Rp.500`, m)
    }

    if (!(await cekKataKBBI(kataUser))) {
        global.db.data.users[m.sender].money -= 500
        return conn.reply(m.chat, `⚠️ Kata *${kataUser}* tidak ditemukan di KBBI! Lanjut dengan kata berawalan huruf *${hurufAwal.toUpperCase()}*! Uang -Rp.500`, m)
    }

    // Hitung reward berdasarkan waktu jawab
    const timeElapsed = Date.now() - game.startTime
    const maxMoney = 3000
    const minMoney = 1000
    const moneyReward = Math.max(minMoney, maxMoney - Math.floor(timeElapsed / 1000) * 50) // Kurang Rp.50 per detik

    // Hitung sisa waktu
    const remainingTime = Math.max(0, Math.floor((timeout - (Date.now() - game.startTime)) / 1000))

    // Update data pemain
    if (!game.players[m.sender]) {
        game.players[m.sender] = { limit: 0, money: 0, lastAnswerTime: 0 }
    }
    game.players[m.sender].limit += 3
    game.players[m.sender].money += moneyReward
    game.players[m.sender].lastAnswerTime = Date.now()

    // Update database user
    global.db.data.users[m.sender].limit += 3
    global.db.data.users[m.sender].money += moneyReward

    game.daftarKata.push(kataUser)
    game.kata = kataUser
    clearTimeout(game.timeout)
    game.timeout = setGameTimeout(conn, id, m)

    await conn.sendMessage(m.chat, {
        text: `✅ Kata *${kataUser}* diterima!\n➡️ Lanjut dengan kata berawalan huruf *"${kataUser.slice(-1).toUpperCase()}"*\n🎁 +3 limit, +Rp.${moneyReward}\n⏰ Sisa Waktu: ${remainingTime} Detik`,
        buttons: [
            { buttonId: '.skipsk', buttonText: { displayText: 'Stop Game' }, type: 1 }
        ],
        headerType: 1
    }, { quoted: m })
}

async function cekKataKBBI(kata) {
    try {
        const res = await fetch(`${global.apibtc}/api/search/kbbi?text=${kata}&apikey=${global.btc}`)
        const data = await res.json()
        return data.status && data.result && data.result.lema === kata
    } catch {
        return false
    }
}

handler.help = ['sambungkata', 'skipsk']
handler.tags = ['game']
handler.command = /^sambungkata|skipsk$/i
handler.register = true
handler.group = true
handler.limit = true

module.exports = handler