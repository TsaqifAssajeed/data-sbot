// ✨ Plugin group - promoteme ✨

let handler = async (m, { conn, isOwner }) => {
  if (!m.isGroup) return m.reply('⚠️ Hanya bisa dipakai di group.');
  if (!isOwner) return m.reply('⚠️ Hanya *Owner Bot* yang bisa pakai perintah ini.');

  // cek bot harus admin
  const groupMetadata = await conn.groupMetadata(m.chat);
  const me = groupMetadata.participants.find(p => p.jid === conn.user.jid);
  if (!me?.admin) return m.reply('⚠️ Bot harus admin dulu agar bisa promote.');

  try {
    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote');
    await m.reply(`✅ @${m.sender.split('@')[0]} berhasil dipromote jadi admin!`, null, { mentions: [m.sender] });
  } catch (e) {
    console.error(e);
    await m.reply('❌ Gagal promote, pastikan bot admin.');
  }
};

handler.help = ['promoteme'];
handler.tags = ['group'];
handler.command = /^promoteme$/i;
handler.group = true;
handler.botAdmin = true;
handler.owner = true;

handler.register = true
handler.limit = true
module.exports = handler;