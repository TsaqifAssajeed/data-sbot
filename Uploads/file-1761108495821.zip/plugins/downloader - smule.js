/**
 * Smule Downloader Plugin
 * Author: gienetic (based on original code)
 * Description: Plugin untuk mengunduh audio dan video dari Smule melalui sownloader.com
 * Version: 1.0.0
 */

const axios = require("axios");
const cheerio = require("cheerio");

let handler = async (m, { conn, usedPrefix, command, args }) => {
  let input = `*[ ! ] Parameter tidak tepat* 😕\n\nContoh: ${usedPrefix + command} https://www.smule.com/recording/sample-song/123456789`;
  if (!args[0]) return conn.reply(m.chat, input, m);

  conn.reply(m.chat, "_Mohon Tunggu, sedang memproses..._ ⏳", m.key);

  try {
    const res = await smuleDownloader(args[0]);
    if (!res.status) throw res.message;

    // Format caption dari metadata
    const caption = `🎵 *${res.data.metadata.title}* 🎵\n\n🔗 *Link*: ${res.data.metadata.smule_link}\n📝 *Deskripsi*: ${res.data.metadata.description}`;

    // Kirim thumbnail dengan caption
    if (res.data.metadata.thumbnail) {
      await conn.sendMessage(
        m.chat,
        {
          image: { url: res.data.metadata.thumbnail },
          caption: caption,
        },
        { quoted: m }
      );
    } else {
      await conn.reply(m.chat, caption, m);
    }

    /* 
    //jangan di aktifkan aklau gak mau kotor :v ini sebagai debug aja akalu sewaktu2 ada erro :
  
    await conn.reply(
      m.chat,
      `📋 *Metadata*:\n\`\`\`json\n${JSON.stringify({ metadata: res.data.metadata, audio: { mp3: res.data.audio.mp3 }, video: res.data.video }, null, 2)}\n\`\`\``,
      m
    );
*/

    // Kirim file audio (mp3) jika tersedia
    if (res.data.audio.mp3 && res.data.audio.mp3 !== "Tidak ditemukan link audio mp3") {
      await conn.sendMessage(
        m.chat,
        {
          document: { url: res.data.audio.mp3 },
          fileName: `${res.data.metadata.title}.mp3`,
          mimetype: "audio/mp3",
        },
        { quoted: m }
      );
    }

    // Kirim file video (mp4) sebagai video jika tersedia
    if (res.data.video.mp4 && res.data.video.mp4 !== "Tidak ditemukan link video mp4") {
      await conn.sendMessage(
        m.chat,
        {
          video: { url: res.data.video.mp4 },
          caption: `🎬 Video: *${res.data.metadata.title}*`,
          mimetype: "video/mp4",
        },
        { quoted: m }
      );
    }

  } catch (error) {
    await conn.reply(m.chat, `❌ Error: ${error.message} 😓`, m);
  }
};

handler.help = ["smule <link>"];
handler.tags = ["downloader"];
handler.command = /^(smule)$/i;
handler.limit = 2;
handler.premium = false;

handler.register = true
module.exports = handler;

async function smuleDownloader(smuleUrl) {
  // Validasi input
  if (!smuleUrl || !smuleUrl.match(/smule\.com/i)) {
    return {
      status: false,
      message: "URL Smule tidak valid",
    };
  }

  // Membuat URL target untuk scraping
  const targetUrl = `https://sownloader.com/index.php?url=${encodeURIComponent(smuleUrl)}`;

  try {
    // Mengambil data dari situs
    const response = await axios.get(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
      },
    });

    // Parsing HTML dengan cheerio
    const $ = cheerio.load(response.data);

    // Mengambil metadata
    const title = $("h4 a").first().text().trim() || "Tidak ditemukan judul";
    const smuleLink = $("h4 a").attr("href") || smuleUrl;
    const thumbnail = $(".sownloader-web-thumbnail").attr("src") || "";
    const description = $(".sownloader-web-thumbnail")
      .closest(".row")
      .find("p")
      .first()
      .text()
      .trim() || "Tidak ada deskripsi";

    // Mengambil link audio (mp3)
    let audioMp3 = "";
    const mp3Button = $("button.btn:contains('Download as MP3')").attr("onclick");
    if (mp3Button) {
      const match = mp3Button.match(/'(https?:\/\/[^']+\.m4a)'/);
      if (match) {
        audioMp3 = `https://sownloader.com/system/modules/downloader.php?url=${encodeURIComponent(
          match[1]
        )}&name=${encodeURIComponent(title)}&ext=mp3`;
      }
    }

    // Mengambil link video (mp4)
    let videoMp4 = $("a.btn[href*='.mp4']").attr("href") || "";
    if (videoMp4 && videoMp4.startsWith("/")) {
      videoMp4 = `https://sownloader.com${videoMp4}`;
    }

    // Mengembalikan hasil
    return {
      status: true,
      message: "Berhasil mengambil data dari Smule",
      data: {
        metadata: {
          title,
          smule_link: smuleLink,
          thumbnail,
          description,
        },
        audio: {
          mp3: audioMp3 || "Tidak ditemukan link audio mp3",
        },
        video: {
          mp4: videoMp4 || "Tidak ditemukan link video mp4",
        },
      },
    };
  } catch (error) {
    return {
      status: false,
      message: `Gagal mengambil data: ${error.message}`,
    };
  }
}