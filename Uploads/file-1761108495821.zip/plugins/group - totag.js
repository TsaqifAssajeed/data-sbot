let handler = async (m, { conn, participants, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("🚨 Fitur ini hanya bisa digunakan di grup! 🚨");
    if (!isAdmin && !isOwner) return m.reply("❌ Hanya admin yang bisa menggunakan perintah ini! ❌");
    
    if (!m.quoted) return m.reply("⚠️ Harap reply pesan yang ingin diberi hidetag! ⚠️"); // Pastikan ada pesan yang di-reply
    
    let member = participants.map(v => v.id) || []; // Ambil semua ID anggota grup

    let forwardMessage = {};
    if (m.quoted.mtype === 'conversation' || m.quoted.mtype === 'extendedTextMessage') {
        forwardMessage = { text: m.quoted.text || ' ', mentions: member };
    } else if (m.quoted.mtype === 'imageMessage' || m.quoted.mtype === 'videoMessage' || m.quoted.mtype === 'documentMessage' || m.quoted.mtype === 'audioMessage' || m.quoted.mtype === 'stickerMessage') {
        let media = await m.quoted.download(); // Unduh media
        forwardMessage = { 
            [m.quoted.mtype.replace('Message', '')]: media, // Sesuaikan jenis media
            caption: m.quoted.text || '',
            mentions: member
        };
    } else {
        return m.reply("⚠️ Jenis pesan tidak didukung untuk hidetag! ⚠️");
    }

    let sentMessage = await conn.sendMessage(m.chat, forwardMessage, { quoted: m });

    // Kirim reaksi ke pesan bot sendiri
    await conn.sendMessage(m.chat, { 
        react: { text: "📢", key: sentMessage.key } 
    });

   }

handler.help = ['totag']
handler.tags = ['group']
handler.command = /^(totag)$/i

handler.group = true
handler.admin = true // Hanya bisa digunakan oleh admin grup

handler.register = true
handler.limit = true
module.exports = handler;
