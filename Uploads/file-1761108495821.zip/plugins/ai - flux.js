const fetch = require('node-fetch');

let handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!text) {
    // Kirim reaksi error
    await conn.sendMessage(m.chat, { react: { text: '🤓', key: m.key } });
    return m.reply(`⚠ *Masukan detail gambar!*\nContoh: ${usedPrefix + command} Kucing lucu di taman`);
  }

  // Kirim reaksi loading
  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    // Kirim pesan sedang proses
    await conn.reply(m.chat, 'Sedang Proses, harap tunggu... ⏳✨', m);

    const response = await fetch(`${global.apisiput}/api/ai/flux`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*'
      },
      body: JSON.stringify({ prompt: text })
    });

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }

    const buffer = await response.buffer();

    // Kirim gambar dengan contextInfo
    await conn.sendFile(
      m.chat,
      buffer,
      'image.png',
      `🎉 Horeee.. Berikut gambar kamu tentang:\n*"${text}"*\nsudah jadi! 🚀\n\n> Flux AI Image`,
      m,
      {
        contextInfo: {
          externalAdReply: {
            title: '🖼️ Flux AI Image',
            body: '',
            thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1758082632617.jpeg',
            sourceUrl: '',
            mediaType: 1,
            renderLargerThumbnail: false
          }
        },
        quoted: {
          key: {
            fromMe: false,
            participant: '0@s.whatsapp.net',
            remoteJid: 'status@broadcast'
          },
          message: { conversation: 'Flux AI Image' }
        }
      }
    );

    // Kirim reaksi sukses
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (error) {
    // Kirim reaksi error
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply(`🚫 Error saat memproses permintaan: ${error.message} 😢`);
  }
};

handler.command = handler.help = ['flux'];
handler.tags = ['ai'];
handler.limit = true;
handler.register = true;

module.exports = handler;