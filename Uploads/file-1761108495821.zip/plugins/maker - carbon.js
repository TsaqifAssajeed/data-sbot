// ✨ Plugin maker - carbon (API Siput langsung kirim, pakai global.apisiput & global.wait) ✨

const fetch = require('node-fetch');

let handler = async (m, { conn, args }) => {
  let text = args.length ? args.join(' ') : m.quoted?.text;
  if (!text) throw '❗ Masukkan teks atau balas pesan yang berisi teks!';

  try {
    // pakai pesan dari settings.js
    m.reply(global.wait);

    const apiUrl = `${global.apisiput}api/m/carbonify`;

    const result = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        input: text,
        title: namebot
      })
    });

    if (!result.ok) throw `Carbonify API gagal (${result.status})`;

    const buffer = await result.buffer();

    await conn.sendFile(m.chat, buffer, 'carbon.png', '', m);
  } catch (e) {
    console.error('[Carbon Error]', e);
    throw '❌ Gagal membuat carbon (siput). Coba lagi nanti.';
  }
};

handler.help = ['carbon'];
handler.tags = ['maker', 'premium'];
handler.command = /^(carbon|carbonara)$/i;
handler.limit = true;
handler.premium = true;

handler.register = true
module.exports = handler;
