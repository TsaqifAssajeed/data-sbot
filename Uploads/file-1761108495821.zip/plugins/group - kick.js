let handler = async (m, { conn, isOwner, isAdmin, args, participants, groupMetadata }) => {
    if (!(isAdmin || isOwner)) {
        global.dfail('admin', m, conn);
        throw false;
    }

    // Fungsi untuk mengonversi LID ke JID
    const getJid = (id) => {
        if (!id) return id;
        if (id.endsWith('@lid') && groupMetadata && groupMetadata.participants) {
            const participant = groupMetadata.participants.find(p => p.lid === id || p.id === id);
            return participant ? participant.jid || id : id;
        }
        return id;
    };

    let ownerGroup = groupMetadata.owner || (m.chat.split`-`[0] + '@s.whatsapp.net');
    let users = [];

    if (m.quoted) {
        let usr = getJid(m.quoted.sender);
        if (usr === ownerGroup || usr === conn.user.jid) {
            m.reply('Tidak dapat mengeluarkan owner grup atau bot!');
            return;
        }
        users = [usr];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        users = m.mentionedJid
            .map(getJid)
            .filter(u => u && u !== ownerGroup && !u.includes(conn.user.jid));
    } else {
        throw `*• Example:* .kick @users *[tag or reply users]*`;
    }

    if (users.length === 0) {
        m.reply('Tidak ada pengguna valid untuk di-kick!');
        return;
    }

    for (let user of users) {
        if (user.endsWith('@s.whatsapp.net')) {
            try {
                await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
                await m.reply('[ Status Kick ] : Success Kick User from group');
                await conn.sendImageAsSticker(m.chat, 'https://files.catbox.moe/fn0v7g.webp', m, {
                    packname: namebot,
                    author: nameowner,
                });
            } catch (e) {
                console.error('Error kicking user:', e);
                m.reply(`Gagal mengeluarkan ${user.split('@')[0]}: ${e.message}`);
            }
        } else {
            m.reply(`ID ${user} tidak valid untuk di-kick (bukan JID)!`);
        }
    }
};

handler.help = ['kick', 'dor', 'cilukbaa'].map(a => a + ' *[tag users]*');
handler.tags = ['group'];
handler.command = /^(kick|dor|cilukbaa)$/i;
handler.group = true;
handler.botAdmin = true;

handler.register = true
handler.limit = true
module.exports = handler;