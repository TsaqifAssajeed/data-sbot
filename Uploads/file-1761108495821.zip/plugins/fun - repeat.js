/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

let handler = async (m, { conn, text, mentionedJid }) => {
    // Penanganan mention user
    let who, displayName;
    // Case 1: Mentioned user (@tag)
    if (m.mentionedJid && m.mentionedJid[0]) {
        who = m.mentionedJid[0];
        displayName = `@${who.split('@')[0]}`; // Format mention untuk user yang di-tag
    } else {
        who = null;
        displayName = ''; // Tidak ada mention jika tidak ada user yang di-tag
    }

    // Fungsi untuk perintah .repeat
    if (m.text.match(/^[!.]repeat\s/i)) {
        // Validasi jika teks kosong atau hanya spasi
        if (!text || text.trim().length === 0) {
            return conn.reply(m.chat, '⚠️ Harap masukkan jumlah pengulangan dan teks untuk diulang. Contoh: .repeat 50 @taguser teks\n\n> Maksimal 500', m, { contextInfo: { mentionedJid: who ? [who] : [] } });
        }

        // Pemisahan jumlah dan teks yang akan diulang
        let args = text.split(' ');
        let count = parseInt(args.shift()); // Ambil angka pertama sebagai jumlah
        let repeatText = args.join(' ');    // Gabungkan sisanya sebagai teks

        // Hapus LID mention (seperti @259420990795862) dari repeatText
        if (who) {
            repeatText = repeatText.replace(/@\d+(@lid)?/g, '').trim(); // Hapus semua @angka dan @angka@lid
        }

        // Jika jumlah bukan angka atau <= 0, kirim pesan peringatan
        if (isNaN(count) || count <= 0) {
            return conn.reply(m.chat, '⚠️ Jumlah harus angka positif!', m, { contextInfo: { mentionedJid: who ? [who] : [] } });
        }

        // Batas maksimal pengulangan
        if (count > 500) count = 500; // Agar tidak overload

        // Membuat pesan yang diulang dengan mention (jika ada)
        let repeatedMessage = Array(count).fill(`${displayName}${displayName && repeatText ? ' ' : ''}${repeatText}`).join('\n');

        // Kirim hasil pengulangan dengan mention
        await conn.reply(m.chat, repeatedMessage, m, { contextInfo: { mentionedJid: who ? [who] : [] } });
    }

    // Fungsi untuk perintah .repeatscroll
    if (m.text.match(/^[!.]repeatscroll\s/i)) {
        if (!text) return conn.reply(m.chat, '⚠️ Masukkan teks untuk scrolling! Contoh: .repeatscroll @taguser teks\n\n> Maksimal 20 karakter', m, { contextInfo: { mentionedJid: who ? [who] : [] } });

        let scrollText = text.trim();

        // Hapus LID mention dari scrollText
        if (who) {
            scrollText = scrollText.replace(/@\d+(@lid)?/g, '').trim(); // Hapus semua @angka dan @angka@lid
        }

        if (scrollText.length > 20) return conn.reply(m.chat, '⚠️ Teks tidak boleh lebih dari 20 karakter (termasuk spasi)!', m, { contextInfo: { mentionedJid: who ? [who] : [] } });

        let scrollEffect = [];
        const maxCharsPerMessage = 65536; // Batas maksimum karakter per pesan WhatsApp
        const maxSpaces = 20; // Maksimal spasi untuk pergeseran

        // Fungsi untuk menghitung jumlah karakter dalam array baris
        const countChars = (lines) => lines.join('\n').length + lines.length - 1; // Tambah \n antar baris

        // Bagian 1: Ulangi teks statis sebanyak 23 baris dengan mention
        for (let i = 0; i < 23; i++) {
            scrollEffect.push(`${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }

        // Bagian 2: Pergeseran teks ke kanan dan kembali (2 kali)
        for (let i = 1; i <= maxSpaces; i++) {
            scrollEffect.push(' '.repeat(i) + `${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }
        for (let i = maxSpaces; i >= 0; i--) {
            scrollEffect.push(' '.repeat(i) + `${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }
        for (let i = 1; i <= maxSpaces; i++) {
            scrollEffect.push(' '.repeat(i) + `${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }
        for (let i = maxSpaces; i >= 0; i--) {
            scrollEffect.push(' '.repeat(i) + `${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }

        // Bagian 3: Pergeseran karakter satu per satu ke kanan
        let chars = scrollText.split('');
        let currentText = scrollText;
        for (let i = chars.length - 1; i >= 0; i--) {
            let spaces = ' '.repeat(chars.length - i - 1);
            let shiftedText = currentText.slice(0, i) + spaces + currentText.slice(i);
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);
        }

        // Bagian 4: Pergeseran teks ke kiri (3 kali)
        for (let j = 0; j < 3; j++) {
            let shiftedText = scrollText;
            for (let i = 1; i <= scrollText.length; i++) {
                scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText.slice(i) + shiftedText.slice(0, i)}`);
            }
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);
        }

        // Bagian 5: Pergeseran teks ke kanan dan kembali
        for (let i = 1; i <= maxSpaces; i++) {
            scrollEffect.push(' '.repeat(i) + `${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }
        for (let i = maxSpaces; i >= 0; i--) {
            scrollEffect.push(' '.repeat(i) + `${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }

        // Bagian 6: Pergeseran spasi antar kata
        let words = scrollText.split(' ');
        for (let i = 0; i < words.length - 1; i++) {
            let shiftedText = words.slice(0, words.length - 1 - i).join(' ') + ' '.repeat(i + 1) + words.slice(words.length - 1 - i).join(' ');
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);
        }
        for (let i = words.length - 2; i >= 0; i--) {
            let shiftedText = words.slice(0, words.length - 1 - i).join(' ') + ' '.repeat(i + 1) + words.slice(words.length - 1 - i).join(' ');
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);
        }
        for (let i = 0; i < words.length - 1; i++) {
            let shiftedText = words.slice(0, words.length - 1 - i).join(' ') + ' '.repeat(i + 1) + words.slice(words.length - 1 - i).join(' ');
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);
        }
        for (let i = words.length - 2; i >= 0; i--) {
            let shiftedText = words.slice(0, words.length - 1 - i).join(' ') + ' '.repeat(i + 1) + words.slice(words.length - 1 - i).join(' ');
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);
        }

        // Bagian 7: Pergeseran teks ke kiri (pendek)
        let shiftedText = scrollText;
        for (let i = 1; i <= scrollText.length; i++) {
            scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText.slice(i) + shiftedText.slice(0, i)}`);
        }
        scrollEffect.push(`${displayName}${displayName && shiftedText ? ' ' : ''}${shiftedText}`);

        // Bagian 8: Ulangi teks statis sebanyak 35 baris
        for (let i = 0; i < 35; i++) {
            scrollEffect.push(`${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
        }

        // Ulangi seluruh pola untuk memaksimalkan output
        let singleCycle = scrollEffect.slice();
        let fullOutput = [];
        let totalChars = 0;
        let cycleCount = 0;
        const maxCycles = 10; // Batasi siklus untuk keamanan

        while (totalChars < maxCharsPerMessage && cycleCount < maxCycles) {
            fullOutput.push(...singleCycle);
            totalChars = countChars(fullOutput);
            cycleCount++;
        }

        // Potong output jika melebihi batas karakter
        while (totalChars > maxCharsPerMessage) {
            fullOutput.pop();
            totalChars = countChars(fullOutput);
        }

        // Tambahkan teks statis untuk mengisi sisa karakter
        while (totalChars + scrollText.length + (displayName ? displayName.length + 1 : 0) + 1 <= maxCharsPerMessage) {
            fullOutput.push(`${displayName}${displayName && scrollText ? ' ' : ''}${scrollText}`);
            totalChars += scrollText.length + (displayName ? displayName.length + 1 : 0) + 1; // Tambah \n dan spasi
        }

        // Bagi output menjadi beberapa pesan
        let messages = [];
        let currentMessage = [];
        let currentChars = 0;

        for (let line of fullOutput) {
            let lineChars = line.length + 1; // Tambah \n
            if (currentChars + lineChars > maxCharsPerMessage) {
                messages.push(currentMessage.join('\n'));
                currentMessage = [line];
                currentChars = lineChars;
            } else {
                currentMessage.push(line);
                currentChars += lineChars;
            }
        }
        if (currentMessage.length > 0) {
            messages.push(currentMessage.join('\n'));
        }

        // Kirim pesan satu per satu dengan jeda
        for (let i = 0; i < messages.length; i++) {
            await new Promise(resolve => setTimeout(resolve, 1000)); // Jeda 1 detik antar pesan
            await conn.reply(m.chat, messages[i], m, { contextInfo: { mentionedJid: who ? [who] : [] } });
        }
    }
}

handler.help = ['repeat <jumlah> <teks> [@tag]', 'repeatscroll <teks> [@tag]']
handler.tags = ['fun']
handler.command = /^(repeat|repeatscroll)$/i

handler.register = true
handler.limit = true
module.exports = handler;