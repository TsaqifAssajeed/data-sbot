let fetch = require('node-fetch');
let uploader = require('../lib/uploadImage');
const { normalizeJid } = require('../function/jid');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

let handler = m => m;

handler.before = async function(m, { conn }) {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    let chat = global.db.data.chats[m.chat] || {};

    if (!chat.antiNsfw) return;
    if (!/image/.test(mime)) return;

    try {
        let media = await q.download();
        let tempFilePath = './temp-image.jpg';
        fs.writeFileSync(tempFilePath, media);
        let url = await uploader(media);

        let percentage, labelName;

        // Coba API nyckelCheck terlebih dahulu
        try {
            const form = new FormData();
            form.append("file", fs.createReadStream(tempFilePath));

            const res = await axios.post(
                "https://www.nyckel.com/v1/functions/o2f0jzcdyut2qxhu/invoke",
                form,
                {
                    headers: {
                        ...form.getHeaders(),
                        "accept": "application/json, text/javascript, */*; q=0.01",
                        "origin": "https://www.nyckel.com",
                        "referer": "https://www.nyckel.com/pretrained-classifiers/nsfw-identifier/",
                        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36",
                        "x-requested-with": "XMLHttpRequest"
                    }
                }
            );

            console.log("✅ Hasil nyckelCheck:", res.data);
            percentage = parseFloat(res.data.confidence || 0) * 100;
            labelName = res.data.labelName || "Unknown";
        } catch (err) {
            console.error("❌ Error nyckelCheck:", err.response?.data || err.message);

            // Fallback ke API paxsenix jika nyckelCheck gagal
            const apiUrl = `${global.paxsenix}/ai-tools/nsfw-checker?url=${encodeURIComponent(url)}`;
            const response = await fetch(apiUrl, {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${global.paxsenixkey}`
                }
            });

            const res = await response.json();
            percentage = parseFloat((res.percentage || "0%").replace('%','')) || 0;
            labelName = res.labelName || "Unknown";
        } finally {
            // Hapus file sementara
            if (fs.existsSync(tempFilePath)) {
                fs.unlinkSync(tempFilePath);
            }
        }

        let who = normalizeJid(m.sender);
        let userNumber = who.split('@')[0].replace(/^\+/, '').replace(/[^0-9]/g, '');

        // Cek apakah pengguna adalah admin
        const groupMetadata = await conn.groupMetadata(m.chat);
        const isAdmin = groupMetadata.participants.some(p => p.id === who && p.admin);

        // Lewati deteksi untuk admin
        if (isAdmin) return;

        if (!(who in global.db.data.users)) {
            global.db.data.users[who] = { warn: 0 };
        }

        if (typeof global.db.data.users[who].warn !== 'number') {
            global.db.data.users[who].warn = 0;
        }

        let maxWarn = global.maxwarn || 3;

        if (labelName === "Porn") {
            global.db.data.users[who].warn += 1;
            let warn = global.db.data.users[who].warn;

            if (warn < maxWarn) {
                await conn.sendMessage(m.chat, {
                    text: `🚨 *NSFW Terdeteksi* 🚨\n\n✧ *Pengguna:* @${userNumber}\n✧ *Label:* ${labelName}\n✧ *Keakuratan:* ${percentage}%\n✧ *Peringatan:* ${warn}/${maxWarn}\n> Konten NSFW terdeteksi dalam pesan gambar! Jika mencapai ${maxWarn} peringatan, Anda akan dikeluarkan dari grup.`,
                    contextInfo: {
                        mentionedJid: [who],
                        externalAdReply: {
                            title: '‼️ NSFW Detected',
                            thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1758114522945.jpeg',
                            mediaType: 1,
                            renderLargerThumbnail: false
                        }
                    }
                }, { quoted: m });
            } else {
                global.db.data.users[who].warn = 0;
                await conn.sendMessage(m.chat, {
                    text: `⛔ *@${userNumber} melampaui ${maxWarn} peringatan dan akan dikeluarkan dari grup!*`,
                    contextInfo: {
                        mentionedJid: [who],
                        externalAdReply: {
                            title: '‼️ NSFW Detected',
                            thumbnailUrl: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1758114522945.jpeg',
                            mediaType: 1,
                            renderLargerThumbnail: false
                        }
                    }
                }, { quoted: m });

                await time(3000);
                await conn.groupParticipantsUpdate(m.chat, [who], 'remove');
            }
        } else {
            console.log(`✅ Aman: ${labelName} (${percentage}%)`);
        }
    } catch (e) {
        console.error("NSFW Check Error:", e);
    }
};

handler.register = true

module.exports = handler;

const time = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};