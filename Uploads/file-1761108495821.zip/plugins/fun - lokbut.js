// ✨ Plugin fun - lokbut ✨

// ✨ Plugin fun - lokbut ✨

// ✨ Plugin fun - lokasibutton.js ✨

let handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    location: {
      degreesLatitude: 40.741895,
      degreesLongitude: -73.989308,
      name: "jawa hama",
      address: "ah crot"
    },
    caption: "📍 Ini lokasi dummy",
    footer: `ARMAN GZ Official`,
    buttons: [
      {
        buttonId: '.menu',
        buttonText: { displayText: '📜 Menu' },
        type: 1
      },
      {
        buttonId: '.owner',
        buttonText: { displayText: '👤 Owner' },
        type: 1
      }
    ],
    headerType: 6
  }, { quoted: m })
}

handler.help = ["lokbut"]
handler.tags = ["fun"]
handler.command = /^lokbut$/i

handler.register = true
handler.limit = true
module.exports = handler