const { GoogleGenerativeAI } = require("@google/generative-ai");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { Sticker } = require("wa-sticker-formatter");
const uploadImage = require("../lib/uploadImage");
const uploadFile = require("../lib/uploadFile");

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
  console.log(`[DEBUG] Perintah ${command} diterima dari ${m.sender}`);

  // Ambil media dari pesan yang di-reply atau pesan itu sendiri
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  console.log(`[DEBUG] MIME Type: ${mime}`);

  // Validasi MIME type
  if (!mime || !/image\/(png|jpe?g|gif)|image\/webp/.test(mime)) {
    return m.reply(
      `📸 Kirim atau reply gambar/stiker (PNG, JPEG, GIF, atau WebP) dengan caption *${usedPrefix}${command} [prompt]*!`
    );
  }

  // Validasi prompt
  if (!text) {
    return m.reply(`✍️ Promptnya mana? Tambahkan instruksi setelah perintah, contoh: *${usedPrefix}${command} ubah latar menjadi pantai*!`);
  }
  console.log(`[DEBUG] Prompt: ${text}`);
  const promptText = text;

  // Download media
  let media;
  try {
    media = await q.download();
    if (!media) throw new Error("Gagal mengunduh media.");
    console.log(`[DEBUG] Media berhasil diunduh, ukuran: ${media.length} bytes`);
  } catch (e) {
    console.error(`[ERROR] Gagal mengunduh media: ${e.message}`);
    return m.reply("❌ Gagal mengunduh gambar/stiker. Coba lagi nanti.");
  }

  // Path sementara untuk menyimpan media
  const tempImgPath = path.join(
    process.cwd(),
    "tmp",
    `temp_${/webp/.test(mime) ? "sticker" : "image"}_${Date.now()}.jpg`
  );
  try {
    fs.writeFileSync(tempImgPath, media);
    console.log(`[DEBUG] Media disimpan di: ${tempImgPath}`);
  } catch (e) {
    console.error(`[ERROR] Gagal menyimpan media: ${e.message}`);
    return m.reply("❌ Gagal menyimpan gambar/stiker. Coba lagi nanti.");
  }

  // Upload ke CDN untuk mendapatkan URL
  const isTele = /image\/(png|jpe?g|gif)/.test(mime);
  let uploadedUrl;
  try {
    uploadedUrl = await (isTele ? uploadImage : uploadFile)(media);
    console.log(`[DEBUG] Media diunggah, URL: ${uploadedUrl}`);
  } catch (e) {
    console.error(`[ERROR] Gagal mengunggah media: ${e.message}`);
    return m.reply("❌ Gagal mengunggah gambar/stiker ke server. Coba lagi nanti.");
  }

  try {
    let resultImage;
    let methodUsed = "";

    // Coba API AlyaChan terlebih dahulu
    try {
      m.reply("⏳ Memproses gambar dengan AI AlyaChan, harap sabar...");
      const response = await axios.get(`${global.alyachan}/api/ai-edit`, {
        params: {
          image: uploadedUrl,
          prompt: promptText,
          apikey: global.alyachankey,
        },
      });

      const images = response.data.data.images;
      if (!images || images.length === 0) {
        throw new Error("Tidak ada gambar yang dihasilkan dari AlyaChan.");
      }

      const imageUrl = images[0].url;
      const imageResponse = await axios.get(imageUrl, { responseType: "arraybuffer" });
      resultImage = Buffer.from(imageResponse.data);
      methodUsed = "AlyaChan AI";
      console.log(`[DEBUG] Gambar berhasil diproses oleh AlyaChan`);
    } catch (err) {
      console.log(`[WARN] AlyaChan gagal: ${err.message}`);
      m.reply("⚠️ Gagal menggunakan AlyaChan, mencoba fallback ke Gemini...");

      // Fallback ke Gemini
      methodUsed = "Gemini";

      const geminiApis = global.geminiApi || [];
      if (geminiApis.length === 0) {
        throw new Error("Tidak ada kunci API Gemini yang diatur di settings.js. Silakan hubungi owner.");
      }

      let lastError;
      for (const apiKey of geminiApis) {
        try {
          console.log(`[INFO] Mencoba kunci API Gemini: ${apiKey.slice(0, 10)}...`);
          const imgData = fs.readFileSync(tempImgPath);
          const base64Image = imgData.toString("base64");

          const genAI = new GoogleGenerativeAI(apiKey);
          const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: { responseModalities: ["text", "image"] },
          });

          const contents = [
            { text: promptText },
            {
              inlineData: { mimeType: "image/jpeg", data: base64Image },
            },
          ];

          const response = await model.generateContent(contents);
          const candidate = response.response.candidates[0];

          for (const part of candidate.content.parts) {
            if (part.inlineData?.data) {
              resultImage = Buffer.from(part.inlineData.data, "base64");
            }
          }

          if (resultImage) {
            console.log(`[DEBUG] Gambar berhasil diproses oleh Gemini`);
            break;
          }
          throw new Error("Gagal mengambil hasil dari Gemini.");
        } catch (e) {
          console.log(`[WARN] Kunci API Gemini gagal: ${apiKey.slice(0, 10)}...`, e.message);
          lastError = e;
        }
      }

      if (!resultImage) {
        throw new Error(
          lastError?.message.includes("API_KEY_INVALID")
            ? "Semua kunci API Gemini tidak valid. Silakan hubungi owner untuk memperbarui kunci API."
            : `Gagal menggunakan Gemini: ${lastError?.message || "Tidak diketahui"}`
        );
      }
    }

    // Simpan hasil sementara
    const tempPath = path.join(process.cwd(), "tmp", `aiimage_${Date.now()}.png`);
    fs.writeFileSync(tempPath, resultImage);
    console.log(`[DEBUG] Hasil gambar disimpan di: ${tempPath}`);

    // Kirim hasil
    if (/webp/.test(mime)) {
      // Kalau input stiker → hasil juga stiker
      const stikerResult = await createSticker(resultImage, false, "AI-Image", "Jagoan Project");
      await conn.sendMessage(m.chat, { sticker: stikerResult }, { quoted: m });
      console.log(`[DEBUG] Stiker dikirim ke ${m.chat}`);
    } else {
      // Kalau input gambar → kirim gambar
      await conn.sendMessage(
        m.chat,
        {
          image: resultImage,
          caption: `✅ Ini dia hasil AI! (Metode: ${methodUsed})`,
        },
        { quoted: m }
      );
      console.log(`[DEBUG] Gambar dikirim ke ${m.chat}`);
    }

    // Cleanup
    setTimeout(() => {
      try {
        if (fs.existsSync(tempImgPath)) fs.unlinkSync(tempImgPath);
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        console.log(`[DEBUG] File sementara dihapus: ${tempImgPath}, ${tempPath}`);
      } catch (err) {
        console.error(`[ERROR] Cleanup error: ${err.message}`);
      }
    }, 30000);
  } catch (e) {
    console.error(`[ERROR] Gagal memproses gambar: ${e.message}`);
    return m.reply(`❌ Error saat memproses gambar: ${e.message}. Silakan laporkan ke owner jika masalah berlanjut.`);
  }
};

async function createSticker(img, url, packName, authorName, quality = 20) {
  try {
    return new Sticker(img ? img : url, {
      type: "full",
      pack: packName,
      author: authorName,
      quality,
    }).toBuffer();
  } catch (e) {
    console.error(`[ERROR] Gagal membuat stiker: ${e.message}`);
    throw new Error("Gagal membuat stiker.");
  }
}

handler.help = ["aiedit <prompt>", "edit <prompt>", "editgambar <prompt>"];
handler.tags = ["ai"];
handler.command = /^(aiimage|aimage|aiedit|edit|editgambar)$/i;
handler.register = false; // Nonaktifkan registrasi agar perintah bisa diakses semua orang
handler.limit = true;

module.exports = handler;