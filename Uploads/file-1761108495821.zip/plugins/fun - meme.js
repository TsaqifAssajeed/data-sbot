// ✨ Plugin fun - meme ✨

const axios = require("axios");

async function lahelu(query) {
  try {
    const { data } = await axios.get("https://lahelu.com/api/post/get-search", {
      params: { query },
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Sec-Ch-Ua":
          '"Chromium";v="140", "Not=A?Brand";v="24", "Google Chrome";v="140"',
      },
    });

    if (!data.postInfos) return [];

    const posts = data.postInfos.map((info) => {
      const contents = info.content?.map((c) => {
        let key = "";
        if (c.type === 0 || c.type === 3) key = "image";
        if (c.type === 1 || c.type === 4) key = "video";
        return { type: c.type, [key]: c.value };
      });
      const ui = info.userInfo;

      return {
        idUser: info.userId,
        idPost: info.postId,
        title: info.title,
        comments: info.totalComments,
        createTime: info.createTime,
        type: info.type,
        hashtags: info.hashtags,
        ageTime: info.ageTime,
        content: contents,
        userInfo: {
          userId: ui.userId,
          authId: ui.authId,
          avatar: info.userAvatar,
          username: ui.username,
          email: ui.email,
          description: ui.description,
          totalUpv: ui.totalUpvotes,
          totalDownv: ui.totalDownvotes,
          totalPost: ui.totalPosts,
          upVotesMap: ui.upvotesMap,
        },
      };
    });

    return posts;
  } catch (error) {
    throw error;
  }
}

let handler = async (m, { conn, text }) => {
  if (!text) throw `Masukkan kata kunci!\n\nContoh: .meme jokowi`

  try {
    let results = await lahelu(text)
    if (!results || results.length === 0) throw `Meme tidak ditemukan!`

    // pilih random
    let selected = results[Math.floor(Math.random() * results.length)]

    let caption = `*${selected.title || "Meme"}*\n👤 ${selected.userInfo?.username || "-"}\n💬 ${selected.comments} komentar\n🕒 ${selected.ageTime || ""}`

    let content = selected.content?.[0] // ambil konten pertama (gambar/video)
    if (!content) throw `Konten kosong!`

    if (content.image) {
      await conn.sendMessage(m.chat, { image: { url: content.image }, caption }, { quoted: m })
    } else if (content.video) {
      await conn.sendMessage(m.chat, { video: { url: content.video }, caption }, { quoted: m })
    } else {
      throw `Konten tidak valid!`
    }

  } catch (e) {
    console.error(e)
    throw `Error: ${e.message || e}`
  }
}

handler.command = /^(meme)$/i
handler.tags = ['fun']
handler.help = ['meme <query>']
handler.limit = true

handler.register = true
module.exports = handler