/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date! 

Jangan Hapus Watermarknya bang , plss :) 
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


const spamUsers = {}; // Penyimpanan sementara

const SPAM_MAX = 1; // Maksimal spam sebelum diberikan peringatan
const SPAM_DELAY = 4000; // 7 detik batas waktu spam
const WARN_LIMIT = 3; // Maksimal peringatan sebelum banned
const WARN_RESET_TIME = 420000; // 7 menit untuk reset warn jika user tidak spam
const BAN_DURATION = 300000; // 5 menit banned otomatis

async function before(m, { isAdmin, isBotAdmin }) {
    if (!m.text) return; 

    // **🔹 CEK APAKAH INI COMMAND 🔹**
    const isCommand = m.text.startsWith('.') || m.text.startsWith('/') || m.text.startsWith('!') || m.text.startsWith('#');

    if (!isCommand) {
        //console.log(`[ANTI-SPAM] Pesan dari ${m.sender} diabaikan karena bukan command.`);
        return;
    }

    // **🔹 CEK NOMOR BOT & OWNER 🔹**
    const botNumber = (conn.user.id || "").replace(/\D/g, '') + '@s.whatsapp.net';
    const ownerNumbers = (Array.isArray(global.owner) ? global.owner : [])
        .map(owner => String(owner[0]).replace(/\D/g, '') + '@s.whatsapp.net');

    if (m.sender === botNumber || ownerNumbers.includes(m.sender)) {
        //console.log(`[ANTI-SPAM] ${m.sender} adalah bot atau owner, abaikan.`);
        return;
    }

    let chat = global.db.data.chats[m.chat];
    let users = global.db.data.users;

    if (!chat) {
        global.db.data.chats[m.chat] = { antispam: false };
        chat = global.db.data.chats[m.chat];
    }

    if (!users[m.sender]) {
        global.db.data.users[m.sender] = { warn: 0, banned: false, bannedProcessing: false };
        users = global.db.data.users;
    }

    if (!chat.antispam) return;

    const now = Date.now();
    const sender = m.sender;

    // **🔹 CEK APAKAH USER SUDAH DIBANNED 🔹**
    if (users[sender].banned) {
        //console.log(`[BLOCKED] ${sender} mencoba mengirim command tetapi sedang dibanned.`);
        return;
    }

    // **🔹 DETEKSI SPAM 🔹**
    if (!spamUsers[sender]) {
        spamUsers[sender] = {
            count: 1,
            lastMessage: now
        };
    } else {
        let timeDiff = now - spamUsers[sender].lastMessage;

        if (timeDiff < SPAM_DELAY) {
            spamUsers[sender].count++;
            //console.log(`[DEBUG] ${sender} mengirim command cepat (${spamUsers[sender].count} kali).`);
        } else {
            spamUsers[sender].count = 1;
        }

        spamUsers[sender].lastMessage = now;
    }

    // **🔹 JIKA USER SPAM LEBIH DARI 2 KALI DALAM < 10 detik, BERIKAN PERINGATAN 🔹**
    if (spamUsers[sender].count > SPAM_MAX) {
        users[sender].warn = (users[sender].warn || 0) + 1;
        global.db.write();

        //console.log(`[WARN] ${sender} diberikan peringatan (${users[sender].warn}/${WARN_LIMIT})`);

        try {
            if (users[sender].warn === 1) {
                await conn.sendMessage(m.chat, { 
                    text: `⚠️ *PERINGATAN SPAM!* ⚠️\n@${sender.split('@')[0]}, ini peringatan 1️⃣ !\n\nJika mencapai *${WARN_LIMIT}* peringatan, Anda akan *dibanned selama 3 menit*!`, 
                    mentions: [sender] 
                }, { quoted: m });
            } else if (users[sender].warn === 2) {
                await conn.sendMessage(m.chat, { 
                    text: `⚠️ *PERINGATAN SPAM!* ⚠️\n@${sender.split('@')[0]}, ini peringatan 2️⃣!\n\nSatu pelanggaran lagi dan Anda akan *dibanned*!`, 
                    mentions: [sender] 
                }, { quoted: m });
            }
        } catch (err) {
            console.error(`❌ Gagal mengirim pesan warn: ${err}`);
        }

        // **🔹 Jika user sudah mencapai batas peringatan, otomatis banned 🔹**
        if (users[sender].warn >= WARN_LIMIT && !users[sender].bannedProcessing) {
            users[sender].bannedProcessing = true;
            users[sender].banned = true;
            global.db.write();

            //console.log(`[BANNED] ${sender} telah dibanned otomatis karena spam!`);

            try {
                await conn.sendMessage(m.chat, { 
                    text: `🚫 *ANDA TELAH DIBANNED!* 🚫\n@${sender.split('@')[0]} telah dibanned dan tidak bisa menggunakan bot selama 5 menit karena terlalu sering spam.`, 
                    mentions: [sender] 
                });
            } catch (err) {
                console.error(`❌ Gagal mengirim pesan banned: ${err}`);
            }

            // **🔹 Unban Otomatis Setelah 3 Menit 🔹**
            setTimeout(async () => {
                users[sender].banned = false;
                users[sender].warn = 0;
                users[sender].bannedProcessing = false;
                global.db.write();
                //console.log(`[UNBANNED] ${sender} telah di-unban otomatis.`);

                try {
                    await conn.sendMessage(m.chat, { 
                        text: `✅ @${sender.split('@')[0]} telah di-unban dan bisa menggunakan bot kembali.\n\n> Tolong jangan spam, jika ketahuan owner spam bot berkali-kali, maka anda akan di banned permanen dari databse bot..!!`, 
                        mentions: [sender] 
                    });
                } catch (err) {
                    console.error(`❌ Gagal mengirim pesan unban: ${err}`);
                }
            }, BAN_DURATION);

            spamUsers[sender].count = 0;
            return;
        }

        // **🔹 Atur Timer untuk Reset Warn Jika User Tidak Spam Lagi 🔹**
        setTimeout(() => {
            if (users[sender].warn > 0) {
                users[sender].warn -= 1;
                global.db.write();
                //console.log(`[RESET WARN] ${sender} mendapatkan pengurangan warn otomatis.`);
            }
        }, WARN_RESET_TIME);

        spamUsers[sender].count = 0;
    }
}

module.exports = { before };
