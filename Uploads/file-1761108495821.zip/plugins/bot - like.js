// 📝 plugin bot - like

const fs = require('fs');
const path = require('path');

const FILE_PATH = path.join(__dirname, '../lib/datalikebot.json');

function formatShort(num) {
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace('.0', '') + 'M';
  if (num >= 1_000) return (num / 1_000).toFixed(1).replace('.0', '') + 'k';
  return num.toString();
}

function formatWithComma(num) {
  return num.toLocaleString('id-ID');
}

let handler = async (m, { conn, command, args }) => {
  if (!fs.existsSync(FILE_PATH)) fs.writeFileSync(FILE_PATH, JSON.stringify({ total: 0 }, null, 2));
  let data = JSON.parse(fs.readFileSync(FILE_PATH));

  if (args[0] === 'info') {
    return m.reply(`❤️‍🔥 *TOTAL LIKE ${global.namebot || 'Bot'}*\n\n📊 *total : ${formatShort(data.total)} (${formatWithComma(data.total)})*`);
  }

  // Tambahkan 1 like
  data.total += 1;
  fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));

  let userTag = '@' + m.sender.split('@')[0];
  await conn.sendMessage(m.chat, {
    text: `Haii ${userTag}, terima kasih telah memberikan like kepada *${global.namebot || 'Bot'}*~ 💖😘\n\n📊 Jumlah like sekarang : *${formatShort(data.total)} (${formatWithComma(data.total)})*`,
    mentions: [m.sender]
  }, { quoted: m });
};

handler.help = ['like', 'like info'];
handler.tags = ['main'];
handler.command = /^like$/i;


module.exports = handler;