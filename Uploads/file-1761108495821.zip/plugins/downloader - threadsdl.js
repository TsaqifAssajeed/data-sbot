const axios = require('axios');

async function ThreadsDl(url) {
  try {
    const response = await axios.get('https://snapthreads.net/api/download', {
      params: {
        url: url,
        slof: 1
      },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://snapthreads.net/id'
      },
      decompress: true
    });
    
    console.log('=== THREADS API RESPONSE ===');
    console.log('Response status:', response.status);
    console.log('Response data:', JSON.stringify(response.data, null, 2));
    console.log('=============================');
    
    return response.data;
  } catch (error) {
    console.error('Error fetching thread:', error.message);
    console.error('Error response:', error.response?.data);
    return null;
  }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  // Pesan panduan jika URL salah
  const guideMessage = `URL tidak valid! Pastikan Anda menyalin link dengan benar dari aplikasi Threads. Berikut cara menyalin link video Threads:

1. Buka aplikasi Threads di smartphone Anda.
2. Cari dan pilih video yang ingin diunduh.
3. Klik ikon bagikan (berbentuk pesawat kertas) di bawah video.
4. Pilih opsi "Salin Link".

Contoh URL yang benar:
${usedPrefix}${command} https://www.threads.net/@kiyoeditz/post/DBM2ZfDhNt1`;

  if (!args[0]) {
    throw `Masukkan URL!\n\nContoh:\n${usedPrefix}${command} https://www.threads.net/@kiyoeditz/post/DBM2ZfDhNt1`;
  }

  try {
    // Validasi URL
    let urlMatch = args[0].match(/\/post\/([A-Za-z0-9-_?=]+)$/i);
    if (!urlMatch) throw guideMessage;

    conn.reply(m.chat, `_Sedang memproses, harap tunggu..._`, m);

    // Mengambil respons dari API ThreadsDl
    const response = await ThreadsDl(args[0]);
    
    if (!response) {
      throw `Gagal mengakses API Threads!`;
    }

    // Cari URL download di response
    console.log('Searching for download URL in response...');
    let downloadUrl = null;
    
    // Coba berbagai kemungkinan struktur response
    if (response.directLink) {
      downloadUrl = response.directLink; // Tambahkan properti directLink
    } else if (response.data && response.data.download_url) {
      downloadUrl = response.data.download_url;
    } else if (response.download_url) {
      downloadUrl = response.download_url;
    } else if (response.url) {
      downloadUrl = response.url;
    } else if (response.link) {
      downloadUrl = response.link;
    } else if (response.data && response.data.url) {
      downloadUrl = response.data.url;
    } else if (response.data && response.data.link) {
      downloadUrl = response.data.link;
    } else if (typeof response === 'string') {
      downloadUrl = response;
    }

    console.log('Found download URL:', downloadUrl);

    if (!downloadUrl) {
      throw `Tidak ditemukan URL download!\n\nResponse API:\n${JSON.stringify(response, null, 2).substring(0, 1000)}...`;
    }

    await m.reply('_Sedang mengirim file..._');

    // Kirim file ke chat
    let fileType = downloadUrl.toLowerCase().endsWith('.jpg') || 
                   downloadUrl.toLowerCase().endsWith('.jpeg') || 
                   downloadUrl.toLowerCase().endsWith('.png') ? 'image' : 'video';
    
    await conn.sendFile(
      m.chat,
      downloadUrl,
      `threads.${fileType === 'image' ? 'jpg' : 'mp4'}`,
      '',
      m,
      null,
      { 
        asDocument: global.db.data?.users?.[m.sender]?.useDocument || false,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
        }
      }
    );
  } catch (e) {
    console.error('Handler error:', e);
    throw e.message === 'URL tidak valid!' ? guideMessage : `Error: ${e.message || e}`;
  }
};

handler.help = ['threads'];
handler.command = /^(threads)$/i;
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.premium = false;

handler.register = true;
module.exports = handler;