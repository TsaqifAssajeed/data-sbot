const fetch = require('node-fetch');

let handler = async (m, { usedPrefix, command, args }) => {
    if (!args[0]) {
        let pilihanRes = await fetch(`https://allhadist.vercel.app/hadith`)
        let pilihan = await pilihanRes.json()
        let pilihanText = pilihan.map(p => `${p.name}\n1 - ${p.total}`).join('\n\n')
        throw `Contoh:\n${usedPrefix + command} Bukhari 1\n\nPilihan tersedia:\n${pilihanText}`
    }  
    if (!args[1]) throw `Hadist yang ke berapa?\nContoh: ${usedPrefix + command} ${args[0]} 1`    
    try {    
        let pilihanRes = await fetch(`https://allhadist.vercel.app/hadith`)
        let pilihan = await pilihanRes.json()
        let hadistSlug = pilihan.find(p => p.name.toLowerCase() === args[0].toLowerCase())?.slug
        if (!hadistSlug) throw `Nama hadist tidak valid. Pilihan tersedia:\n${pilihan.map(p => p.name).join(', ')}`     
        let res = await fetch(`https://allhadist.vercel.app/hadith/${hadistSlug}/${args[1]}`)
        let json = await res.json()        
        let { name, number, arab, id } = json        
        let info = `*\`HADIST:\`* ${name}\n*\`NOMOR:\`* ${number}\n\n*${arab}*\n\n*Artinya: ${id}*`
        await m.reply(info)
    } catch (e) {
        throw e
    }
}
handler.help = ['hadist']
handler.tags = ['islami']
handler.command = /^(hadist?)$/i

handler.register = true
handler.limit = true
module.exports = handler;