let handler = async (m, { conn }) => {
  const isGroup = m.chat.endsWith('@g.us');
  if (!isGroup) return m.reply('‼️ Fitur ini hanya bisa digunakan di dalam grup!');

  try {
    // Fetch metadata segar
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants;

    // Cari bot dengan normalisasi JID (salin dari handler)
    const botParticipant = participants.find(p => {
      const botJid = conn.user.jid;
      return p.id === botJid || p.jid === botJid || (p.lid && p.lid.replace('@lid', '@s.whatsapp.net') === botJid);
    });

    // Check admin: Gunakan !== null
    const isBotAdmin = botParticipant && botParticipant.admin !== null;
    console.log(`[DEBUG LINKGC] Bot admin status: ${botParticipant?.admin}`);  // Log debug

    if (!isBotAdmin) return m.reply('‼️ Bot harus menjadi admin untuk mengambil link grup!');

    // Ambil link
    let link = await conn.groupInviteCode(m.chat);
    m.reply(`📝 Link group ini :\n\nhttps://chat.whatsapp.com/${link}`);
  } catch (e) {
    m.reply('❌ Gagal mengambil link grup, mungkin bot belum jadi admin atau ada kesalahan lain.');
    console.error('[ERROR LINKGC]', e);
  }
};

handler.help = ['linkgc'];
handler.tags = ['group'];
handler.command = /^linkgc$/i;

handler.register = true
handler.limit = true
module.exports = handler;