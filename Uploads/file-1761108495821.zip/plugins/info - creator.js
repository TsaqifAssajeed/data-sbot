const { generateWAMessageContent, proto } = require('@whiskeysockets/baileys');

var handler = async (m, { conn }) => {
  const p = nomorown;
  let pp = await conn.profilePictureUrl(`${p}@s.whatsapp.net`, 'image').catch(_ => "https://files.catbox.moe/o0vdyr.jpg");

  // --- Pesan: VCARD Owner ---
  let vcard = `
BEGIN:VCARD
VERSION:3.0
N:${nameowner};;;
NICKNAME:🔰 DEVELOPER
ORG:${nameowner}
TITLE:Developer Bot WhatsApp
item1.TEL;waid=${nomorown}:${nomorown}
item1.X-ABLabel:📱 Nomor Utama
item2.URL:https://wa.me/${nomorown}
item2.X-ABLabel:💬 Klik untuk Chat
item3.EMAIL;type=INTERNET:owner@example.com
item3.X-ABLabel:✉️ Email
item4.ADR:;;Indonesia;;;;
item4.X-ABLabel:🏴‍☠️ Lokasi
BDAY:20080119
END:VCARD
`.trim();

  // Kirim VCARD
  await conn.sendMessage(m.chat, {
    contacts: {
      displayName: namebot,
      contacts: [{ vcard }]
    },
    contextInfo: {
      externalAdReply: {
        title: `🔰 Hubungi Developer Resmi`,
        body: `👤 ${nameowner} • Creator ${namebot}`,
        thumbnailUrl: pp,
        sourceUrl: `https://wa.me/${nomorown}`,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: fkontak });

  // Kirim pesan reply
  await conn.sendMessage(m.chat, {
    text: "Itu Adalah Owner Ku, Silahkan Chat Jika Mau Membeli Bot, Sewa Bot, Atau Upgrade Ke Premium Dan Owner"
  }, { quoted: m });
};

handler.help = ['owner', 'creator'];
handler.tags = ['info'];
handler.command = /^(owner|creator)$/i;


handler.register = true
module.exports = handler;