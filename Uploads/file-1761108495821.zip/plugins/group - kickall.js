let handler = async (m, { conn, isOwner, isAdmin }) => {
  if (!(isAdmin || isOwner)) {
      global.dfail('admin', m, conn);
      throw false;
  }

  let participants = await conn.groupMetadata(m.chat);
  let admins = participants.participants.filter(p => p.admin).map(p => p.id);
  let membersToKick = participants.participants
      .map(p => p.id)
      .filter(id => !admins.includes(id) && id !== conn.user.jid);

  if (membersToKick.length === 0) {
      return m.reply("Tidak ada member yang bisa dikick.");
  }

  for (let user of membersToKick) {
      await conn.groupParticipantsUpdate(m.chat, [user], "remove");
      await new Promise(resolve => setTimeout(resolve, 5000)); // Delay 5 detik
  }

  await conn.sendMessage(m.chat, { text: "Berhasil mengeluarkan semua member." });
};

handler.help = ['kickall'];
handler.tags = ['group','owner'];
handler.command = /^(kickall)$/i;

handler.group = true;
handler.botAdmin = true;
handler.owner = true

handler.register = true
handler.limit = true
module.exports = handler;
