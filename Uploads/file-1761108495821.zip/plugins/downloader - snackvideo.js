const axios = require("axios");
const cheerio = require("cheerio");

//BabyBotz
let handler = async (m, { conn, text, command }) => {
    if (!text) return m.reply('Silakan masukkan URL video untuk DIDOWNLOAD.');
    
    try {
        const result = await downloadSnackVideo(text);
        let message = `
🎥 *SnackVideo Download!* 🎥
-  Title: ${result.metadata.title}
-  Uploaded: ${result.metadata.uploaded}
-  Likes: ${result.metadata.likes}
-  Views: ${result.metadata.watch}
-  Comments: ${result.metadata.comment}
-  Shares: ${result.metadata.share}
-  Author: ${result.metadata.author}
        `;
        m.reply(message);
        await conn.sendFile(m.chat, result.download, 'snackvideo.mp4', null, m);
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat memproses permintaan Anda.');
    }
};

handler.command = /^(snackvideo-download|snackdl)$/i;
handler.help = ['snackvideo-download <URL>'];
handler.tags = ['fun'];
handler.limit = true;

handler.register = true
module.exports = handler;

async function downloadSnackVideo(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios.get(url);
            const $ = cheerio.load(response.data);
            let result = {
                metadata: {},
                download: null
            };
            const json = JSON.parse($("#VideoObject").text().trim());
            result.metadata.title = json.name;
            result.metadata.thumbnail = json.thumbnailUrl[0];
            result.metadata.uploaded = new Date(json.uploadDate).toLocaleString();
            result.metadata.comment = json.commentCount;
            result.metadata.watch = json.interactionStatistic[0].userInteractionCount;
            result.metadata.likes = json.interactionStatistic[1].userInteractionCount;
            result.metadata.share = json.interactionStatistic[2].userInteractionCount;
            result.metadata.author = json.creator.mainEntity.name;
            result.download = json.contentUrl;
            resolve(result);
        } catch (error) {
            reject({ msg: error.message });
        }
    });
}