const fs = require('fs');
const path = require('path');

// Helper function to load giveaways from JSON file
const loadGiveaways = () => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (err) {
        console.error('Error loading giveaways:', err);
        return {};
    }
};

let handler = async (m, { conn, usedPrefix }) => {
    // Initialize conn.giveway from JSON file
    conn.giveway = loadGiveaways();

    let id = m.chat;
    if (!(id in conn.giveway)) throw `‼️ *UPSS!! TIDAK BISA*\n\n– tidak ada giveaway yang sedang berlangsung di group ini, untuk memulai giveaway ikuti contoh dibawah ini.\n📝 Contoh penggunaan :\n\n– ${usedPrefix}mulaigiveaway akun epep`;

    let d = new Date;
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
    let absen = conn.giveway[id][1];

    // Shuffle the absen array
    shuffleArray(absen);

    let list = absen.map((v, i) => `${i + 1}. @${v.split`@`[0]}`).join('\n');
    conn.reply(m.chat, `*🛍️ LIST PESERTA GIVEAWAY*

– 📆 tanggal : ${date}
– 🎁 hadiah  : ${conn.giveway[id][2]}

– 👨‍👨‍👧‍👦 peserta giveway :

${list}

> *${global.namebot}*`, m, { contextInfo: { mentionedJid: absen } });
};

// Fisher-Yates Shuffle Algorithm
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

handler.help = ['cekgiveaway'];
handler.tags = ['giveaway'];
handler.command = /^cekgiveaway$/i;
handler.admin = true;
handler.register = true
handler.limit = true
module.exports = handler;