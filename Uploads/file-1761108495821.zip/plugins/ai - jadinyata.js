
const axios = require('axios');
const fs = require('fs');
const { generateWAMessageContent } = require('@whiskeysockets/baileys');
const uploadImage = require('../lib/uploadImage');

let handler = async (m, ctx) => {
    let { conn, usedPrefix, command } = ctx;

    // Cek apakah ada gambar yang dikirim atau dibalas (sesuai dengan removebg.js)
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    if (!mime || !/image\/(png|jpe?g)/.test(mime)) {
        return m.reply(`Kirim atau balas sebuah gambar (PNG/JPG) dengan perintah *${usedPrefix + command}*`);
    }

    await m.reply(global.wait); // Menggunakan global.wait dari settings.js

    try {
        // Mendapatkan URL gambar dari pesan
        let media = await q.download();
        if (!media) return m.reply('❌ Gagal mengunduh gambar, coba lagi nanti.');

        // Batas ukuran file (5MB, sesuai dengan removebg)
        const fileSizeLimit = 5 * 1024 * 1024;
        if (media.length > fileSizeLimit) {
            return m.reply('❌ Ukuran gambar tidak boleh melebihi 5MB.');
        }

        // Unggah gambar menggunakan uploadImage
        let imageUrl = await uploadImage(media);
        if (!imageUrl) return m.reply('❌ Gagal mengunggah gambar, coba lagi nanti.');

        // Default prompt untuk API
        const prompt = `Ultra-realistic portrait of a real person with slight wrinkles on the skin to look authentic to a specific character, taken in 4K cinematic studio photography. The subject must look exactly 100% identical to the original character in terms of pose, body proportions, hairstyle, and clothing design (modernized but inspired by the original clothing). The subject has large, bright blue eyes, natural facial expressions, detailed and realistic skin with visible pores, subtle imperfections, and lifelike hair strands. Dramatic cinematic lighting with soft highlights and shadows. Shallow depth of field, soft bokeh background. Taken with a Canon EOS R5 with an 85mm f/1.2 lens, DSLR photo style, National Geographic portrait photography, highly detailed photorealism. In finished images, it is forbidden to contain: anime, 2d, illustrations, drawings, sketches, comics, cel-shaded, manga, digital paintings, concept art, stylized, pixar, disney, cgi, 3d rendering, dolls, toys, action figures, plastic skin, low resolution, blurry, fake, unrealisUltra-realistic portrait photograph of a real human person, authentic skin texture with fine pores, subtle wrinkles, natural imperfections, lifelike hair strands, large bright blue eyes. The subject must be a perfect 100% match to the original character in pose, proportions, hairstyle, and clothing (modernized realistic fabric but inspired by the original). Real human photography, cinematic studio lighting, dramatic yet natural, soft highlights and shadows. Captured in 4K with Canon EOS R5 + RF 85mm f/1.2 lens, shallow depth of field, soft creamy bokeh, National Geographic editorial style, DSLR raw photo, hyper-detailed, professional portrait photography.
Negative prompt: anime, 2d, illustration, drawing, sketch, cartoon, comic, manga, stylized, pixar, disney, digital painting, painting, cgi, 3d rendering, render, artificial, doll, toy, figurine, plastic skin, fake, game character, fantasy art, unreal, VR, AR, lowres, blurry, bad quality, watermark, logo, text, glitch, distortion
tic, video games, VR, AR, fantasy art, watermarks, text, logos, glitches`;
        // Panggil API AlyaChan menggunakan global.alyachan
        let { data } = await axios.get(`${global.alyachan}/api/ai-edit`, {
            params: {
                image: imageUrl,
                prompt: prompt,
                apikey: global.alyachankey // Menggunakan global.alyachankey dari settings.js
            }
        });

        if (!data.status || !data.data.images.length) {
            return m.reply('❌ Tidak ada hasil yang ditemukan dari API.');
        }

        // Proses setiap gambar hasil dari API
        let i = 1;
        for (let img of data.data.images) {
            if (img.status === 'succeeded') {
                // Unduh gambar hasil dari API
                const responseFile = await axios.get(img.url, { responseType: 'arraybuffer' });
                const filePath = `./tmp/jadinyata-result-${i}.png`;
                fs.writeFileSync(filePath, responseFile.data);

                // Unggah gambar hasil ke server WhatsApp untuk mendapatkan URL
                const uploadedResultUrl = await uploadImage(fs.readFileSync(filePath));

                // Kirim gambar hasil ke pengguna dengan caption
                await conn.sendFile(
                    m.chat,
                    filePath,
                    `jadinyata-result-${i}.png`,
                    `✨ Gambar ke-${i} berhasil ditransformasi ke realistis!\n> URL: ${uploadedResultUrl}`,
                    m
                );

                // Hapus file sementara
                fs.unlinkSync(filePath);
                i++;
            }
        }

        if (i === 1) {
            return m.reply('❌ Tidak ada gambar yang berhasil diproses.');
        }
    } catch (err) {
        console.error('Error:', err);
        m.reply('🚩 *Terjadi kesalahan server, coba lagi nanti!*');
    }
};

handler.help = ["jadinyata"];
handler.tags = ["ai"];
handler.command = /^(jadinyata|toreal)$/i;
handler.premium = false;
handler.limit = 10;

handler.register = true
module.exports = handler;
