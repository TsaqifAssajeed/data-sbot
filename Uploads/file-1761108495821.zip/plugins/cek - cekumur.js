let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.umur)}”`, m)
}
handler.help = ['cekumur']
handler.tags = ['cek']
handler.command = /^(cekumur)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.umur = [
'10 Tahun (Buset Bocil)', '1 Tahun (Bisa Main Hp Lu? ☠️)', '5 Tahun (apa ya nama nya kalo 5 tahun, Batista? Ehh Balita)', '8 Tahun (Aduh anak kemarin sore udah bisa main hp aja nih😂)', '12 Tahun (Masih SD Udah Mau Masuk SMP)', '13 Tahun (diem dulu, anak esempeh satu ini sedang memasuki fase pahitnya kehidupan)', '15 Tahun (udah mau tamat esempeh)', '17 Tahun (cieee dah punya KTP, jangan di pake pinjol 😂)', '20 Tahun (cok kapan nikah?)', '21 Tahun (yakin belum mau nikah?)', '22 Tahun (umur yang udah serius, jangan main main)', '25 Tahun (woi tua, kapan lu nikah tolol 😂)', '30 Tahun (Udah pantes di panggil bapak bapak/om)', '1000 Tahun (Jangan heran, bangsa elf loh ya)', 'Unlimited Umur/Immortal💀', ' 5000 Tahun (waw kalo kalian mau nanya nanya sejarah dunia ini ke dia aja nih)', 'Lahir Dari 1 Tahun Masehi 💀)', 'Udah hidup dari awal terbentuknya bumi (Nenek moyang nematoda 😂)',
]