let handler = async (m, { conn, participants, groupMetadata }) => {
    const getGroupAdmins = (participants) => {
        let admins = [];
        for (let i of participants) {
            if (i.admin === "admin" || i.admin === "superadmin") {
                // Gunakan jid jika tersedia, jika tidak gunakan id
                admins.push(i.jid || i.id);
            }
        }
        return admins;
    };

    let pp = './media/avatar_contact.png';
    try {
        pp = await conn.profilePictureUrl(m.chat, 'image');
    } catch (e) {
        // Biarkan pp default jika gagal
    }

    let { isBanned, welcome, detect, sWelcome, sBye, sPromote, sDemote, antiLink } = global.db.data.chats[m.chat];
    const groupAdmins = getGroupAdmins(participants);
    // Konversi JID ke nomor telepon tanpa @s.whatsapp.net
    let listAdmin = groupAdmins.map((v, i) => {
        let number = v.split('@')[0];
        // Hapus karakter non-digit (misalnya, +) untuk format bersih
        number = number.replace(/\D/g, '');
        return `${i + 1}. @${number}`;
    }).join('\n');

    let text = `*Name:* 
${groupMetadata.subject}
*ID GROUP:* 
${m.chat.split`-`[0]}
*Group Admins:*
${listAdmin}\n\n` + "```J Don't tag admins carelessly\nthey will be kicked```".trim();

    await m.reply(text, null, {
        mentions: groupAdmins
    });
};

handler.help = ['tagadmin', 'min'].map(a => a + ' *[tag admin]*');
handler.tags = ['group'];
handler.command = /^(tagadmin|min)$/i;
handler.group = true;

handler.register = true
handler.limit = true
module.exports = handler;