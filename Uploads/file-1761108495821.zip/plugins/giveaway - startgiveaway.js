const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// Helper function to ensure database directory exists
const ensureDatabaseDir = () => {
    const dir = path.join(__dirname, '../database');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
};

// Helper function to load giveaways from JSON file
const loadGiveaways = () => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (err) {
        console.error('Error loading giveaways:', err);
        return {};
    }
};

// Helper function to save giveaways to JSON file
const saveGiveaways = (giveaways) => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        ensureDatabaseDir();
        fs.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), 'utf8');
    } catch (err) {
        console.error('Error saving giveaways:', err);
    }
};

let handler = async (m, { conn, usedPrefix, text, command, participants }) => {
    // Initialize conn.giveway from JSON file
    conn.giveway = loadGiveaways();

    let id = m.chat; // ID grup

    if (!text) throw `‼️ *FORMAT TIDAK LENGKAP*\n\n📝 Contoh penggunaan :\n\n${usedPrefix + command} GIVEAWAY AKUN PREMIUM`;
    if (id in conn.giveway) {
        throw `‼️ *ATTENTION*\n\n> masih ada giveaway yang belum selesai di group ini, untuk menghapus giveaway ketik .deletegiveaway`;
    }

    let mentionedJids = participants.map(u => u.id); // Ambil semua ID anggota grup

    // 🔹 **Pesan Hanya "GIVEAWAY DIMULAI!" dengan Hidetag**
    const giveawayTitle = `🎉 *GIVEAWAY DIMULAI!!*`;
    await conn.sendMessage(m.chat, { text: giveawayTitle, mentions: mentionedJids }, { quoted: m });

    // 🔹 **List Message untuk Single Select Button**
    let listMessage = {
        title: '🎁 CLICK HERE',
        sections: [{
            title: '‼️ SILAHKAN PILIH OPSI DIBAWAH INI',
            rows: [
                {
                    title: '📋 IKUT GIVEAWAY',
                    id: `${usedPrefix}ikut`,
                    description: '╰┈➤ untuk mengikuti giveaway'
                },
                {
                    title: '🎯 PILIH PEMENANG',
                    id: `${usedPrefix}rollgiveaway`,
                    description: '╰┈➤ untuk mengacak pemenang (khusus admin).'
                },
                {
                    title: '🗑️ HAPUS GIVEAWAY',
                    id: `${usedPrefix}deletegiveaway`,
                    description: '╰┈➤ untuk menghapus giveaway (khusus admin).'
                },
                {
                    title: '👥 CEK PESERTA',
                    id: `${usedPrefix}cekgiveaway`,
                    description: '╰┈➤ untuk melihat daftar peserta giveaway.'
                }
            ]
        }]
    };

    // 🔹 **Pesan Interactive dengan Single Select Button**
    try {
        let msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: `\n– silahkan klik tombol dibawah untuk melihat opsi giveaway.\n\n🛍️ *DETAIL GIVEAWAY*\n╰┈➤ ${text}\n\n`
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: '*_Semoga keberuntungan datang padamu kawan 🎊_*'
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: '🎁 GIVEAWAY BERLANGSUNG'
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                        {
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify(listMessage)
                        }
                    ]
                })
            })
        }, { userJid: m.chat, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (err) {
        console.error('[ERROR] Gagal mengirim interactive message:', err);
        // Fallback to text message if interactive message fails
        await conn.sendMessage(m.chat, {
            text: `‼️ INFORMASI GIVEAWAY*\n\n📋 *.ikut* - bergabung giveaway\n🎯 *.rollgiveaway* - pilih pemenang\n🗑️ *.deletegiveaway* - hapus giveaway\n👥 *.cekgiveaway* - cek peserta\n\n🛍️ *DETAIL GIVEAWAY*\n╰┈➤ ${text}\n\n*_Semoga beruntung bang🎊_*`
        }, { quoted: m });
    }

    // Simpan Giveaway dalam Database
    conn.giveway[id] = [{ text: giveawayTitle, mentions: mentionedJids }, [], text];
    saveGiveaways(conn.giveway); // Save to JSON file
};

handler.help = ['mulaigiveaway'];
handler.tags = ['giveaway'];
handler.command = /^(start|mulai)giveaway$/i;
handler.group = true;
handler.admin = true;
handler.register = true
handler.limit = true
module.exports = handler;