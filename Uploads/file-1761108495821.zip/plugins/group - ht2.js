// ✨ Plugin group - ht2 ✨

const handler = async (m, { conn, text, args }) => {
  let txt = m.quoted ? m.quoted.text : args.join(" ");
  if (!txt) txt = 'assalamualaikum warahmatullahi wabarakatuh wahai memberku'; // default jika kosong

  let groupMetadata = await conn.groupMetadata(m.chat);
  let mem = groupMetadata.participants.map((a) => a.id);

  conn.sendMessage(m.chat, {
    text: `@${m.chat}`,
    contextInfo: {
      mentionedJid: mem,
      groupMentions: [{ groupSubject: txt, groupJid: m.chat }]
    }
  });
};

handler.help = ["ht2 [Input text/reply]"];
handler.tags = ["group"];
handler.command = /^ht2$/i;
handler.fail = null;
handler.group = true;
handler.admin = true;

handler.register = true
handler.limit = true
module.exports = handler;