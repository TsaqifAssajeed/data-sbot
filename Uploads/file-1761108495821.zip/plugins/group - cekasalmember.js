// ✨ Plugin group - cekasalmember ✨

let handler = async (m, { conn }) => {
  const participants = await conn.groupMetadata(m.chat).then(metadata => metadata.participants);
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  
  participants.forEach(participant => {
    const phoneNumber = participant.jid.split('@')[0]; // ✅ pakai jid
    if (phoneNumber.startsWith("62")) {
      countIndonesia++;
    } else if (phoneNumber.startsWith("60")) {
      countMalaysia++;
    } else if (phoneNumber.startsWith("1")) {
      countUSA++;
    } else {
      countOther++;
    }
  });
  
  const replyMessage = `Jumlah Anggota Grup Berdasarkan Negara:\n\n` +
    `🇮🇩 Indonesia: ${countIndonesia}\n` +
    `🇲🇾 Malaysia: ${countMalaysia}\n` +
    `🇺🇸 USA: ${countUSA}\n` +
    `🏳️ Lainnya: ${countOther}`;
    
  m.reply(replyMessage);
}

handler.tags = ['group']
handler.help = ['cekasalmember']
handler.command = ["cekasalmember"]
handler.group = true
handler.register = true
handler.limit = true
module.exports = handler

// === Patch tonoprefix ===
handler.all = async (m, { conn }) => {
  let text = m.text?.trim()
  if (!text) return

  if (text.toLowerCase().startsWith("cekasalmember")) {
    let isi = text.slice(13).trim()
    if (!isi) {
      if (m.quoted?.text || m.quoted?.caption || m.quoted?.description) {
        isi = m.quoted.text || m.quoted.caption || m.quoted.description
      } else {
        return m.reply("*📝 CONTOH :*\n\n— cekasalmember <teks>")
      }
    }
    let fakeCmd = { ...m, text: isi }
    return handler(fakeCmd, { conn, args: [], text: fakeCmd.text, usedPrefix: '', command: 'cekasalmember' })
  }
}