let handler = m => m;

let linkAllRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/i;

handler.before = async function (m, { user, isBotAdmin, isAdmin, conn }) {
    if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;
    let chat = global.db.data.chats[m.chat];
    let userData = global.db.data.users[m.sender];
    let isLink = linkAllRegex.test(m.text);

    const maxWarn = 0;

    if (chat.antiLinkAll && isLink) {
        if (isAdmin) {
            return m.reply('👑 Admin terdeteksi mengirim link\nSaya sebagai babu tidak berani menendang beliau, silahkan lanjutkan 🙇🏼‍♂️');
        }

        if (!isBotAdmin) {
            return m.reply(`⁉️ Saya bukan admin, jadi tidak bisa menghapus dan menendang keluar angkasa alien itu.`);
        }

        if (!userData.linkAllWarn) userData.linkAllWarn = 0;
        userData.linkAllWarn += 1;

        await conn.sendMessage(m.chat, { delete: m.key });

        if (userData.linkAllWarn <= maxWarn) {
            await m.reply(`
⚠️ *PERINGATAN LINK* ⚠️
Kamu terdeteksi mengirim link!
✧ Peringatan: ${userData.linkAllWarn}/${maxWarn}
✧ Kirim link lagi? Peringatan bertambah!
Jika mencapai ${maxWarn}x, kamu akan di-kick!`);
        } else {
            await m.reply(`
⛔ *BANNED* ⛔
@${m.sender.split('@')[0]} telah mencapai batas kesabaran gua (${maxWarn}/${maxWarn}) 
karena mengirim link berulang-ulang. Selamat tinggal sampahh!`, null, { mentions: [m.sender] });
            userData.linkAllWarn = 0;
            await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
        }
    }
    return true;
};

handler.register = true

module.exports = handler;