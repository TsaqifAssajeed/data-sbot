// ✨ Plugin maker - fakedev ✨

// ✨ Plugin maker - fakedev ✨

// ✨ Plugin: fakedev.js ✨
// 📦 Membuat kartu Fake Developer otomatis
// 📁 Semua data user diambil dari database.json saja

const { createCanvas, loadImage } = require('canvas')
const fs = require('fs')
const path = require('path')

let handler = async (m, { conn, text }) => {
  const basePath = '/home/container/'
  const dbPath = path.join(basePath, 'database.json')

  // 🔹 Coba baca database.json
  let db = {}
  try {
    if (fs.existsSync(dbPath)) {
      db = JSON.parse(fs.readFileSync(dbPath))
    } else {
      console.log('[fakedev] database.json tidak ditemukan, menggunakan data sementara.')
    }
  } catch (err) {
    console.error('[fakedev] Gagal membaca database.json:', err)
  }

  const userId = m.sender

  // 🔹 Auto-register user jika belum ada
  if (!db[userId]) db[userId] = { name: m.pushName || 'User Baru', limit: 10 }

  // 🔹 Cek limit user
  if ((db[userId].limit || 0) <= 0)
    return m.reply('❌ Limit kamu habis.')

  // 🔹 Validasi input
  if (!text || !text.includes('|')) {
    return m.reply(`🚩 Contoh penggunaan:\n.fakedev Nama Kamu | true\nGunakan "true" untuk verified badge, "false" untuk tidak.`)
  }

  const [nama, verified] = text.split('|').map(v => v.trim())
  m.reply('⏳ Membuat Fake Dev...')

  try {
    // 🔹 Ambil gambar
    let media
    if (m.quoted && /image/.test(m.quoted.mimetype)) {
      media = await m.quoted.download()
    } else if (/image/.test(m.mimetype)) {
      media = await m.download()
    } else {
      return m.reply('🚩 Kirim atau reply gambar untuk digunakan.')
    }

    const userImage = await loadImage(media)
    const bg = await loadImage('https://files.catbox.moe/ek8di9.jpg')
    const badge = await loadImage('https://files.catbox.moe/6hkvux.png')

    const canvas = createCanvas(1080, 1080)
    const ctx = canvas.getContext('2d')

    // 🎨 Gambar latar
    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height)

    // 🎨 Gambar foto profil lingkaran
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = 263
    ctx.save()
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    ctx.closePath()
    ctx.clip()
    ctx.drawImage(userImage, centerX - radius, centerY - radius, radius * 2, radius * 2)
    ctx.restore()

    // 📝 Nama melingkar + badge
    ctx.font = 'bold 60px Arial'
    ctx.fillStyle = '#fff'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    drawCircularTextTop(ctx, nama.toUpperCase(), centerX, centerY, radius, verified.toLowerCase() === 'true' ? badge : null)

    // 🖼️ Kirim hasil
    const buffer = canvas.toBuffer()
    await conn.sendMessage(m.chat, {
      image: buffer,
      caption: '💻 Fake Developer berhasil dibuat!'
    }, { quoted: m })

    // ⚠️ Tidak menulis database.json karena sistem read-only
    // Jika ingin update limit, gunakan database eksternal (Mongo/Supabase)

  } catch (err) {
    console.error('[fakedev ERROR]', err)
    m.reply('❌ Gagal membuat Fake Dev: ' + err.message)
  }
}

handler.help = ['fakedev <nama> | <true/false>']
handler.tags = ['maker']
handler.command = /^fakedev$/i
handler.limit = true
handler.register = true

module.exports = handler

// 🌀 Fungsi teks melingkar di bagian atas
function drawCircularTextTop(ctx, text, centerX, centerY, radius, badgeImage) {
  const fontSize = 72
  const strokeWidth = 3
  const strokeColor = '#000'
  const arcSpan = Math.PI * 0.7
  const textRadius = radius + 75
  const chars = text.split('')
  const n = chars.length
  const angleIncrement = n > 1 ? arcSpan / (n - 1) : 0
  const start = Math.PI / 2 + arcSpan / 2

  for (let i = 0; i < n; i++) {
    const char = chars[i]
    const angle = start - i * angleIncrement
    const x = centerX + Math.cos(angle) * textRadius
    const y = centerY + Math.sin(angle) * textRadius

    ctx.save()
    ctx.translate(x, y)
    ctx.rotate(angle - Math.PI / 2)
    ctx.lineWidth = strokeWidth
    ctx.strokeStyle = strokeColor
    ctx.strokeText(char, 0, 0)
    ctx.fillText(char, 0, 0)
    ctx.restore()
  }

  if (badgeImage) {
    const endAngle = start - (n - 1) * angleIncrement
    const badgeAngle = endAngle - angleIncrement
    const badgeSize = Math.round(fontSize * 0.9)
    const bx = centerX + Math.cos(badgeAngle) * textRadius
    const by = centerY + Math.sin(badgeAngle) * textRadius
    ctx.drawImage(badgeImage, bx - badgeSize / 2, by - badgeSize / 2, badgeSize, badgeSize)
  }
}