let handler = async (m, { usedPrefix, command, text }) => {
    let id = m.chat
    conn.absen = conn.absen || {}

if (!text) return m.reply(
`⚠️ *Format Salah!*

> Penggunaan: ${usedPrefix}${command} (nama atau nomor urut)

💡 Contoh:
> ${usedPrefix}${command} Budi
> ${usedPrefix}${command} 1`
)


    if (!(id in conn.absen)) {
        throw `_*Tidak ada absen berlangsung di grup ini!*_\n\nKetik *${usedPrefix}mulaiabsen* untuk memulai absen`
    }

    let absen = conn.absen[id][1]

    // Cek apakah input adalah angka (nomor urut) atau teks (nama)
    let input = text.trim()
    let indexToRemove = -1
    let removedEntry = null

    if (/^\d+$/.test(input)) {
        // Input adalah angka (nomor urut)
        let number = parseInt(input) - 1 // Konversi ke indeks (0-based)
        if (number >= 0 && number < absen.length) {
            indexToRemove = number
            removedEntry = absen.splice(indexToRemove, 1)[0] // Menghapus entri berdasarkan nomor urut
            m.reply(`Nama ${removedEntry.name} (nomor ${number + 1}) berhasil dihapus dari daftar absen.`)
        } else {
            m.reply(`Nomor ${input} tidak valid. Pastikan nomor urut antara 1 dan ${absen.length}.`)
        }
    } else {
        // Input adalah nama
        indexToRemove = absen.findIndex(participant => participant.name.toLowerCase() === input.toLowerCase())
        if (indexToRemove !== -1) {
            removedEntry = absen.splice(indexToRemove, 1)[0] // Menghapus entri berdasarkan nama
            m.reply(`Nama ${removedEntry.name} (nomor ${indexToRemove + 1}) berhasil dihapus dari daftar absen.`)
        } else {
            m.reply(`Nama ${input} tidak ditemukan dalam daftar absen.`)
        }
    }
}

handler.help = ['cutabsen [nama atau nomor urut]']
handler.tags = ['absen']
handler.command = /^(rmabsen|cutabsen|cabsen)$/i
handler.group = true
handler.register = true
handler.limit = true
module.exports = handler