const axios = require('axios');

// Fungsi untuk query ke API AI Dokter
async function dokterQuery(prompt) {
    try {
        const response = await axios.get(`${global.alyachan}/api/ai-dokter`, {
            params: {
                text: prompt,
                apikey: global.alyachankey
            }
        });
        return response.data.data.content;
    } catch (error) {
        throw new Error(error.response?.data?.message || error.message);
    }
}

let handler = async (m, { text, command, usedPrefix, conn }) => {
    if (!text) {
        throw `Harap masukkan teks.\nContoh:\n${usedPrefix + command} Penyebab batuk`;
    }

    // Kirim reaction loading
    await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
    });

    try {
        // Query ke API AI Dokter
        let responseText = await dokterQuery(text);

        // Ganti markdown
        responseText = responseText.replace(/\*\*(.*?)\*\*/g, '*$1*');
        responseText = responseText.replace(/### (.*?)(?=\n)/g, '`$1`');
        responseText = responseText.replace(/##/g, '✦');
        // Hapus referensi sumber seperti [1], [2], dll.
        responseText = responseText.replace(/\[\d+\]/g, '');
        responseText += '\n\n> AI Dokter';

        // Kirim dengan contextInfo
        await conn.sendMessage(
            m.chat,
            {
                text: responseText,
                contextInfo: {
                    externalAdReply: {
                        title: '🏥 AI Dokter Response',
                        body: '',
                        thumbnailUrl: 'https://img.freepik.com/premium-vector/female-doctor-cartoon-character-with-stethoscope-vector-illustration-female-doctor-uniform_1142-72453.jpg',
                        sourceUrl: '',
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            },
            {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: '0@s.whatsapp.net',
                        remoteJid: 'status@broadcast'
                    },
                    message: { conversation: 'AI Dokter Response' }
                }
            }
        );

        // Kirim reaksi sukses
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
    } catch (e) {
        console.error('Error:', e);
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        m.reply(`🚫 Error saat memproses permintaan: ${e.message}`);
    }
};


handler.help = ['dokter'].map(a => a + ' *[text]*');
handler.command = ['dokter','aidokter'];
handler.tags = ['ai'];


handler.register = true;
handler.limit = true;
module.exports = handler;