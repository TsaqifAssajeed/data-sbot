//Fungsi Ini Dibuat Oleh Aping, JANGAN HAPUS UNTUK MENGHARGAI GW :(

const { dare, truth } = require('@bochilteam/scraper');

// Fungsi untuk menambahkan delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let handler = async function (m, { conn, text, command, usedPrefix }) {
    if (command === 'dare') {
        await delay(2000); // Menambahkan delay 2 detik
        await conn.reply(m.chat, await dare(), m);
    }
    if (command === 'truth') {
        await delay(2000); // Menambahkan delay 2 detik
        await conn.reply(m.chat, await truth(), m);
    }
};

handler.command = handler.help = ['dare', 'truth'];
handler.tags = ['fun','game'];
handler.limit = 1

handler.register = true
module.exports = handler;