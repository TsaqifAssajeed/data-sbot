/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const moment = require('moment-timezone');
const PhoneNumber = require('awesome-phonenumber');
const fs = require('fs');
const fetch = require('node-fetch');
const util = require('util');
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require('@whiskeysockets/baileys');
const { pickRandom } = require('../lib/functions.js');
const { getDevice } = require('@whiskeysockets/baileys');
require('moment/locale/id') 
moment.tz.setDefault('Asia/Makassar').locale('id');

let menulist = async (m, { conn, usedPrefix, command, args }) => {
  // Mengaktifkan status "typing" dan menunda selama 3 detik
 // await conn.sendPresenceUpdate('recording', m.chat);
 // await new Promise(resolve => setTimeout(resolve, 2500)); // Delay 3 detik

  // Normalisasi perintah
  const perintah = args[0] ? args[0].toLowerCase() : 'tags';

  // Inisialisasi pengaturan setmenu
  let settings = global.db.data.settings[conn.user.jid] || {};
  if (!('setmenu' in settings)) settings.setmenu = 'simple'; // Default simple jika belum ada pengaturan
  global.db.data.settings[conn.user.jid] = settings; // Simpan pengaturan ke database

  // Inisialisasi tagCount dan tagHelpMapping
  const tagCount = {};
  const tagHelpMapping = {};

  // Bangun tagCount dan tagHelpMapping dari global.features
  Object.keys(global.features)
    .filter(plugin => !plugin.disabled)
    .forEach(plugin => {
      const tagsArray = Array.isArray(global.features[plugin].tags)
        ? global.features[plugin].tags
        : [];
      if (tagsArray.length > 0) {
        const helpArray = Array.isArray(global.features[plugin].help)
          ? global.features[plugin].help
          : [global.features[plugin].help].filter(item => item);
        tagsArray.forEach(tag => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });

  // Hitung total fitur untuk semua kategori
  let totalAllFeatures = 0;
  Object.keys(tagHelpMapping).forEach(tag => {
    totalAllFeatures += (tagHelpMapping[tag] || []).length;
  });

  // Hitung total fitur berdasarkan info - totalfitur.js
  let fitur = Object.values(global.features).filter(v => v.help && !v.disabled).map(v => v.help).flat(1);
  let totalFitur = fitur.length;



  // Fungsi untuk format uptime
  const clockString = (ms) => {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000);
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
  };

  // Fungsi untuk format tanggal
  const DateNow = (date) => {
    let offset = 7;
    let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
    let jakartaTime = new Date(utc + (3600000 * offset));
    let hours = jakartaTime.getHours() < 10 ? "0" + jakartaTime.getHours() : jakartaTime.getHours();
    let minutes = jakartaTime.getMinutes() < 10 ? "0" + jakartaTime.getMinutes() : jakartaTime.getMinutes();
    let seconds = jakartaTime.getSeconds() < 10 ? "0" + jakartaTime.getSeconds() : jakartaTime.getSeconds();
    return `*${hours}:${minutes}:${seconds}*`;
  };

  // Fungsi untuk memvalidasi URL dengan timeout dan pengecekan Content-Type
  const isValidUrl = async (url, timeoutMs = 5000) => {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);
      const response = await fetch(url, { method: 'HEAD', signal: controller.signal });
      clearTimeout(timeout);
      const contentType = response.headers.get('content-type');
      return response.ok && contentType && (contentType.includes('video/mp4') || contentType.includes('image/gif'));
    } catch (err) {
      console.error('[ERROR] URL tidak valid atau timeout:', url, err);
      return false;
    }
  };

  // Ambil nama pengguna dan data pengguna
  let userName = m.pushName || conn.getName(m.sender);
  let { premium, registered } = global.DATABASE.data.users[m.sender] || { premium: false, registered: false };

// Fungsi salam sesuai waktu
function getGreeting() {
  const hour = moment().hour();
  if (hour >= 4 && hour < 10) return 'Pagi 🌅';
  if (hour >= 10 && hour < 15) return 'Siang ☀️';
  if (hour >= 15 && hour < 18) return 'Sore 🌇';
  return 'Malam 🌙';
}

let device = await getDevice(m.key.id)

  // Teks informasi bot untuk semua format menu
let infoBot = `
-ˋˏ ༻𓆩💖𓆪༺ ˎˊ-

Halo, Selamat *${getGreeting()}*, kak *${userName}* 👋

📱 Device kamu : ${device}. Kamu adalah ${premium ? '💎 User Premium' : '❌ User Tidak Premium'} dan ${registered ? '✅️ Sudah Terdaftar dalam database' : '❌ Belum Terdaftar dalam database'}. Semoga aku bisa membantumu yahh.. 😉

‧₊˚ ⋅  𓐐𓎩 ‧₊˚ ⋅‧₊˚ ⋅  𓐐𓎩 ‧₊˚ ⋅‧₊˚

╭───「 *⏳ WAKTU* 」───✧
│ 📅 Tanggal    : ${moment().format('DD MMM YYYY')}
│ 📆 Hari       : ${moment().format('dddd')}
│ ⏰ Jam        : ${moment().format('HH:mm:ss')}
╰──────────────✧

╭───「 *💶  INFO BOT* 」───✧
│ 👾 Nama Bot   : ${namebot}
│ 🆙 Versi      : 105.2.1
│ ⚙️ Fitur      : ${totalFitur} Fitur
│ ⏳ Runtime    : ${clockString(process.uptime() * 1000)}
│ 📊 Pengguna   : ${Object.keys(global.db.data.users).length}
│ ❄️ Mode       : ${global.opts['self'] ? '🔒 Self' : '🌍 Public'}
╰──────────────✧

📂 Silakan pilih kategori menu di bawah ini:
`.trim();

  // Daftar kategori
  const daftarTag = Object.keys(tagCount).sort();

  // Buat teks daftar kategori dengan total fitur
  let categoryListText = daftarTag.map(tag => {
    return `› menu ${tag.charAt(0).toUpperCase() + tag.slice(1)}\n> total fitur: ${(tagHelpMapping[tag] || []).length}`;
  }).join('\n');

  // URL default untuk gambar dan GIF
  const defaultImageUrl = global.thumb; // URL fallback untuk gambar
  const defaultGifUrl = 'https://media.giphy.com/media/3o6Zt6KHxJTbNbLDeM/giphy.mp4'; // URL GIF alternatif yang kompatibel

  // Logika utama berdasarkan perintah
  if (perintah === 'tags') {
    let _mpt;
    if (process.send) {
      process.send('uptime');
      _mpt = await new Promise(resolve => {
        process.once('message', resolve);
        setTimeout(resolve, 1000);
      }) * 1000;
    }
    let mpt = clockString(_mpt);
    let name = m.pushName || conn.getName(m.sender);

    // Buat daftar opsi untuk menu list
    let rows = [
      {
        title: 'All Menu',
        id: `${usedPrefix + command} all`,
        description: `Total fitur: ${totalAllFeatures} perintah`
      },
      ...daftarTag.filter(tag => tag !== 'all').map(tag => ({
        title: `${tag.charAt(0).toUpperCase() + tag.slice(1)}`,
        id: `${usedPrefix + command} ${tag}`,
        description: `Total fitur: ${(tagHelpMapping[tag] || []).length} perintah`
      }))
    ];

    if (settings.setmenu === 'simple') {
      await conn.sendMessage(m.chat, {
        text: infoBot + '\n\n' + categoryListText,
        contextInfo: global.adReply.contextInfo
      }, { quoted: m });
      
    } else if (settings.setmenu === 'payment') {
      await conn.relayMessage(m.chat, {
        requestPaymentMessage: {
          currencyCodeIso4217: 'IDR',
          amount1000: 80000 * 1000, // Rp. 70.000
          requestFrom: '0@s.whatsapp.net',
          noteMessage: {
            extendedTextMessage: {
              text: infoBot + '\n\n' + categoryListText,
              contextInfo: global.adReply.contextInfo
            }
          },
          contextInfo: global.adReply.contextInfo
        }
      }, {});
      
    } else if (settings.setmenu === 'image') {
      try {
        console.log('[INFO] Memulai pengiriman image dengan URL:', global.thumb);
        const startTime = Date.now();
        if (!(await isValidUrl(global.thumb))) {
          console.warn('[WARN] URL thumbnail tidak valid, menggunakan defaultImageUrl');
          await conn.sendMessage(m.chat, {
            image: { url: defaultImageUrl },
            caption: infoBot + '\n\n' + categoryListText,
            contextInfo: global.fakeig.contextInfo
          }, { quoted: m });
        } else {
          await conn.sendMessage(m.chat, {
            image: { url: global.thumb },
            caption: infoBot + '\n\n' + categoryListText,
            contextInfo: global.fakeig.contextInfo
          }, { quoted: m });
        }
        console.log('[INFO] Pesan image berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim image:', err);
        await conn.sendMessage(m.chat, {
          text: infoBot + '\n\n' + categoryListText,
          contextInfo: global.fakeig.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'button') {
      try {
        console.log('[INFO] Memulai pengiriman button menu dengan URL:', global.thumb);
        const startTime = Date.now();
        const thumbUrl = (await isValidUrl(global.thumb)) ? global.thumb : defaultImageUrl;
        await conn.sendMessage(m.chat, {
          image: { url: thumbUrl },
          caption: infoBot + '\n\n' + categoryListText,
          footer: global.namebot,
          buttons: [
            {
              buttonId: '.sc',
              buttonText: { displayText: 'Script 📁' },
              type: 1
            },
            {
              buttonId: '.owner',
              buttonText: { displayText: 'Owner 👑' },
              type: 1
            }
          ],
          headerType: 4,
          viewOnce: true
        }, { quoted: m });
        console.log('[INFO] Pesan button berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim button menu:', err);
        await conn.sendMessage(m.chat, {
          text: infoBot + '\n\n' + categoryListText,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'mix') {
  if (device === 'ios') {
    console.log('[INFO] Device iOS terdeteksi, alihkan menu mix ke simple');
    // kirim menu simple lalu hentikan block ini
    await conn.sendMessage(m.chat, {
      text: infoBot + '\n\n' + categoryListText,
      contextInfo: global.adReply.contextInfo
    }, { quoted: m });
    return; // ⬅️ penting, supaya tidak lanjut eksekusi mix
  }
      try {
        console.log('[INFO] Memulai pengiriman mix menu dengan URL:', global.thumb);
        const startTime = Date.now();
        const thumbUrl = (await isValidUrl(global.thumb)) ? global.thumb : defaultImageUrl;

        let listMessage = {
          title: 'Daftar Menu',
          sections: [{
            title: 'Pilih Kategori',
            highlight_label: 'Hot 🥵',
            rows: rows.map(row => ({
             // header: row.title,
           title: row.title,
              description: row.description,
              id: row.id
            }))
          }]
        };

        await conn.sendMessage(m.chat, {
          image: { url: thumbUrl },
          caption: infoBot,
          footer: global.namebot,
          buttons: [
            {
              buttonId: '.sc',
              buttonText: { displayText: 'Script 📁' },
              type: 1
            },
            {
              buttonId: '.owner',
              buttonText: { displayText: 'Owner 👑' },
              type: 1
            },
            {
              buttonId: 'action',
              buttonText: { displayText: 'Pilih Kategori' },
              type: 4,
              nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify(listMessage)
              }
            }
          ],
          headerType: 1,
          viewOnce: true
        }, { quoted: m });
        console.log('[INFO] Pesan mix berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim mix menu:', err);
        await conn.sendMessage(m.chat, {
          text: infoBot + '\n\n' + categoryListText,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'gift') {
      try {
        console.log('[INFO] Memulai pengiriman gift menu dengan URL:', global.gifmenu);
        const startTime = Date.now();
        const gifUrl = (await isValidUrl(global.gifmenu)) ? global.gifmenu : defaultGifUrl;
        console.log('[INFO] Menggunakan URL GIF:', gifUrl);
        await conn.sendMessage(m.chat, {
          video: { url: gifUrl },
          gifPlayback: true,
          mimetype: 'video/mp4',
          caption: infoBot + '\n\n' + categoryListText,
          contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
              title: `${global.namebot} - Version ${global.version || '89.1.3'}`,
              body: `Powered by ${global.nameowner || 'Jagoan Project'}`,
              thumbnailUrl: global.thumb || 'https://i.ibb.co/Fb2z8jz/zhenya-menu.jpg',
              mediaType: 1,
              renderLargerThumbnail: true,
              sourceUrl: 'https://wa.me/' + (global.rowner || '62895362282300'),
            },
          },
        }, { quoted: m });
        console.log('[INFO] Pesan gift berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim gift menu:', err);
        await conn.sendMessage(m.chat, {
          text: infoBot + '\n\n' + categoryListText,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    }
    // Kirim VN setelah menu dikirim
    if (!args[0]) {
      try {
        await conn.sendMessage(m.chat, {
          audio: { url: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1759312106346.mpeg' },
          mimetype: 'audio/aac',
          ptt: true
        }, { quoted: m });
      } catch (err) {
        console.error('[ERROR] Gagal mengirim VN:', err);
      }
    }
  } else if (tagCount[perintah]) {
    let daftarHelp = tagHelpMapping[perintah] || [];
    if (!Array.isArray(daftarHelp)) {
      daftarHelp = [];
    }


    // Urutkan daftar perintah secara alfabetis
    daftarHelp.sort((a, b) => a.localeCompare(b));

    if (daftarHelp.length === 0) {
      await conn.reply(m.chat, `Tidak ada perintah dengan kategori *${perintah}* yang tersedia.`, m);
      
      // Kirim VN setelah pesan dikirim
      if (!args[0]) {
        try {
          await conn.sendMessage(m.chat, {
            audio: { url: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1759312106346.mpeg' },
            mimetype: 'audio/aac',
            ptt: true
          }, { quoted: m });
        } catch (err) {
          console.error('[ERROR] Gagal mengirim VN:', err);
        }
      }
      return;
    }

    const list2 = `✦. ── *MENU ${perintah.toUpperCase()}* ── .✦\n\n${daftarHelp.map((helpItem, index) => `› .${helpItem}`).join('\n')}`;

    if (settings.setmenu === 'simple') {
      await conn.sendMessage(m.chat, {
        text: list2,
        contextInfo: global.adReply.contextInfo
      }, { quoted: m });
      
    } else if (settings.setmenu === 'payment') {
      await conn.relayMessage(m.chat, {
        requestPaymentMessage: {
          currencyCodeIso4217: 'IDR',
          amount1000: 70000 * 1000, // Rp. 70.000
          requestFrom: '0@s.whatsapp.net',
          noteMessage: {
            extendedTextMessage: {
              text: list2,
              contextInfo: global.adReply.contextInfo
            }
          },
          contextInfo: global.adReply.contextInfo
        }
      }, {});
      
    } else if (settings.setmenu === 'buttonlist') {
      let rows = daftarHelp.map((helpItem, index) => ({
        title: `.${helpItem}`.substring(0, 24),
        id: `${usedPrefix}${helpItem}`,
        description: ''
      }));

      let listMessage = {
        title: `Menu ${perintah.toUpperCase()}`,
        sections: [{
          title: 'Pilih Perintah',
          rows
        }]
      };

      try {
        let msg = generateWAMessageFromContent(m.chat, {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: list2
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: `Hubungi ${global.nameowner || 'Jagoan Project'} untuk info lebih lanjut: wa.me/${global.rowner || '62895362282300'}`
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              title: `✨ ${global.namebot} ✨`,
              hasMediaAttachment: global.thumb ? true : false,
              ...(global.thumb ? await prepareWAMessageMedia({ image: { url: global.thumb } }, { upload: conn.waUploadToServer }).catch(() => ({})) : {})
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify(listMessage)
                }
              ]
            })
          })
        }, { userJid: m.chat, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim buttonlist untuk kategori:', err);
        await conn.sendMessage(m.chat, {
          text: list2,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'image') {
      try {
        console.log('[INFO] Memulai pengiriman image dengan URL:', global.thumb);
        const startTime = Date.now();
        if (!(await isValidUrl(global.thumb))) {
          console.warn('[WARN] URL thumbnail tidak valid, menggunakan defaultImageUrl');
          await conn.sendMessage(m.chat, {
            image: { url: defaultImageUrl },
            caption: list2,
            contextInfo: global.fakeig.contextInfo
          }, { quoted: m });
        } else {
          await conn.sendMessage(m.chat, {
            image: { url: global.thumb },
            caption: list2,
            contextInfo: global.fakeig.contextInfo
          }, { quoted: m });
        }
        console.log('[INFO] Pesan image berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim image:', err);
        await conn.sendMessage(m.chat, {
          text: list2,
          contextInfo: global.fakeig.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'button') {
      try {
        console.log('[INFO] Memulai pengiriman button menu dengan URL:', global.thumb);
        const startTime = Date.now();
        const thumbUrl = (await isValidUrl(global.thumb)) ? global.thumb : defaultImageUrl;
        await conn.sendMessage(m.chat, {
          image: { url: thumbUrl },
          caption: list2,
          footer: global.namebot,
          buttons: [
            {
              buttonId: '.sc',
              buttonText: { displayText: 'Script 📁' },
              type: 1
            },
            {
              buttonId: '.owner',
              buttonText: { displayText: 'Owner 👑' },
              type: 1
            }
          ],
          headerType: 4,
          viewOnce: true
        }, { quoted: m });
        console.log('[INFO] Pesan button berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim button menu:', err);
        await conn.sendMessage(m.chat, {
          text: list2,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
   } else if (settings.setmenu === 'mix') {
  if (device === 'ios') {
    console.log('[INFO] Device iOS terdeteksi, alihkan menu mix ke simple');
    // kirim menu simple lalu hentikan block ini
    await conn.sendMessage(m.chat, {
      text: infoBot + '\n\n' + categoryListText,
      contextInfo: global.adReply.contextInfo
    }, { quoted: m });
    return; // ⬅️ penting, supaya tidak lanjut eksekusi mix
  }
      try {
        console.log('[INFO] Memulai pengiriman mix menu dengan URL:', global.thumb);
        const startTime = Date.now();
        const thumbUrl = (await isValidUrl(global.thumb)) ? global.thumb : defaultImageUrl;

        let rows = daftarHelp.map((helpItem, index) => ({
         // header: `Perintah ${index + 1}`,
          title: `.${helpItem}`,
          description: `Gunakan perintah .${helpItem}`,
          id: `${usedPrefix}${helpItem}`
        }));

        let listMessage = {
          title: `Menu ${perintah.toUpperCase()}`,
          sections: [{
            title: 'Pilih Perintah',
            highlight_label: '😜',
            rows
          }]
        };

        await conn.sendMessage(m.chat, {
          image: { url: thumbUrl },
          caption: list2,
          footer: global.namebot,
          buttons: [
            {
              buttonId: '.sc',
              buttonText: { displayText: 'Script 📁' },
              type: 1
            },
            {
              buttonId: '.owner',
              buttonText: { displayText: 'Owner 👑' },
              type: 1
            },
            {
              buttonId: 'action',
              buttonText: { displayText: 'Pilih Perintah' },
              type: 4,
              nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify(listMessage)
              }
            }
          ],
          headerType: 1,
          viewOnce: true
        }, { quoted: m });
        console.log('[INFO] Pesan mix berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim mix menu:', err);
        await conn.sendMessage(m.chat, {
          text: list2,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'gift') {
      try {
        console.log('[INFO] Memulai pengiriman gift menu dengan URL:', global.gifmenu);
        const startTime = Date.now();
        const gifUrl = (await isValidUrl(global.gifmenu)) ? global.gifmenu : defaultGifUrl;
        console.log('[INFO] Menggunakan URL GIF:', gifUrl);
        await conn.sendMessage(m.chat, {
          video: { url: gifUrl },
          gifPlayback: true,
          mimetype: 'video/mp4',
          caption: list2,
          contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
              title: `${global.namebot} - Version ${global.version || '89.1.3'}`,
              body: `Powered by ${global.nameowner || 'Jagoan Project'}`,
              thumbnailUrl: global.thumb || 'https://i.ibb.co/Fb2z8jz/zhenya-menu.jpg',
              mediaType: 1,
              renderLargerThumbnail: true,
              sourceUrl: 'https://wa.me/' + (global.rowner || '62895362282300'),
            },
          },
        }, { quoted: m });
        console.log('[INFO] Pesan gift berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim gift menu:', err);
        await conn.sendMessage(m.chat, {
          text: list2,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    }
    // Kirim VN setelah menu dikirim
    if (!args[0]) {
      try {
        await conn.sendMessage(m.chat, {
          audio: { url: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1759312106346.mpeg' },
          mimetype: 'audio/aac',
          ptt: true
        }, { quoted: m });
      } catch (err) {
        console.error('[ERROR] Gagal mengirim VN:', err);
      }
    }
  } else if (perintah === 'all') {
    let name = m.pushName || conn.getName(m.sender);
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(4001);
    const allTagsAndHelp = Object.keys(tagCount).map(tag => {
      let daftarHelp = tagHelpMapping[tag] || [];
      if (!Array.isArray(daftarHelp)) {
        daftarHelp = [];
      }

// Urutkan daftar perintah secara alfabetis
        daftarHelp.sort((a, b) => a.localeCompare(b));

      if (daftarHelp.length === 0) {
        return `✦. ── *MENU ${tag.toUpperCase()}* ── .✦\n\nTidak ada perintah yang tersedia.`;
      }

      const helpText = daftarHelp.map((helpItem, index) => `› .${helpItem}`).join('\n');
      return `✦. ── *MENU ${tag.toUpperCase()}* ── .✦\n\n${helpText}`;
    }).join('\n\n');

    let all = `
╭───「 👾 Status Bot 」───✧ 
│🤖 *Nama Bot*     : ${global.namebot}  
│📦 *Versi*        : ${global.version || '1.0.0'}  
│🌐 *Mode*         : ${global.opts['self'] ? '🔒 Privat' : '🌍 Publik'}  
│⏰ *Jam Aktif*    : ${await DateNow(new Date)}  
│👥 *Jumlah User*  : ${Object.keys(global.db.data.users).length}  
│📜 *Jumlah Menu*  : ${Object.keys(tagCount).length}  
╰─────────────── ✧

_Aku Adalah ${global.namebot}. Aku dibuat oleh ${global.nameowner || 'Jagoan Project'} untuk jadi asisten mu_\n\n` + allTagsAndHelp;

    if (settings.setmenu === 'simple') {
      await conn.sendMessage(m.chat, {
        text: all,
        contextInfo: global.adReply.contextInfo
      }, { quoted: m });
      
    } else if (settings.setmenu === 'payment') {
      await conn.relayMessage(m.chat, {
        requestPaymentMessage: {
          currencyCodeIso4217: 'IDR',
          amount1000: 70000 * 1000, // Rp. 70.000
          requestFrom: '0@s.whatsapp.net',
          noteMessage: {
            extendedTextMessage: {
              text: all,
              contextInfo: global.adReply.contextInfo
            }
          },
          contextInfo: global.adReply.contextInfo
        }
      }, {});
      
    } else if (settings.setmenu === 'buttonlist') {
      let rows = [];
      Object.keys(tagCount).forEach(tag => {
        let daftarHelp = tagHelpMapping[tag] || [];
        if (!Array.isArray(daftarHelp)) daftarHelp = [];
        if (daftarHelp.length > 0) {
          rows.push({
            title: tag === 'all' ? `All Menu` : `${tag.charAt(0).toUpperCase() + tag.slice(1)}`,
            id: `${usedPrefix + command} ${tag}`,
            description: `Total fitur: ${(tagHelpMapping[tag] || []).length} perintah`
          });
        }
      });

      let listMessage = {
        title: 'Semua Menu',
        sections: [{
          title: 'Pilih Kategori',
          rows
        }]
      };

      try {
        let msg = generateWAMessageFromContent(m.chat, {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: all
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: `Hubungi ${global.nameowner || 'Jagoan Project'} untuk info lebih lanjut: wa.me/${global.rowner || '62895362282300'}`
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              title: `✨ ${global.namebot} ✨`,
              hasMediaAttachment: global.thumb ? true : false,
              ...(global.thumb ? await prepareWAMessageMedia({ image: { url: global.thumb } }, { upload: conn.waUploadToServer }).catch(() => ({})) : {})
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify(listMessage)
                }
              ]
            })
          })
        }, { userJid: m.chat, quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim buttonlist untuk semua menu:', err);
        await conn.sendMessage(m.chat, {
          text: all,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'image') {
      try {
        console.log('[INFO] Memulai pengiriman image dengan URL:', global.thumb);
        const startTime = Date.now();
        if (!(await isValidUrl(global.thumb))) {
          console.warn('[WARN] URL thumbnail tidak valid, menggunakan defaultImageUrl');
          await conn.sendMessage(m.chat, {
            image: { url: defaultImageUrl },
            caption: all,
            contextInfo: global.fakeig.contextInfo
          }, { quoted: m });
        } else {
          await conn.sendMessage(m.chat, {
            image: { url: global.thumb },
            caption: all,
            contextInfo: global.fakeig.contextInfo
          }, { quoted: m });
        }
        console.log('[INFO] Pesan image berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim image:', err);
        await conn.sendMessage(m.chat, {
          text: all,
          contextInfo: global.fakeig.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'button') {
      try {
        console.log('[INFO] Memulai pengiriman button menu dengan URL:', global.thumb);
        const startTime = Date.now();
        const thumbUrl = (await isValidUrl(global.thumb)) ? global.thumb : defaultImageUrl;
        await conn.sendMessage(m.chat, {
          image: { url: thumbUrl },
          caption: all,
          footer: global.namebot,
          buttons: [
            {
              buttonId: '.sc',
              buttonText: { displayText: 'Script 📁' },
              type: 1
            },
            {
              buttonId: '.owner',
              buttonText: { displayText: 'Owner 👑' },
              type: 1
            }
          ],
          headerType: 4,
          viewOnce: true
        }, { quoted: m });
        console.log('[INFO] Pesan button berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim button menu:', err);
        await conn.sendMessage(m.chat, {
          text: all,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
   } else if (settings.setmenu === 'mix') {
  if (device === 'ios') {
    console.log('[INFO] Device iOS terdeteksi, alihkan menu mix ke simple');
    // kirim menu simple lalu hentikan block ini
    await conn.sendMessage(m.chat, {
      text: infoBot + '\n\n' + categoryListText,
      contextInfo: global.adReply.contextInfo
    }, { quoted: m });
    return; // ⬅️ penting, supaya tidak lanjut eksekusi mix
  }
      try {
        console.log('[INFO] Memulai pengiriman mix menu dengan URL:', global.thumb);
        const startTime = Date.now();
        const thumbUrl = (await isValidUrl(global.thumb)) ? global.thumb : defaultImageUrl;

        let rows = [];
        Object.keys(tagCount).forEach(tag => {
          let daftarHelp = tagHelpMapping[tag] || [];
          if (!Array.isArray(daftarHelp)) daftarHelp = [];
          if (daftarHelp.length > 0) {
            rows.push({
              header: `Kategori ${tag.charAt(0).toUpperCase() + tag.slice(1)}`,
              title: tag === 'all' ? `All Menu` : `${tag.charAt(0).toUpperCase() + tag.slice(1)}`,
              description: `Total fitur: ${(tagHelpMapping[tag] || []).length} perintah`,
              id: `${usedPrefix + command} ${tag}`
            });
          }
        });

        let listMessage = {
          title: 'Semua Menu',
          sections: [{
            title: 'Pilih Kategori',
            highlight_label: '😜',
            rows
          }]
        };

        await conn.sendMessage(m.chat, {
          image: { url: thumbUrl },
          caption: all,
          footer: global.namebot,
          buttons: [
            {
              buttonId: '.sc',
              buttonText: { displayText: 'Script 📁' },
              type: 1
            },
            {
              buttonId: '.owner',
              buttonText: { displayText: 'Owner 👑' },
              type: 1
            },
            {
              buttonId: 'action',
              buttonText: { displayText: 'Pilih Kategori' },
              type: 4,
              nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify(listMessage)
              }
            }
          ],
          headerType: 1,
          viewOnce: true
        }, { quoted: m });
        console.log('[INFO] Pesan mix berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim mix menu:', err);
        await conn.sendMessage(m.chat, {
          text: all,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    } else if (settings.setmenu === 'gift') {
      try {
        console.log('[INFO] Memulai pengiriman gift menu dengan URL:', global.gifmenu);
        const startTime = Date.now();
        const gifUrl = (await isValidUrl(global.gifmenu)) ? global.gifmenu : defaultGifUrl;
        console.log('[INFO] Menggunakan URL GIF:', gifUrl);
        await conn.sendMessage(m.chat, {
          video: { url: gifUrl },
          gifPlayback: true,
          mimetype: 'video/mp4',
          caption: all,
          contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
              title: `${global.namebot} - Version ${global.version || '105.1.3'}`,
              body: `Powered by ${global.nameowner || 'Jagoan Project'}`,
              thumbnailUrl: global.thumb || 'https://i.ibb.co/Fb2z8jz/zhenya-menu.jpg',
              mediaType: 1,
              renderLargerThumbnail: true,
              sourceUrl: 'https://wa.me/' + (global.rowner || '62895362282300'),
            },
          },
        }, { quoted: m });
        console.log('[INFO] Pesan gift berhasil dikirim, waktu: ', (Date.now() - startTime) / 1000, 'detik');
        
      } catch (err) {
        console.error('[ERROR] Gagal mengirim gift menu:', err);
        await conn.sendMessage(m.chat, {
          text: all,
          contextInfo: global.adReply.contextInfo
        }, { quoted: m });
        
      }
    }
    // Kirim VN setelah menu dikirim
    if (!args[0]) {
      try {
        await conn.sendMessage(m.chat, {
          audio: { url: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1759312106346.mpeg' },
          mimetype: 'audio/aac',
          ptt: true
        }, { quoted: m });
      } catch (err) {
        console.error('[ERROR] Gagal mengirim VN:', err);
      }
    }
  } else {
    await conn.reply(m.chat, `*MENU Not found:*`, m);
    
    // Kirim VN setelah pesan dikirim
    if (!args[0]) {
      try {
        await conn.sendMessage(m.chat, {
          audio: { url: 'https://raw.githubusercontent.com/typographuniverse/uploader-Jagpro/main/Uploads/file-1759312106346.mpeg' },
          mimetype: 'audio/aac',
          ptt: true
        }, { quoted: m });
      } catch (err) {
        console.error('[ERROR] Gagal mengirim VN:', err);
      }
    }
  }
};

menulist.help = ['menu'];
menulist.tags = ['main'];
menulist.command = ['menu'];
menulist.register = true;
module.exports = menulist;