// ✨ Plugin fun - ddos (CDN only) — domain overlay di atas host kanan-bawah ✨
// ⚠️ HANYA simulasi gambar. Jangan gunakan untuk tindakan berbahaya.

const { createCanvas, loadImage } = require('canvas')
const fetch = require('node-fetch')

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))

// simple validation
const domainRegex = /^(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/
const urlRegex = /^(https?:\/\/)?((?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})(\/[^\s]*)?$/

/**
 * Ambil image dari URL (CDN only)
 */
async function loadImageFromUrlOnly(url) {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`Gagal mengambil mentahan dari url: ${res.status} ${res.statusText}`)
  const buffer = await res.buffer()
  return await loadImage(buffer)
}

/**
 * Buat gambar simulasi dan kembalikan Buffer PNG
 * Posisi teks diatur relatif (multiplier) sehingga bisa ditempatkan di area host kanan-bawah
 */
async function createSimulationImageBuffer_TargetAtHost(targetDomain, cdnUrl) {
  const baseImg = await loadImageFromUrlOnly(cdnUrl)

  // canvas
  const canvas = createCanvas(baseImg.width, baseImg.height)
  const ctx = canvas.getContext('2d')

  // gambar base
  ctx.drawImage(baseImg, 0, 0, baseImg.width, baseImg.height)

  // teks domain (bersihkan protokol)
  const domainText = String(targetDomain || 'unknown').replace(/^https?:\/\//i, '')

  // font size relatif
const fontSize = Math.max(14, Math.floor(baseImg.height * 0.025))
ctx.font = `400 ${fontSize}px Sans`
ctx.textBaseline = 'middle'
ctx.textAlign = 'center'   // 🔥 bikin teks centre


 // --- POSISI untuk "di atas host kanan-bawah" ---
const xMultiplier = 0.80   // relatif area kanan
const yMultiplier = 0.71   // relatif bawah
let centerX = Math.floor(baseImg.width * xMultiplier)
  const x = Math.floor(baseImg.width * xMultiplier)
  const y = Math.floor(baseImg.height * yMultiplier)


  // ukur lebar teks
  ctx.textAlign = 'centre'
  const metrics = ctx.measureText(domainText)
  const textW = metrics.width
  const paddingX = Math.floor(fontSize * 0.6)
  const paddingY = Math.floor(fontSize * 0.35)

  // buat rounded rect di belakang teks supaya terbaca
  const rectW = Math.max(120, textW + paddingX * 2)
  const rectH = Math.max(fontSize + paddingY * 2, Math.floor(fontSize * 1.2))
  const rectX = x - paddingX // sedikit geser ke kiri supaya teks tampak di tengah latar
  const rectY = y - rectH / 2
  const radius = Math.max(6, Math.floor(fontSize * 0.18))

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath()
    ctx.moveTo(x + r, y)
    ctx.arcTo(x + w, y, x + w, y + h, r)
    ctx.arcTo(x + w, y + h, x, y + h, r)
    ctx.arcTo(x, y + h, x, y, r)
    ctx.arcTo(x, y, x + w, y, r)
    ctx.closePath()
  }

  // draw domain text (white)
  ctx.fillStyle = '#404040'
  ctx.fillText(domainText, x, y)

  // optional: tambahkan small label "SIMULASI" agar jelas
  const simText = 'Down!'
  const simFontSize = Math.max(10, Math.floor(baseImg.height * 0.012))
  ctx.font = `500 ${simFontSize}px Sans`
  ctx.textAlign = 'right'
  ctx.textBaseline = 'bottom'
  ctx.fillStyle = 'rgba(255,255,255,0.85)'
  ctx.fillText(simText, baseImg.width - 12, baseImg.height - 10)

  // return buffer
  return canvas.toBuffer('image/png')
}

/**
 * Handler plugin (mirip fun ddos)
 */
let handler = async (m, { conn, text, usedPrefix }) => {
  try {
    if (!text) return conn.reply(m.chat, `🚫 Masukkan URL/domain target!\nContoh: ${usedPrefix || '.'}ddos example.com`, m)

    const target = String(text).trim()

    if (!domainRegex.test(target) && !urlRegex.test(target)) {
      return conn.reply(m.chat, '❌ Format tidak valid!\nContoh: .ddos example.com', m)
    }

    // kirim langkah/animasi progress
    let sent = await conn.sendMessage(m.chat, { text: `🌩️ Memulai simulasi DDoS ke ${target}...` }, { quoted: m })
   const steps = [
    `🌩️ Memulai simulasi DDoS ke ${target}...`,
    `🔥 Menghubungkan ke botnet...`,
    `🚀 Meluncurkan 10.000 request per detik...`,
    `📡 Membanjiri server dengan paket data dummy...`,
    `💥 Server ${target} mulai overload: [█░░░░░░░░░] 10%`,
    `💥 Server ${target} mulai overload: [█████░░░░░] 50%`,
    `💥 Server ${target} mulai overload: [████████░░] 85%`,
    `💥 Server ${target} mulai overload: [██████████] 100%`,
    `📊 Status serangan :
🌐 Target: ${target}
📡 Botnet: 50.000
📈 Trafik: 1 TB data dummy per detik
⏱️ Waktu eksekusi: 8.7 detik

🛑 *Disclaimer:* Admin atau Owner tidak bertanggung jawab atas kerusakan web target.
`]
    for (let i = 0; i < steps.length; i++) {
      await delay(3000)
      try {
        if (conn.relayMessage && sent && sent.key) {
          await conn.relayMessage(m.chat, {
            protocolMessage: {
              key: sent.key,
              type: 14,
              editedMessage: { conversation: steps[i] }
            }
          }, {})
        } else {
          await conn.sendMessage(m.chat, { text: steps[i] }, { quoted: m })
        }
      } catch (e) {
        // fallback: kirim new message
        await conn.sendMessage(m.chat, { text: steps[i] }, { quoted: m }).catch(()=>{})
      }
    }

    // buat image (CDN only)
    await delay(1200)
    const cdnUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/apakahh.png'
    const imageBuffer = await createSimulationImageBuffer_TargetAtHost(target, cdnUrl)

    if (!imageBuffer || !Buffer.isBuffer(imageBuffer)) throw new Error('Image buffer invalid')

    const caption = `✅ Hasil untuk ${target}\n> Silahkan Cek, jika belum, ulangi kembali`
    await conn.sendMessage(m.chat, { image: imageBuffer, caption }, { quoted: m })

    // penutup prank
    await delay(20000)
    await conn.sendMessage(m.chat, { text: 'Ini cuma prank ngab, Ngeri kali sampai di buka gitu 😅' }, { quoted: m })

  } catch (err) {
    console.error('Error plugin ddos (overlay host):', err)
    await conn.sendMessage(m.chat, { text: 'Gagal membuat gambar simulasi. Cek log.' }, { quoted: m })
  }
}

handler.help = ['ddos <domain>']
handler.tags = ['fun']
handler.command = ['ddos']
handler.limit = 5

handler.register = true
module.exports = handler
