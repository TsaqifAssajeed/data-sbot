// ✨ Plugin downloader - tiktok ✨

// ✨ Plugin downloader - tiktok ✨

const axios = require('axios');

// Handler utama
let handler = async (m, { conn, text }) => {
  if (!text) return m.reply(`‼️ Harap masukan link TikTok, jika tiktok slide gunakan .ttslide`);

  try {
    // Kirim reaksi jam saat proses dimulai
    await conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

    const result = await tiktok2(text);

    if (!result.no_watermark) return m.reply("❌ Video tidak ditemukan.");

    // Kirim video dulu
    await conn.sendMessage(m.chat, {
      video: { url: result.no_watermark },
      caption: `
 ⏬ ＤＯＷＮＬＯＡＤ　ＣＯＭＰＬＥＴＥ 

🎬 𝐉𝐮𝐝𝐮𝐥 : ${result.title}  
❤️ 𝐋𝐢𝐤𝐞   : ${result.digg_count}  
👀 𝐕𝐢𝐞𝐰   : ${result.play_count}  
📤 𝐒𝐡𝐚𝐫𝐞  : ${result.share_count}  

💡 𝐍𝐨𝐭𝐞 : Jika Tiktok Slide, gunakan perintah *.ttslide*
`,
      footer: namebot,
      thumbnail: { url: result.cover }
    }, { quoted: m });

    // Pastikan hanya kirim audio jika ada dan tidak kosong
    if (result.music && result.music !== '') {
      await conn.sendMessage(m.chat, {
        audio: { url: result.music },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m });
    }

    // Reaksi centang setelah selesai
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error(error);
    m.reply("❌ Terjadi kesalahan: " + error.message);
  }
};

handler.help = ["tiktok", "tt"];
handler.tags = ["downloader"];
handler.command = /^(tiktok|tt)$/i;

handler.register = true
handler.limit = true
module.exports = handler;

// Fungsi ambil data TikTok
async function tiktok2(query) {
  try {
    const encodedParams = new URLSearchParams();
    encodedParams.set('url', query);
    encodedParams.set('hd', '1');

    const response = await axios({
      method: 'POST',
      url: 'https://tikwm.com/api/',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': 'current_language=en',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
      },
      data: encodedParams
    });

    const data = response.data.data;

    return {
      title: data.title,
      cover: data.cover,
      origin_cover: data.origin_cover,
      no_watermark: data.play,
      watermark: data.wmplay,
      music: data.music,
      digg_count: data.digg_count,
      play_count: data.play_count,
      share_count: data.share_count
    };
  } catch (error) {
    console.error('Error fetching TikTok video:', error);
    throw new Error('Gagal mengambil data dari TikTok.');
  }
}