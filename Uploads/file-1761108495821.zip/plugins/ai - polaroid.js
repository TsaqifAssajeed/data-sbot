const axios = require('axios')
const sharp = require('sharp');
const fs = require("fs")
const path = require("path")
const uploadImage = require("../lib/uploadImage")

let sesiPolaroid = {};

let handler = async (m, { conn }) => {
  const sender = m.sender;
  const quoted = m.quoted;
  const mimeCaption = m.mimetype || '';
  const mimeReply = quoted?.mimetype || '';
  const isImageCaption = mimeCaption.startsWith('image/');
  const isImageReply = mimeReply.startsWith('image/');

  const getImageBuffer = async () => {
    if (isImageCaption) {
      return await m.download(); // Gambar dikirim dengan caption
    } else if (isImageReply && /image\/(png|jpe?g|gif)/.test(mimeReply)) {
      return await quoted.download(); // Gambar di-reply
    }
    return null;
  };

  if (!sesiPolaroid[sender]) {
    const img1 = await getImageBuffer();
    if (!img1) {
      return m.reply(
        '🖼️ Kirim gambar pertama dengan caption *.polaroid* atau reply gambar (PNG/JPEG/GIF) lalu ketik *.polaroid*'
      );
    }

    sesiPolaroid[sender] = {
      step: 1,
      img1Buffer: img1,
      timeout: setTimeout(() => {
        delete sesiPolaroid[sender];
        m.reply('⌛ Sesi polaroid kadaluarsa. Silakan mulai dari awal dengan *.polaroid*');
      }, 60000),
    };

    return m.reply(
      '✅ Gambar pertama diterima.\nSekarang kirim gambar kedua (dengan caption *.polaroid* atau reply gambar dan ketik *.polaroid*).'
    );
  }

  if (sesiPolaroid[sender].step === 1) {
    const img2 = await getImageBuffer();
    if (!img2) {
      return m.reply(
        '🖼️ Kirim gambar kedua (dengan caption *.polaroid* atau reply gambar (PNG/JPEG/GIF) dan ketik *.polaroid*)'
      );
    }

    clearTimeout(sesiPolaroid[sender].timeout);

    m.reply('⏳ Sedang memproses polaroid, tunggu sebentar...');

    try {
      // Fungsi helper untuk merge dua gambar ke canvas putih polos rasio 9:16 portrait
      const mergePolaroidFrame = async (buf1, buf2) => {
        // Resize gambar ke ukuran yang sesuai untuk frame polaroid
        const img1 = await sharp(buf1).resize(400, 400).toBuffer();
        const img2 = await sharp(buf2).resize(400, 400).toBuffer();

        // Buat canvas putih polos dengan rasio 9:16 portrait (lebar 900, tinggi 1600)
        const canvasWidth = 900;
        const canvasHeight = 1600;
        const polaroidWidth = 425;
        const polaroidHeight = 425;

        const merged = await sharp({
          create: {
            width: canvasWidth,
            height: canvasHeight,
            channels: 4,
            background: { r: 255, g: 255, b: 255, alpha: 1 }, // Latar putih polos
          },
        })
          .composite([
            // Foto 1 di tengah atas
            {
              input: img1,
              top: 200,
              left: Math.floor((canvasWidth - polaroidWidth * 2 - 50) / 2),
            },
            // Foto 2 di sebelah kanan foto 1
            {
              input: img2,
              top: 200,
              left: Math.floor((canvasWidth - polaroidWidth * 2 - 50) / 2) + polaroidWidth + 50,
            },
          ])
          .png()
          .toBuffer();

        return merged;
      };

      const prompt = `Buatlah foto polaroid dari gambar input. Terlihat seperti foto biasa dengan frame polaroid klasik, sedikit efek blur, cahaya kilat dari ruangan gelap yang merata. Jangan ubah wajah, ganti latar belakang dengan tirai putih, pose natural, keduanya senang menghadap kamera dan saling berpelukan. ukuran canvas 9:16 potrait`;

      console.log('Processing images with AlyaChan API...');
      const old = new Date();

      // Merge gambar terlebih dahulu menjadi satu buffer
      const mergedBuffer = await mergePolaroidFrame(sesiPolaroid[sender].img1Buffer, img2);

      // Upload merged buffer ke CDN untuk mendapatkan URL
      const uploadedUrl = await uploadImage(mergedBuffer);

      // Panggil API AlyaChan
      const response = await axios.get(`${global.alyachan}/api/ai-edit`, {
        params: {
          image: uploadedUrl,
          prompt: prompt,
          apikey: global.alyachankey
        }
      });

      const images = response.data.data.images;
      if (!images || images.length === 0) {
        throw new Error("❌ Tidak ada gambar yang dihasilkan dari API");
      }

      // Tunggu 10 detik sebelum mengirim hasil
      await new Promise(resolve => setTimeout(resolve, 10000));

      // Proses dan kirim kedua gambar
      for (let i = 0; i < Math.min(images.length, 2); i++) {
        const imageUrl = images[i].url;
        const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        let resultImage = Buffer.from(imageResponse.data);

        // Tempatkan hasil ke canvas putih polos 9:16
        const finalCanvas = await sharp({
          create: {
            width: 900,
            height: 1600,
            channels: 4,
            background: { r: 255, g: 255, b: 255, alpha: 1 }, // Latar putih polos
          },
        })
          .composite([
            { 
              input: resultImage, 
              top: 100, 
              left: Math.floor((900 - 800) / 2) // Gambar hasil di tengah
            },
          ])
          .png()
          .toBuffer();

        // Simpan hasil sementara
        const tempPath = path.join(
          process.cwd(),
          "tmp",
          `polaroid_${Date.now()}_${i}.png`
        );
        fs.writeFileSync(tempPath, finalCanvas);

        // Kirim gambar
        await conn.sendMessage(
          m.chat,
          {
            image: finalCanvas,
            caption: `📸 *Polaroid selesai dalam*: ${new Date() - old} ms (Metode: AlyaChan API, Gambar ${i + 1})\n> Limit -25`,
          },
          { quoted: m }
        );

        // Cleanup
        setTimeout(() => {
          try {
            if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
          } catch (err) {
            console.error("Cleanup error:", err);
          }
        }, 30000);
      }

    } catch (err) {
      console.error('Error:', err);
      m.reply(
        `❌ Terjadi error saat memproses polaroid:\n${err.message || err}\n\nCoba lagi nanti atau pastikan gambar valid (PNG/JPEG/GIF)!`
      );
    } finally {
      delete sesiPolaroid[sender];
    }
  }
};

handler.help = ['polaroid'];
handler.tags = ['ai', 'maker', 'premium'];
handler.command = /^polaroid$/i;
handler.limit = 25;
handler.premium = true;

handler.register = true;
module.exports = handler;