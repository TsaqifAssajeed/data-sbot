const { createCanvas, loadImage, registerFont } = require('canvas');
const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('🚩 Format salah!\n\nContoh:\n.fakeml Who is?\n*Reply gambar profil target!*');

  if (!m.quoted) return m.reply('📷 Harap *reply* ke gambar yang ingin ditempel.');

  let mediaBuffer = null;

  try {
    if (conn.downloadAndSaveMediaMessage) {
      try {
        const tmp = await conn.downloadAndSaveMediaMessage(m.quoted);
        mediaBuffer = fs.readFileSync(tmp);
        try { fs.unlinkSync(tmp); } catch {}
      } catch {}
    }

    if (!mediaBuffer && conn.downloadMediaMessage) {
      try { mediaBuffer = await conn.downloadMediaMessage(m.quoted); } catch {}
    }

    if (!mediaBuffer && conn.downloadContentFromMessage) {
      try {
        const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
        const type = Object.keys(quotedMsg)[0];
        const stream = await conn.downloadContentFromMessage(quotedMsg[type], type.replace('Message', ''));
        let buffer = Buffer.from([]);
        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
        mediaBuffer = buffer;
      } catch {}
    }
  } catch (err) {
    mediaBuffer = null;
  }

  if (!mediaBuffer) return m.reply('📷 Gagal mendapatkan gambar. Pastikan kamu *reply* ke pesan gambar (bukan sticker/profile placeholder).');

  try {
    const fontPath = path.join(__dirname, '../font/Roboto.ttf');
    if (fs.existsSync(fontPath)) registerFont(fontPath, { family: 'Roboto' });

    const userImage = await loadImage(mediaBuffer);
    const bg = await loadImage('https://files.catbox.moe/liplnf.jpg');
    const frameOverlay = await loadImage('https://files.catbox.moe/2vm2lt.png');

    const canvas = createCanvas(bg.width, bg.height);
    const ctx = canvas.getContext('2d');

    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

    const avatarSize = 205;
    const frameSize = 293;
    const centerX = (canvas.width - frameSize) / 2;
    const centerY = (canvas.height - frameSize) / 2 - 282;
    const avatarX = centerX + (frameSize - avatarSize) / 2;
    const avatarY = centerY + (frameSize - avatarSize) / 2 - 3;

    const { width, height } = userImage;
    const minSide = Math.min(width, height);
    const cropX = (width - minSide) / 2;
    const cropY = (height - minSide) / 2;

    ctx.drawImage(userImage, cropX, cropY, minSide, minSide, avatarX, avatarY, avatarSize, avatarSize);
    ctx.drawImage(frameOverlay, centerX, centerY, frameSize, frameSize);

    const nickname = text.trim();
    const maxFontSize = 36;
    const minFontSize = 24;
    const maxChar = 11;
    let fontSize = maxFontSize;

    if (nickname.length > maxChar) {
      const excess = nickname.length - maxChar;
      fontSize -= excess * 2;
      if (fontSize < minFontSize) fontSize = minFontSize;
    }

    ctx.font = `${fontSize}px Roboto`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(nickname, canvas.width / 2 + 13, centerY + frameSize + 15);

    const buffer = canvas.toBuffer('image/png');

    await conn.sendMessage(m.chat, {
      image: buffer,
      caption: `🎮 Fake ML Lobby berhasil dibuat!\n🆔 *${nickname}*`
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    return m.reply('❌ Gagal membuat Fake ML Lobby:\n' + (err.message || err));
  }
};

handler.help = ['fakeml <nickname>'];
handler.tags = ['maker'];
handler.command = /^fakeml$/i;

handler.register = true
handler.limit = true
module.exports = handler;