let handler = async (m, { conn, text }) => {
    const pushname = m.pushName || "Kawan"; // Nama pengguna

    // ✅ Respon untuk sapaan
    if (/^(halo|p|hai|hello|hi|hey|halo semuanya|hai semua|hey guys|what's up|sup|yo)$/i.test(m.text)) {
        const greetings = [
            `Halo, ${pushname}! Apa kabar? 😊`,
            `Hai ${pushname}, ada yang bisa saya bantu? 😄`,
            `Hello ${pushname}! Semoga harimu menyenangkan. 🌞`,
            `Hai, ${pushname}. Lagi apa nih? 😎`,
            `Halo, ${pushname}! Apa yang bisa saya bantu hari ini? 🙌`,
            `Hai, ${pushname}! Ada yang ingin dibicarakan? 🗣️`,
            `What's up, ${pushname}? Ada yang bisa saya bantu? 🤗`,
            `Yo, ${pushname}! Semoga harimu luar biasa. ✨`,
            `Hai semua! Apa kabar? 🎉`,
            `Halo semuanya! Semoga hari kalian menyenankan. 🌟`,
            `Hello there, ${pushname}! 😊`,
            `Hai ${pushname}, senang bertemu denganmu! 😁`,
            `Halo, ${pushname}! Siap membantu kamu! 💪`,
            `Hey ${pushname}, ada yang bisa dibantu? 🤔`,
            `Hai, ${pushname}. Punya rencana seru hari ini? 🌈`,
            `Hello ${pushname}, semoga hari-harimu menyenankan! 🌸`,
            `Hai ${pushname}, semangat terus ya! 💥`,
            `Halo ${pushname}, semoga harimu penuh kebahagiaan! 😍`,
            `Hi, ${pushname}! Lagi ngapain nih? 😄`,
            `Hai, ${pushname}, semoga semuanya lancar! 🌻`,
        ];
        const response = greetings[Math.floor(Math.random() * greetings.length)];
        await conn.sendMessage(m.chat, { text: response }, { quoted: m });
    }

    // ✅ Respon untuk ucapan terima kasih
    else if (/terima kasih|makasih|tq|thanks|thank you|matur nuwun|thank you very much|thanks a lot/i.test(m.text)) {
        const thanksReplies = [
            `Sama-sama, ${pushname}! 😊`,
            `Dengan senang hati! 😄`,
            `No problem, ${pushname}! 🙌`,
            `Sama-sama! Kalau ada masalah, kabari ya. 💬`,
            `Tidak masalah, ${pushname}. Senang bisa membantu! 😁`,
            `Tentu, ${pushname}, kapan pun kamu butuh bantuan! 💪`,
            `Senang bisa membantu, ${pushname}! 😇`,
            `Sama-sama, semoga harimu menyenangkan! 🌞`,
            `No worries, ${pushname}, senang bisa membantu! 🤗`,
            `Terima kasih juga, ${pushname}! 🙏`,
            `Senang mendengarnya, ${pushname}! 🎉`,
            `Sama-sama, kalau ada yang lain bisa tanya ya! 💬`,
            `Kembali, ${pushname}, semoga bermanfaat! ✨`,
            `Sama-sama, semoga hari kamu lebih baik! 🌻`,
            `Tidak masalah, ${pushname}! Semoga sukses selalu! 🌟`,
            `Semoga bisa terus membantu, ${pushname}! 💡`,
            `Semoga hari kamu lebih cerah, ${pushname}! ☀️`,
            `Sama-sama, yuk terus semangat! 🔥`,
            `Dengan senang hati, ${pushname}! 😊`,
            `Selalu siap membantu, ${pushname}! 💖`,
        ];
        const response = thanksReplies[Math.floor(Math.random() * thanksReplies.length)];
        await conn.sendMessage(m.chat, { text: response }, { quoted: m });
    }
};

// Menggunakan regex global agar bisa mendeteksi kata kunci di mana saja
handler.customPrefix = /^(halo|p|hai|hello|hi|hey|halo semuanya|hai semua|hey guys|what's up|sup|yo|terima kasih|makasih|tq|thanks|thank you|matur nuwun|thank you very much|thanks a lot)$/i;
handler.command = new RegExp;
handler.fail = null;

module.exports = handler;
