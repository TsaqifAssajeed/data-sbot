const axios = require('axios');
const cheerio = require('cheerio');

const handler = async (m, { text, command }) => {
  if (command === 'starstats') {
    try {
      const characters = await statsStarRail();
      if (characters.length === 0) {
        return m.reply("Tidak ditemukan karakter.");
      }

      let response = "📊 *Daftar Karakter Star Rail*\n\n";
      characters.forEach((char, i) => {
        response += `${i + 1}. *${char.name}*\n` +
          `- HP: ${char.hp}\n` +
          `- ATK: ${char.atk}\n` +
          `- DEF: ${char.def}\n` +
          `- SPD: ${char.speed}\n\n`;
      });

      return m.reply(response.trim());
    } catch (err) {
      console.error(err);
      return m.reply("Terjadi kesalahan saat mengambil data karakter.");
    }
  }

  if (command === 'stardetail') {
    if (!text) return m.reply("Kirimkan URL karakter untuk melihat detailnya.");
    try {
      const details = await detailStarRail(text);
      if (!details.name) return m.reply("Detail karakter tidak ditemukan.");

      let response = `📜 *Detail Karakter*\n\n` +
        `*Name:* ${details.name}\n` +
        `*Path:* ${details.path}\n` +
        `*Element:* ${details.element}\n` +
        `*Description:* ${details.description}\n\n` +
        `📊 *Stats:*\n` +
        `- HP: ${details.stats.hp}\n` +
        `- ATK: ${details.stats.atk}\n` +
        `- DEF: ${details.stats.def}\n` +
        `- SPD: ${details.stats.speed}\n` +
        `- Taunt: ${details.stats.taunt}\n\n` +
        `📚 *Skills:*\n`;

      details.skills.forEach(skill => {
        response += `- *${skill.title} (${skill.type})*\n  ${skill.description}\n\n`;
      });

      return m.reply(response.trim());
    } catch (err) {
      console.error(err);
      return m.reply("Terjadi kesalahan saat mengambil detail karakter.");
    }
  }
};

async function statsStarRail() {
  const url = 'https://genshin.gg/star-rail/character-stats/';
  const { data } = await axios.get(url);
  const $ = cheerio.load(data);
  const characters = [];

  $('.rt-tr').each((i, el) => {
    const name = $(el).find('.character-name').text().trim();
    if (name) {
      const hp = $(el).find('div').eq(1).text().trim();
      const atk = $(el).find('div').eq(2).text().trim();
      const def = $(el).find('div').eq(3).text().trim();
      const speed = $(el).find('div').eq(4).text().trim();

      characters.push({ name, hp, atk, def, speed });
    }
  });

  return characters;
}

async function detailStarRail(url) {
  const { data } = await axios.get(url);
  const $ = cheerio.load(data);

  const details = {
    name: $('.character-info-name').text().trim(),
    path: $('.character-info-path').text().trim(),
    element: $('.character-info-element').attr('src'),
    description: $('.character-info-intro').find('p').text().trim(),
    stats: {
      hp: $('.character-info-stat').eq(0).find('.character-info-stat-value').text().trim(),
      atk: $('.character-info-stat').eq(1).find('.character-info-stat-value').text().trim(),
      def: $('.character-info-stat').eq(2).find('.character-info-stat-value').text().trim(),
      speed: $('.character-info-stat').eq(3).find('.character-info-stat-value').text().trim(),
      taunt: $('.character-info-stat').eq(4).find('.character-info-stat-value').text().trim()
    },
    skills: []
  };

  $('.character-info-skill').each((i, el) => {
    const title = $(el).find('.character-info-skill-title').text().trim();
    const type = $(el).find('.character-info-skill-type').text().trim();
    const description = $(el).find('.character-info-skill-description').text().trim();
    details.skills.push({ title, type, description });
  });

  return details;
}

handler.command = ['starrail', 'starstats'];
handler.tags = ['genshin'];
handler.help = ['starstats', 'starrail'];

handler.register = true
handler.limit = true
module.exports = handler;