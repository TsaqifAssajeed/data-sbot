const animexin = require('../scrape/animexin');

let handler = async (m, { conn, text, command }) => {
  try {
    if (!text) {
      return m.reply(`Please provide a keyword or an action (update/detail/search)!\n\nExample:\n.${command} update`);
    }

    const args = text.split(' ');
    const action = args[0].toLowerCase();
    const query = args.slice(1).join(' ');

    if (action === 'update') {
      m.reply('Fetching latest anime updates... Please wait...');
      const result = await animexin.animexinUpdate();
      if (result && result.length > 0) {
        let message = '🔍 *Latest Anime Updates* 🔍\n\n';
        result.forEach(anime => {
          message += `📺 *Title*: ${anime.title}\n🔗 *URL*: ${anime.url}\n🖼️ *Image*: ${anime.image}\n🎬 *Episode*: ${anime.episode}\n📦 *Type*: ${anime.type}\n\n`;
        });
        m.reply(message);
      } else {
        m.reply('No updates found.');
      }
    } else if (action === 'detail' && query) {
      m.reply('Fetching anime details... Please wait...');
      const result = await animexin.animexinDetail(query);
      if (result) {
        m.reply(`🔍 *Anime Details* 🔍\n\n${result}`);
      } else {
        m.reply('No details found for the provided URL.');
      }
    } else if (action === 'search' && query) {
      m.reply('Searching for anime... Please wait...');
      const result = await animexin.animexinSearch(query);
      if (result) {
        m.reply(`🔍 *Search Results* 🔍\n\n${result}`);
      } else {
        m.reply('No results found for the provided keyword.');
      }
    } else {
      m.reply(`Invalid command or missing query. Please use the following format:\n\n.${command} update\n.${command} detail <URL>\n.${command} search <keyword>`);
    }
  } catch (error) {
    console.error(error);
    m.reply('Error: ' + error.message);
  }
};

handler.help = ['animexin'];
handler.tags = ['anime'];
handler.command = ['animexin'];
handler.limit = true;

handler.register = true
module.exports = handler;

