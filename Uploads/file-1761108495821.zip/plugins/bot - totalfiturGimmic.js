let handler = async (m, { conn, command }) => {
  await conn.reply(m.chat, `Perintah *${command}* berhasil dijalankan untuk pengujian total fitur!`, m);
};

handler.help = ['martabak', ...Array.from({ length: 530 }, (_, i) => `dummy${i + 1} *[dummy fitur ${i + 1}]*`)];
handler.tags = [];
handler.command = /^(dihhhhh2222\d+)$/;

module.exports = handler;