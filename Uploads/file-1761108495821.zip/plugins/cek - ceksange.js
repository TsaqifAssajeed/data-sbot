let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.sange)}”`, m)
}
handler.help = ['ceksange']
handler.tags = ['cek']
handler.command = /^(ceksange)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.sange = [
'sangean lu', 'kebal sange🧢', 'gak terlalu sangean', 'agak agak suka sange', 'sange sama kartun😂', 'sering sange kalo liat anak kecil', 'sange sama bokep anak kecil', 'raja sange', 'puncak kesangean njir😨', 'gak suka sange', 'menolak sange dia mah padahal sebenarnya pengen', 'gabisa sange (mandul kali ya?)', 'sange sama pintu lemari😂', 'sange kalo liat kucing lagi kawin', 'sange sama bokep furry', 'sange sama papan tulis', 'sange kalo liat foto mas amba loh ya',
]