let handler = async (m, { conn, command }) => {
    // Inisialisasi data grup jika belum ada
    const chat = db.data.chats[m.chat] = db.data.chats[m.chat] || {};
    chat.total = chat.total || {};



    if (command === 'resetchat') {
        if (!chat.total || Object.keys(chat.total).length === 0) {
            return m.reply('Belum ada data pesan untuk direset.');
        }
        chat.total = {};
        db.data.chats[m.chat] = chat;
        // Simpan perubahan ke database (sesuaikan dengan sistem Anda)
        // Contoh: fs.writeFileSync('database.json', JSON.stringify(db.data, null, 2));
        return m.reply('✅ Statistik total chat berhasil direset!');
    }

    // Ambil metadata grup untuk mendapatkan daftar peserta aktif
    let pesertaAktif = [];
    try {
        const metadataGrup = await conn.groupMetadata(m.chat);
        pesertaAktif = metadataGrup.participants.map(peserta => peserta.id);
    
    } catch (error) {
    
        return m.reply('❌ Gagal mengambil data grup. Coba lagi nanti.');
    }

    // Inisialisasi chat.total untuk semua peserta aktif dengan nilai 0
    pesertaAktif.forEach(lid => {
        if (!chat.total[lid]) {
            chat.total[lid] = 0;
        }
    });

    // Simpan perubahan inisialisasi ke database
    db.data.chats[m.chat] = chat;

    // Ambil data statistik dan urutkan berdasarkan jumlah pesan
    const sortedData = Object.entries(chat.total)
        .filter(([lid]) => pesertaAktif.includes(lid))
        .sort((a, b) => b[1] - a[1]);

    const totalMessages = sortedData.reduce((acc, [, count]) => acc + count, 0);
    const totalPeople = pesertaAktif.length; // Gunakan jumlah peserta aktif

    // Buat daftar pesan, termasuk anggota dengan 0 pesan
    const messageList = pesertaAktif
        .map((lid, index) => {
            const count = chat.total[lid] || 0;
            const number = lid.split('@')[0];
            return `*${index + 1}.* @${number}: *${count}* pesan`;
        })
        .join('\n');

    await m.reply(
        `📊 *Statistik Pesan Grup:*\n\n` +
        `📝 *Total Pesan*: *${totalMessages}*\n` +
        `👥 *Jumlah Pengguna*: *${totalPeople}*\n\n` +
        `${messageList || 'Belum ada pesan yang tercatat dari peserta aktif.'}`,
        null,
        {
            contextInfo: {
                mentionedJid: pesertaAktif
            }
        }
    );
};

handler.help = ['totalchat', 'resetchat'];
handler.tags = ['group'];
handler.command = /^(totalchat|resetchat)$/i;
handler.group = true;
handler.admin = true;

handler.before = async function (m, { conn }) {
    if (!m.isGroup) return;

    // Inisialisasi data grup jika belum ada
    const chat = db.data.chats[m.chat] = db.data.chats[m.chat] || {};
    chat.total = chat.total || {};

    const sender = m.sender;


    // Ambil metadata grup untuk memeriksa peserta aktif
    let pesertaAktif = [];
    try {
        const metadataGrup = await conn.groupMetadata(m.chat);
        pesertaAktif = metadataGrup.participants.map(peserta => peserta.id);

    } catch (error) {

        return; // Lewati jika metadata gagal diambil
    }

    // Inisialisasi chat.total untuk semua peserta aktif dengan nilai 0
    pesertaAktif.forEach(lid => {
        if (!chat.total[lid]) {
            chat.total[lid] = 0;
        }
    });

    // Konversi JID pengirim ke LID
    let normalizedSender = sender;
    if (typeof global.getLidFromJid === 'function') {
        try {
            normalizedSender = await global.getLidFromJid(sender, conn);
           
        } catch (error) {
           
            normalizedSender = sender; // Fallback ke JID asli jika gagal
        }
    } else {
    }

    // Tambah jumlah pesan jika pengirim adalah peserta aktif
    if (pesertaAktif.includes(normalizedSender)) {
        chat.total[normalizedSender] = (chat.total[normalizedSender] || 0) + 1;
        db.data.chats[m.chat] = chat;
        // Debugging: Log total pesan untuk pengirim
        // Simpan perubahan ke database (sesuaikan dengan sistem Anda)
        // Contoh: fs.writeFileSync('database.json', JSON.stringify(db.data, null, 2));
    } else {
       // console.log(`Pengirim ${sender} (LID: ${normalizedSender}) tidak dikenali sebagai peserta aktif di ${m.chat}`);
    }
};

handler.register = true

module.exports = handler;