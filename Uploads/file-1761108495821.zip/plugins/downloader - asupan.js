/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

let { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys")

let handler = async (m, { conn, usedPrefix, command, text }) => {
  const asupan = [
    { title: 'Rikagusriani', url: `https://api.botcahx.eu.org/api/asupan/rikagusriani?apikey=${btc}` },
    { title: 'Ukhty', url: `https://api.botcahx.eu.org/api/asupan/ukhty?apikey=${btc}` },
    { title: 'Bocil', url: `https://api.botcahx.eu.org/api/asupan/bocil?apikey=${btc}` },
    { title: 'Gheayubi', url: `https://api.botcahx.eu.org/api/asupan/gheayubi?apikey=${btc}` },
    { title: 'Natajadeh', url: `https://api.botcahx.eu.org/api/asupan/natajadeh?apikey=${btc}` },
    { title: 'Euni', url: `https://api.botcahx.eu.org/api/asupan/euni?apikey=${btc}` },
    { title: 'Douyin', url: `https://api.botcahx.eu.org/api/asupan/douyin?apikey=${btc}` },
    { title: 'Cecan', url: `https://api.botcahx.eu.org/api/asupan/cecan?apikey=${btc}` },
    { title: 'Hijaber', url: `https://api.botcahx.eu.org/api/asupan/hijaber?apikey=${btc}` },
    { title: 'Anony', url: `https://api.botcahx.eu.org/api/asupan/anony?apikey=${btc}` }
  ]

  // Handler untuk getasupan
  if (command === 'getasupan') {
    try {
      await conn.sendFile(m.chat, text, 'asupan', '', m)
    } catch (e) {
      console.log(e)
      m.reply('Maaf, media asupan (foto/video) tidak ditemukan')
    }
    return
  }

  // Handler untuk asupan (menu)
  let user = global.db.data.users[m.sender]
  if (!user) {
    user = global.db.data.users[m.sender] = { limit: 100 } // Default limit jika user belum terdaftar
  }
  if (user.limit < 10) {
    return m.reply('Maaf, limit kamu tidak cukup! Minimal 10 limit dibutuhkan untuk menggunakan perintah ini.')
  }

  let rows = asupan.map(x => ({
    title: x.title,
    id: `${usedPrefix}getasupan ${x.url}`,
    //description: `Pilih kategori asupan ${x.title}`
  }))

  let sections = [{ rows: rows }]
  let listMessage = {
    title: 'Pilih Kategori Asupan',
    sections
  }

  // Fetch group profile picture
  let profilePicUrl
  try {
    profilePicUrl = await conn.profilePictureUrl(m.chat, 'image')
  } catch (e) {
    console.error('Failed to fetch group profile picture:', e)
    // Fallback image URL in case group profile picture is not available
    profilePicUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.jpg' // Replace with a suitable fallback image URL
  }

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `⚠ Fitur ini akan memakan limit 10 sekali kirim, pertimbangkan agar limit kami tidak boros.!!\n\nSisa limit kamu: ${user.limit}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'Buy limit? ketik .buy'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: namebot,
            hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: profilePicUrl } }, { upload: conn.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage)
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: m })

  // Kurangi limit sebesar 10
  user.limit -= 10
  await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
}

// Dynamically generate handler.help based on asupan titles
handler.help = ['asupan']
handler.tags = ['downloader']
handler.command = /^(asupan|getasupan)$/i
handler.owner = false
handler.premium = false
handler.group = true // Restrict to group chats to ensure profile picture fetching works
handler.private = false
handler.limit = true // Aktifkan limit untuk perintah asupan

handler.register = true
module.exports = handler