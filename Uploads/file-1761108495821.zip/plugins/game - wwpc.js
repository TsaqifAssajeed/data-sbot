const {
    emoji_role,
    sesi,
    playerOnGame,
    playerOnRoom,
    playerExit,
    dataPlayer,
    dataPlayerById,
    getPlayerById,
    getPlayerById2,
    killWerewolf,
    killww,
    dreamySeer,
    sorcerer,
    protectGuardian,
    roleShuffle,
    roleChanger,
    roleAmount,
    roleGenerator,
    addTimer,
    startGame,
    playerHidup,
    playerMati,
    vote,
    voteResult,
    clearAllVote,
    getWinner,
    win,
    pagi,
    malam,
    skill,
    voteStart,
    voteDone,
    voting,
    run,
    run_vote,
    run_malam,
    run_pagi
} = require('../lib/werewolf.js')

let handler = async (m, { conn, command, usedPrefix, args }) => {
    let { sender, chat } = m
    conn.werewolf = conn.werewolf ? conn.werewolf : {}
    let ww = conn.werewolf
    let value = (args[0] || '').toLowerCase()
    let target = args[1]

    if (playerOnGame(sender, ww) === false)
        return m.reply("Lu Gak Ada Dalam Sesi Game")
    if (dataPlayer(sender, ww).status === true)
        return m.reply("Lu Udah Pake Skill Lu Kocak, Skill Hanya Bisa Lu Pake Satu Kali Setiap Satu Putaran")
    if (dataPlayer(sender, ww).isdead === true)
        return m.reply("Lu Udah Jadi Mayat")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return m.reply(`Masukan nomor player \nContoh : \n${usedPrefix + command} kill 1`)
    if (isNaN(target)) 
        return m.reply("Pake Nomer Aja Anjay")
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (byId.db.isdead === true) 
        return m.reply("Dia Udah Jadi Mayat")
    if (byId.db.id === sender)
        return m.reply("Skill Lu Gabisa Di Pake Buat Diri Sendiri")
    if (byId === false) 
        return m.reply("Player Gaada Di Dalam Daftar")
    if (value === "kill") {
        if (dataPlayer(sender, ww).role !== "werewolf")
            return m.reply("Peran Ini Bukan Buat Kamu")

        if (byId.db.role === "sorcerer") 
            return m.reply("Peran Ini Bukan Buat Kamu")

            return m.reply("Berhasil membunuh player " + parseInt(target)).then(() => {
                dataPlayer(sender, ww).status = true
                killWerewolf(sender, parseInt(target), ww)
            })
    } else if (value === "dreamy") {
        if (dataPlayer(sender, ww).role !== "seer") 
            return m.reply("Peran Ini Bukan Buat Kamu")

        let dreamy = dreamySeer(sender, parseInt(target), ww)
        return m.reply(`Berhasil membuka identitas player ${target} adalah ${dreamy}`).then(() => {
                dataPlayer(sender, ww).status = true
        })
    } else if (value === "deff") {
        if (dataPlayer(sender, ww).role !== "guardian") 
            return m.reply("Peran Ini Bukan Buat Kamu")

        return m.reply(`Berhasil melindungi player ${target}`).then(() => {
            protectGuardian(sender, parseInt(target), ww)
            dataPlayer(sender, ww).status = true
        })
    } else if (value === "sorcerer") {
        if (dataPlayer(sender, ww).role !== "sorcerer") 
            return m.reply("Peran Ini Bukan Buat Kamu")

        let sorker = sorcerer(sender, parseInt(target), ww)
        return m.reply(`Berhasil membuka identitas player ${target} adalah ${sorker}`).then(() => {
            dataPlayer(sender, ww).status = true
        })
    }
}
handler.command = /^((ww|werewolf)pc)$/i
handler.private = true
handler.register = true
handler.limit = true
module.exports = handler
