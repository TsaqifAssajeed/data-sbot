// ✨ Plugin maker - fakeffduo ✨

// ✨ Plugin maker - lobbyffduo ✨

// ✨ Plugin: lobbyffduo.js ✨
// 🎮 Membuat Fake Free Fire Max Duo Lobby otomatis (fitur auto nama user dari database.json)

const { createCanvas, loadImage } = require("canvas")
const fs = require("fs")
const path = require("path")

let handler = async (m, { conn, args }) => {
  const basePath = "./database.json/"
  const dbPath = path.join(basePath, "database.json")

  // 🔹 Baca database.json
  let db = {}
  try {
    if (fs.existsSync(dbPath)) {
      db = JSON.parse(fs.readFileSync(dbPath))
    } else {
      console.log("[lobbyffduo] database.json tidak ditemukan, menggunakan data sementara.")
    }
  } catch (err) {
    console.error("[lobbyffduo] Gagal membaca database.json:", err)
  }

  const userId = m.sender

  // 🔹 Auto-register user baru
  if (!db[userId]) db[userId] = { name: m.pushName || "User Baru", limit: 10 }

  // 🔹 Validasi limit
  if ((db[userId].limit || 0) <= 0)
    return m.reply("❌ Limit kamu habis.")

  // 🔹 Ambil input pengguna
  const q = args.join(" ")?.trim()
  if (!q)
    return m.reply(
      `🚩 Format salah!\n\nContoh:\n` +
      `.lobbyffduo Arman|Hikmal|3`
    )

  const [nama1Raw, nama2Raw, nomorRaw] = q.split("|")

  // 🔹 Gunakan nama dari database jika tidak diisi
  const nama1 = nama1Raw?.trim() || db[userId].name
  const nama2 = nama2Raw?.trim()
  const nomor = nomorRaw ? parseInt(nomorRaw.trim(), 10) : null

  // 🔹 Validasi nama
  if (!nama2)
    return m.reply(`🚩 Nama kedua tidak boleh kosong!\nContoh: .lobbyffduo ${nama1}|Zxyn|3`)

  const backgroundList = [
    "https://c.termai.cc/i77/WxeDts.jpg",
    "https://c.termai.cc/i56/mgFeI.jpg",
    "https://c.termai.cc/i98/ISMYzN.jpg",
    "https://c.termai.cc/i66/3pyL6U9.jpg",
    "https://c.termai.cc/i11/8bHWbJ.jpg",
    "https://c.termai.cc/i22/18YqDIt.jpg",
    "https://c.termai.cc/i12/gcj0Y4.jpg",
    "https://c.termai.cc/i58/At6x6.jpg"
  ]

  await m.reply("⏳ Membuat Fake Free Fire Max Duo Lobby...")

  try {
    const max = backgroundList.length
    let index

    // 🔹 Tentukan background
    if (nomor && !isNaN(nomor)) {
      if (nomor < 1 || nomor > max)
        return m.reply(`🚩 Nomor background tidak valid.\nPilih angka 1–${max}.`)
      index = nomor - 1
    } else {
      index = Math.floor(Math.random() * max)
    }

    const backgroundUrl = backgroundList[index]
    const bg = await loadImage(backgroundUrl)
    const canvas = createCanvas(bg.width, bg.height)
    const ctx = canvas.getContext("2d")

    // 🎨 Gambar latar
    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height)

    // 🎨 Tulisan nama duo
    ctx.font = `bold 32px "TeutonNormal"`
    ctx.fillStyle = "#ffb300"
    ctx.textAlign = "center"
    ctx.fillText(nama1, 212, canvas.height - 314)
    ctx.fillText(nama2, 740, canvas.height - 434)

    // 🖼️ Kirim hasil
    const buffer = canvas.toBuffer()
    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption:
          `🎮 Fake Free Fire Duo Lobby berhasil dibuat!\n\n` +
          `👥 *${nama1} & ${nama2}*\n` +
          `🖼️ Background ke *${index + 1}*`
      },
      { quoted: m }
    )

    // 🔹 Kurangi limit user
    try {
      db[userId].limit = Math.max(0, (db[userId].limit || 0) - 1)
      fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
    } catch {
      console.log("[lobbyffduo] Gagal menulis database (read-only). Skip update limit.")
    }

  } catch (err) {
    console.error("[lobbyffduo ERROR]", err)
    m.reply("❌ Gagal membuat Lobby FF Duo: error saat memuat background.")
  }
}

handler.help = ["lobbyffduo <nama1>|<nama2>|<nomor>"]
handler.tags = ["maker"]
handler.command = /^lobbyffduo|fakeffduo$/i
handler.limit = true
handler.register = true

module.exports = handler