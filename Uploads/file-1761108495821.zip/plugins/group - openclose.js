let handler = async (m, { conn, args, usedPrefix, command, participants }) => {
    let options = {
        'open': 'not_announcement',
        'close': 'announcement'
    };
    
    let action = args[0]?.toLowerCase();
    let isClose = options[action];

    if (!isClose) {
        return conn.reply(m.chat, `⚠ *Format Salah!*

📌 Gunakan perintah dengan benar:
  ✅ *${usedPrefix + command} open* (Membuka grup)
  ✅ *${usedPrefix + command} close* (Menutup grup)
`, m);
    }

    // Eksekusi langsung perubahan pengaturan grup
    await conn.groupSettingUpdate(m.chat, isClose);

    let member = participants.map(v => v.id) || [];
    let notificationText = `🚀 Grup telah di *${action === 'open' ? 'buka' : 'tutup'}*!`;

    let sentMessage = await conn.sendMessage(m.chat, { 
        text: notificationText,
        mentions: member 
    }, { quoted: m });

    await conn.sendMessage(m.chat, { 
        react: { text: "📢", key: sentMessage.key } 
    });
};

handler.help = ['gc'].map(a => a + ' *[open/close]*');
handler.tags = ['group'];
handler.command = /^(gc|grup)$/i; // Perbaikan regex di sini
handler.admin = true;
handler.botAdmin = true;

handler.register = true
handler.limit = true
module.exports = handler;