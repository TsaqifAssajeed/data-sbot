const fs = require('fs');
const path = require('path');
const axios = require('axios');
const QRCode = require('qrcode');
const sharp = require('sharp');

const sewaPath = path.join(__dirname, '../database/sewa.json');
let sewa = fs.existsSync(sewaPath) ? JSON.parse(fs.readFileSync(sewaPath)) : {};
function saveSewa() { fs.writeFileSync(sewaPath, JSON.stringify(sewa, null, 2)) }

// ===== Konfigurasi Pakasir di settings.js =====
const PROJECT = pakasirApi;
const API_KEY = pakasirKey; 

const USE_UNIQUE_FEE = true;
function getRandomFee() { return Math.floor(Math.random() * 150) + 1 }

// Harga SEWA
const LIST_SEWA = {
  "7": 5000,    // 1 minggu
  "14": 9000,   // 2 minggu
  "30": 20000,  // 1 bulan
  "60": 30000   // 2 bulan
};

// Harga PREMIUM
const LIST_PREMIUM = {
  "1": 1000,    // 1 hari
  "7": 5000,
  "15": 8000,
  "30": 12000,
  "unli": 30000 // unlimited
};

let pending = {};           // key: chatId -> { type, durasiKey, baseHarga, fee, totalHarga, trxid, qrKey, payer }
let awaitingGroupLink = {}; // key: payerJid -> { durasiMs, startMs, timeout, trxid, payer }

// Auto-clear sewa expired dan keluar grup
setInterval(async () => {
  const now = Date.now();
  for (let id in sewa) {
    if (sewa[id].expired && now >= sewa[id].expired) {
      try { 
        await global.conn.sendMessage(id, { text: '⏰ Waktu sewa bot habis! Bot otomatis nonaktif dan akan keluar dari grup ini.' });
        await global.conn.groupLeave(id); // Bot keluar dari grup
      } catch {}
      delete sewa[id];
      saveSewa();
    }
  }
}, 10000);

// utils
async function safeDelete(conn, key) {
  if (!key) return;
  try { await conn.sendMessage(key.remoteJid, { delete: key }) } catch {}
}

function parseInviteCode(text = '') {
  const m = text.match(/(?:https?:\/\/)?chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
  return m ? m[1] : null;
}

function normalizeSewaKey(k) {
  k = String(k).toLowerCase();
  if (k === '1w' || k === '1minggu') return '7';
  if (k === '2w' || k === '2minggu') return '14';
  if (k === '1m' || k === '1bulan') return '30';
  if (k === '2m' || k === '2bulan') return '60';
  return k;
}

function normalizePremKey(k) {
  k = String(k).toLowerCase();
  if (k === 'unlimited' || k === 'perm' || k === 'permanent') return 'unli';
  return k;
}

function keyToMs(type, key) {
  if (type === 'sewa') {
    const days = Number(key);
    return days * 86400000;
  } else {
    if (key === 'unli') return null;
    const days = Number(key);
    return days * 86400000;
  }
}

function labelSewa(key) {
  return key === '7' ? '1 Minggu' : key === '14' ? '2 Minggu' : key === '30' ? '1 Bulan' : '2 Bulan';
}

function labelPrem(key) {
  return key === '1' ? '1 Hari' : key === '7' ? '7 Hari' : key === '15' ? '15 Hari' : key === '30' ? '30 Hari' : 'Unlimited';
}

let handler = async (m, { conn, args, command }) => {
  if (command.toLowerCase() === 'sewalist') {
    if (Object.keys(sewa).length === 0) {
      return m.reply('❌ Tidak ada grup yang sedang menyewa bot saat ini.');
    }
    
    let text = '📋 *Daftar Grup Sewa Bot*\n\n';
    for (let id in sewa) {
      try {
        const groupMetadata = await conn.groupMetadata(id);
        const groupName = groupMetadata.subject || 'Nama Tidak Tersedia';
        const expired = sewa[id].expired;
        const expiredStr = new Date(expired).toLocaleString();
        text += `🔗 *Grup*: ${groupName}\n`;
        text += `🆔 *ID*: ${id}\n`;
        text += `⏳ *Berakhir*: ${expiredStr}\n`;
        text += `𓆩༺ _________________________ ༻𓆪\n\n`;
      } catch {
        text += `🔗 *Grup*: ${sewa[id].name || id}\n`;
        text += `🆔 *ID*: ${id}\n`;
        text += `⏳ *Berakhir*: ${new Date(sewa[id].expired).toLocaleString()}\n`;
        text += `𓆩༺ _________________________ ༻𓆪\n\n`;
      }
    }
    return m.reply(text);
  }

  if (!args || args.length < 1) {
    return await conn.relayMessage(
      m.chat,
      {
        interactiveMessage: {
          header: { title: "🤖 Sewa / Premium", subtitle: "Pilih paket", hasMediaAttachment: false },
          body: { text:
`📦 Paket Sewa Grup
• 1 Minggu : Rp5.000
• 2 Minggu : Rp9.000
• 1 Bulan  : Rp20.000
• 2 Bulan  : Rp30.000

⭐ Premium User
• 1 Hari   : Rp1.000
• 7 Hari   : Rp5.000
• 15 Hari  : Rp8.000
• 30 Hari  : Rp12.000
• Unlimited: Rp30.000

💡 Saat sewa grup aktif, akun pembayar otomatis dapat Premium sesuai masa sewa.` },
         footer: { text: namebot },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  title: "📆 Paket Sewa Bot (Grup)",
                  sections: [
                    {
                      title: "Sewa Bot",
                      rows: [
                        { title: "1 Minggu", description: `Rp${(5000).toLocaleString()}`, id: "sewa 7" },
                        { title: "2 Minggu", description: `Rp${(9000).toLocaleString()}`, id: "sewa 14" },
                        { title: "1 Bulan", description: `Rp${(20000).toLocaleString()}`, id: "sewa 30" },
                        { title: "2 Bulan", description: `Rp${(30000).toLocaleString()}`, id: "sewa 60" }
                      ]
                    }
                  ],
                  has_multiple_buttons: false
                })
              },
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  title: "⭐ Premium User",
                  sections: [
                    {
                      title: "Premium",
                      rows: [
                        { title: "1 Hari", description: `Rp${(1000).toLocaleString()}`, id: "prem 1" },
                        { title: "7 Hari", description: `Rp${(5000).toLocaleString()}`, id: "prem 7" },
                        { title: "15 Hari", description: `Rp${(8000).toLocaleString()}`, id: "prem 15" },
                        { title: "30 Hari", description: `Rp${(12000).toLocaleString()}`, id: "prem 30" },
                        { title: "Unlimited", description: `Rp${(30000).toLocaleString()}`, id: "prem unli" }
                      ]
                    }
                  ],
                  has_multiple_buttons: false
                })
              },
              { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Menu", id: ".menu" }) },
              { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Owner", id: ".owner" }) }
            ],
            messageParamsJson: JSON.stringify({ bottom_sheet: { in_thread_buttons_limit: 1, divider_indices: [1, 2], list_title: "📋 Daftar Paket", button_title: "Pilih Paket" } })
          }
        }
      },
      {}
    );
  }

  let type = String(args[0]).toLowerCase();
  let rawDur = args[1];
  if (!rawDur) return m.reply("❌ Pilih durasi valid", m);

  if (type === 'sewa') {
    let key = normalizeSewaKey(rawDur);
    if (!(key in LIST_SEWA)) return m.reply("❌ Pilih sewa: 7 | 14 | 30 | 60", m);
    const baseHarga = LIST_SEWA[key];
    const fee = USE_UNIQUE_FEE ? getRandomFee() : 0;
    const totalHarga = baseHarga + fee;
    const trxid = 'INV-' + Date.now();
    pending[m.chat] = { type, durasiKey: key, baseHarga, fee, totalHarga, trxid, payer: m.sender };

    try {
      let response = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
        project: PROJECT,
        order_id: trxid,
        amount: totalHarga,
        api_key: API_KEY
      });
      let data = response.data.payment;

      if (!data.payment_number) throw new Error('Payment number tidak ditemukan');

      //Ukuran QR
      let qrImageBuffer = await QRCode.toBuffer(data.payment_number, {
        type: 'png',
        errorCorrectionLevel: 'H',
        width: 900
      });

      // Unduh template dari GitHub
      const templateUrl = templateQRIS;
      const templateResponse = await axios.get(templateUrl, { responseType: 'arraybuffer' });
      const templateBuffer = Buffer.from(templateResponse.data);

      // Gabungkan QR dengan template menggunakan sharp
      const resizedQrBuffer = await sharp(qrImageBuffer)
        .resize(953, 953)
        .toBuffer();
      const finalImage = await sharp(templateBuffer)
        .composite([
          {
            input: resizedQrBuffer,
            top: 600,
            left: 230,
            fit: 'contain'
          }
        ])
        .toBuffer();

      const teks = `┏─❑ SEWA BOT (GRUP) ❑
│ 🆔 Kode: ${trxid}
│ 📦 Durasi: ${labelSewa(key)}
│ 💵 Harga: Rp${baseHarga.toLocaleString()}
│ 🔢 Fee unik: Rp${fee.toLocaleString()}
│ 💰 Total bayar: Rp${totalHarga.toLocaleString()}
│ ⏳ Expired: ${data.expired_at}
┗────────────`;

      // Kirim gambar yang sudah digabungkan
      const sent = await conn.sendMessage(m.chat, { image: finalImage, caption: teks }, { quoted: m });
      pending[m.chat].qrKey = sent.key;

      // Kirim tombol "Salin Nominal"
      await conn.relayMessage(
        m.chat,
        {
          interactiveMessage: {
            header: { title: "🔗 Salin Nominal Pembayaran", hasMediaAttachment: false },
            body: { text: `Klik tombol di bawah untuk *menyalin* nominal total.\nNominal: Rp${totalHarga.toLocaleString()}` },
            footer: { text: "Gunakan nominal persis agar terdeteksi otomatis." },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: `Salin: ${totalHarga}`,
                    copy_code: String(totalHarga)
                  })
                }
              ],
              messageParamsJson: ""
            }
          }
        },
        {}
      );

      cekPembayaran(conn, m);
    } catch (e) {
      console.error('Error generating QR:', e);
      m.reply(`❌ Gagal generate QR: ${e.message || 'Unknown error'}`, m);
    }
  } else if (type === 'prem' || type === 'premium') {
    let key = normalizePremKey(rawDur);
    if (!(key in LIST_PREMIUM)) return m.reply("❌ Pilih premium: 1 | 7 | 15 | 30 | unli", m);
    const baseHarga = LIST_PREMIUM[key];
    const fee = USE_UNIQUE_FEE ? getRandomFee() : 0;
    const totalHarga = baseHarga + fee;
    const trxid = 'INV-' + Date.now();
    pending[m.chat] = { type: 'prem', durasiKey: key, baseHarga, fee, totalHarga, trxid, payer: m.sender };

    try {
      let response = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
        project: PROJECT,
        order_id: trxid,
        amount: totalHarga,
        api_key: API_KEY
      });
      let data = response.data.payment;

      if (!data.payment_number) throw new Error('Payment number tidak ditemukan');

      //Ukuran QR
      let qrImageBuffer = await QRCode.toBuffer(data.payment_number, {
        type: 'png',
        errorCorrectionLevel: 'H',
        width: 900
      });

      // Unduh template dari GitHub
      const templateUrl = templateQRIS
      const templateResponse = await axios.get(templateUrl, { responseType: 'arraybuffer' });
      const templateBuffer = Buffer.from(templateResponse.data);

      // Gabungkan QR dengan template menggunakan sharp
      const resizedQrBuffer = await sharp(qrImageBuffer)
        .resize(953, 953)
        .toBuffer();
      const finalImage = await sharp(templateBuffer)
        .composite([
          {
            input: resizedQrBuffer,
            top: 600,
            left: 230,
            fit: 'contain'
          }
        ])
        .toBuffer();

      const teks = `┏─❑ PREMIUM USER ❑
│ 🆔 Kode: ${trxid}
│ 📦 Durasi: ${labelPrem(key)}
│ 💵 Harga: Rp${baseHarga.toLocaleString()}
│ 🔢 Fee unik: Rp${fee.toLocaleString()}
│ 💰 Total bayar: Rp${totalHarga.toLocaleString()}
│ ⏳ Expired: ${data.expired_at}
┗────────────`;

      const sent = await conn.sendMessage(m.chat, { image: finalImage, caption: teks }, { quoted: m });
      pending[m.chat].qrKey = sent.key;

      await conn.relayMessage(
        m.chat,
        {
          interactiveMessage: {
            header: { title: "🔗 Salin Nominal Pembayaran", hasMediaAttachment: false },
            body: { text: `Klik tombol di bawah untuk *menyalin* nominal total.\nNominal: Rp${totalHarga.toLocaleString()}` },
            footer: { text: "Gunakan nominal persis agar terdeteksi otomatis." },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: `Salin: ${totalHarga}`,
                    copy_code: String(totalHarga)
                  })
                }
              ],
              messageParamsJson: ""
            }
          }
        },
        {}
      );

      cekPembayaran(conn, m);
    } catch (e) {
      console.error('Error generating QR:', e);
      m.reply(`❌ Gagal generate QR: ${e.message || 'Unknown error'}`, m);
    }
  } else {
    return m.reply("❌ Perintah tidak dikenal. Gunakan: sewa <durasi>, premium <durasi>, atau sewalist", m);
  }
};

async function cekPembayaran(conn, m) {
  let data = pending[m.chat];
  if (!data) return;
  let tries = 0, maxTries = 15, intervalMs = 30000;
  let url = `https://app.pakasir.com/api/transactiondetail?project=${PROJECT}&amount=${data.totalHarga}&order_id=${data.trxid}&api_key=${API_KEY}`;
  let interval = setInterval(async () => {
    tries++;
    try {
      let res = await axios.get(url);
      let transaction = res.data.transaction;
      if (transaction.status === 'completed') {
        clearInterval(interval);
        const snapshot = pending[m.chat];
        delete pending[m.chat];

        // Hapus QR otomatis
        await safeDelete(conn, snapshot?.qrKey);

        const now = Date.now();

        if (data.type === 'sewa') {
          const trxid = data.trxid;
          const durMs = keyToMs('sewa', data.durasiKey);

          if (awaitingGroupLink[data.payer]?.timeout) clearTimeout(awaitingGroupLink[data.payer].timeout);
          const timeout = setTimeout(() => {
            delete awaitingGroupLink[data.payer];
            conn.sendMessage(m.chat, { text: "⌛ Waktu untuk mengirim link grup habis. Kirim perintah sewa lagi jika ingin melanjutkan." });
          }, 10 * 60 * 1000);
          awaitingGroupLink[data.payer] = { durasiMs: durMs, startMs: now, trxid, timeout, payer: data.payer };

          if (!global.db.data.users[data.payer]) global.db.data.users[data.payer] = {};
          global.db.data.users[data.payer].premium = true;
          const prev = global.db.data.users[data.payer].premiumDate || now;
          const start = prev > now ? prev : now;
          global.db.data.users[data.payer].premiumDate = start + durMs;
          saveSewa();

          await conn.sendMessage(m.chat, {
            text: `✅ Pembayaran Berhasil (Kode: ${trxid})
            
Silakan kirim link grup WhatsApp untuk aktivasi sewa di grup tersebut.
🔐 Hanya nomor pembayar yang dapat mengirim link ini.
🎁 Premium untuk akun kamu sudah aktif sesuai masa sewa.

> Note Jika ada antilink, tolong matikan antilink dulu, baru kirim link`
          });
        } else { // premium
          const durMs = keyToMs('prem', data.durasiKey);
          if (!global.db.data.users[data.payer]) global.db.data.users[data.payer] = {};
          global.db.data.users[data.payer].premium = true;
          if (durMs === null) {
            global.db.data.users[data.payer].premiumDate = now + (3650 * 86400000);
          } else {
            const prev = global.db.data.users[data.payer].premiumDate || now;
            const start = prev > now ? prev : now;
            global.db.data.users[data.payer].premiumDate = start + durMs;
          }
          saveSewa();

          const akhirPremiumStr = new Date(global.db.data.users[data.payer].premiumDate).toLocaleString();
          conn.sendMessage(m.chat, {
            text: `┏━━━『 ✅ Premium Aktif 』
┃ 📦 Paket : Premium User (${labelPrem(data.durasiKey)})
┃ 📅 Berakhir : ${akhirPremiumStr}
┃ 🆔 Kode Transaksi : ${data.trxid}
┃ 💰 Total : Rp${data.totalHarga.toLocaleString()}
┗━━━━━━━━━━━━`
          });
        }
      }
    } catch (e) {
      console.error('Error checking payment:', e);
    }
    if (tries >= maxTries) {
      clearInterval(interval);
      const snap = pending[m.chat];
      await safeDelete(conn, snap?.qrKey);
      delete pending[m.chat];
      conn.sendMessage(m.chat, { text: "⏰ Waktu pembayaran habis." });
    }
  }, intervalMs);
}

handler.before = async function (m, { conn }) {
  if (m.message?.listResponseMessage) {
    let id = m.message.listResponseMessage.singleSelectReply?.selectedRowId;
    if (!id) return;
    let parts = id.split(" ");
    if (parts.length < 2) return; // Guard: Skip jika format gak lengkap (bukan "type durasi")
    let fake = { ...m };
    fake.text = parts[1];
    fake.args = [parts[0], fake.text];
    fake.command = parts[0]; // Dinamis: command = type (e.g., "sewa" atau "prem")
    return handler(fake, { conn, args: fake.args, command: fake.command }); // FIX: Pass command!
  }
  
  if (m.message?.interactiveResponseMessage) {
    let id = m.message.interactiveResponseMessage.nativeFlowResponseMessage?.paramsJson;
    if (!id) return;
    
    // FIX: Handle JSON atau string langsung
    let selectedId;
    try {
      let parsed = JSON.parse(id);
      selectedId = parsed.id || parsed.selectedId || id; // Support variasi response WA
    } catch {
      selectedId = id; // Fallback: id as string (e.g., "sewa 7" atau ".cerpenjudul")
    }
    
    if (!selectedId) return;
    let parts = selectedId.split(" ");
    if (parts.length < 2) return; // Guard: Skip jika bukan format "type durasi" (e.g., cerpen skip)
    
    let fake = { ...m };
    fake.text = parts[1];
    fake.args = [parts[0], fake.text];
    fake.command = parts[0]; // Dinamis: command = type
    return handler(fake, { conn, args: fake.args, command: fake.command }); // FIX: Pass command!
  }

  // Bagian awaitingGroupLink tetap sama (untuk handle link grup setelah sewa)
  const wait = awaitingGroupLink[m.sender];
  if (wait) {
    if (m.sender !== wait.payer) {
      return conn.sendMessage(m.chat, { text: "❌ Hanya pembayar yang boleh mengirim link grup untuk sewa ini." });
    }

    const body = (m.text || m.message?.conversation || '').trim();
    const code = parseInviteCode(body);
    if (!code) {
      if (/^https?:\/\//i.test(body)) {
        return conn.sendMessage(m.chat, { text: "❌ Link tidak valid. Kirim link undangan grup WhatsApp format https://chat.whatsapp.com/xxxx." });
      }
      return;
    }

    try {
      const gid = await conn.groupAcceptInvite(code);
      const groupMetadata = await conn.groupMetadata(gid);
      const groupName = groupMetadata.subject || 'Nama Tidak Tersedia';
      const now = Date.now();
      const start = now;
      const expired = start + wait.durasiMs;

      sewa[gid] = { name: groupName, expired };
      saveSewa();

      const mulaiStr = new Date(start).toLocaleString();
      const akhirStr = new Date(expired).toLocaleString();

      await conn.sendMessage(m.chat, {
        text: `✅ Berhasil join ke grup!\n\n🔗 Nama Grup: ${groupName}\n🆔 Group JID: ${gid}\n⏳ Durasi: ${(wait.durasiMs / 86400000)} hari\n📅 Mulai: ${mulaiStr}\n📅 Berakhir: ${akhirStr}\n🆔 Kode Transaksi: ${wait.trxid}`
      });

      try {
        await conn.sendMessage(gid, {
          text: `✅ Sewa bot aktif hingga *${akhirStr}*.\nTerima kasih telah menggunakan layanan kami!`
        });
      } catch {}

      clearTimeout(wait.timeout);
      delete awaitingGroupLink[m.sender];
    } catch (err) {
      console.error('Join group error:', err);
      return conn.sendMessage(m.chat, { text: "❌ Gagal join ke grup. Pastikan link masih aktif dan bot belum diblokir oleh admin. Kirim link lain jika perlu." });
    }
  }
};

handler.help = ['sewa', 'sewalist'];
handler.tags = ['info'];
handler.command = /^(sewa|sewalist)$/i;
handler.register = true;

module.exports = handler;