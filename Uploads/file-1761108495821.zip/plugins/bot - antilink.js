let handler = m => m
let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i

handler.before = async function (m, { user, isBotAdmin, isAdmin, conn }) {
    if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true
    let chat = global.db.data.chats[m.chat]
    let userData = global.db.data.users[m.sender]
    let isGroupLink = linkRegex.exec(m.text)
    
    // Maksimum peringatan ubah, jika nol berarti langsung di kick tanpa peringatan dulu
    const maxWarn = 0
    
    if (chat.antiLink && isGroupLink) {
        // Cek link grup sendiri
        let linkGC = ('https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat))
        let isLinkconnGc = new RegExp(linkGC, 'i')
        let isgclink = isLinkconnGc.test(m.text)
        
        if (isgclink) return true // Jika link grup sendiri, abaikan
        
        // Jika admin yang kirim link
        if (isAdmin) {
            return m.reply('👑 Admin terdeteksi mengirim link\nSaya sebagai babu tidak berani menendang beliau, silahkan lanjutkan 🙇🏼‍♂️')
        }
        
        // Jika bot bukan admin
        if (!isBotAdmin) {
            return m.reply(`⁉️ Saya bukan admin, jadi tidak bisa menghapus dan menendang keluar angkasa alien itu.`)
        }
        
        // Inisialisasi warning jika belum ada
        if (!userData.linkWarn) userData.linkWarn = 0
        
        // Tambah peringatan
        userData.linkWarn += 1
        
        // Hapus pesan yang mengandung link
        await conn.sendMessage(m.chat, { delete: m.key })
        
        if (userData.linkWarn < maxWarn) {
            // Kirim peringatan
            await m.reply(`
⚠️ *PERINGATAN LINK* ⚠️
Kamu terdeteksi mengirim link!
✧ Peringatan: ${userData.linkWarn}/${maxWarn}
✧ Kirim link lagi? Peringatan bertambah!
Jika mencapai ${maxWarn}x, kamu akan di-kick!`)
        } else {
            // Jika peringatan maksimum tercapai
            await m.reply(`
⛔ *BANNED* ⛔
@${m.sender.split('@')[0]} telah mencapai batas kesabaran gua (${maxWarn}/${maxWarn}) 
karena mengirim link berulang-ulang. Selamat tinggal sampahh!`, null, { mentions: [m.sender] })
            
            // Reset warning dan kick user
            userData.linkWarn = 0
            await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
    }
    return true
}

handler.register = true

module.exports = handler