let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.pedo)}”`, m)
}
handler.help = ['cekpedo']
handler.tags = ['cek']
handler.command = /^(cekpedo)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.pedo = [
'Pedo 1%\n\nGaK Pedo Kok Aman',
'Pedo 5%\n\nMasih Gak Pedo',
'Pedo 10%\n\nMasih Aman',
'Pedo 15%\n\nAman Kok',
'Pedo 20%\n\nHampir Aman',
'Pedo 25%\n\nWahh Udah Rada Rada Nih',
'Pedo 30%\n\n😨😨😨',
'Pedo 35%\n\nAdek Kalian Cewek? Amanin Cepet',
'Pedo 40%\n\nSalah Satu Sekte *Umur Hanya Angka*',
'Pedo 45%\n\nUdah Mau Setengah Pedo Njir',
'Pedo 50%\n\nWaduh Rek',
'Pedo 55%\n\nMulai Gak Aman Nih',
'Pedo 60%\n\nSuka Jilatin Kaki Anak Kecil Dia Nih',
'Pedo 65%\n\nWaduhhh',
'Pedo 70%\n\nKok Lu Bisa Suka Sama Anak Kecil Sih',
'Pedo 75%\n\nMenjauh Kau Pedo',
'Pedo 80%\n\nAduhh Bang Jangan Ewe Adek Gw Yak',
'Pedo 85%\n\nBang Anak Tetangga Itu Bang Jangan Di Ewe',
'Pedo 90%\n\nGolongan Orang Yang Kalo Ada Anak Kecil Langsung Ngaceng',
'Pedo 95%\n\nMending Gay Aja Bang, Ngapain Jadi Pedo Njir😹',
'Pedo 100%\n\n☠️☠️☠️☠️☠️',
'Pedo Pro\n\nHarus Di Basmi Dia Nih Woi',
'Inilah Pedo Tersebut\n\nPANGGIL FBI CEPET WOI, KETIK 1 UNTUK MEMBUNUH PEDO',
]