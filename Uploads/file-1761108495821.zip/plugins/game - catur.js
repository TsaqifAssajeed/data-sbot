// 📝 plugin game - catur

const { Chess } = require('chess.js');
const Jimp = require('jimp');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

const data = [{
    map: "https://chessboardimage.com/{fen}.png",
    name: "Premium",
    stabil_x: 0,
    stabil_y: 0
}];

let handler = async (m, { conn, text, usedPrefix }) => { // Add usedPrefix to handler parameters
    conn.catur = conn.catur || {};
    const ct = conn.catur;

    const catur_cmd = {
        create: async () => {
            if (ct[m.chat]) return m.reply("‼️ *GAME SEDANG BERLANGSUNG*\n> masih ada game yang belum selesai di chat ini.");

            ct[m.chat] = {
                chess: new Chess(),
                date: Date.now(),
                status: '⌛ MENUNGGU',
                host: m.sender,
                players: {},
                map: data[0].map,
                moves: [],
                captures: { white: [], black: [] }
            };

            ct[m.chat].players[m.sender] = { color: 'white', captures: 0 };

            return conn.sendMessage(m.chat, {
                text: `🏠 *ROOM CATUR TELAH DIBUAT*\n\n🤴🏻 *host :* @${m.sender.split('@')[0]}\n> ketik *.catur join* atau gunakan tombol untuk bergabung ke room`,
                mentions: [m.sender]
            });
        },

        join: async () => {
            if (!ct[m.chat]) return m.reply("‼️ *ROOM TIDAK DITEMUKAN*\n> belum ada room catur yang dibuat.");
            if (m.sender === ct[m.chat].host) return m.reply("‼️ *KAMU ADALAH HOST*\n> host sudah otomatis bergabung dalam room.");
            if (Object.keys(ct[m.chat].players).length >= 2) return m.reply("‼️ *ROOM SUDAH PENUH*\n> mohon maaf room catur sudah penuh.");

            ct[m.chat].players[m.sender] = { color: 'black', captures: 0 };
            ct[m.chat].status = '🎯 BERMAIN';

            await conn.sendMessage(m.chat, {
                text: `🏠 *GAME DIMULAI*\n\n⚪ putih : @${ct[m.chat].host.split('@')[0]}\n⚫ hitam : @${m.sender.split('@')[0]}\n\nkepada @${ct[m.chat].host.split('@')[0]} dipersilahkan melakukan langkah terlebih dahulu.`,
                mentions: [ct[m.chat].host, m.sender]
            });

            return sendBoard(m, ct, conn);
        },

        delete: async () => {
            if (!ct[m.chat]) return m.reply("‼️ *ROOM TIDAK DITEMUKAN*\n> tidak ada room aktif di chat ini.");
            delete ct[m.chat];
            return m.reply(`✅ *ROOM TELAH DIHAPUS*\n> (ID: ${m.chat})`);
        },

        info: async () => {
            if (!ct[m.chat]) return m.reply("‼️ *TIDAK ADA ROOM*\n> tidak ada room aktif di chat ini.");

            const game = ct[m.chat].chess;
            const putih = Object.keys(ct[m.chat].players).find(j => ct[m.chat].players[j].color === 'white');
            const hitam = Object.keys(ct[m.chat].players).find(j => ct[m.chat].players[j].color === 'black');

            return conn.sendMessage(m.chat, {
                text: `📊 *STATUS GAME CATUR*\n\n🤴🏻 *host :* @${ct[m.chat].host.split('@')[0]}\n\n⚪ putih : @${putih?.split('@')[0] || '-'}\n⚫ hitam : @${hitam?.split('@')[0] || 'Menunggu...'}\n⏳ *Giliran :* ${game.turn() === 'w' ? 'putih' : 'hitam'}\n♟️ langkah : ${Math.floor(game.history().length / 2)}`,
                mentions: [ct[m.chat].host, putih, hitam].filter(Boolean)
            });
        },

        tutor: async () => {
            return conn.sendMessage(m.chat, {
                text: `📚 *PENJELASAN GAME CATUR*\n\n` +
                      `🧩 *PERINTAH DASAR :*\n\n` +
                      `– *.catur create*\n> membuat room permainan\n` +
                      `– *.catur join*\n> bergabung sebagai lawan main\n` +
                      `– *.catur info*\n> melihat status permainan\n` +
                      `– *.catur delete*\n> menghapus room permainan\n\n` +
                      `🧩 *ATURAN CARA MAIN :*\n\n– room max 2 pemain\n– putih menjalankan langkah terlebih dahulu\n– reply papan catur untuk melakukan langkah\n> contoh langkah : e2 e4\n\n` +
                      `SELAMAT BERMAIN, AND GOOD LUCK!!`
            });
        }
    };

    if (!text) {
        // Interactive button message when no subcommand is provided
        let listMessage = {
            title: '♟️ PILIH OPSI CATUR',
            sections: [{
                title: '‼️ SILAHKAN PILIH OPSI DIBAWAH INI',
                rows: [
                    {
                        title: '🏠 BUAT ROOM',
                        id: `${usedPrefix}catur create`,
                        description: '╰┈➤ Membuat room catur baru'
                    },
                    {
                        title: '🤝 GABUNG ROOM',
                        id: `${usedPrefix}catur join`,
                        description: '╰┈➤ Bergabung sebagai lawan main'
                    },
                    {
                        title: '📊 INFO GAME',
                        id: `${usedPrefix}catur info`,
                        description: '╰┈➤ Melihat status permainan'
                    },
                    {
                        title: '🗑️ HAPUS ROOM',
                        id: `${usedPrefix}catur delete`,
                        description: '╰┈➤ Menghapus room catur'
                    },
                    {
                        title: '📚 TUTORIAL',
                        id: `${usedPrefix}catur tutor`,
                        description: '╰┈➤ Petunjuk cara bermain'
                    }
                ]
            }]
        };

        try {
            let msg = generateWAMessageFromContent(m.chat, {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `\n> SILAHKAN PILIH OPSI DIBAWAH INI UNTUK BERMAIN CATUR\n`
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: '*♟️ SELAMAN BERMAIN*'
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: '        — [ GAME CATUR ] —'
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify(listMessage)
                            }
                        ]
                    })
                })
            }, { userJid: m.chat, quoted: m });

            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        } catch (err) {
            console.error('[ERROR] Gagal mengirim interactive message:', err);
            // Fallback to text message if interactive message fails
            await conn.sendMessage(m.chat, {
                text: `♟️ *Perintah Catur*\n• *.catur create*\n• *.catur join*\n• *.catur info*\n• *.catur delete*\n• *.catur tutor*`
            }, { quoted: m });
        }
        return;
    }

    if (!(text in catur_cmd)) {
        return m.reply(`‼️ *Perintah tidak valid*\n> Gunakan *.catur* untuk melihat opsi atau ketik salah satu: create, join, info, delete, tutor`);
    }

    await catur_cmd[text]();
};

handler.command = ['catur'];
handler.tags = ['game'];
handler.help = ['catur'];

handler.register = true
handler.limit = true
module.exports = handler;

// 📤 Fungsi Kirim Gambar Papan
async function sendBoard(m, ct, conn) {
    try {
        const fen = ct[m.chat].chess.fen().split(' ')[0];
        const boardUrl = `https://chessboardimage.com/${fen}.png?size=600&coordinates=true`;

        const img = await Jimp.read(boardUrl);
        const buffer = await img.getBufferAsync(Jimp.MIME_PNG);

        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: `♟️ *POSISI SAAT INI*\n\n> 🔁balas gambar ini dengan langkahmu, contoh: e2 e4`,
            mentions: [conn.user.jid]
        });
    } catch (e) {
        console.error("Gagal kirim papan:", e);
        m.reply("❌ Gagal menampilkan papan!");
    }
}