// ✨ Plugin maker - fakecall ✨

const { createCanvas, loadImage } = require("canvas")
 
let handler = async (m, { args, usedPrefix, command }) => {
  if (!m.quoted || !m.quoted.mimetype?.startsWith('image/')) {
    return m.reply(`❌ Reply ke *foto* yang mau dipakai! lalu ketik\n${usedPrefix}fakecall nama penelpon|jam/durasi\n\nContoh:\n${usedPrefix}fakecall ${namebot}|24:25`)
  }
 
  let [nama, durasi] = (args.join(' ') || '').split('|')
  if (!nama || !durasi) return m.reply(`❌ Format salah!\nContoh:\n${usedPrefix}fakecall nama penelpon|jam/durasi\n\nContoh:\n${usedPrefix}fakecall ${namebot}|24:25`)
 
  try {
    const qimg = await m.quoted.download()
    const avatar = await loadImage(qimg)
    const bg = await loadImage('https://files.catbox.moe/pmhptv.jpg')
 
    const canvas = createCanvas(720, 1280)
    const ctx = canvas.getContext('2d')
 
    ctx.drawImage(bg, 0, 0, 720, 1280)
 
    ctx.font = 'bold 40px sans-serif'
    ctx.fillStyle = 'white'
    ctx.textAlign = 'center'
    ctx.fillText(nama.trim(), 360, 150) 
 
    ctx.font = '30px sans-serif'
    ctx.fillStyle = '#d1d1d1'
    ctx.fillText(durasi.trim(), 360, 200)
 
    ctx.save()
    ctx.beginPath()
    ctx.arc(360, 635, 160, 0, Math.PI * 2)
    ctx.closePath()
    ctx.clip()
    ctx.drawImage(avatar, 200, 475, 320, 320)
    ctx.restore()
 
    const buffer = canvas.toBuffer()
    await conn.sendFile(m.chat, buffer, 'fakecall.jpg', 'awokawok halu😹', m)
  } catch (e) {
    m.reply(`❌ Error\nLogs error : ${e.message}`)
  }
}
 
handler.command = ['fakecall']
handler.help = ['fakecall nama|durasi']
handler.tags = ['maker']
handler.register = true
handler.limit = true
module.exports = handler