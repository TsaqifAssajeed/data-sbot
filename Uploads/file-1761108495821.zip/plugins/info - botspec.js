/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/


let os = require('os')

let handler = async (m, { conn, text }) => {
  let totalStorage = Math.floor(os.totalmem() / 1024 / 1024) + 'MB'
  let freeStorage = Math.floor(os.freemem() / 1024 / 1024) + 'MB'
  let cpuModel = os.cpus()[0].model
  let cpuSpeed = os.cpus()[0].speed / 1000
  let cpuCount = os.cpus().length
  let message = `  
  ✨ *Spesifikasi BOT* ✨  
  
  📦 *Total Storage*   : ${totalStorage}  
  📂 *Free Storage*    : ${freeStorage}  
  ⚙️ *CPU Model*       : ${cpuModel}  
  🚀 *CPU Speed*       : ${cpuSpeed} GHz  
  🖥️ *CPU Cores*       : ${cpuCount}  
  `
  

  m.reply(message)
}

handler.help = ['botspec']
handler.tags = ['info']
handler.command = /^botspec$/i


module.exports = handler