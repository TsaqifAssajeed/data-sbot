// ✨ Plugin game - TestIQ with Buttons

let soalTestIQ = {
  easy: [
    { soal: "Bumi berbentuk?", opsi: ["Datar", "Kotak", "Bulat"], jawaban: "c" },
    { soal: "Berapa jumlah roda mobil pada umumnya?", opsi: ["1", "2", "4"], jawaban: "c" },
    { soal: "Jika 2 + 3 = 5, maka 5 + 4 = ?", opsi: ["7", "8", "9"], jawaban: "c" },
    { soal: "Hewan yang dikenal sebagai 'raja hutan'?", opsi: ["Singa", "Harimau", "Gajah"], jawaban: "a" },
    { soal: "1 jam = berapa menit?", opsi: ["30", "60", "90"], jawaban: "b" },
    { soal: "Warna apa yang paling genit di pelangi?", opsi: ["Merah", "Kuning", "Hijau"], jawaban: "a" }
  ],
  medium: [
    { soal: "Jika 1 kg apel harganya Rp20.000, berapa harga 2,5 kg apel?", opsi: ["Rp40.000", "Rp50.000", "Rp60.000"], jawaban: "b" },
    { soal: "Gaya yang menyebabkan benda jatuh ke bumi disebut?", opsi: ["Gesekan", "Gravitasi", "Inersia"], jawaban: "b" },
    { soal: "Unsur kimia dengan simbol 'O' adalah?", opsi: ["Osmium", "Oksigen", "Oganesson"], jawaban: "b" },
    { soal: "Siapa presiden pertama Indonesia?", opsi: ["Sukarno", "Suharto", "Habibie"], jawaban: "a" },
    { soal: "Jika A = 1, B = 2, C = 3, maka berapa nilai dari kata 'CAB'?", opsi: ["4", "6", "7"], jawaban: "b" }
  ],
  hard: [
    { soal: "Jika kecepatan mobil 60 km/jam, berapa jarak yang ditempuh dalam 2,5 jam?", opsi: ["120 km", "140 km", "150 km"], jawaban: "c" },
    { soal: "Reaksi kimia yang menghasilkan panas disebut?", opsi: ["Endoterm", "Eksoterm", "Netralisasi"], jawaban: "b" },
    { soal: "Tahun berapa Perang Dunia II berakhir?", opsi: ["1943", "1944", "1945"], jawaban: "c" },
    { soal: "Jika 3x + 5 = 20, maka x = ?", opsi: ["3", "4", "5"], jawaban: "c" },
    { soal: "Dalam psikologi, efek yang membuat orang cenderung memilih opsi pertama yang ditawarkan disebut?", opsi: ["Efek Halo", "Efek Primacy", "Efek Recency"], jawaban: "b" }
  ],
  legend: [
    { soal: "Jika sebuah benda dilempar vertikal ke atas dengan kecepatan awal 20 m/s, berapa waktu yang dibutuhkan untuk kembali ke titik awal? (g = 10 m/s²)", opsi: ["2 s", "3 s", "4 s"], jawaban: "c" },
    { soal: "Unsur dengan nomor atom 26 adalah?", opsi: ["Kromium", "Besi", "Kobalt"], jawaban: "b" },
    { soal: "Peristiwa sejarah yang terjadi pada 17 Agustus 1945 di Indonesia adalah?", opsi: ["Konferensi Meja Bundar", "Proklamasi Kemerdekaan", "Agresi Militer Belanda"], jawaban: "b" },
    { soal: "Dalam deret: 2, 6, 12, 20, 30, berapa suku berikutnya?", opsi: ["42", "45", "48"], jawaban: "a" },
    { soal: "Dalam tes IQ, pola gambar segitiga dengan jumlah titik bertambah 3 setiap langkah. Jika langkah pertama memiliki 3 titik, langkah kelima memiliki berapa titik?", opsi: ["12", "15", "18"], jawaban: "b" }
  ]
}

let sesiTestIQ = {}
const timeout = 60000 // 60 detik
const namebot = "Grok"

let handler = async (m, { conn, command, args, usedPrefix }) => {
  let id = m.chat
  switch (command.toLowerCase()) {
    case 'testiq':
      if (sesiTestIQ[id]) return conn.reply(m.chat, '🤬 Masih ada soal yang belum dijawab!\n\n> Klik tombol jawaban atau ketik *.gtw* untuk menyerah!', m)

      let level = (args[0] || '').toLowerCase()
      if (!['easy', 'medium', 'hard', 'legend'].includes(level)) {
        return conn.reply(m.chat, '❌ Pilih level: *easy*, *medium*, *hard*, atau *legend*.\nContoh: *.testiq hard*', m)
      }

      let data = soalTestIQ[level][Math.floor(Math.random() * soalTestIQ[level].length)]
      let soalText = `🧠 *TEST IQ - ${level.toUpperCase()}* 🧠\n\n📜 Soal: ${data.soal}\n\n`
      data.opsi.forEach((opt, i) => {
        soalText += `${String.fromCharCode(97 + i)}. ${opt}\n`
      })
      soalText += `\n⏰ Waktu: 60 detik\n‼️ Pilih tombol di bawah untuk menjawab!\n\n> *.gtw* jika ingin menyerah.`

      let buttons = [
        { buttonId: `${usedPrefix}jawab ${id} a`, buttonText: { displayText: 'a' }, type: 1 },
        { buttonId: `${usedPrefix}jawab ${id} b`, buttonText: { displayText: 'b' }, type: 1 },
        { buttonId: `${usedPrefix}jawab ${id} c`, buttonText: { displayText: 'c' }, type: 1 }
      ]

      let kirim = await conn.sendMessage(m.chat, {
        text: soalText,
        footer: namebot,
        buttons: buttons,
        headerType: 1,
        viewOnce: true
      }, { quoted: m })

      sesiTestIQ[id] = {
        soalData: data,
        jawaban: data.jawaban.toLowerCase(),
        idPesan: kirim.key.id,
        level: level,
        timeout: setTimeout(() => {
          if (sesiTestIQ[id]) {
            let opsiIndex = sesiTestIQ[id].jawaban.charCodeAt(0) - 97
            let opsiTeks = sesiTestIQ[id].soalData.opsi[opsiIndex]
            conn.sendMessage(m.chat, { text: `⏰ Waktu habis!\n\nJawabannya adalah: *${sesiTestIQ[id].jawaban}* (${opsiTeks})` })
            delete sesiTestIQ[id]
          }
        }, timeout)
      }
      break

    case 'gtw':
      if (!sesiTestIQ[id]) return conn.reply(m.chat, '❌ Tidak ada sesi TestIQ yang aktif.', m)
      clearTimeout(sesiTestIQ[id].timeout)
      let jawabanGtw = sesiTestIQ[id].jawaban
      let opsiIndexGtw = jawabanGtw.charCodeAt(0) - 97
      let opsiTeksGtw = sesiTestIQ[id].soalData.opsi[opsiIndexGtw]
      await conn.sendMessage(m.chat, { text: `🏳️ *MENYERAH!*\n\nJawabannya adalah: *${jawabanGtw}* (${opsiTeksGtw})` })
      delete sesiTestIQ[id]
      break

    case 'jawab':
      if (!sesiTestIQ[id]) return conn.reply(m.chat, '❌ Tidak ada sesi TestIQ yang aktif.', m)
      let userAnswer = args[1]?.toLowerCase()
      if (!['a', 'b', 'c'].includes(userAnswer)) {
        return conn.reply(m.chat, '❌ Pilih jawaban hanya dengan tombol *a, b, c*!', m)
      }

      clearTimeout(sesiTestIQ[id].timeout)
      const session = sesiTestIQ[id]
      const jawaban = session.jawaban
      const soalData = session.soalData

      if (userAnswer === jawaban) {
        let iqScore = {
          easy: Math.floor(Math.random() * 21) + 80,
          medium: Math.floor(Math.random() * 21) + 100,
          hard: Math.floor(Math.random() * 21) + 120,
          legend: Math.floor(Math.random() * 21) + 140
        }[session.level]
        let hadiah = {
          easy: Math.floor(Math.random() * 501) + 500,
          medium: Math.floor(Math.random() * 1001) + 1000,
          hard: Math.floor(Math.random() * 1501) + 2000,
          legend: Math.floor(Math.random() * 2001) + 3500
        }[session.level]
        let user = global.db.data.users[m.sender]
        if (user) user.money = (user.money || 0) + hadiah

        let opsiIndex = jawaban.charCodeAt(0) - 97
        let opsiTeks = soalData.opsi[opsiIndex]
        let response = `✅ *Selamat, jawaban kamu benar!*\n\n📝 Jawaban: *${jawaban}* (${opsiTeks})\n🧠 Skor IQ: *${iqScore}*\n🎁 Hadiah: *${hadiah} money*`

        await conn.sendMessage(m.chat, {
          text: response,
          footer: namebot,
          headerType: 1,
          viewOnce: true
        }, { quoted: m })

        delete sesiTestIQ[id]
      } else {
        let opsiIndex = jawaban.charCodeAt(0) - 97
        let opsiTeks = soalData.opsi[opsiIndex]
        await conn.reply(m.chat, `❌ *Jawaban salah!! Soal diganti*\n\nJawabannya adalah: *${jawaban}* (${opsiTeks})`, m)

        let newData = soalTestIQ[session.level][Math.floor(Math.random() * soalTestIQ[session.level].length)]
        while (newData.jawaban === jawaban) {
          newData = soalTestIQ[session.level][Math.floor(Math.random() * soalTestIQ[session.level].length)]
        }
        let soalText = `🧠 *TEST IQ - ${session.level.toUpperCase()}* 🧠\n\n📜 Soal: ${newData.soal}\n\n`
        newData.opsi.forEach((opt, i) => {
          soalText += `${String.fromCharCode(97 + i)}. ${opt}\n`
        })
        soalText += `\n⏰ Waktu: 60 detik\n‼️ Pilih tombol di bawah untuk menjawab!\n\n> *.gtw* jika ingin menyerah.`

        let buttonsNew = [
          { buttonId: `${usedPrefix}jawab ${id} a`, buttonText: { displayText: 'a' }, type: 1 },
          { buttonId: `${usedPrefix}jawab ${id} b`, buttonText: { displayText: 'b' }, type: 1 },
          { buttonId: `${usedPrefix}jawab ${id} c`, buttonText: { displayText: 'c' }, type: 1 }
        ]

        let kirim = await conn.sendMessage(m.chat, {
          text: soalText,
          footer: namebot,
          buttons: buttonsNew,
          headerType: 1,
          viewOnce: true
        }, { quoted: m })

        sesiTestIQ[id] = {
          soalData: newData,
          jawaban: newData.jawaban.toLowerCase(),
          idPesan: kirim.key.id,
          level: session.level,
          timeout: setTimeout(() => {
            if (sesiTestIQ[id]) {
              let opsiIndex = sesiTestIQ[id].jawaban.charCodeAt(0) - 97
              let opsiTeks = sesiTestIQ[id].soalData.opsi[opsiIndex]
              conn.sendMessage(m.chat, { text: `⏰ Waktu habis!\n\nJawabannya adalah: *${sesiTestIQ[id].jawaban}* (${opsiTeks})` })
              delete sesiTestIQ[id]
            }
          }, timeout)
        }
      }
      break
  }
}

handler.before = async function (m, { conn, usedPrefix }) {
  let id = m.chat
  if (!sesiTestIQ[id]) return
  if (!m.quoted || m.quoted.id !== sesiTestIQ[id].idPesan) return

  const session = sesiTestIQ[id]
  const jawaban = session.jawaban
  const soalData = session.soalData
  let userAnswer = m.text.toLowerCase().trim()

  if (!['a', 'b', 'c'].includes(userAnswer)) {
    return conn.reply(m.chat, '❌ Reply hanya dengan *a, b, atau c* atau gunakan tombol!', m)
  }

  clearTimeout(session.timeout)
  delete sesiTestIQ[id]

  if (userAnswer === jawaban) {
    let iqScore = {
      easy: Math.floor(Math.random() * 21) + 80,
      medium: Math.floor(Math.random() * 21) + 100,
      hard: Math.floor(Math.random() * 21) + 120,
      legend: Math.floor(Math.random() * 21) + 140
    }[session.level]
    let hadiah = {
      easy: Math.floor(Math.random() * 501) + 500,
      medium: Math.floor(Math.random() * 1001) + 1000,
      hard: Math.floor(Math.random() * 1501) + 2000,
      legend: Math.floor(Math.random() * 2001) + 3500
    }[session.level]
    let user = global.db.data.users[m.sender]
    if (user) user.money = (user.money || 0) + hadiah

    let opsiIndex = jawaban.charCodeAt(0) - 97
    let opsiTeks = soalData.opsi[opsiIndex]
    let response = `✅ *Selamat, jawaban kamu benar!*\n\n📝 Jawaban: *${jawaban}* (${opsiTeks})\n🧠 Skor IQ: *${iqScore}*\n🎁 Hadiah: *${hadiah} money*`

    await conn.sendMessage(m.chat, {
      text: response,
      footer: namebot,
      headerType: 1,
      viewOnce: true
    }, { quoted: m })
  } else {
    let opsiIndex = jawaban.charCodeAt(0) - 97
    let opsiTeks = soalData.opsi[opsiIndex]
    await conn.reply(m.chat, `❌ *Jawaban salah!! Soal diganti*\n\nJawabannya adalah: *${jawaban}* (${opsiTeks})`, m)

    let newData = soalTestIQ[session.level][Math.floor(Math.random() * soalTestIQ[session.level].length)]
    while (newData.jawaban === jawaban) {
      newData = soalTestIQ[session.level][Math.floor(Math.random() * soalTestIQ[session.level].length)]
    }
    let soalText = `🧠 *TEST IQ - ${session.level.toUpperCase()}* 🧠\n\n📜 Soal: ${newData.soal}\n\n`
    newData.opsi.forEach((opt, i) => {
      soalText += `${String.fromCharCode(97 + i)}. ${opt}\n`
    })
    soalText += `\n⏰ Waktu: 60 detik\n‼️ Pilih tombol di bawah untuk menjawab!\n\n> *.gtw* jika ingin menyerah.`

    let buttonsNew = [
      { buttonId: `${usedPrefix}jawab ${id} a`, buttonText: { displayText: 'a' }, type: 1 },
      { buttonId: `${usedPrefix}jawab ${id} b`, buttonText: { displayText: 'b' }, type: 1 },
      { buttonId: `${usedPrefix}jawab ${id} c`, buttonText: { displayText: 'c' }, type: 1 }
    ]

    let kirim = await conn.sendMessage(m.chat, {
      text: soalText,
      footer: namebot,
      buttons: buttonsNew,
      headerType: 1,
      viewOnce: true
    }, { quoted: m })

    sesiTestIQ[id] = {
      soalData: newData,
      jawaban: newData.jawaban.toLowerCase(),
      idPesan: kirim.key.id,
      level: session.level,
      timeout: setTimeout(() => {
        if (sesiTestIQ[id]) {
          let opsiIndex = sesiTestIQ[id].jawaban.charCodeAt(0) - 97
          let opsiTeks = sesiTestIQ[id].soalData.opsi[opsiIndex]
          conn.sendMessage(m.chat, { text: `⏰ Waktu habis!\n\nJawabannya adalah: *${sesiTestIQ[id].jawaban}* (${opsiTeks})` })
          delete sesiTestIQ[id]
        }
      }, timeout)
    }
  }
}

handler.command = /^testiq|gtw|jawab$/i
handler.tags = ['game']
handler.help = ['testiq <easy|medium|hard|legend>', 'gtw']
handler.limit = false
handler.register = true

module.exports = handler