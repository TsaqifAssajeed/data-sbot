// https://console.cloud.google.com/apis/api/sheets.googleapis.com

const { google } = require("googleapis");
const path = require("path");

const auth = new google.auth.GoogleAuth({
  keyFile: path.join(__dirname, "../function/sheet.json"),
  scopes: ["https://www.googleapis.com/auth/spreadsheets"]
});

const SHEET_ID = "1p_lHTAqkZnE_syDzPnn_Y0bKqbEAdpJloIPdGqcMZZE";

async function getFilteredData(command) {
  try {
    const client = await auth.getClient();
    const sheets = google.sheets({ version: "v4", auth: client });

    // Tentukan sheet berdasarkan command
    const sheetName = command === "jagoanexpired" ? "USER EXPIRED" : "DATA PANEL";
    const range = `${sheetName}!A1:K`;

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_ID,
      range: range,
    });

    const data = response.data.values || [];

    const list = data
      .filter(row => row[0] && row[0].trim() !== "")
      .map(row => {
        const nama = row[0]?.trim() || "-";
        const expired = row[6] || "-";
        const v1 = row[7]?.trim();
        const v2 = row[8]?.trim();
        const v3 = row[10]?.trim(); // Tambahan untuk Server-V3 (kolom K)
        const sisa = parseInt(row[9]) || 0;

        let server = "-";
        if (v3) server = `V3 (server ${v3})`; // Prioritaskan V3 jika ada
        else if (v1) server = `V1 (server ${v1})`;
        else if (v2) server = `V2 (server ${v2})`;

        return { nama, expired, server, sisa };
      })
      .filter(item => {
        if (command === "jagoanexp" || command === "jagoanexpired") return item.sisa === 0;
        return item.sisa > 0; // Untuk jagoanlist, tampilkan semua data dengan sisa hari > 0
      })
      .sort((a, b) => a.nama.localeCompare(b.nama));

    return list;
  } catch (error) {
    console.error("Error in getFilteredData:", error);
    throw new Error("Gagal mengambil data dari Google Sheets. Silakan periksa koneksi atau kredensial.");
  }
}

let handler = async (m, { command }) => {
  try {
    const list = await getFilteredData(command);

    if (!list.length) {
      if (command === "jagoanexpired" || command === "jagoanexp") {
        return m.reply("✅ Tidak ada panel yang expired hari ini.");
      }
      return m.reply("✅ Tidak ada panel aktif dengan sisa hari > 0.");
    }

    const header = (command === "jagoanexpired" || command === "jagoanexp")
      ? `☠️ *PANEL EXPIRED JAGPRO* ⚠️\nBerikut adalah panel yang sudah *expired*:\n\n`
      : `📅 *MASA EXPIRED PANEL JAGPRO* ⚠️\nBerikut adalah data masa aktif panel Anda:\n\n`;

    const body = list.map((item, i) => {
      return `${i + 1}. Nama: ${item.nama}
Expired: ${item.expired}
Server: ${item.server}
Sisa Hari: ${item.sisa}`;
    }).join("\n\n");

    m.reply(`${header}${body}`);
  } catch (error) {
    console.error("Error in handler:", error);
    m.reply("❌ Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.");
  }
};

handler.command = ["jagoanlist", "jagoanexpired", "jagoanexp"];
handler.tags = ["tools"];
handler.help = ["jagoanlist", "jagoanexpired", "jagoanexp"];
handler.rowner = true;

handler.register = true;
handler.limit = true;
module.exports = handler;