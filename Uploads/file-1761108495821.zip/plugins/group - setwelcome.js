// 📝 Plugin group - setwelcome
const fs = require('fs')

// Fungsi simpan database
function saveDatabase() {
  try {
    fs.writeFileSync('./database.json', JSON.stringify(global.db.data, null, 2))
  } catch (e) {
    console.error('❌ Gagal menyimpan database:', e)
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `❌ Teksnya mana?\n\nContoh:\n${usedPrefix + command} Hai @user!\nSelamat datang di @subject\n\n@desc\n\n> Gunakan:\n> @user → Tag member baru\n> @subject → Nama grup\n> @desc → Deskripsi grup`

  global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
  global.db.data.chats[m.chat].sWelcome = text.trim()
  saveDatabase()

  m.reply(`✅ Welcome berhasil diatur untuk grup ini menjadi :\n${text.trim()}`)
}

handler.help = ['setwelcome <teks>']
handler.tags = ['group']
handler.command = /^(setwelcome|setw)$/i
handler.group = true
handler.admin = true

handler.register = true
handler.limit = true
module.exports = handler
