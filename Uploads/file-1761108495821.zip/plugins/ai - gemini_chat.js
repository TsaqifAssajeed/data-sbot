const axios = require('axios');

// Fungsi untuk query ke API AI Gemini
async function geminiQuery(prompt) {
    try {
        const response = await axios.get(`${global.alyachan}/api/ai-gemini`, {
            params: {
                q: prompt,
                apikey: global.alyachankey
            }
        });
        return response.data.data.content;
    } catch (error) {
        throw new Error(error.response?.data?.message || error.message);
    }
}

let handler = async (m, { text, command, usedPrefix, conn }) => {
    if (!text) {
        throw `Harap masukkan teks.\nContoh:\n${usedPrefix + command} Apa itu kota Jakarta?`;
    }

    // Kirim reaction loading
    await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
    });

    try {
        // Query ke API AI Gemini
        let responseText = await geminiQuery(text);

        // Ganti markdown
        responseText = responseText.replace(/\*\*(.*?)\*\*/g, '*$1*');
        responseText = responseText.replace(/### (.*?)(?=\n)/g, '`$1`');
        responseText = responseText.replace(/##/g, '✦');
        // Hapus referensi sumber seperti [1], [2], dll.
        responseText = responseText.replace(/\[\d+\]/g, '');
        responseText += '\n\n> AI Gemini ';

        // Kirim dengan contextInfo
        await conn.sendMessage(
            m.chat,
            {
                text: responseText,
                contextInfo: {
                    externalAdReply: {
                        title: '❇️ AI Gemini Response',
                        body: '',
                        thumbnailUrl: 'https://pnghdpro.com/wp-content/themes/pnghdpro/download/social-media-and-brands/gemini-app-icon-hd.png',
                        sourceUrl: '',
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            },
            {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: '0@s.whatsapp.net',
                        remoteJid: 'status@broadcast'
                    },
                    message: { conversation: 'AI Gemini Response' }
                }
            }
        );

        // Kirim reaksi sukses
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
    } catch (e) {
        console.error('Error:', e);
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        m.reply(`🚫 Error saat memproses permintaan: ${e.message}`);
    }
};


handler.help = ['gemini'].map(a => a + ' *[text]*');
handler.command = ['gemini','aigemini'];
handler.tags = ['ai'];


handler.register = true;
handler.limit = true;
module.exports = handler;