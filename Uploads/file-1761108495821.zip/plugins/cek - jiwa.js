let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.jiwa)}”`, m)
}
handler.help = ['cekjiwa']
handler.tags = ['cek']
handler.command = /^(cekjiwa)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

handler.register = true
module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.jiwa = [
'lu nggak gila kok siapa bilang?', 'agak gila lu', 'kadang koslet', 'selalu gila', 'lu kena penyakit yung kai blue gila', 'kadang stress kadang enggak', 'lu gak benar benar gila, kadang kadang aja', 'ke RSJ yuk? udah parah itu', 'lu yang gw sering liat di lampu merah cuma pake kolor ya?😂', 'gak gila', 'beneran gila, cuma kalo mau di tanganin udah telat, udah parah ini mah😂', 'stress + gila + tolol (lengkap dah', 'lu kena penyakit siput gila', 'lu kena penyakit amba gila', 'lu gak gila kok, cuma stress😂', 'gila lu ya? minum obat sana',
]