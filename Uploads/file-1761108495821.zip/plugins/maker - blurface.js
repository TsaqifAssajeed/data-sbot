const fetch = require('node-fetch');
const uploadFile = require('../lib/uploadFile');
const uploadImage = require('../lib/uploadImage');

let handler = async (m, { text, usedPrefix, command }) => {
  let url;
  if (text) {
    // Asumsikan text adalah URL gambar
    url = text;
  } else {
    // Cek jika ada quoted message dengan gambar
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    if (!mime.startsWith('image/')) {
      throw `🚩 Masukan URL gambar atau reply gambar! 😓`;
    }
    const media = await q.download();
    if (!media) throw `❌ Gagal mengunduh gambar. 😢`;

    // Pastikan media adalah Buffer
    if (!Buffer.isBuffer(media)) {
      if (media instanceof Uint8Array || media instanceof ArrayBuffer) {
        media = Buffer.from(media); // Konversi ke Buffer jika Uint8Array atau ArrayBuffer
      } else if (typeof media === 'object' && media.data) {
        media = Buffer.from(media.data); // Coba ambil data dari properti object
      } else {
        throw `❌ Data gambar tidak valid: ${typeof media}. 😢`;
      }
    }

    const fileSizeLimit = 5 * 1024 * 1024;
    if (media.length > fileSizeLimit) {
      throw `❌ Ukuran gambar tidak boleh melebihi 5MB. 😢`;
    }

    const isTele = /image\/(png|jpe?g|gif)/.test(mime);
    url = await (isTele ? uploadImage : uploadFile)(media);
    if (!url) throw `❌ Gagal mengunggah gambar. 😢`;
  }

  try {
    conn.reply(m.chat, 'Processing... ⏳✨', m, { contextInfo: global.fakeig.contextInfo });

    const apiUrl = `${global.apisiput}api/iloveimg/blurface?image=${encodeURIComponent(url)}`;
    const res = await fetch(apiUrl);
    if (!res.ok) throw `Gagal menghubungi API. 😢`;

    const buffer = await res.buffer();
    conn.sendFile(m.chat, buffer, 'blur.jpg', '🫣 Wajah berhasil di-blur! 🎉🚀', m, { contextInfo: global.fakeig.contextInfo });
  } catch (e) {
    m.reply(`Error: ${e.message} 😢`, null, { contextInfo: global.fakeig.contextInfo });
  }
};

handler.help = ['blurface [urlgambar]'];
handler.tags = ['maker'];
handler.command = /^blurface$/i;
handler.limit = true;

handler.register = true
module.exports = handler;