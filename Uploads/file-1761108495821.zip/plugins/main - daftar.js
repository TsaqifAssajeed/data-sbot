// ✨ Plugin main - daftar ✨

// 📝 plugin main - daftar

const { createHash } = require('crypto');

global.timeZone = 'Asia/Jakarta'; // default timezone
let idch = salurandaftar; // ID CH DEFAULT

function getZoneLabel(zone) {
  const found = [
    { zone: 'Asia/Jakarta', label: 'WIB' },
    { zone: 'Asia/Makassar', label: 'WITA' },
    { zone: 'Asia/Jayapura', label: 'WIT' }
  ].find(z => z.zone === zone);
  return found ? found.label : zone;
}

let handler = async function (m, { conn, text, usedPrefix, command }) {
  const zones = [
    { number: 1, zone: 'Asia/Jakarta', label: 'WIB' },
    { number: 2, zone: 'Asia/Makassar', label: 'WITA' },
    { number: 3, zone: 'Asia/Jayapura', label: 'WIT' }
  ];

  const isOwner = (conn?.user?.jid && m.sender === conn.user.jid) || global.owner?.some(([v]) => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net' === m.sender);

  if (command === 'setch') {
    if (!m.isGroup && !isOwner) return m.reply('‼️ *AKSES DITOLAK*\n\n> perintah ini hanya dapat digunakan oleh owner.');
    if (!text) return m.reply('⚠️ *Masukkan ID channel*\n\nContoh : .setch 120363420422653130@newsletter');
    if (!text.includes('@newsletter')) return m.reply('❌ ID channel tidak valid! Pastikan formatnya seperti: 120363374854049231@newsletter');

    idch = text;
    return m.reply(`✅ ID channel berhasil diatur ke: ${idch}`);
  }

  if (command === 'settimezone') {
    if (!isOwner) return m.reply('‼️ *AKSES DITOLAK*\n\n> Perintah ini hanya dapat digunakan oleh owner.');
    if (!text) {
      let list = zones.map(z => `${z.number}. ${z.zone} (${z.label})`).join('\n');
      return m.reply(`‼️ *SILAHKAN PILIH FORMAT WAKTU*\n\n${list}\n\n> Contoh: .settimezone 1`);
    }

    let choice = parseInt(text.trim());
    let selected = zones.find(z => z.number === choice);
    if (!selected) return m.reply('❌ *Nomor timezone tidak valid!*\n\nKetik .settimezone untuk melihat daftar.');

    global.timeZone = selected.zone;
    return m.reply(`✅ *Timezone berhasil diatur ke* ${selected.zone} (${selected.label})`);
  }

  // Handle registration commands (register, reg, daftar)
  if (['register', 'reg', 'daftar'].includes(command)) {
    conn.register = conn.register ? conn.register : {};
    let user = global.db.data.users[m.sender];

    if (user.registered === true) throw `*‼️ KAMU SUDAH TERDAFTAR*`;

    let exampleUsage = `📝 *CARA PENGUNAAN :*\n> ${usedPrefix + command} Nama.Umur\n\n📝 *CONTOH PENGGUNAAN :*\n> ${usedPrefix + command} ${namebot}.20`;

    if (!text) return m.reply(exampleUsage);
    let [name, age] = text.split(".");
    if (!name || !age) return m.reply(exampleUsage);

    age = parseInt(age);
    if (age > 50 || age < 1) return m.reply('‼️ *Woy Tuaak mian bot. Umur tidak valid! Rentang 1 - 50 tahun yang udah tuak kerja sono..*');

    let sn = createHash('md5').update(m.sender).digest('hex');

    // Send confirmation message with Y and N buttons
    await conn.sendMessage(m.chat, {
      text: `╭─⋆✦「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐀𝐊𝐔𝐍 」\n` +
            `│𝗡𝗔𝗠𝗔 : ${name}\n` +
            `│𝗨𝗠𝗨𝗥 : ${age} tahun\n` +
            `╰─═───────═──•⟢\n\n` +
            `> SUDAH YAKIN DENGAN INFO INI?`,
      buttons: [
        { buttonId: `.confirmreg y`, buttonText: { displayText: 'YOI BANG SETUJU' }, type: 1 },
        { buttonId: `.confirmreg n`, buttonText: { displayText: 'SKIP AH GAJADI' }, type: 1 }
      ],
      headerType: 1,
      viewOnce: true
    }, { quoted: m });

    conn.register[m.sender] = {
      status: 'PROCESS',
      name: name,
      age: age,
      sn: sn
    };
  }
};

handler.before = async function (m, { conn }) {
  conn.register = conn.register ? conn.register : {};
  if (!conn.register[m.sender] || conn.register[m.sender].status !== 'PROCESS') return;

  let user = global.db.data.users[m.sender];
  if (user.registered === true) return;

  let input = m.text.toLowerCase();
  let ppUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/src/avatar_contact.png';
  try {
    ppUrl = await conn.profilePictureUrl(m.sender, 'image');
  } catch (e) {}

  const date = new Date();
  const formattedDate = new Intl.DateTimeFormat('id-ID', {
    timeZone: global.timeZone,
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).format(date);

  const formattedTime = new Intl.DateTimeFormat('id-ID', {
    timeZone: global.timeZone,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).format(date);

  // Handle button responses for confirmation
  if (input === ".confirmreg y") {
    const contextInfo = {
      mentionedJid: [],
      groupMentions: [],
      isForwarded: true,
      forwardingScore: 256,
      forwardedNewsletterMessageInfo: {
        newsletterJid: idch,
        newsletterName: 'Terverifikasi',
        serverMessageId: -1
      },
      externalAdReply: {
        title: '✅ BERHASIL TERDAFTAR',
        body: `Terima kasih telah bergabung di ${namebot}`,
        thumbnailUrl: ppUrl,
        sourceUrl: saluran,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    };

    const success =
      `Terimakasih telah mendaftar di ${namebot}, informasi akan disimpan kedalam database bot.\n\n` +
      `╭─⋆✦「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐀𝐊𝐔𝐍 」\n` +
      `│ Nama    : ${conn.register[m.sender].name}\n` +
      `│ Umur    : ${conn.register[m.sender].age} tahun\n` +
      `│ Tanggal : ${formattedDate}\n` +
      `│ Waktu   : ${formattedTime} (${getZoneLabel(global.timeZone)})\n` +
      `│ Status  : Berhasil\n` +
      `╰─═───────═──•⟢\n` +
      `SERIAL NUMBER : ${conn.register[m.sender].sn}`;

    await conn.sendMessage(m.chat, { text: success, contextInfo }, { quoted: m });

    let name = conn.register[m.sender].name;
    let age = conn.register[m.sender].age;

    let channelMessage = `🎉 *USER TERDAFTAR DALAM BOT!!*\n\n` +
      `╭─⋆✦「 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐀𝐊𝐔𝐍 」\n` +
      `│Nama    : ${name}\n` +
      `│Umur    : ${age} tahun\n` +
      `│Tanggal : ${formattedDate}\n` +
      `│Waktu   : ${formattedTime} (${getZoneLabel(global.timeZone)})\n` +
      `╰─═───────═──•⟢\n` +
      `SERIAL NUMBER : ${conn.register[m.sender].sn}`;

    try {
      await conn.sendMessage(idch, { text: channelMessage, contextInfo });
    } catch (err) {
      m.reply(`❌ Gagal mengirim pemberitahuan ke channel.\n\n📄 *Logs error:* \n\`\`\`${err.message}\`\`\``);
    }

    conn.register[m.sender].status = 'FINISH';
    user.name = name;
    user.age = age;
    user.sn = conn.register[m.sender].sn;
    user.registered = true;
    user.regTime = +new Date();
    delete conn.register[m.sender];
  } else if (input === ".confirmreg n") {
    await m.reply('❌ *Registrasi dibatalkan*');
    delete conn.register[m.sender];
  } else if (input === "y" || input === "n") {
    m.reply('‼️ *Silahkan gunakan tombol untuk konfirmasi*');
  }
};

handler.help = ['register', 'reg', 'daftar'].map(v => v + ' <name.age>').concat(['setch <channel_id>', 'settimezone <nomor>']);
handler.tags = ['main', 'owner'];
handler.command = /^(register|reg|daftar|setch|settimezone|confirmreg)$/i;

module.exports = handler;