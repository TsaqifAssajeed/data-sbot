const axios = require('axios');
const cheerio = require('cheerio');

// Fungsi untuk mengekstrak URL dari teks
function extractCapcutUrl(text) {
    const urlRegex = /https:\/\/www\.capcut\.com\/[^\s]*/;
    const match = text.match(urlRegex);
    return match ? match[0] : null;
}

const handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) return m.reply(`⚠️ Contoh Penggunaan : ${usedPrefix + command} *[url capcut]*`);
    
    // Ekstrak URL dari teks input
    const capcutUrl = extractCapcutUrl(text);
    if (!capcutUrl) return m.reply(`⚠️ Tidak ditemukan URL CapCut yang valid dalam input! Pastikan URL benar. 🔗`);

    m.reply('🔍 Sedang Mengunduh video CapCut... ⏳');
    
    try {
        let result, isWatermark = false;
        let source = '';
        
        // Coba metode AlyaChan API terlebih dahulu (tanpa watermark)
        console.log('ℹ️ Memulai percobaan AlyaChan API...');
        let alyaResult = await capcutAlyaChan(capcutUrl);
        
        if (alyaResult && alyaResult.status && alyaResult.data) {
            result = alyaResult.data;
            source = 'AlyaChan API';
            isWatermark = false;
            console.log('✅ Menggunakan AlyaChan API (No Watermark)');
        } else {
            // Fallback ke capcutdl (dengan watermark)
            console.log('ℹ️ Beralih ke Web Scraping (fallback)...');
            result = await capcutdl(capcutUrl);
            if (!result) {
                return m.reply('❌ Gagal mendapatkan data. Pastikan URL valid! 🔗\n💡 *Tips*: Gunakan URL lengkap dari CapCut (contoh: template-detail dengan share_token).');
            }
            source = 'Web Scraping';
            isWatermark = true;
            console.log('⚠️ Menggunakan Web Scraping (Dengan Watermark)');
        }

        // Format tampilan sesuai sumber
        let cpt;
        if (!isWatermark) {
            cpt = `*✨ C A P C U T - D O W N L O A D E R ✨*\n\n` +
                  `🎥 *Judul*: ${result.title}\n` +
                  `📅 *Tanggal*: ${result.create_time || result.date}\n` +
                  `👥 *Pengguna*: ${result.usage_amount || result.pengguna} pengguna\n` +
                  `❤️ *Suka*: ${result.like_count || result.likes} likes\n` +
                  `👤 *Pembuat*: ${result.author.name} 🌟\n\n` +
                  `✅ *Status*: Video tanpa watermark!`;
                  
        } else {
            cpt = `*✨ C A P C U T - D O W N L O A D E R ✨*\n\n` +
                  `🎥 *Judul*: ${result.title}\n` +
                  `📅 *Tanggal*: ${result.date}\n` +
                  `👥 *Pengguna*: ${result.pengguna}\n` +
                  `❤️ *Suka*: ${result.likes}\n` +
                  `👤 *Pembuat*: ${result.author.name}\n\n` +
                  `⚠️ *Status*: Video dengan watermark (metode cadangan)`;
        }
        
        // Kirim video dengan thumbnail
        const videoUrl = result.url || result.videoUrl;
        const thumbnailUrl = result.thumbnail || result.posterUrl;
        
        console.log('ℹ️ Mengirim video:', { videoUrl, thumbnailUrl });
        await conn.sendFile(m.chat, videoUrl, '', cpt, m, {
            thumbnail: await (await axios.get(thumbnailUrl, { responseType: 'arraybuffer' })).data
        });
        
    } catch (error) {
        console.error('❌ Error umum:', error.message, error.stack);
        m.reply('😓 Terjadi kesalahan saat mengambil data. Coba lagi nanti! 🔄');
    }
};

handler.help = ["capcut"].map((a) => a + " *[url capcut]*");
handler.tags = ["downloader"];
handler.command = ["capcut"];
handler.register = true;
handler.limit = true;
module.exports = handler;

async function capcutAlyaChan(url) {
    try {
        // Coba URL asli
        let response = await axios.get(`${global.alyachan}/api/capcut-dl`, {
            params: {
                url: url,
                type: 'nowatermark',
                apikey: global.alyachankey
            },
            timeout: 15000
        });
        
        if (response.data && response.data.status === true && response.data.data) {
            return response.data;
        }
        
        // Coba modifikasi URL ke format template-detail
        const urlId = url.split('/').pop();
        const modifiedUrl = `https://www.capcut.com/template-detail/${urlId}?template_id=${urlId}`;
        
        response = await axios.get(`${global.alyachan}/api/capcut-dl`, {
            params: {
                url: modifiedUrl,
                type: 'nowatermark',
                apikey: global.alyachankey
            },
            timeout: 15000
        });
        
        if (response.data && response.data.status === true && response.data.data) {
            return response.data;
        }
        
        return null;
    } catch (error) {
        return null;
    }
}

async function capcutdl(url) {
    try {
        const response = await axios.get(url, { timeout: 10000 });
        const html = response.data;
        const $ = cheerio.load(html);
        const videoElement = $('video.player-o3g3Ag');
        const videoSrc = videoElement.attr('src');
        const posterSrc = videoElement.attr('poster');
        const title = $('h1.template-title').text().trim();
        const actionsDetail = $('p.actions-detail').text().trim();
        const [date, uses, likes] = actionsDetail.split(',').map(item => item.trim());
        const authorAvatar = $('span.lv-avatar-image img').attr('src');
        const authorName = $('span.lv-avatar-image img').attr('alt');

        if (!videoSrc || !posterSrc || !title || !date || !uses || !likes || !authorAvatar || !authorName) {
            throw new Error('Beberapa elemen penting tidak ditemukan di halaman.');
        }

        const result = {            
            title: title,
            date: date,
            pengguna: uses,
            likes: likes,
            author: {
                name: authorName,
                avatarUrl: authorAvatar
            },
            videoUrl: videoSrc,
            posterUrl: posterSrc
        };
        
        return result;
    } catch (error) {
        return null;
    }
}