let handler = async (m, { conn }) => {
    conn.tebakgambar = conn.tebakgambar ? conn.tebakgambar : {}
    let id = m.chat
    if (!(id in conn.tebakgambar)) {
        conn.reply(m.chat, '⚠️ Tidak ada permainan tebak gambar yang sedang berlangsung! 😕', m)
        throw false
    }
    let game = conn.tebakgambar[id]
    let jawabanHint = game.jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/gi, '_')
    m.reply('```' + jawabanHint + '``` ✨\n*Ketik jawaban langsung di chat ya!* 🚀')
}

handler.command = /^hint$/i
handler.limit = true

handler.register = true
module.exports = handler