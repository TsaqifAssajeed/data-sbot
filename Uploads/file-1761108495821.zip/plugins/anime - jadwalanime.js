const axios = require('axios');
const cheerio = require('cheerio');
const moment = require('moment-timezone');

const handler = async (m, { conn, command }) => {
  try {
    const isBesok = /besok/i.test(command);
    const targetDate = moment().tz('Asia/Jakarta').add(isBesok ? 1 : 0, 'day');
    const tanggal = targetDate.format('YYYY-MM-DD');
    const displayDate = targetDate.format('dddd, DD MMMM YYYY');
    const url = `https://www.livechart.me/schedule?date=${tanggal}`;

    const { data: html } = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
    });

    const $ = cheerio.load(html);
    const dayBlock = $('.lc-timetable-day.lc-today');
    const result = [];

    dayBlock.find('.lc-timetable-anime-block').each((_, el) => {
      const title = $(el).attr('data-schedule-anime-title')?.trim();
      const time = $(el).closest('.lc-timetable-timeslot').find('.lc-time').text().trim();
      const epInfo = $(el).find('.lc-tt-release-label span.font-medium').text().trim();
      const typeInfo = $(el).find('.lc-tt-release-label').text().replace(epInfo, '').replace('·', '').trim();
      const episodeLink = 'https://www.livechart.me' + $(el).find('.lc-tt-release-label').attr('href');
      const animeLink = 'https://www.livechart.me' + $(el).find('.lc-tt-anime-title').attr('href');

      if (title) {
        result.push(
          `📺 Judul : ${title}` +
          `\n🕒 Waktu : ${time || 'Waktu tidak diketahui'}` +
          `\n🎞 Episode : ${epInfo} - ${typeInfo}` +
          `\n🔗 Link  : ${episodeLink}` +
          `\n🧸 Tentang Anime : ${animeLink}`
        );
      }
    });

    if (result.length === 0) throw `Tidak ada anime tayang ${isBesok ? 'besok' : 'hari ini'}.`;

    const text = `📅 *Jadwal Anime ${isBesok ? 'Besok' : 'Hari Ini'} (${displayDate})*\n\n` + result.join('\n\n');

    await conn.reply(m.chat, text, m, { linkPreview: false });

  } catch (e) {
    console.error(e);
    await conn.reply(m.chat, `Gagal mengambil jadwal anime ${/besok/i.test(command) ? 'besok' : 'hari ini'} dari LiveChart.\n\n${e}`, m);
  }
};

handler.command = /^jadwalanime(besok)?$/i;
handler.group = true;
handler.botAdmin = true;
handler.help = ['jadwalanime', 'jadwalanimebesok'];
handler.tags = ['anime'];

handler.register = true
handler.limit = true
module.exports = handler;
