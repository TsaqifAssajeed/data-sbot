let handler = async (m, { conn, participants, groupMetadata }) => {
    // Load data sewa dari lib/sewa.json
    const sewaData = require('../lib/sewa.json') // Pastikan path sesuai dengan struktur proyek Anda

    let pp = './media/avatar_contact.png'
    try {
        pp = await conn.profilePictureUrl(m.chat, 'image')
    } catch (e) {}

    // Mendapatkan link grup
    let inviteLink = ''
    try {
        inviteLink = await conn.groupInviteCode(m.chat)
        inviteLink = `https://chat.whatsapp.com/${inviteLink}`
    } catch (e) {
        inviteLink = 'Tidak dapat mengambil link grup'
    }

    // Mendapatkan daftar admin dan owner
const groupAdmins = participants.filter(p => p.admin)
const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.jid.split('@')[0]}`).join('\n')

    // Mendapatkan owner grup
    const owner = groupMetadata.owner || m.chat.split`-`[0] + '@s.whatsapp.net'

    let now = new Date() * 1
    let { viewonce, antiSticker, antiBadword, isBanned, welcome, detect, sWelcome, sBye, sPromote, sDemote, antiLink } = global.db.data.chats[m.chat]

    // Mendapatkan waktu expired dari sewa.json berdasarkan grup ID
    let expired = sewaData[m.chat]?.expired || 0 // Default ke 0 jika tidak ada data sewa
    let expiredText = (expired - now) > 1 ? msToDate(expired - now) : '*TIDAK DI SETEL EXPIRED*'

    let text = `🐣 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐆𝐑𝐎𝐔𝐏 🐣

*ID:* 
${groupMetadata.id}

*NAMA:* 
${groupMetadata.subject}

*DESKRIPSI:* 
${groupMetadata.desc?.toString() || 'Tidak ada deskripsi'}

*TOTAL MEMBER:*
${participants.length} Members

*LINK GRUP:*
${inviteLink}

*PEMILIK GROUP:* 
@${owner.split('@')[0]}

*ADMIN GROUP:*
${listAdmin || 'Tidak ada admin'}

*EXPIRED:*
${expiredText}

*PENGATURAN GROUP:*
${isBanned ? '✅' : '❌'} *BANNED*
${welcome ? '✅' : '❌'} *WELCOME*
${detect ? '✅' : '❌'} *DETECT*
${antiLink ? '✅' : '❌'} *ANTILINK*
`.trim()

    // Menggabungkan owner dan admin untuk mention
    let mentionedJid = [...new Set([owner, ...groupAdmins.map(v => v.id)])]
    
    conn.sendFile(m.chat, pp, 'pp.jpg', text, m, false, { 
        contextInfo: { 
            mentionedJid: conn.parseMention(text),
            externalAdReply: {
                title: groupMetadata.subject,
                body: 'Informasi Grup',
                thumbnail: await (await conn.getFile(pp)).data,
                sourceUrl: inviteLink
            }
        }
    })
}

handler.help = ['infogrup']
handler.tags = ['group']
handler.command = /^(gro?upinfo|info(gro?up|gc))$/i
handler.group = true

handler.register = true
handler.limit = true
module.exports = handler

function msToDate(ms) {
    let days = Math.floor(ms / (24*60*60*1000))
    let daysms = ms % (24*60*60*1000)
    let hours = Math.floor((daysms)/(60*60*1000))
    let hoursms = ms % (60*60*1000)
    let minutes = Math.floor((hoursms)/(60*1000))
    return days + " Hari " + hours + " Jam " + minutes + " Menit"
}