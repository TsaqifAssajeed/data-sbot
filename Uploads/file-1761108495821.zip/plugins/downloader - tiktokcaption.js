// ✨ Plugin downloader - tiktokcaption ✨

// ✨ Plugin downloader - ttcaption (to the point) ✨
const axios = require('axios');

// Handler utama
let handler = async (m, { conn, text }) => {
  if (!text) return m.reply(`‼️ Harap masukan link TikTok, contoh: .ttcaption https://vt.tiktok.com/...`);

  try {
    // Reaksi jam saat proses dimulai
    await conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

    const result = await tiktok2(text);

    if (!result.title) return m.reply("❌ Caption tidak ditemukan.");

    // Kirim hanya caption saja (to the point)
    await conn.sendMessage(m.chat, {
      text: result.title
    }, { quoted: m });

    // Reaksi centang selesai
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (error) {
    console.error(error);
    m.reply("❌ Terjadi kesalahan: " + error.message);
  }
};

handler.help = ["ttcaption"];
handler.tags = ["downloader"];
handler.command = /^(ttcaption)$/i;

handler.register = true;
handler.limit = true;
module.exports = handler;

// Fungsi ambil data TikTok
async function tiktok2(query) {
  try {
    const encodedParams = new URLSearchParams();
    encodedParams.set('url', query);
    encodedParams.set('hd', '1');

    const response = await axios({
      method: 'POST',
      url: 'https://tikwm.com/api/',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': 'current_language=en',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
      },
      data: encodedParams
    });

    const data = response.data.data;

    return {
      title: data.title,
      digg_count: data.digg_count,
      play_count: data.play_count,
      share_count: data.share_count
    };
  } catch (error) {
    console.error('Error fetching TikTok caption:', error);
    throw new Error('Gagal mengambil data dari TikTok.');
  }
}