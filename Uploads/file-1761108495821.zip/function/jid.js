const { jidNormalizedUser } = require('@whiskeysockets/baileys')

function normalizeJid(jid) {
    if (!jid) return null
    try {
        // kalau grup, biarin tetap g.us
        if (jid.endsWith('@g.us')) return jid
        return jidNormalizedUser(jid)
    } catch (e) {
        console.error('Gagal normalisasi JID:', e)
        return jid
    }
}

module.exports = { normalizeJid }
