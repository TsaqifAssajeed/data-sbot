const { makeWASocket } = require("@whiskeysockets/baileys");
const { resolveLidViaMeta } = require('@whiskeysockets/baileys')

async function checkUserExists(jid, socket) {
  try {
    const response = await socket.sendQuery({
      tag: "iq",
      attrs: {
        xmlns: "urn:xmpp:whatsapp:account",
        type: "get",
        to: jid,
        id: Date.now().toString(),
      },
      content: [{ tag: "user", attrs: {}, content: [] }],
    });

    return response?.content?.find((item) => item.tag === "user") || null;
  } catch (error) {
    console.error("Gagal memeriksa pengguna:", error);
    return null;
  }
}

async function getUserInfo(jid, socket, baileysUtils) {
  const userExists = baileysUtils.isUserOnline(jid);
  const socketExists = baileysUtils.userExists(socket);

  if (!userExists || !socketExists) {
    console.error("Pengguna atau soket tidak ada:", jid);
    return jid;
  }

  const userData = await checkUserExists(jid, socket);
  if (userData) {
    const users = userData.content?.filter((item) => item.tag === "user") || [];
    for (const user of users) {
      const userJid = user.attrs?.jid;
      const phoneNumber = user.attrs?.phone_number;
      if (userJid === jid && phoneNumber?.endsWith("@whatsapp.net")) {
        console.log("Ditemukan pengguna dengan nomor telepon:", phoneNumber);
        return phoneNumber;
      }
    }
    console.log("Tidak ada pengguna yang cocok");
  } else {
    console.log("Tidak ada data pengguna");
  }

  try {
    const groupData = await socket.groupMetadata(jid);
    const participant = groupData?.participants?.find((p) => p.id === jid);
    if (participant) {
      console.log("Ditemukan peserta grup:", participant.id);
      return participant.id;
    }
  } catch (error) {
    console.error("Gagal mengambil metadata grup:", error);
  }

  return jid;
}

module.exports = {
  getUserInfo,
  checkUserExists,
};