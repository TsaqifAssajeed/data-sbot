// secure-pairing.js
module.exports = async function smeme(fs, chalk, sesi, usePairingCode, useMobile, isPairing, question, rl, conn) {
    try {
        const credsRaw = fs.readFileSync('./session/creds.json', 'utf-8');
        const credsJson = JSON.parse(credsRaw);
        const nomorTerdaftar = credsJson?.me?.id || credsJson?.me?.jid || '';
        const nomorFormat = nomorTerdaftar.split(':')[0].replace(/[^0-9]/g, '');
        if (nomorFormat) {
            let validasi = await sesi(nomorFormat);
            if (!validasi) {
                console.log(
                    chalk.white('╭─❖───────────────────────────────❖') + '\n' +
                    chalk.white('│ ') + 
                    chalk.red.bold('✖ Nomor Terdaftar di creds.json: ') +
                    chalk.yellow(nomorFormat) +
                    chalk.red.bold(' tidak ada dalam database! ') +
                    chalk.white(' │') + '\n' +
                    chalk.white('╰─❖───────────────────────────────❖') + '\n' +
                    chalk.green.bold('Silahkan hubungi owner Jagoan Project untuk di tambahkan: ') + '\n' +
                    chalk.blue.bold('+62 895-3622-82300 : Chandra') + '\n' +
                    chalk.yellow.bold('Restart dibatalkan, sesi tidak valid atau nomor terdeteksi illegal.')
                );
                process.exit(1);
            }
        }
    } catch (e) {
        console.error('❌ Gagal membaca creds.json atau format tidak sesuai!', e);
    }

    if ((usePairingCode || useMobile) && fs.existsSync('./session/creds.json') && !conn.authState.creds.registered) {
        console.log(chalk.yellow('-- WARNING: creds.json rusak, silahkan hapus folder session dan pairing ulang --'));
        process.exit(0);
    }
    if (isPairing && !conn.authState.creds.registered) {
        if (useMobile) throw new Error('Tidak dapat menggunakan Pairing Baileys API!');
        const { registration } = { registration: {} };
        let phoneNumber = await question(chalk.yellowBright('Masukkan nomor yang valid, dengan kode negara (62xxx):\nContoh: 6285888777444\n'));
        rl.close();
        phoneNumber = phoneNumber.replace(/\D/g, '');
        const customPairingCode = "JAGPRO26";
        console.log(chalk.bgWhite(chalk.blue('Tunggu Sebentar...')));
        let jagpro = await sesi(phoneNumber);
        if (!jagpro) {
            console.log(
                chalk.white('╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄') + '\n' +
                chalk.white('┆ ') + 
                chalk.red.bold('✖ Woop Woop Woop Nomor : ') +
                chalk.yellow(phoneNumber) +
                chalk.red.bold(' tidak terdaftar di database! ') +
                chalk.white(' ┆') + '\n' +
                chalk.white('╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄') + '\n' +
                chalk.white('----------------------------') + '\n' +
                chalk.green.bold('Silahkan hubungi owner Jagoan Project untuk di tambahkan dalam database: ') + '\n' +
                chalk.blue.bold('+62 895-3622-82300 : Chandra') + '\n' +
                chalk.yellow.bold('Jika anda mencuri Script ini tolong hentikan niat burukmu....')
            );
            process.exit(1);
        }
        setTimeout(async () => {
    try {
        let code = await conn.requestPairingCode(phoneNumber, customPairingCode);
        code = code?.match(/.{1,4}/g)?.join('-') || code;

        console.log(); // baris kosong di atas
        console.log(chalk.bgGreen.black(' Your Custom Pairing Code: '), chalk.white.bold(code));
        console.log(); // baris kosong
        console.log(chalk.bgBlue.white(' Apabila gagal pairing, silahkan hapus folder session dan restart ulang '));
        console.log(); // baris kosong di bawah

    } catch (error) {
        console.log();
        console.log(chalk.bgRed.white(' Gagal membuat pairing code '));
        console.log(chalk.red(`› ${error.message}`));
        console.log();
        console.log(chalk.bgBlue.white(' Silahkan hapus folder session dan restart ulang '));
        console.log();
    }
}, 3000);

    }
}