const fs = require('fs')
const path = require('path')
const { spawn } = require('child_process')

// folder tmp otomatis
const tmpDir = path.join(__dirname, '../tmp')
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

function ffmpeg(buffer, args = [], ext = '', ext2 = '') {
  return new Promise(async (resolve, reject) => {
    let tmpIn = path.join(tmpDir, `${Date.now()}.${ext}`)
    let tmpOut = `${tmpIn}.${ext2}`
    try {
      await fs.promises.writeFile(tmpIn, buffer)

      const ff = spawn('ffmpeg', [
        '-y',
        '-i', tmpIn,
        ...args,
        tmpOut
      ])

      ff.on('error', reject)
      ff.on('close', async (code) => {
        try {
          await fs.promises.unlink(tmpIn).catch(() => { })
          if (code !== 0) return reject(new Error(`ffmpeg exited with code ${code}`))
          let data = await fs.promises.readFile(tmpOut)
          await fs.promises.unlink(tmpOut).catch(() => { }) // auto hapus output setelah dibaca
          resolve({ data, filename: `${Date.now()}.${ext2}` })
        } catch (e) {
          reject(e)
        }
      })
    } catch (e) {
      reject(e)
    }
  })
}

// Konversi ke VN (WA Compatible)
function toPTT(buffer, ext) {
  return ffmpeg(buffer, [
    '-vn',
    '-acodec', 'libopus',
    '-b:a', '64k',
    '-ar', '48000',
    '-ac', '1',
    '-application', 'voip',
    '-map_metadata', '-1',
    '-f', 'ogg'
  ], ext, 'ogg')
}

// Konversi ke Audio biasa (mp3)
function toAudio(buffer, ext) {
  return ffmpeg(buffer, [
    '-vn',
    '-c:a', 'libmp3lame',
    '-q:a', '4',
    '-map_metadata', '-1'
  ], ext, 'mp3')
}

// Konversi ke Video (mp4 WA compatible)
function toVideo(buffer, ext) {
  return ffmpeg(buffer, [
    '-c:v', 'libx264',
    '-c:a', 'aac',
    '-ab', '128k',
    '-ar', '44100',
    '-crf', '32',
    '-preset', 'veryfast'
  ], ext, 'mp4')
}

module.exports = {
  ffmpeg,
  toPTT,
  toAudio,
  toVideo
}