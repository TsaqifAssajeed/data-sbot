let fs = require('fs');
let { execSync } = require('child_process');
let path = require('path');

/* ====== KONFIGURASI ====== */
const username = 'typographuniverse';
const token = process.env.GITHUB_TOKEN || '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'; // Gunakan variabel lingkungan
const repo = 'uploader-Jagpro';
/* ========================== */

const branch = 'main';
const email = 'typographuniverse@example.com';
const LOCAL_DIR = '/home/container/tmp';
const TARGET_FOLDER = 'Uploads';
const MAX_SIZE = 100 * 1024 * 1024;


const GIT_REPO = `https://${username}:${token}@github.com/${username}/${repo}.git`;

// Atasi batasan sistem file
process.env.GIT_DISCOVERY_ACROSS_FILESYSTEM = '1';

let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted || !m.quoted.mimetype || !m.quoted.fileLength) {
    return m.reply(`📎 Kirim file sebagai dokumen, lalu balas dengan perintah:\n> ${usedPrefix + command}`);
  }

  // ✅ Tambahkan react ⏳ ke pesan pengguna
  if (m.key && conn.sendMessage) {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
  }

  if (m.quoted.fileLength > MAX_SIZE) {
    return m.reply(`🚫 Ukuran file terlalu besar!\n\n📦 Maksimum: *100 MB*`);
  }

  try {
    let mime = m.quoted.mimetype;
    let buffer = await m.quoted.download();
    let ext = mime.split('/')[1];
    let fileName = `file-${Date.now()}.${ext}`;

    // Periksa dan inisialisasi direktori tmp
    if (fs.existsSync(LOCAL_DIR)) {
      // Verifikasi apakah direktori adalah repositori Git
      try {
        execSync(`git -C ${LOCAL_DIR} rev-parse --is-inside-work-tree`, { stdio: 'ignore' });
      } catch (gitError) {
        // Hapus dan kloning ulang jika tidak valid
        fs.rmSync(LOCAL_DIR, { recursive: true, force: true });
        execSync(`git clone -b ${branch} ${GIT_REPO} ${LOCAL_DIR}`, { stdio: 'inherit' });
      }
    } else {
      // Kloning repositori jika direktori tidak ada

      execSync(`git clone -b ${branch} ${GIT_REPO} ${LOCAL_DIR}`, { stdio: 'inherit' });
    }

    // Tulis file
    let filePath = path.join(LOCAL_DIR, TARGET_FOLDER, fileName);
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, buffer);

    // Jalankan perintah Git

    execSync(`git add .`, { cwd: LOCAL_DIR, stdio: 'inherit' });
    execSync(`git config user.name "${username}"`, { cwd: LOCAL_DIR });
    execSync(`git config user.email "${email}"`, { cwd: LOCAL_DIR });
    execSync(`git commit -m "Upload ${fileName}"`, { cwd: LOCAL_DIR, stdio: 'inherit' });
    execSync(`git push origin ${branch}`, { cwd: LOCAL_DIR, stdio: 'inherit' });

    let fileUrl = `https://raw.githubusercontent.com/${username}/${repo}/${branch}/${TARGET_FOLDER}/${fileName}`;

    // ✅ Ubah react menjadi centang ✅
    if (m.key && conn.sendMessage) {
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    }

    // Kirim pesan sukses dan hapus isi folder tmp
    await m.reply(`✅ *Upload Berhasil!*\n\n📄 Nama: ${fileName}\n\n🔗 Link: ${fileUrl}`);
    if (fs.existsSync(LOCAL_DIR)) {
      fs.readdirSync(LOCAL_DIR).forEach((item) => {
        const itemPath = path.join(LOCAL_DIR, item);
        fs.rmSync(itemPath, { recursive: true, force: true });
      });
    }
  } catch (e) {
    console.error(e);
    m.reply(`❌ Gagal upload ke GitHub.\nError: ${e.message}`);
  }
};

handler.help = ['uploadgithub'];
handler.tags = ['tools'];
handler.command = /^uploadgithub|togit|upgit$/i;
handler.limit = true;

module.exports = handler;