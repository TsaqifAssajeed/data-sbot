let FormData = require('form-data');
let Jimp = require('jimp');
let fetch = require('node-fetch');
let uploadImage = require('../lib/uploadImage');


async function processing(urlPath, method) {
    return new Promise(async (resolve, reject) => {
        let Methods = ["enhance", "recolor", "dehaze"];
        Methods.includes(method) ? (method = method) : (method = Methods[0]);
        let buffer,
            Form = new FormData(),
            scheme = "https" + "://" + "inferenceengine" + ".vyro" + ".ai/" + method;
        Form.append("model_version", 1, {
            "Content-Transfer-Encoding": "binary",
            contentType: "multipart/form-data; charset=uttf-8",
        });
        Form.append("image", Buffer.from(urlPath), {
            filename: "enhance_image_body.jpg",
            contentType: "image/jpeg",
        });
        Form.submit(
            {
                url: scheme,
                host: "inferenceengine" + ".vyro" + ".ai",
                path: "/" + method,
                protocol: "https:",
                headers: {
                    "User-Agent": "okhttp/4.9.3",
                    Connection: "Keep-Alive",
                    "Accept-Encoding": "gzip",
                },
            },
            function (err, res) {
                if (err) reject();
                let data = [];
                res
                    .on("data", function (chunk, resp) {
                        data.push(chunk);
                    })
                    .on("end", () => {
                        resolve(Buffer.concat(data));
                    });
                res.on("error", (e) => {
                    reject();
                });
            }
        );
    });
}

let handler = async (m, { conn, usedPrefix, command }) => {
    switch (command) {
        case "enhancer":
        case "unblur":
        case "enhance":
            {
                conn.enhancer = conn.enhancer ? conn.enhancer : {};
                if (m.sender in conn.enhancer)
                    throw "Masih Ada Proses Yang Belum Selesai Kak, Silahkan Tunggu Sampai Selesai Yah >//<";
                
                conn.enhancer[m.sender] = true;

                // Tambahkan timeout untuk mencegah penguncian permanen
                setTimeout(() => {
                    if (m.sender in conn.enhancer) {
                        delete conn.enhancer[m.sender];
                        console.log(`Penguncian enhancer untuk ${m.sender} dihapus karena timeout`);
                    }
                }, 60000); // Timeout setelah 60 detik

                m.reply("⏳ Sedang diproses, harap tunggu...");
                let q = m.quoted ? m.quoted : m;
                let mime = (q.msg || q).mimetype || q.mediaType || "";
                if (!mime)
                    throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;

                let img = await q.download?.();
                let error;
                try {
                    const This = await processing(img, "enhance");
                    conn.sendFile(m.chat, This, "", "✅ Berhasil! Berikut hasilnya:", m);
                } catch (er) {
                    error = true;
                    console.error(`Error pada enhancer: ${er}`);
                } finally {
                    if (error) {
                        m.reply("❌ Gagal memproses gambar, coba lagi nanti.");
                    }
                    delete conn.enhancer[m.sender];
                }
            }
            break;

        case "colorize":
        case "colorizer":
            {
                conn.recolor = conn.recolor ? conn.recolor : {};
                if (m.sender in conn.recolor)
                    throw "Masih Ada Proses Yang Belum Selesai Kak, Silahkan Tunggu Sampai Selesai Yah >//<";
                
                conn.recolor[m.sender] = true;

                // Tambahkan timeout untuk mencegah penguncian permanen
                setTimeout(() => {
                    if (m.sender in conn.recolor) {
                        delete conn.recolor[m.sender];
                        console.log(`Penguncian recolor untuk ${m.sender} dihapus karena timeout`);
                    }
                }, 60000); // Timeout setelah 60 detik

                m.reply("⏳ Sedang diproses, harap tunggu...");
                let q = m.quoted ? m.quoted : m;
                let mime = (q.msg || q).mimetype || q.mediaType || "";
                if (!mime)
                    throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;

                let img = await q.download?.();
                let error;
                try {
                    const This = await processing(img, "recolor");
                    conn.sendFile(m.chat, This, "", "✅ Berhasil! Berikut hasilnya:", m);
                } catch (er) {
                    error = true;
                    console.error(`Error pada colorizer: ${er}`);
                } finally {
                    if (error) {
                        m.reply("❌ Gagal memproses gambar, coba lagi nanti.");
                    }
                    delete conn.recolor[m.sender]; // Perbaikan: ganti m.chat jadi m.sender
                }
            }
            break;

        case "hd":
        case "hdvid":
case "hdr":
case "remini":
    {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || q.mediaType || "";
        
        // Validasi jika media tidak ada
        if (!mime) {
            throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;
        }

        // Validasi jika media adalah video
        if (/video/.test(mime)) {
            throw "❌ Maaf, fitur ini hanya mendukung foto. Silakan kirim foto untuk diproses.";
        }

        // Validasi jika media bukan gambar
        if (!/image/.test(mime)) {
            throw "❌ Media yang dikirim harus berupa foto (jpg, png, dll). Silakan kirim foto untuk diproses.";
        }

        conn.hdr = conn.hdr ? conn.hdr : {};
        if (m.sender in conn.hdr) {
            throw "Masih Ada Proses Yang Belum Selesai Kak, Silahkan Tunggu Sampai Selesai Yah >//<";
        }

        conn.hdr[m.sender] = true;

        // Tambahkan timeout untuk mencegah penguncian permanen
        setTimeout(() => {
            if (m.sender in conn.hdr) {
                delete conn.hdr[m.sender];
                console.log(`Penguncian hdr untuk ${m.sender} dihapus karena timeout`);
            }
        }, 60000); // Timeout setelah 60 detik

        m.reply("⏳ Sedang diproses, harap tunggu..., jika tidak bisa gunakan .hd2");

        let img = await q.download?.();
        let out;

        try {
            out = await require("../lib/uploadImage")(img); // Upload gambar
            console.log(`Upload berhasil: ${out}`);
        } catch (error) {
            console.error("Error saat mengunggah gambar:", error);
            delete conn.hdr[m.sender];
            return m.reply("❌ Gagal mengunggah gambar, coba lagi nanti.");
        }

        const apiEndpoints = [
            `https://api.botcahx.eu.org/api/tools/remini?url=${out}&apikey=${btc}`,
            `https://api.botcahx.eu.org/api/tools/remini-v2?url=${out}&apikey=${btc}`,
            `https://api.botcahx.eu.org/api/tools/remini-v3?url=${out}&resolusi=4&apikey=${btc}`,
            `https://api.botcahx.eu.org/api/tools/remini-v4?url=${out}&resolusi=16&apikey=${btc}`
        ];

        let success = false;
        let image;

        for (let i = 0; i < apiEndpoints.length; i++) {
            try {
                const apiResponse = await fetch(apiEndpoints[i]);
                const responseText = await apiResponse.text();

                try {
                    image = JSON.parse(responseText);
                } catch (error) {
                  
                    continue; // Lanjut ke API berikutnya
                }

                if (!image || !image.url) {
                  
                    continue; // Lanjut ke API berikutnya
                }

                success = true;
                conn.sendFile(m.chat, image.url, null, "✅ Berhasil! Berikut hasilnya:", m);
                delete conn.hdr[m.sender]; // Hapus penguncian setelah berhasil
                break; // Keluar dari loop jika berhasil
            } catch (error) {
                
                if (i === apiEndpoints.length - 1) {
                    m.reply("❌ Gagal memproses gambar setelah mencoba semua API.");
                    delete conn.hdr[m.sender]; // Hapus penguncian jika semua API gagal
                }
            }
        }
    }
    break;

        default:
            m.reply("⚠️ Perintah tidak dikenali!");
            break;
    }
};

handler.help = ["unblur", "enchaner", "enhance", "hdr", "colorize", "hd", "remini"].map(a => a + ' *[reply/send media]*');
handler.tags = ["tools"];
handler.premium = false;
handler.command = ["unblur", "enchaner", "enhance", "hdr", "colorize", "hd", "remini"];
module.exports = handler;