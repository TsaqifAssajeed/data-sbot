// ✨ Plugin owner - boost ✨

// 📝 plugin owner - boost

const fs = require('fs')
const path = require('path')
const { performance } = require('perf_hooks')

let handler = async (m, { conn }) => {
  let start = performance.now()

  let sent = await conn.sendMessage(m.chat, {
    text: '⏳ *Memulai proses boosting...*\n\n       ▱▱▱▱▱ 0%'
  }, { quoted: m })

  let loadingSteps = [
    '▰▱▱▱▱ 20%',
    '▰▰▱▱▱ 40%',
    '▰▰▰▰▱ 80%',
    '▰▰▰▰▰ 100%'
  ]

  for (let step of loadingSteps) {
    await new Promise(res => setTimeout(res, 500)) // 0.5 detik tiap step
    await conn.sendMessage(m.chat, {
      text: `⏳ *Memproses boosting...*\n\n       ${step}`,
      edit: sent.key
    })
  }

  const foldersToClean = ['.cache', 'temp', 'tmp']
  let deleted = []

  for (let folder of foldersToClean) {
    let fullPath = path.join(__dirname, '..', folder)

    if (fs.existsSync(fullPath) && fs.lstatSync(fullPath).isDirectory()) {
      try {
        let count = 0
        for (let file of fs.readdirSync(fullPath)) {
          let filePath = path.join(fullPath, file)
          fs.rmSync(filePath, { recursive: true, force: true })
          count++
        }
        deleted.push(`${folder} ( ${count} file${count !== 1 ? 's' : ''} dibersihkan )`)
      } catch (err) {
        console.error(`❌ Gagal membersihkan isi folder ${folder}: ${err.message}`)
      }
    }
  }

  let end = performance.now()
  let timeTaken = (end - start).toFixed(2)

  await new Promise(res => setTimeout(res, 300))
  await conn.sendMessage(m.chat, {
    text: `✅ *Boosting Selesai!*\n\n🗑️ Folder yang dibersihkan :\n\n- ${deleted.join('\n- ') || 'tidak ada yang dibersihkan'}\n\n⚡ Waktu proses : *${timeTaken} ms*`,
    edit: sent.key
  })
}

handler.help = ['boost']
handler.tags = ['owner']
handler.command = /^boost|refresh$/i
handler.rowner = true

module.exports = handler