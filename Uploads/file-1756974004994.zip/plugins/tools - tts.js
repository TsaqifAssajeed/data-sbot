// plugin by Tsaqifz
const fetch = require("node-fetch");

// Konfigurasi
const ELEVENLABS_API_KEY = global.elevenLabsApiKey; // Ambil dari settings.js
const API_BASE_URL = "https://api.elevenlabs.io/v1";

// Cache untuk daftar suara agar tidak memanggil API berulang kali
let cachedVoices = null;
let cacheTimestamp = 0;
const CACHE_DURATION = 3600 * 1000; // Cache suara selama 1 jam

// --- Fungsi Handler Plugin ---
async function handler(m, { conn, usedPrefix, args, command, text }) {
  if (!ELEVENLABS_API_KEY || ELEVENLABS_API_KEY === "YOUR_ELEVENLABS_API_KEY") {
    return m.reply("Kunci API ElevenLabs belum dikonfigurasi untuk plugin ini.");
  }

  try {
    // 1. Ekstrak nama suara dari perintah (command)
    const voiceMatch = command.match(/^tts-(.+)/i);
    if (!voiceMatch || !voiceMatch[1]) {
        console.log(`Perintah tidak valid untuk TTS: ${command}`);
        return; 
    }
    const voiceIdentifier = voiceMatch[1].trim().toLowerCase(); // Nama suara dari perintah

    // 2. Teks input adalah seluruh argumen setelah perintah
    const inputText = text.trim();

    if (!inputText) {
        // Jika tidak ada teks, tampilkan cara penggunaan
        const voices = await getVoices(m); // Ambil daftar suara untuk ditampilkan
        const voiceList = voices ? voices.map(v => v.name).join(", ") : "(tidak dapat mengambil daftar suara)";
        return m.reply(`❌ *Format tidak valid*\n\n 📝 Contoh Penggunaan: .tts-<nama_suara> <teks> (.tts-aria Halo apa kabar?)\n
🔊 Suara yang tersedia:\n ${voiceList}`);
    }

    // 3. Dapatkan daftar suara yang tersedia 
    const voices = await getVoices(m);
    if (!voices || voices.length === 0) {
      return m.reply("Tidak dapat mengambil daftar suara dari ElevenLabs. Silakan periksa kunci API atau jaringan.");
    }

    // 4. Cari ID suara berdasarkan nama suara dari perintah
    const selectedVoice = voices.find(v => v.name.toLowerCase() === voiceIdentifier);
    if (!selectedVoice) {
      const availableVoiceNames = voices.map(v => v.name).join(", ");
      return m.reply(`Suara "${voiceIdentifier}" tidak ditemukan. Suara yang tersedia: ${availableVoiceNames}`);
    }
    const voiceId = selectedVoice.voice_id;

    // 5. Panggil API ElevenLabs untuk menghasilkan suara
    m.reply(`Ｌｏａｄｉｎｇ．．．`);
    const audioBuffer = await generateSpeech(inputText, voiceId, m);

    // 6. Kirim audio kembali ke pengguna
    if (audioBuffer) {
      conn.sendMessage(m.chat, { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true }, { quoted: m });
    } else {
      m.reply(`${global.eror}`);
    }

  } catch (error) {
    console.error("TTS Plugin Error:", error);
    m.reply(`Terjadi kesalahan: ${error.message}`);
  }
}

// Fungsi untuk mendapatkan daftar suara yang tersedia
async function getVoices(m) {
  const now = Date.now();
  if (cachedVoices && (now - cacheTimestamp < CACHE_DURATION)) {
    // console.log("Menggunakan cache suara");
    return cachedVoices;
  }

  // console.log("Mengambil daftar suara dari API");
  try {
    const response = await fetch(`${API_BASE_URL}/voices`, {
      headers: { "xi-api-key": ELEVENLABS_API_KEY }
    });
    if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`Kesalahan API (${response.status}): ${response.statusText}. ${errorBody}`);
    }
    const data = await response.json();
    
    // Ambil semua suara dari API
    const allVoicesFromAPI = data.voices.map(v => ({ name: v.name, voice_id: v.voice_id }));

    // Definisikan suara kustom
    const customVoices = [
      { name: "Putra", voice_id: "RWiGLY9uXI70QL540WNd" },
      { name: "Mahaputra", voice_id: "v70fYBHUOrHA3AKIBjPq" },
      { name: "Andi", voice_id: "TMvmhlKUioQA4U7LOoko" }
    ];

    // Gabungkan suara kustom dengan suara dari API 
    // Suara kustom diletakkan di depan
    const combinedVoices = [...customVoices, ...allVoicesFromAPI.filter(apiVoice =>
        !customVoices.some(customVoice => customVoice.name.toLowerCase() === apiVoice.name.toLowerCase())
    )];


    if (!combinedVoices || combinedVoices.length === 0) {
        m.reply("Tidak ada suara yang ditemukan (termasuk suara kustom).");
        return null;
    }

    cachedVoices = combinedVoices; // Cache daftar gabungan
    cacheTimestamp = now;
    // console.log("Suara diambil dan disimpan di cache:", cachedVoices);
    return cachedVoices;

  } catch (error) {
    console.error("Kesalahan saat mengambil suara:", error);
    m.reply(`Kesalahan saat mengambil suara dari ElevenLabs: ${error.message}`);
    return null;
  }
}

// Fungsi untuk menghasilkan suara
async function generateSpeech(text, voiceId, m) {
  try {
    const response = await fetch(`${API_BASE_URL}/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "xi-api-key": ELEVENLABS_API_KEY,
        "Accept": "audio/mpeg"
      },
      body: JSON.stringify({
        text: text,
        model_id: "eleven_multilingual_v2", // Model default yang bagus untuk banyak bahasa
        voice_settings: {
          stability: 0.7,
          similarity_boost: 0.75,
          // style: 0.3, // Opsional: Sesuaikan penekanan gaya
          // use_speaker_boost: true // Opsional: Tingkatkan kejelasa bicara
        }
      })
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Kesalahan API (${response.status}): ${response.statusText}. ${errorBody}`);
    }

    const audioBuffer = await response.arrayBuffer();
    return Buffer.from(audioBuffer);

  } catch (error) {
    console.error("Kesalahan saat menghasilkan suara:", error);
    m.reply(`Kesalahan saat menghasilkan suara: ${error.message}`);
    return null;
  }
}

handler.tags = ["sound"];
handler.command = /^tts-([a-zA-Z0-9]+)$/i; 
handler.limit = true; // Terapkan batas penggunaan 
handler.register = true; // Wajibkan registrasi 
handler.help = ["tts-<nama_suara> <teks>"];

async function updateHelp() {
    try {
        const voices = await getVoices({ reply: console.log }); // Gunakan console.log untuk mock reply
        if (voices && voices.length > 0) {
            handler.help = voices.map(v => `tts-${v.name.toLowerCase()} <teks>`);
            console.log("Bantuan TTS diperbarui dengan daftar suara.");
        } else {
            handler.help = ["tts-<nama_suara> <teks> (gagal mengambil daftar suara)"];
            console.warn("Gagal memperbarui bantuan TTS dengan daftar suara.");
        }
    } catch (error) {
        console.error("Kesalahan saat memperbarui bantuan TTS:", error);
        handler.help = ["tts-<nama_suara> <teks> (error saat mengambil daftar suara)"];
    }
}

module.exports = handler;

