const fetch = require('node-fetch')
const cheerio = require('cheerio')

const isValidWord = (text) => /^[a-zA-Z]{2,}$/.test(text)
const cleanInput = text => text
    .replace(/[\u{1F600}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
    .replace(/[^a-zA-Z]/g, '')
    .toLowerCase()

let timeout = 60000 // ubah waktu disini!!

let handler = async (m, { conn, usedPrefix, command }) => {
    conn.sambungkata = conn.sambungkata || {}
    let id = m.chat

    if (command === 'sambungkata') {
        if (id in conn.sambungkata)
            return conn.reply(m.chat, '_Masih ada game yang belum selesai_', conn.sambungkata[id].message)

        let kataAwal = m.text.split(' ')[1]
        if (!kataAwal || m.text.trim().split(/\s+/).length > 2)
            return conn.reply(m.chat, `📝 Masukan kata awal :\n\nContoh: *${usedPrefix}sambungkata makan*`, m)

        kataAwal = cleanInput(kataAwal)

        if (!isValidWord(kataAwal)) return conn.reply(m.chat, `⚠️ Kata tidak valid!`, m)
        if (!(await cekKataKBBI(kataAwal))) return conn.reply(m.chat, `⚠️ Kata *${kataAwal}* tidak ditemukan di KBBI`, m)

        let caption = `🎮 *SAMBUNG KATA DIMULAI!* 🎮

*📝 PERATURAN :*

1️⃣ Kata pertama : *${kataAwal}*
2️⃣ Kata berikutnya dari huruf : *"${kataAwal.slice(-1).toUpperCase()}"*
3️⃣ Kata wajib sesuai *KBBI*
⏳ Waktu : *60 detik*

✨ Ketik *kata* tanpa reply chat ini!!

> Selamat bermain 🎉`

        let sentMsg = await conn.reply(m.chat, caption, m)

        conn.sambungkata[id] = {
            message: sentMsg,
            kata: kataAwal,
            daftarKata: [kataAwal],
            timeout: setGameTimeout(conn, id, m)
        }
    }

    if (command === 'skipsk') {
        if (!(id in conn.sambungkata))
            return conn.reply(m.chat, '_Tidak ada game yang berjalan_', m)

        clearTimeout(conn.sambungkata[id].timeout)
        conn.reply(m.chat, `⛔ Game dihentikan!\n📜 Kalimat terakhir: "${conn.sambungkata[id].daftarKata.join(' ')}"`, conn.sambungkata[id].message)
        delete conn.sambungkata[id]
    }
}

function setGameTimeout(conn, id, m) {
    return setTimeout(() => {
        if (conn.sambungkata[id]) {
            conn.reply(m.chat, `⏳ Waktu habis!\n📜 Kalimat terakhir: "${conn.sambungkata[id].daftarKata.join(' ')}"`, conn.sambungkata[id].message)
            delete conn.sambungkata[id]
        }
    }, timeout)
}

handler.before = async (m, { conn }) => {
    conn.sambungkata = conn.sambungkata || {}
    let id = m.chat

    if (!m.text || m.fromMe || !(id in conn.sambungkata)) return

    let kataUser = m.text.trim()

    // Kalau lebih dari satu kata, abaikan tanpa respon
    if (kataUser.split(/\s+/).length > 1) return

    kataUser = cleanInput(kataUser)

    if (!kataUser || !isValidWord(kataUser)) return
    let game = conn.sambungkata[id]
    let hurufAwal = game.kata.slice(-1)

    if (!(await cekKataKBBI(kataUser))) return
    if (kataUser[0] !== hurufAwal) return

    game.daftarKata.push(kataUser)
    game.kata = kataUser
    clearTimeout(game.timeout)
    game.timeout = setGameTimeout(conn, id, m)

    conn.reply(m.chat, `✅ Kata *${kataUser}* diterima!\n➡️ Lanjut dengan kata berawalan huruf *"${kataUser.slice(-1).toUpperCase()}"*`, m)
}

async function cekKataKBBI(kata) {
    try {
        const res = await fetch(`https://kbbi.web.id/${kata}`)
        const html = await res.text()
        const $ = cheerio.load(html)
        return $('ol').length > 0 || $('ul').length > 0
    } catch {
        return false
    }
}

handler.help = ['sambungkata', 'skipsk']
handler.tags = ['game']
handler.command = /^sambungkata|skipsk$/i
handler.register = false
handler.group = true

module.exports = handler