// ✨ Plugin tools - gagstock ✨

const WebSocket = require('ws');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // Kirim reaction loading
    await conn.sendMessage(m.chat, {
        react: { text: '⏳', key: m.key }
    });

    const ws = new WebSocket('wss://ws.growagardenpro.com', [], {
        headers: {
            'Host': 'ws.growagardenpro.com',
            'Origin': 'https://growagardenpro.com',
            'User-Agent': 'NekoHost/1.0.0'
        }
    });

    let dataArray = [];
    let isReady = false;

    ws.on('open', () => isReady = true);
    ws.on('message', (data) => {
        try {
            const parsed = JSON.parse(data);
            dataArray.push(parsed);
        } catch {
            dataArray.push(data.toString());
        }
    });
    ws.on('error', (err) => console.error('[✗] Error:', err.message));

    const waitUntilReady = () => new Promise(resolve => {
        const check = () => isReady ? resolve() : setTimeout(check, 100);
        check();
    });

    await waitUntilReady();
    await new Promise(resolve => setTimeout(resolve, 10000));
    ws.close();

    const latestData = dataArray.pop();
    if (!latestData || !latestData.data) {
        await conn.sendMessage(m.chat, {
            react: { text: '⚠️', key: m.key }
        });
        return m.reply('Tidak ada data diterima.');
    }

    const { data } = latestData;
    let textResult = '🌿 *ɢʀᴏᴡ ᴀ ɢᴀʀᴅᴇɴ ʀᴇᴘᴏʀᴛ*\n\n';

    const renderSection = (title, emoji, items) => {
        if (!items || items.length === 0) return '';
        let section = `${emoji} *${title}*\n`;
        for (let item of items) section += `• ${item.name} ➔ ${item.quantity}\n`;
        return section + '\n';
    };

    textResult += renderSection('ꜱᴇᴇᴅꜱ', '🌱', data.seeds);
    textResult += renderSection('ɢᴇᴀʀ', '🛠️', data.gear);
    textResult += renderSection('ᴇɢɢꜱ', '🥚', data.eggs);
    textResult += renderSection('ᴄᴏꜱᴍᴇᴛɪᴄꜱ', '💄', data.cosmetics);
    textResult += renderSection('ʜᴏɴᴇʏ', '🍯', data.honey);

    if (data.weather) {
        textResult += '⛅ *ᴡᴇᴀᴛʜᴇʀ*\n';
        textResult += `• ᴛʏᴘᴇ: ${data.weather.type}\n`;
        textResult += `• ᴀᴄᴛɪᴠᴇ: ${data.weather.active ? '✅ ʏᴇꜱ' : '❌ ɴᴏ'}\n`;
        if (data.weather.effects?.length) {
            textResult += '• ᴇꜰꜰᴇᴄᴛꜱ:\n';
            for (let effect of data.weather.effects) {
                textResult += `   ➔ ${effect}\n`;
            }
        }
        textResult += '\n';
    }

    if (data.weatherHistory) {
        textResult += '📊 *ᴡᴇᴀᴛʜᴇʀ ʜɪꜱᴛᴏʀʏ*\n';
        for (let item of data.weatherHistory) {
            textResult += `• ${item.type} (${item.active ? 'Active' : 'Ended'})\n`;
        }
        textResult += '\n';
    }

    // Format Last Update ke format lokal WIB
    const lastUpdateKey = Object.keys(data).find(k => k.toLowerCase().includes('lastglobalupdate'));
    let updateTime = lastUpdateKey ? data[lastUpdateKey] : null;
    if (updateTime) {
        try {
            let dateObj = new Date(updateTime);
            let tanggal = dateObj.toLocaleDateString('id-ID', {
                day: '2-digit',
                month: 'long',
                year: 'numeric',
                timeZone: 'Asia/Jakarta'
            });
            let jam = dateObj.toLocaleTimeString('id-ID', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false,
                timeZone: 'Asia/Jakarta'
            });
            updateTime = `${tanggal} - ${jam} WIB`;
        } catch {
            updateTime = 'Format waktu tidak valid';
        }
    } else {
        updateTime = 'Data tidak tersedia';
    }

    textResult += `🕒 *ʟᴀꜱᴛ ᴜᴘᴅᴀᴛᴇ:* \n${updateTime}`;

    await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
    });
    await m.reply(textResult.trim());
};

handler.help = ['gagstock'];
handler.tags = ['tools'];
handler.command = ['growgardenstock', 'gagstock', 'stockgag'];
module.exports = handler;