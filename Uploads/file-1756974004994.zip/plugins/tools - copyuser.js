// ✨ Plugin tools - copyuser ✨

let handler = async (m, { conn, groupMetadata }) => {
  if (!m.mentionedJid || m.mentionedJid.length === 0) {
    return m.reply('‼️ *TAG USERNYA*\n\n> Contoh : .copy @armancuki');
  }

  let mentioned = m.mentionedJid[0];
  let number;

  // Cari di participants untuk dapet nomor asli
  if (groupMetadata?.participants) {
    let target = groupMetadata.participants.find(p =>
      p.jid === mentioned || p.jid === mentioned
    );

    if (target?.jid) {
      number = target.jid.replace(/[^0-9]/g, '');
    } else if (target?.jid) {
      number = target.id.replace(/[^0-9]/g, '');
    }
  }

  // Fallback kalau tetap gak dapat nomor
  if (!number || number.length < 5) {
    return m.reply(`❌ Nomor asli user ini tidak dapat ditemukan!`);
  }

  // Kirim tombol salin
  const interactiveMessage = {
    text: `\n 🪀 Nomor user\n ╰┈➤ *${number}*`,
    title: "✅ *BERHASIL COPY NOMOR*",
    footer: "\nᴛᴇᴋᴀɴ ᴛᴏᴍʙᴏʟ ᴅɪʙᴀᴡᴀʜ ɪɴɪ ᴜɴᴛᴜᴋ ᴍᴇɴʏᴀʟɪɴ ɴᴏᴍᴏʀ.",
    interactiveButtons: [
      {
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "📋 SALIN NOMOR",
          id: "copy_number",
          copy_code: number
        })
      }
    ]
  };

  await conn.sendMessage(m.chat, interactiveMessage, { quoted: m });
};

handler.help = ['copy <@user>'];
handler.tags = ['tools'];
handler.command = /^copy$/i;

module.exports = handler;