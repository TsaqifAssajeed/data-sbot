const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('❌ Masukkan username TikTok yang ingin kamu stalk.\n\n📌 *Contoh:* .ttstalk username');

    try {
        const result = await tiktokStalk(text);
        const { userInfo } = result;

        // Ambil avatar
        const avatarUrl = userInfo.avatar;

        // Buat caption dengan emotikon
        let caption = `✨ *TIKTOK STALK RESULT* ✨\n\n`;
        caption += `👤 *Nama:* ${userInfo.nama || '-'}\n`;
        caption += `📛 *Username:* @${userInfo.username || '-'}\n`;
        caption += `🆔 *ID:* ${userInfo.id || '-'}\n`;
        caption += `📝 *Bio:* ${userInfo.bio || 'Tidak ada bio'}\n`;
        caption += `✅ *Verifikasi:* ${userInfo.verifikasi ? '✔️ Ya' : '❌ Tidak'}\n\n`;
        caption += `📊 *Statistik Akun*\n`;
        caption += `👥 Followers: *${userInfo.totalfollowers}*\n`;
        caption += `➡️ Mengikuti: *${userInfo.totalmengikuti}*\n`;
        caption += `❤️ Total Like: *${userInfo.totaldisukai}*\n`;
        caption += `🎞 Total Video: *${userInfo.totalvideo}*\n`;
        caption += `🤝 Teman: *${userInfo.totalteman}*`;

        // Kirim pesan dengan gambar avatar langsung
        await conn.sendMessage(m.chat, {
            image: { url: avatarUrl },
            caption
        }, { quoted: m });

    } catch (error) {
        await m.reply(`❌ Gagal mengambil data: ${error.message}`);
    }
};

handler.command = /^(ttstalk)$/i;
handler.help = ["ttstalk [username]"];
handler.tags = ["stalk","premium"];
handler.premium = true;

module.exports = handler;

async function tiktokStalk(username) {
    try {
        const response = await axios.get(`https://www.tiktok.com/@${username}?_t=ZS-8tHANz7ieoS&_r=1`);
        const html = response.data;
        const $ = cheerio.load(html);
        const scriptData = $('#__UNIVERSAL_DATA_FOR_REHYDRATION__').html();
        const parsedData = JSON.parse(scriptData);

        const userDetail = parsedData.__DEFAULT_SCOPE__?.['webapp.user-detail'];
        if (!userDetail) throw new Error('User tidak ditemukan');

        const userInfo = userDetail.userInfo?.user;
        const stats = userDetail.userInfo?.stats;

        return {
            userInfo: {
                id: userInfo?.id || null,
                username: userInfo?.uniqueId || null,
                nama: userInfo?.nickname || null,
                avatar: userInfo?.avatarLarger || null,
                bio: userInfo?.signature || null,
                verifikasi: userInfo?.verified || false,
                totalfollowers: stats?.followerCount || 0,
                totalmengikuti: stats?.followingCount || 0,
                totaldisukai: stats?.heart || 0,
                totalvideo: stats?.videoCount || 0,
                totalteman: stats?.friendCount || 0,
            }
        };
    } catch (error) {
        throw new Error(error.message);
    }
}
