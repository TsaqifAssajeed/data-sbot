const fetch = require('node-fetch');
const axios = require('axios');

// FlowFalcon Downloader
async function flowFalconDl(ytUrl) {
  try {
    const res = await axios.get(`${global.flowfalcon}/download/ytmp4?url=${encodeURIComponent(ytUrl)}`);
    if (res.data?.status && res.data?.result) {
      return {
        url: res.data.result,
        source: "API Flow Falcon"
      };
    }
    throw 'FlowFalcon tidak memberikan hasil.';
  } catch (e) {
    console.error('[FlowFalcon ERROR]', e.message || e);
    return null;
  }
}

// Botcahx Downloader
async function botcahxDl(ytUrl) {
  try {
    const res = await fetch(`https://api.botcahx.eu.org/api/dowloader/yt?url=${encodeURIComponent(ytUrl)}&apikey=${global.btc}`);
    const data = await res.json();
    if (data?.result?.mp4) {
      return {
        url: data.result.mp4,
        source: "API Botcahx"
      };
    }
    throw 'Botcahx tidak memberikan hasil.';
  } catch (e) {
    console.error('[Botcahx ERROR]', e.message || e);
    return null;
  }
}

// GrabTheClip Scraper
async function grabTheClipDl(ytUrl, quality = 720) {
  const payload = {
    height: quality,
    media_type: "video",
    url: ytUrl
  };

  try {
    const { data } = await axios.post("https://api.grabtheclip.com/submit-download", payload);
    const task = data.task_id;
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    let result;

    do {
      const { data: statusRes } = await axios.get(`https://api.grabtheclip.com/get-download/${task}`);
      result = statusRes;
      if (result.status !== "Success") await delay(3000);
    } while (result.status !== "Success");

    const finalUrl =
      result?.download_urls?.[0]?.url ||
      result?.result?.url ||
      result?.url ||
      null;

    if (!finalUrl) throw 'GrabTheClip tidak memberikan URL video.';

    return {
      url: finalUrl,
      source: "Scrape GrabTheClip.com"
    };
  } catch (e) {
    console.error('[GrabTheClip ERROR]', e.message || e);
    return null;
  }
}

// Handler utama
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Contoh:* ${usedPrefix + command} https://www.youtube.com/watch?v=abc123`;

  m.reply('⏳ Sedang memproses, mohon tunggu...');

  let video = null;

  // 1. Flow Falcon
  video = await flowFalconDl(text);

  // 2. Botcahx (jika FlowFalcon gagal)
  if (!video) video = await botcahxDl(text);

  // 3. GrabTheClip (jika semuanya gagal)
  if (!video) video = await grabTheClipDl(text);

  // Jika semua gagal
  if (!video) throw '❌ Gagal mengunduh video dari ketiga server.';

  // Kirim hasil video hanya sekali
  try {
    await conn.sendMessage(m.chat, {
      video: { url: video.url },
      mimetype: 'video/mp4',
      caption: `✅ Video berhasil diunduh\n🌐 Sumber: *${video.source}*`
    }, { quoted: m });
  } catch (err) {
    console.warn('[❌ GAGAL KIRIM VIDEO]', err);
    await m.reply(`❌ Video berhasil diambil dari *${video.source}*, tapi gagal dikirim ke WhatsApp.\n\n🔗 Link download:\n${video.url}`);
  }
};

handler.help = ['ytmp4'];
handler.command = ['ytmp4', 'ytv', 'mp4'];
handler.tags = ['downloader'];
handler.limit = true;
handler.premium = true;

module.exports = handler;
