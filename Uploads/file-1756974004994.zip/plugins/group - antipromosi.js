// ✨ Plugin group - antipromosi ✨

const moment = require('moment-timezone');
const fs = require('fs');

const promoDbPath = './lib/datapromo.json';

const defaultPromoWords = [
    '#WTS', 'buy pm', 'hub:', 'ingin order?', 'jual cepat', 'buy panel pm', 'buy? pm',
    'melayani :', 'melayani:', 'minat hub', 'minat?', 'need akun', 'need dana', 'open murbug',
    '#WTT', 'pm for price', 'fast order', 'hubungi wa:', 'ready stock', 'order sekarang',
    'promo hari ini', 'cek dm', 'langsung wa', 'murah meriah', 'stok terbatas', 'pm je', 'nego tipis',
];

if (!fs.existsSync(promoDbPath)) {
    fs.writeFileSync(promoDbPath, JSON.stringify(defaultPromoWords, null, 2));
} else {
    try {
        const data = fs.readFileSync(promoDbPath, 'utf8');
        const parsedData = JSON.parse(data);
        if (!Array.isArray(parsedData) || parsedData.length === 0) {
            fs.writeFileSync(promoDbPath, JSON.stringify(defaultPromoWords, null, 2));
        }
    } catch (err) {
        fs.writeFileSync(promoDbPath, JSON.stringify(defaultPromoWords, null, 2));
    }
}

const maxWarnPromo = 3;

const handler = async (m, { usedPrefix, text, command, isOwner, conn }) => {
    if (!conn) throw new Error('Koneksi bot (conn) tidak tersedia!');

    let promoWords = JSON.parse(fs.readFileSync(promoDbPath, 'utf8'));

    if (command === 'listpromo') {
        if (!promoWords.length) throw `⚠️ Belum ada kata atau pola promosi! Tambahkan pakai *${usedPrefix}addpromo* ya!`;

        const greetings = (() => {
            const hours = moment().tz('Asia/Makassar').hour();
            return hours < 6 ? '🌙 Selamat Malam'
                : hours < 12 ? '☀️ Selamat Pagi'
                : hours < 16 ? '🌞 Selamat Siang'
                : hours < 19 ? '🌅 Selamat Sore'
                : '🌙 Selamat Malam';
        })();

        const userName = m.pushName || m.name || 'Sobat';
        const promoList = promoWords
            .sort((a, b) => a.localeCompare(b))
            .map(word => ` ${word}`)
            .join('\n');

        const replyMessage = `${greetings}, ${userName}!\n\n📜 Daftar kata promosi:\n${promoList}\n\nGunakan *${usedPrefix}addpromo* / *${usedPrefix}delpromo* untuk kelola daftar.`;
        return conn.sendMessage(m.chat, { text: replyMessage });
    }

    if (command === 'addpromo') {
        if (!isOwner) throw `🚫 Hanya *Owner* yang bisa menambah kata promosi!`;
        if (!text) throw `❓ Contoh: *${usedPrefix}${command} jual cepat*`;

        const newWord = text.trim().toLowerCase();
        if (promoWords.includes(newWord)) {
            throw `⚠️ Kata *${newWord}* sudah ada di daftar!`;
        }

        promoWords.push(newWord);
        fs.writeFileSync(promoDbPath, JSON.stringify(promoWords, null, 2));
        return conn.sendMessage(m.chat, { text: `✅ Kata *${newWord}* berhasil ditambahkan!` });
    }

    if (command === 'delpromo') {
        if (!isOwner) throw `🚫 Hanya *Owner* yang bisa menghapus kata promosi!`;
        if (!text) throw `❓ Contoh: *${usedPrefix}${command} jual cepat*`;

        const wordToDelete = text.trim().toLowerCase();
        const wordIndex = promoWords.indexOf(wordToDelete);

        if (wordIndex !== -1) {
            promoWords.splice(wordIndex, 1);
            fs.writeFileSync(promoDbPath, JSON.stringify(promoWords, null, 2));
            return conn.sendMessage(m.chat, { text: `🗑️ Kata *${wordToDelete}* berhasil dihapus!` });
        } else {
            throw `❌ Kata *${wordToDelete}* tidak ditemukan. Gunakan *${usedPrefix}listpromo* untuk cek.`;
        }
    }

    throw `⚡ Perintah tidak dikenal! Gunakan: *${usedPrefix}listpromo*, *${usedPrefix}addpromo*, atau *${usedPrefix}delpromo*`;
};

handler.all = async function (m, chatUpdate) {
    const conn = this;
    if (!conn || !m || !m.text || !m.chat || !m.key || m.fromMe) return;

    let chat = global.db.data.chats[m.chat];
    if (!chat || !chat.antiPromo) return;

    let promoWords = JSON.parse(fs.readFileSync(promoDbPath, 'utf8'));
    const messageText = m.text.toLowerCase();
    const who = m.sender;

    if (!(who in global.db.data.users)) {
        global.db.data.users[who] = {};
    }

    if (typeof global.db.data.users[who].warnPromo !== 'number') {
        global.db.data.users[who].warnPromo = 0;
    }

    let warnPromo = global.db.data.users[who].warnPromo;
    const groupMetadata = await conn.groupMetadata(m.chat);
    const isAdmin = groupMetadata.participants.some(p => p.id === who && p.admin);

    // Skip promotion detection for admins
    if (isAdmin) return;

    let detectedPromo = false;
    let detectedWord = '';

    for (const promoWord of promoWords) {
        const escapedWord = promoWord.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(escapedWord, 'i');
        if (regex.test(messageText)) {
            detectedPromo = true;
            detectedWord = promoWord;
            break;
        }
    }

    if (detectedPromo) {
        try {
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.key.participant
                }
            });

            if (warnPromo < maxWarnPromo) {
                global.db.data.users[who].warnPromo += 1;

                await conn.sendMessage(m.chat, {
                    text: `🚨 *Peringatan Promosi* 🚨\n\n✧ *Pengguna:* @${who.split`@`[0]}\n✧ *Peringatan:* ${global.db.data.users[who].warnPromo}/${maxWarnPromo}\n> Pesan telah dihapus karena mengandung promosi!`,
                    contextInfo: {
                        mentionedJid: [who],
                        externalAdReply: {
                            title: '‼️ Promosi Detected',
                            thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/antipromo.png',
                            mediaType: 1,
                            renderLargerThumbnail: false
                        }
                    }
                }, { quoted: m });

            } else {
                global.db.data.users[who].warnPromo = 0;

                await conn.sendMessage(m.chat, {
                    text: `⛔ *@${who.split`@`[0]} melampaui ${maxWarnPromo} peringatan dan akan dikeluarkan dari grup!*`,
                    contextInfo: {
                        mentionedJid: [who],
                        externalAdReply: {
                            title: '⛔ Promosi Detected',
                            thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/antipromo.png',
                            mediaType: 1,
                            renderLargerThumbnail: false
                        }
                    }
                }, { quoted: m });

                await time(3000);
                await conn.groupParticipantsUpdate(m.chat, [who], 'remove');
            }
        } catch (err) {
            console.error('Gagal memproses peringatan promosi:', err);
        }
    }
};

handler.help = ['listpromo', 'addpromo', 'delpromo'];
handler.tags = ['group'];
handler.command = /^listpromo|addpromo|delpromo$/i;
handler.owner = false;
handler.group = true;
handler.botAdmin = true;

module.exports = handler;

const time = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};