let fetch = require('node-fetch')
let PhoneNumber = require('awesome-phonenumber')
const canvacord = require("canvacord")
let levelling = require('../scrape/levelling')

let handler = async (m, { conn, args, usedPrefix, command }) => {
  let who
  if (m.mentionedJid && m.mentionedJid.length > 0) {
    who = m.mentionedJid[0]
  } else if (args[0] && args[0].includes('@')) {
    who = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  } else {
    who = m.sender
  }

  let ppUrl = 'https://i.pinimg.com/736x/dc/26/2f/dc262f1cd78130b972c5dbd8643ad972.jpg'
  try {
    ppUrl = await conn.profilePictureUrl(who, 'image')
  } catch (e) {}

  let pp = await (await fetch(ppUrl)).buffer()
  let user = global.db.data.users[who] || {}
  let { name, premium, level, limit, money, exp, registered, age, role } = user
  let username = await conn.getName(who)

  // Hitung XP Range
  let { min, xp, max } = levelling.xpRange(user.level, global.multiplier)
  let curr = user.exp - min
  let required = xp

  // Rank Card dengan Canvacord
  const rank = new canvacord.Rank()
    .setAvatar(pp)
    .setCurrentXP(curr)
    .setRequiredXP(required)
    .setLevel(Number(user.level) || 0, "LEVEL", true)
    .setRank(1, "RANK", true) // HARUS angka, bukan string
    .setProgressBar("#6636E5", "COLOR")
    .setProgressBarTrack("#FFFFFF")
    .setStatus("online")
    .setUsername(username)
    .setDiscriminator("0001")
    .setLevelColor("#2B2E35", "#2B2E35")
    .setRankColor("#FFFFFF", "#6636E5")

  let str = `

꧁⎝ 𓆩༺ 𝐏𝐑𝐎𝐅𝐈𝐋𝐄 ༻𓆪 ⎠꧂


🪪 Nama
> ✦︎ ${username}
🔖 Username
> ✦︎ ${registered ? name : ''}
🪀 Nomor
> ✦︎ ${PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')}
💳 Limit
> ✦︎ ${limit ?? '0'}
📊 Exp
> ✦︎ ${exp ?? '0'}
⏳ Umur
> ✦︎ ${age ?? '-'}
🎚️ Level
> ✦︎ ${level ?? '0'}
💰 Uang
> ✦︎ ${money ?? '0'}
🏅 Role
> ✦︎ ${role || 'Beginner'}

✩₊˚.⋆☾⋆⁺₊✧✩₊˚.⋆☾⋆⁺₊✧

🎁 Premium : ${premium ? "✅" : "❌"}
📝 Terdaftar : ${registered ? '✅' : '❌'}
`.trim()

  rank.build()
    .then(async data => {
      await conn.sendFile(m.chat, data, "rank.png", str, m, false, {
        mentions: [who]
      })
    })
}

handler.help = ['profile']
handler.tags = ['tools', 'info', 'main']
handler.command = /^(profile|me|pp)$/i

module.exports = handler
