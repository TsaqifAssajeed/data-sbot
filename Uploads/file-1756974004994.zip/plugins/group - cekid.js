// 📝 plugin group - cekid

let handler = async (m, { conn, groupMetadata, args }) => {
  if (args[0]) {
    const groupLinkRegex = /https:\/\/chat\.whatsapp\.com\/(?:invite\/)?([a-zA-Z0-9]+)/;
    const match = args[0].match(groupLinkRegex);
    
    if (match && match[1]) {
      const groupId = match[1];
      try {
        const groupInfo = await conn.groupGetInviteInfo(groupId);
        if (groupInfo) {
          conn.reply(m.chat, groupInfo.id, m);
        } else {
          conn.reply(m.chat, 'Link grup tidak valid atau bot tidak memiliki akses.', m);
        }
      } catch (error) {
        conn.reply(m.chat, 'Gagal memeriksa link grup. Pastikan link valid atau bot memiliki izin.', m);
      }
    } else {
      conn.reply(m.chat, 'Link grup tidak valid. Gunakan format: https://chat.whatsapp.com/xxx', m);
    }
  } else {
    conn.reply(m.chat, await groupMetadata.id, m);
  }
};

handler.help = ['cekid'];
handler.tags = ['group'];
handler.command = /^(cekid|idgc|gcid)$/i;
handler.group = true;

module.exports = handler;