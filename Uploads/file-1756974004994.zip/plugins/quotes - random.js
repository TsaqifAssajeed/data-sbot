// random quotes 
// scraper by : https://whatsapp.com/channel/0029Vb2mOzL1Hsq0lIEHoR0N/117

const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn }) => {
    const result = await quotes();
    if (result) {
        const { quote, author, tags } = result;
        const response = `_${quote}_\n\n~ *${conn.getName(m.sender)}*`;
        m.reply(response)
    } else {
        console.log("tidak ada kata kata untuk hari ini");
    }
};

handler.help = ["quotes *random quotes*"];
handler.tags = ["quotes"];
handler.command = /^(quotesrandom)$/i;

module.exports = handler;

async function quotes() {
    try {
        const { data } = await axios.get(`https://quotes.toscrape.com/random`, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
            }
        });

        const $ = cheerio.load(data);
        const quoteText = $('.quote .text').text().trim();
        const author = $('.quote .author').text().trim();
        const tags = [];

        $('.quote .tags .tag').each((i, el) => {
            tags.push($(el).text().trim());
        });

        return {
            quote: quoteText,
            author: author,
            tags: tags
        };
    } catch (error) {
        console.error('Error fetching quote:', error.message);
        return null;
    }
}