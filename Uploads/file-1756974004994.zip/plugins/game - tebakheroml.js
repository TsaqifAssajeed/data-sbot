const fetch = require('node-fetch')

let hadiah = {
  money: 5000,
  limit: 2,
  exp: 200
}

async function handler(m, { conn }) {
  conn.game = conn.game || {}
  let id = 'tebakheroml_' + m.chat

  if (id in conn.game) {
    return conn.reply(m.chat, '❗ Masih ada game *Tebak Hero ML* yang belum selesai di chat ini.', conn.game[id].msg)
  }

  try {
    const res = await fetch(global.apisiput + 'api/games/tebakheroml')
    const json = await res.json()
    if (!json.status) return m.reply('❌ Gagal mengambil data.')

    const { name, audio } = json.data
    const resAudio = await fetch(audio)
    const audioBuffer = await resAudio.buffer()

    let teks = `🎮 *Tebak Hero ML!*

🧠 Tebak nama hero dari suara berikut ini!
⏱️ Waktu menjawab: *60 detik*
😖 Salah menjawab akan diberi emot 💩

🏳️ Ketik *nyerah* jika ingin menyerah.
🎁 Hadiah jika menang:
+💰 ${hadiah.money} Money
+🔋 ${hadiah.limit} Limit
+✨ ${hadiah.exp} XP`

    // Kirim audio lebih dulu
    let msg = await conn.sendMessage(m.chat, {
      audio: audioBuffer,
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: m })

    // Kirim teks penjelasan setelah audio
    await conn.sendMessage(m.chat, {
      text: teks
    }, { quoted: m })

    conn.game[id] = {
      id,
      name: name.toLowerCase(),
      msg,
      starter: m.sender,
      timeout: setTimeout(() => {
        if (conn.game[id]) {
          conn.reply(m.chat, `⏱️ Waktu habis!\nJawaban: *${name}*`, conn.game[id].msg)
          delete conn.game[id]
        }
      }, 60000)
    }
  } catch (e) {
    console.error(e)
    m.reply('❌ Terjadi kesalahan saat memulai game.')
  }
}

handler.before = async function (m, { conn }) {
  conn.game = conn.game || {}
  let id = 'tebakheroml_' + m.chat
  if (!(id in conn.game)) return false

  let room = conn.game[id]
  let jawaban = room.name
  let userJawab = m.text?.toLowerCase()
  if (!userJawab) return false

  if (/^(me)?nyerah$/i.test(userJawab)) {
    if (m.sender !== room.starter) return m.reply('❌ Hanya pengguna yang memulai game yang dapat menyerah.')
    clearTimeout(room.timeout)
    conn.reply(m.chat, `😔 Menyerah ya?\nJawaban: *${jawaban}*`, room.msg)
    delete conn.game[id]
    return true
  }

  if (userJawab === jawaban) {
    clearTimeout(room.timeout)

    let user = global.db.data.users[m.sender]
    user.money += hadiah.money
    user.limit += hadiah.limit
    user.exp += hadiah.exp

    conn.sendMessage(m.chat, { react: { text: "🎉", key: m.key }})
    conn.reply(m.chat, `🎉 *Benar!* Jawabannya: *${jawaban}*\n\n🎁 Kamu mendapat:\n+💰 ${hadiah.money} Money\n+🔋 ${hadiah.limit} Limit\n+✨ ${hadiah.exp} XP`, room.msg)
    delete conn.game[id]
  } else {
    conn.sendMessage(m.chat, { react: { text: "💩", key: m.key }})
  }

  return true
}

handler.help = ['tebakheroml']
handler.tags = ['game']
handler.command = /^tebakheroml$/i
handler.group = true
handler.register = true

module.exports = handler
