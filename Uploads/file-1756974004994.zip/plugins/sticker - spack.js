const { sticker5 } = require('../lib/sticker');
const axios = require('axios');
const cheerio = require('cheerio');
const { Buffer } = require('buffer');

const handler = async (m, { conn, command, text }) => {
    const error = 'https://telegra.ph/file/12141dd462ecabeed1347.png'; // Ganti dengan URL valid jika diperlukan
    
    // Fungsi untuk menambahkan jeda
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    
    try {
        if (command === 'spack') {
            if (!text) throw new Error('Masukkan nama sticker pack, misal: .spack dino');
            
            // Debugging input
            console.log('Input text:', text);
            const query = text.toLowerCase().replace(/\s+/g, '-');
            console.log('Generated query:', query);
            const url = `https://getstickerpack.com/stickers/${query}`;
            console.log('Target URL:', url);
            
            // Scraping halaman sticker pack
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            
            // Ekstrak URL sticker dari halaman
            const stickerUrls = [];
            $('img[src*="sticker_"]').each((i, elem) => {
                const stickerUrl = $(elem).attr('src');
                if (stickerUrl) stickerUrls.push(stickerUrl);
            });
            
            console.log('Sticker URLs:', stickerUrls);
            if (stickerUrls.length === 0) throw new Error('Sticker pack tidak ditemukan atau tidak ada sticker di halaman ini.');
            
            // Batasi jumlah sticker untuk mencegah rate limiting
            const maxStickers = 30;
            const limitedStickerUrls = stickerUrls.slice(0, maxStickers);
            
            // Konversi dan kirim setiap sticker
            const packname = `Sticker Pack: ${text}`;
            for (const [index, stickerUrl] of limitedStickerUrls.entries()) {
                console.log(`Processing sticker ${index + 1}: ${stickerUrl}`);
                const stiker = await sticker5(stickerUrl, { packname });
                if (!stiker || !(stiker instanceof Buffer)) {
                    console.log(`Failed to convert sticker ${stickerUrl}`);
                    throw new Error(`Gagal mengonversi sticker dari ${stickerUrl}`);
                }
                
                console.log(`Sticker buffer length: ${stiker.length} bytes`);
                
                // Kirim sebagai stickerMessage
                try {
                    await conn.sendMessage(m.chat, {
                        sticker: stiker,
                        mimetype: 'image/webp', // Perbaiki typo dari 'image/webUberp'
                        isAnimated: stickerUrl.endsWith('.gif')
                    }, { quoted: m });
                    console.log(`Sticker ${index + 1} sent successfully`);
                } catch (sendError) {
                    console.log(`Failed to send sticker ${index + 1}:`, sendError);
                    // Fallback ke conn.sendFile
                    await conn.sendFile(m.chat, stiker, `sticker_${index + 1}.webp`, '', m);
                    console.log(`Sticker ${index + 1} sent via sendFile`);
                }
                
                // Tambahkan jeda 500ms untuk menghindari rate limiting
                await delay(500);
            }
            
            await conn.sendMessage(m.chat, { text: `Berhasil mengirim ${limitedStickerUrls.length} sticker dari pack '${text}'` }, { quoted: m });
        }
    } catch (e) {
        console.log('Error:', e);
        if (e.response && e.response.status === 404) {
            await conn.sendMessage(m.chat, { text: `Sticker pack '${text}' tidak ditemukan di getstickerpack.com.` }, { quoted: m });
        } else {
            // Unduh gambar error untuk memastikan buffer valid
            try {
                const errorResponse = await axios.get(error, { responseType: 'arraybuffer' });
                const errorBuffer = Buffer.from(errorResponse.data);
                await conn.sendFile(m.chat, errorBuffer, 'error.webp', '', m);
            } catch (fileError) {
                console.log('Error sending file:', fileError);
                await conn.sendMessage(m.chat, { text: `Terjadi kesalahan saat memproses sticker pack: ${e.message}` }, { quoted: m });
            }
        }
    }
};

handler.command = ['spack'];
handler.tags = ['sticker', 'premium'];
handler.limit = true;
handler.premium = true;

module.exports = handler;