 const axios = require('axios');

let handler = async (m, { conn, text }) => {   
          if (!text) throw m.reply `[ Example ] .yousearch Siapa penemu sepeda uap`;
                try {
                    let yousearch = await (await fetch(`https://endpoint.web.id/ai/yousearch?key=Yori&query=${text}`)).json()
                    let Baby = yousearch.result
                    m.reply(Baby)
                } catch (err) {
                    m.reply("Terjadi Kesalahan Saat Searching")
                }
            }
            
handler.command = ['yousearch', 'you', 'search'];
handler.tags = ["ai"]
handler.help = ['ai', 'search', 'yousearch'].map(a => a + " *[text]*");

module.exports = handler;
