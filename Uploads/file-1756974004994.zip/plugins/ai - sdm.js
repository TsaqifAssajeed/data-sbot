const { GoogleGenAI, Modality } = require('@google/genai')

let handler = async (m, { conn }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    if (!mime.startsWith('image/')) return m.reply('Balas gambar yang ingin dijadikan versi PP Sdm Tinggi.')

    m.reply('⏳ Sedang memproses ke versi PP Sdm Tinggi...')

    let buffer = await q.download()
    let base64 = buffer.toString('base64')

    // Ambil daftar API key dari settings.js
    const apiKeys = global.geminiApi || []


    const tryWithApiKey = async (apiKey) => {
      const ai = new GoogleGenAI({
        apiKey: apiKey
      })

      const contents = [
        { text: 'Edit the uploaded image by keeping the exact same character and anything they are holding without changing their pose, position, or appearance, convert only the character and held objects into grayscale with all visual details preserved (not fully white), add a clean solid black rectangular censor bar that precisely follows the orientation of the character’s eyes and covers only the eyes, remove the entire original background completely and replace it with a flat solid pure red color (#FF0000), and make sure no parts of the character or the items they are holding are removed or replaced.' },
        {
          inlineData: {
            mimeType: mime,
            data: base64
          }
        }
      ]

      return await ai.models.generateContent({
        model: 'gemini-2.0-flash-preview-image-generation',
        contents,
        config: {
          responseModalities: [Modality.TEXT, Modality.IMAGE]
        }
      })
    }

    let res
    let lastError

    // Iterasi melalui setiap API key
    for (let apiKey of apiKeys) {
      try {
        res = await tryWithApiKey(apiKey)
        break // Jika berhasil, keluar dari loop
      } catch (e) {
        lastError = e
        console.log(`Gagal dengan API key: ${apiKey}, mencoba API berikutnya...`)
      }
    }

    // Jika semua API key gagal
    if (!res) {
      throw new Error(`Semua API key gagal: ${String(lastError)}`)
    }

    for (let part of res.candidates?.[0]?.content?.parts || []) {
      if (part.text) await m.reply(part.text)
      if (part.inlineData) {
        let outBuffer = Buffer.from(part.inlineData.data, 'base64')
        await conn.sendMessage(m.chat, { image: outBuffer, caption: '*SDM TINGGI BANGETT!😱*' }, { quoted: m })
      }
    }
  } catch (e) {
    m.reply('❌ Error NJIRR, hubungi owner dengan ketik .report:\n' + String(e))
  }
}

handler.help = ['sdm (kirim/reply image)']
handler.tags = ['ai']
handler.command = /^(sdm|ppsdm|sdmtinggi)$/i

module.exports = handler