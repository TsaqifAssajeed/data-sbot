let handler = async (m, { conn }) => {
      let caption = `
𝗦𝗖𝗥𝗜𝗣𝗧 𝗕𝗢𝗧 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗥𝗜𝗕𝗨𝗔𝗡 𝗙𝗜𝗧𝗨𝗥 𝗚𝗥𝗔𝗧𝗜𝗦 𝗣𝗔𝗡𝗘𝗟 𝗟𝗔𝗚𝗜 ?😱

Hai! Kamu Mau Beli SC Ini? sebelum beli pastikan paham cara instalasi yaa. toton cara install Script disini : https://youtu.be/LkWie8a52N0
  
Script Jagoan Project ini memiliki banyak keuntungan :
✅ Free Konsultasi Penginstalan untuk buyer awam sekalipun dijamin Bisa pasang
✅ Free Panel Selama Sebulan ( +15 hari )
✅ Masuk grup khusus Update dan Grup Diskusi ( permanen )
✅ Type Plugin CJS – Bebas menambahkan fitur
✅ 100% NO ENC – Leluasa dimodifikasi
✅ Memakai Scrape dan API premium yang selalu diperpanjang
✅ Saat ini ada total 1200+ fitur
✅ Bebas Request Fitur, bebas lapor error.
  
Harga SC Saat Ini : 𝗥𝗽. 𝟴𝟬.𝟬𝟬𝟬  ( Harga bisa bertambah seiring berkembangan fitur-fitur, jadi jangan sampai beli di harga pas sudah tinggi-tingginya, ntar nyesel loh ehhehe )

Sung pm  : 
Admin 1 : 62895362282300
Admin 2: 6282252509320
   
> Jagoan Project
      `;

      const p = '62895362282300'; // Nomor dari URL button sebelumnya
      let pp = await conn.profilePictureUrl(`${p}@s.whatsapp.net`, 'image').catch((_) => "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/SCRIPT.png");
      let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:Jagoan;Project\nNICKNAME:🔰 DEVELOPER\nORG:Jagoan Project\nTITLE:Developer\nitem1.TEL;waid=${p}:${p}\nitem1.X-ABLabel:Contact Developer\nitem2.URL:https://wa.me/${p}\nitem2.X-ABLabel:💬 More\nitem3.EMAIL;type=INTERNET:wa.me/${p}\nitem3.X-ABLabel:Email\nitem4.ADR:;;🏴‍☠️ Indonesia;;;;\nitem4.X-ABADR:💬 More\nitem4.X-ABLabel:Lokasi\nEND:VCARD`;

      // Kirim caption dengan gambar terlebih dahulu
      const sentCaption = await conn.sendMessage(m.chat, {
        image: { url: "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/SCRIPT.png" },
        caption: caption
      }, { quoted: m });

      // Kirim kontak setelah caption
      await conn.sendMessage(m.chat, {
        contacts: {
          displayName: 'Jagoan Project',
          contacts: [{ vcard }]
        },
        contextInfo: {
          externalAdReply: {
            title: 'Script Jagoan Project',
            body: 'Chat Untuk Beli..!!',
            thumbnailUrl: pp,
            sourceUrl: null,
            mediaType: 1,
            showAdAttribution: true,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: sentCaption });
}

handler.help = ['script'];
handler.tags = ['main'];
handler.command = /^sc|script$/i;

module.exports = handler;