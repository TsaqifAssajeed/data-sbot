const { Sticker } = require('wa-sticker-formatter');
const { createCanvas, loadImage } = require('canvas');

const handler = async (m, { conn, command, usedPrefix }) => {
  try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!/image\/(png|jpe?g)|webp/.test(mime)) {
      return m.reply(`📸 Reply gambar (PNG/JPEG/WebP) atau sticker dengan caption *${usedPrefix + command}* untuk membuat stiker wanted!`);
    }

    await conn.sendMessage(m.chat, { react: { text: '🎯', key: m.key } });

    const media = await q.download();
    const userImage = await loadImage(media);

    const templateUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/menntahhan.png';
    const template = await loadImage(templateUrl);

    const canvas = createCanvas(template.width, template.height);
    const ctx = canvas.getContext('2d');

    // Draw background
    ctx.drawImage(template, 0, 0, canvas.width, canvas.height);

    // COVER FIT LOGIC
    const frameW = 1000; // area "foto wanted" di tengah, kamu bisa sesuaikan kalau mau
    const frameH = 1000;

    const frameX = (canvas.width - frameW) / 2;
    const frameY = (canvas.height - frameH) / 2;

    const ratioW = frameW / userImage.width;
    const ratioH = frameH / userImage.height;
    const scale = Math.max(ratioW, ratioH); // agar menutupi penuh

    const drawW = userImage.width * scale;
    const drawH = userImage.height * scale;

    const drawX = frameX - (drawW - frameW) / 2;
    const drawY = frameY - (drawH - frameH) / 2;

    ctx.save();
    ctx.beginPath();
    ctx.rect(frameX, frameY, frameW, frameH); // hanya gambar dalam slot ini
    ctx.clip();
    ctx.drawImage(userImage, drawX, drawY, drawW, drawH);
    ctx.restore();

    // Lapisan wanted paling atas
    ctx.drawImage(template, 0, 0, canvas.width, canvas.height);

    const buffer = canvas.toBuffer();
    const sticker = new Sticker(buffer, {
      pack: global.packname || 'Wanted Sticker',
      author: global.author || 'Jagoan Project',
      type: 'full',
      quality: 20
    });

    await conn.sendFile(m.chat, await sticker.toBuffer(), 'wanted.webp', '', m);
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error('Error in .wanted canvas:', e);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply('❌ Gagal membuat stiker wanted. Pastikan gambar valid.');
  }
};

handler.help = ['wanted'];
handler.tags = ['sticker'];
handler.command = /^wanted$/i;
handler.limit = true;

module.exports = handler;