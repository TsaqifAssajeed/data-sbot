let handler = async (m, { conn }) => {
    const pushname = m.pushName || "Kawan";

    // ✅ Respon untuk daget
    const dagetInfo = `Hai ${pushname} Aku lagi sebar DANA Kaget nih! Yuk, sikat segera sebelum melayang 💸💸💸 https://m-dana-id-dana-transfer-luckymoney.free.nf/?fbclid=IwZXh0bgNhZW0CMTEAAR7Pl9x-ro1sxwhWKvEnzLvEWNUXHdRasv6Q22w1LMUggIkKdn3Roqt9opRkPQ_aem_VH8mRyoYJsDwhEJYuLc4uA`;

    await conn.sendMessage(m.chat, {
        text: dagetInfo,
        contextInfo: {
            externalAdReply: {
                title: "DANA - Dompet Digital Indonesia",
                body: "DANA merupakan dompet digital terkemuka di Indonesia yang mendukung transaksi non-tunai dan non-kartu secara digital, baik untuk penggunaan online maupun offline",
                thumbnailUrl: "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/dana%20prank/preview.jpg",
                sourceUrl: "https://m-dana-id-dana-transfer-luckymoney",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
};

handler.customPrefix = /^(daget|dana kaget|claim dana|bagi daget|sedekah daget|jumat berkah)$/i;
handler.command = new RegExp;
handler.fail = null;

module.exports = handler;
