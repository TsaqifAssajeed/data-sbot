const axios = require('axios');
const cheerio = require('cheerio');

async function checkDataBreach(email) {
  try {
    const url = 'https://periksadata.com/';
    const formData = new URLSearchParams();
    formData.append('email', email);

    const response = await axios.post(url, formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    const $ = cheerio.load(response.data);
    const info = $('.text-center.col-md-6.col-lg-5 > div > h2').text();

    // Jika data aman
    if (info.includes('WAH SELAMAT!')) {
      return [];
    }

    const breaches = [];
    $('div.col-md-6').each((i, element) => {
      try {
        const title = $(element).find('div.feature__body > h5').text().trim();
        const boldElements = $(element).find('div.feature__body > p > b');

        if (boldElements.length >= 3) {
          const date = $(boldElements[0]).text().trim();
          const breachedData = $(boldElements[1]).text().trim();
          const totalBreach = $(boldElements[2]).text().trim();
          
          if (title) {
            breaches.push({
              title,
              date,
              breached_data: breachedData,
              total_breach: totalBreach
            });
          }
        }
      } catch (error) {
        console.error('Error parsing breach data:', error);
      }
    });

    return breaches;
  } catch (error) {
    console.error('Error checking data breach:', error.message);
    throw new Error('Gagal terhubung ke PeriksaData.com atau terjadi kesalahan.');
  }
}

const handler = async (m, { conn, text, command }) => {
    if (!text || !text.includes('@')) {
        return m.reply(`❗ Format salah! Masukkan email yang ingin diperiksa.\n\nContoh:\n*.${command} email@contoh.com*`);
    }

    const email = text.trim();
    await m.reply(`🔍 Sedang memeriksa email *${email}* di database kebocoran data...`);

    try {
        const results = await checkDataBreach(email);

        if (results.length === 0) {
            let safeText = `✅ *DATA AMAN*\n\n`;
            safeText += `📧 Email: *${email}*\n`;
            safeText += `📌 Status: *Selamat!* Tidak ditemukan dalam kebocoran data.\n\n`;
            safeText += `💡 Tetap waspada dan ganti password secara berkala!`;
            return m.reply(safeText);
        }

        let breachText = `⚠ *DATA BOCOR TERDETEKSI*\n\n`;
        breachText += `📧 Email: *${email}*\n`;
        breachText += `📊 Ditemukan dalam *${results.length}* kebocoran data:\n\n`;

        results.forEach((item, index) => {
            breachText += `📂 Kebocoran #${index + 1}\n`;
            breachText += `• 🔖 Sumber: *${item.title}*\n`;
            breachText += `• 📅 Tanggal: ${item.date}\n`;
            breachText += `• 📑 Data Bocor: ${item.breached_data}\n`;
            breachText += `• 👥 Total Terdampak: ${item.total_breach}\n\n`;
        });
        
        breachText += `⚠ Segera ganti password pada akun-akun yang terdampak!`;
        m.reply(breachText);

    } catch (e) {
        console.error("PeriksaData Plugin Error:", e);
        m.reply(`❌ Gagal memeriksa data.\n${e.message}`);
    }
};

handler.help = ["cekdata <email>"];
handler.command = ["periksadata", "cekdata"];
handler.tags = ["tools"];
handler.description = "Mengecek apakah email pernah mengalami kebocoran data.";
handler.limit = 5;

module.exports = handler;
