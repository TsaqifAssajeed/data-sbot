// 📝 plugin group - setbye

// 📝 plugin group - setbye
const fs = require('fs')

// Fungsi untuk menyimpan database
function saveDatabase() {
  try {
    fs.writeFileSync('./database.json', JSON.stringify(global.db.data, null, 2))
  } catch (e) {
    console.error('Gagal menyimpan database:', e)
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (text) {
    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
    global.db.data.chats[m.chat].sBye = text
    saveDatabase() // Simpan ke file
    m.reply(`✅ Bye berhasil di atur untuk grup ini menjadi:\n${text.trim()}`)
  } else {
    throw `Teksnya mana?\n\nContoh:\n${usedPrefix + command} Hai @user!\nSelamat datang di @subject\n\n@desc\n\n> Gunakan:\n> @user → Tag member baru\n> @subject → Nama grup\n> @desc → Deskripsi grup`
  }
}

handler.help = ['setbye <teks>']
handler.tags = ['group']
handler.command = /^setbye$/i
handler.group = true
handler.admin = true 

module.exports = handler