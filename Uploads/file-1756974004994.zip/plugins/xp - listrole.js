let handler = async (m, { usedPrefix }) => {
    let role = global.db.data.users[m.sender].role
    m.reply(`
Role kamu adalah = *${role}*
Ketik *${usedPrefix}levelup* untuk memperbarui Role

*List Role*

level  10 = Beginner
level  15 = Kyuu ||
level  20 = Kyuu |
level  25 = Dan ||
level  30 = Dan |
level  35 = Mentor ||
level  40 = Mentor |
level  45 = Master 
level  50 = Rogue
level  55 = Brawler
level  60 = Marauder
level  65 = Berzerker
level  70 = Warrior
level  75 = Avengers 
level  80 = Vindicator
level  85 = Juggernaut
level  90 = Vanquisher
level  95 = Destroyer
level 100 = Conqueror
level 105 = Saviour
level 110 = Champion
level 115 = Overlord
level 120 = Sage
level 125 = Legends
level 130 = Fujin
level 135 = Raijin
level 140 = Yaksa
level 145 = Raksasa
level 150 = Asura  
level 155 = Dragon Lord 
level 160 = Ruby Lord     
level 165 = Ruby Emperor
level 9999 = Ruby Owner                    
  `.trim()

    )
}
handler.help = ['role']
handler.tags = ['xp']
handler.command = /^role$/i


module.exports = handler