const ms = require('ms');
const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');

// Path untuk database pengingat
const libDir = path.join(__dirname, '../lib');
const dbPath = path.join(libDir, 'pengingat.json');

// Buat folder ./lib jika belum ada
if (!fs.existsSync(libDir)) {
  fs.mkdirSync(libDir, { recursive: true });
}

// Inisialisasi database jika belum ada
if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, JSON.stringify({}));
}

// Fungsi untuk membaca database
const readDb = () => JSON.parse(fs.readFileSync(dbPath, 'utf-8'));

// Fungsi untuk menulis ke database
const writeDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

let handler = async (m, { text, conn, participants, command }) => {
  let targetUser = m.sender; // Default ke pengirim
  let pesan, waktu;

  if (command.toLowerCase() === 'remind') {
    // Format: .remind @user <pesan>|<waktu>
    const tagMatch = text.match(/^@(\S+)(?:\s+(.+))?/);
    if (!tagMatch || !tagMatch[2]) {
      return m.reply('‼️ *Format tidak valid*\n\n📝 *Contoh penggunaan:*\n\n> .remind @user makan|13:21\n> .remind @user olahraga|10m');
    }

    const taggedUser = tagMatch[1];
    const remainingText = tagMatch[2].trim();

    if (!remainingText.includes('|')) {
      return m.reply('‼️ *Format tidak valid*\n\n📝 *Contoh penggunaan:*\n\n> .remind @user makan|13:21\n> .remind @user olahraga|10m');
    }

    [pesan, waktu] = remainingText.split('|').map(a => a.trim());

    // Validasi tagged user
    let cleanedTag = taggedUser.replace('@', '');
    let foundUser = participants.find(p => p.id.includes(cleanedTag));
    if (!foundUser && !m.isGroup) {
      foundUser = { id: `${cleanedTag}@s.whatsapp.net` }; // Untuk privat
    }
    if (!foundUser) {
      return m.reply('‼️ *Pengguna tidak ditemukan!* Pastikan tag valid atau pengguna ada di grup.');
    }
    targetUser = foundUser.id;
  } else {
    // Format: .remindme <pesan>|<waktu>
    if (!text.includes('|')) {
      return m.reply('‼️ *Format tidak valid*\n\n📝 *Contoh penggunaan:*\n\n> .remindme makan|13:21\n> .remindme olahraga|10m');
    }
    [pesan, waktu] = text.split('|').map(a => a.trim());
  }

  if (!pesan || !waktu) {
    return m.reply('‼️ *Format tidak valid*\n\n– Kamu harus memasukkan pesan dan waktu.\n\n📝 *Contoh penggunaan:*\n\n> .remind @user makan|13:21\n> .remindme olahraga|20h');
  }

  // Konfigurasi zona waktu (default: WITA)
  const timeZoneConfig = {
    WIB: false,  // Asia/Jakarta
    WITA: true,  // Asia/Makassar
    WIT: false   // Asia/Jayapura
  };

  let timeZone;
  if (timeZoneConfig.WIB) timeZone = 'Asia/Jakarta';
  else if (timeZoneConfig.WITA) timeZone = 'Asia/Makassar';
  else if (timeZoneConfig.WIT) timeZone = 'Asia/Jayapura';
  else timeZone = 'Asia/Makassar'; // Default ke WITA

  // Validasi format waktu
  const timePattern = /^(\d+)(s|m|h)$/i; // Untuk detik, menit, jam
  const clockPattern = /^(\d{1,2}):(\d{2})$/; // Untuk format jam (HH:mm)
  const dateClockPattern = /^(\d{1,2})-(\d{1,2}):(\d{2})$/; // Untuk format tanggal dan jam (DD-HH:mm)

  let delay, targetTime;

  if (timePattern.test(waktu)) {
    delay = ms(waktu.toLowerCase());
    if (!delay || delay < 1000) {
      return m.reply('‼️ *Minimal waktu satu detik!*');
    }
    targetTime = moment().tz(timeZone).add(delay, 'ms');
  } else if (clockPattern.test(waktu)) {
    const [hours, minutes] = waktu.split(':').map(Number);
    if (hours > 23 || minutes > 59) {
      return m.reply('‼️ *Format jam tidak valid!* Gunakan HH:mm (contoh: 13:21).');
    }
    targetTime = moment().tz(timeZone).set({ hour: hours, minute: minutes, second: 0 });
    if (targetTime.isBefore(moment().tz(timeZone))) {
      targetTime.add(1, 'day');
    }
    delay = targetTime.diff(moment().tz(timeZone));
  } else if (dateClockPattern.test(waktu)) {
    const [day, hours, minutes] = waktu.split(/[-:]/).map(Number);
    const currentYear = moment().tz(timeZone).year();
    const currentMonth = moment().tz(timeZone).month();
    if (day < 1 || day > 31 || hours > 23 || minutes > 59) {
      return m.reply('‼️ *Format tanggal/jam tidak valid!* Gunakan DD-HH:mm (contoh: 13-13:21).');
    }
    targetTime = moment().tz(timeZone).set({
      year: currentYear,
      month: currentMonth,
      date: day,
      hour: hours,
      minute: minutes,
      second: 0
    });
    if (targetTime.isBefore(moment().tz(timeZone))) {
      return m.reply('‼️ *Tanggal/jam sudah lewat!* Pilih waktu di masa depan.');
    }
    delay = targetTime.diff(moment().tz(timeZone));
  } else {
    return m.reply('‼️ *Format waktu tidak valid!*\n\n– Gunakan:\n  - `s` (detik), `m` (menit), `h` (jam)\n  - HH:mm (jam)\n  - DD-HH:mm (tanggal dan jam)');
  }

  if (delay <= 0) {
    return m.reply('‼️ *Waktu tidak valid!* Pastikan waktu di masa depan.');
  }

  // Simpan pengingat ke database
  const db = readDb();
  const chatId = m.chat; // ID grup atau privat
  if (!db[chatId]) db[chatId] = [];
  const reminderId = Date.now().toString();
  db[chatId].push({
    id: reminderId,
    pesan,
    targetUser,
    targetTime: targetTime.toISOString(),
    delay,
    chatId
  });
  writeDb(db);

  // Kirim konfirmasi
  await conn.reply(m.chat, `✅ *Pengingat telah diterima.*\n\n– Bot akan mengingatkan @${targetUser.split('@')[0]} sesuai format yang diminta.\n\n– ⏰ Waktu: *${moment(targetTime).format('DD-MM-YYYY HH:mm')} ${timeZone.split('/')[1]}*\n\n– 📍 Untuk: *${pesan}*`, m, { mentions: [targetUser] });

  // Jadwalkan pengingat
  setTimeout(() => {
    const currentDb = readDb();
    const reminder = currentDb[chatId]?.find(r => r.id === reminderId);
    if (reminder) {
      conn.sendMessage(reminder.chatId, {
        text: `⏰ *KRING!! KRINGG!! KRINGGG!!!*\n\n– Haii @${reminder.targetUser.split('@')[0]}, sudah waktunya *${reminder.pesan}*`,
        mentions: [reminder.targetUser]
      }, { quoted: m });

      // Hapus pengingat dari database setelah dikirim
      currentDb[chatId] = currentDb[chatId].filter(r => r.id !== reminderId);
      if (currentDb[chatId].length === 0) delete currentDb[chatId];
      writeDb(currentDb);
    }
  }, delay);
};

handler.help = ['remind @user <pesan>|<waktu>', 'remindme <pesan>|<waktu>'];
handler.tags = ['tools','group'];
handler.command = /^(remind|remindme)$/i;
//handler.group = true; // Bisa di grup
//handler.private = true; // Bisa di privat

module.exports = handler;