const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const cron = require('node-cron');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// Gunakan direktori persisten
const TMP_DIR = './temp';

async function ensureTmpDir() {
    try {
        await fsPromises.mkdir(TMP_DIR, { recursive: true });
        await fsPromises.access(TMP_DIR, fs.constants.W_OK | fs.constants.R_OK);
        //console.log(`Folder ${TMP_DIR} siap digunakan`);
    } catch (e) {
        //console.error('Gagal memastikan folder tmp:', e);
        throw new Error('Tidak dapat mengakses atau membuat folder tmp');
    }
}

async function checkTmpOnStart() {
    try {
        const files = await fsPromises.readdir(TMP_DIR);
        if (files.length === 0) {
            //console.warn('Peringatan: Folder tmp kosong. Tidak ada pesan sementara ditemukan.');
        } else {
          //  console.log(`Ditemukan ${files.length} file di folder tmp`);
        }
    } catch (e) {
       // console.error('Gagal memeriksa folder tmp saat start:', e);
    }
}

async function saveMessageToTmp(chatId, messageId, messageData) {
    try {
        const fileName = `pesan_sementara_${chatId}_${messageId}.json`;
        const filePath = path.join(TMP_DIR, fileName);
        let mediaFilePath = null;

        const messageType = Object.keys(messageData.message || {})[0];
        if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(messageType)) {
            const mediaMsg = messageData.message[messageType];
            if (mediaMsg.url) {
                const stream = await downloadContentFromMessage(mediaMsg, messageType.replace('Message', ''));
                let buffer = Buffer.concat([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                const ext = messageType === 'stickerMessage' ? 'webp' : (mediaMsg.mimetype?.split('/')[1] || 'bin');
                mediaFilePath = path.join(TMP_DIR, `media_${chatId}_${messageId}.${ext}`);
                await fsPromises.writeFile(mediaFilePath, buffer);
            }
        }

        const safeMessage = JSON.parse(JSON.stringify(messageData, (key, value) => {
            if (key === 'buffer' || key === 'stream') return undefined;
            return value;
        }));

        await fsPromises.writeFile(filePath, JSON.stringify({
            ...safeMessage,
            mediaFilePath,
            timestamp: Date.now()
        }));
    } catch (e) {
        console.error('Gagal menyimpan pesan ke tmp:', e);
    }
}

async function getMessageFromTmp(chatId, messageId) {
    try {
        const fileName = `pesan_sementara_${chatId}_${messageId}.json`;
        const filePath = path.join(TMP_DIR, fileName);
        const data = await fsPromises.readFile(filePath, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return null;
    }
}

function startCleanupJob() {
    cron.schedule('0 3 * * *', async () => {
        try {
            console.log('Memulai pembersihan tmp...');
            const files = await fsPromises.readdir(TMP_DIR);
            const now = Date.now();
            const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;

            for (const file of files) {
                if (file.startsWith('pesan_sementara_')) {
                    const filePath = path.join(TMP_DIR, file);
                    const data = JSON.parse(await fsPromises.readFile(filePath, 'utf8'));
                    if (now - data.timestamp > sevenDaysInMs) {
                        await fsPromises.unlink(filePath);
                        if (data.mediaFilePath) {
                            try {
                                await fsPromises.unlink(data.mediaFilePath);
                            } catch (e) {
                                console.error(`Gagal menghapus media: ${data.mediaFilePath}`, e);
                            }
                        }
                        console.log(`Hapus file lama: ${file}`);
                    }
                }
            }
            console.log('Pembersihan tmp selesai');
        } catch (e) {
            console.error('Gagal membersihkan tmp:', e);
        }
    }, {
        timezone: 'Asia/Makassar'
    });
}

// Inisialisasi
ensureTmpDir().then(() => {
    checkTmpOnStart();
    startCleanupJob();
});

async function before(m, { isAdmin, isBotAdmin, conn }) {
    if (m.isBaileys && m.fromMe) return;

    let chat = global.db.data.chats[m.chat];

    if (m.message && m.isGroup && chat.antiDelete) {
        await saveMessageToTmp(m.chat, m.id, m);
    }

    if (chat.antiDelete && m.message && m.message.protocolMessage && m.isGroup) {
        if (isBotAdmin) {
            if (m.message.protocolMessage.type === 0) {
                try {
                    let deletedMsg = m.message.protocolMessage;
                    let key = deletedMsg.key;
                    let sender = key.participant || m.sender;
                    const senderName = m.pushName || (await conn.getName(sender)) || sender.split('@')[0];

                    let cachedMsg = await getMessageFromTmp(m.chat, key.id);

                    if (cachedMsg && cachedMsg.message) {
                        await conn.sendMessage(m.chat, {
                            text: `⚠️ *Pesan Dihapus Terdeteksi!*\n` +
                                  `• Pengirim: @${sender.split('@')[0]}\n` +
                                  `• Pesan akan diteruskan di bawah\n\n` +
                                  `> Fitur antidelete aktif! .off antidelete untuk mematikan (Admin Only)`,
                            contextInfo: {
                                mentionedJid: [sender],
                                externalAdReply: {
                                    title: '‼️ Pesan Di Teruskan',
                                    body: `@${senderName} terdeteksi menghapus pesan`,
                                    thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ANTIDELTE.png',
                                    sourceUrl: '',
                                    mediaType: 1,
                                    renderLargerThumbnail: false
                                }
                            }
                        }, {
                            quoted: {
                                key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' },
                                message: { conversation: 'Deleted Message Detected' }
                            }
                        });

                        let messageType = Object.keys(cachedMsg.message)[0];
                        let forwardedMessage;

                        if (messageType === 'conversation' || messageType === 'extendedTextMessage') {
                            forwardedMessage = {
                                text: cachedMsg.message.conversation || cachedMsg.message.extendedTextMessage?.text,
                                contextInfo: {
                                    forwardingScore: 500,
                                    isForwarded: true
                                }
                            };
                            await conn.sendMessage(m.chat, forwardedMessage);
                        } else if (['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage'].includes(messageType)) {
                            let mediaMsg = cachedMsg.message[messageType];
                            if (cachedMsg.mediaFilePath && await fsPromises.access(cachedMsg.mediaFilePath).then(() => true).catch(() => false)) {
                                const mediaTypeMap = {
                                    imageMessage: 'image',
                                    videoMessage: 'video',
                                    documentMessage: 'document',
                                    audioMessage: 'audio',
                                    stickerMessage: 'sticker'
                                };
                                forwardedMessage = {
                                    [mediaTypeMap[messageType]]: {
                                        stream: fs.createReadStream(cachedMsg.mediaFilePath),
                                        mimetype: mediaMsg.mimetype,
                                        caption: mediaMsg.caption || '',
                                        fileName: mediaMsg.fileName || undefined,
                                        ...(messageType === 'stickerMessage' ? { isAnimated: mediaMsg.isAnimated || false } : {})
                                    },
                                    contextInfo: {
                                        forwardingScore: 500,
                                        isForwarded: true
                                    }
                                };
                                await conn.sendMessage(m.chat, forwardedMessage);
                            } else {
                                await conn.sendMessage(m.chat, {
                                    text: `⚠️ *Pesan Media Dihapus Terdeteksi!*\n` +
                                          `• Pengirim: @${sender.split('@')[0]}\n` +
                                          `• Media tidak dapat diteruskan karena file tidak ditemukan.\n\n` +
                                          `> Fitur antidelete aktif! .off antidelete untuk mematikan (Admin Only)`,
                                    contextInfo: {
                                        mentionedJid: [sender],
                                        externalAdReply: {
                                            title: '‼️ Pesan Di Teruskan',
                                            body: `@${senderName} terdeteksi menghapus pesan`,
                                            thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ANTIDELTE.png',
                                            sourceUrl: '',
                                            mediaType: 1,
                                            renderLargerThumbnail: false
                                        }
                                    }
                                }, {
                                    quoted: {
                                        key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' },
                                        message: { conversation: 'Deleted Message Detected' }
                                    }
                                });
                            }
                        } else {
                            await conn.sendMessage(m.chat, {
                                text: `Pesan Dihapus Terdeteksi!\n` +
                                      `• Pengirim: @${sender.split('@')[0]}\n` +
                                      `• Jenis pesan tidak didukung untuk diteruskan.\n` +
                                      `> Untuk mematikan: .off antidelete (Admin Only)`,
                                contextInfo: {
                                    mentionedJid: [sender],
                                    externalAdReply: {
                                        title: '‼️ Pesan Di Teruskan',
                                        body: 'Ya maaap 👉🏻👈🏻',
                                        thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ANTIDELTE.png',
                                        sourceUrl: '',
                                        mediaType: 1,
                                        renderLargerThumbnail: false
                                    }
                                }
                            }, {
                                quoted: {
                                    key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' },
                                    message: { conversation: 'Deleted Message Detected' }
                                }
                            });
                        }
                    } else {
                        await conn.sendMessage(m.chat, {
                            text: `⚠️ *Pesan Dihapus Terdeteksi!*\n` +
                                  `• Pengirim: @${sender.split('@')[0]}\n` +
                                  `• Pesan tidak dapat diteruskan (data tidak valid atau sudah dihapus)\n\n` +
                                  `> Fitur antidelete aktif! .off antidelete untuk mematikan (Admin Only)`,
                            contextInfo: {
                                mentionedJid: [sender],
                                externalAdReply: {
                                    title: '‼️ Pesan Di Teruskan',
                                    body: `@${senderName} terdeteksi menghapus pesan`,
                                    thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ANTIDELTE.png',
                                    sourceUrl: '',
                                    mediaType: 1,
                                    renderLargerThumbnail: false
                                }
                            }
                        }, {
                            quoted: {
                                key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' },
                                message: { conversation: 'Deleted Message Detected' }
                            }
                        });
                    }
                } catch (e) {
                    console.error("Error in antidelete:", e);
                    await conn.sendMessage(m.chat, {
                        text: `⚠️ *Error Antidelete* ⚠️\n` +
                              `Gagal memproses pesan yang dihapus: ${e.message}`,
                        contextInfo: {
                            externalAdReply: {
                                title: '‼️ Pesan Di Teruskan',
                                body: `@${sender.split('@')[0]} terdeteksi menghapus pesan`,
                                thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/ANTIDELTE.png',
                                sourceUrl: '',
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        }
                    }, {
                        quoted: {
                            key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '17608914335-1615035634@g.us' },
                            message: { conversation: 'Deleted Message Detected' }
                        }
                    });
                }
            }
        }
    }
    return;
}

module.exports = { before };