/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '')
  }

  text = no(text)

  let user
  let number

  if (!text && !m.quoted) {
    return conn.reply(m.chat, `*Masukkan nomor atau tag user yang mau di ${command} bang*`, m)
  }

  try {
    if (text) {
      number = text
      user = number + '@s.whatsapp.net'
    } else if (m.quoted && m.quoted.sender) {
      user = m.quoted.sender
      number = user.split('@')[0]
    } else if (m.mentionedJid && m.mentionedJid[0]) {
      user = m.mentionedJid[0]
      number = user.split('@')[0]
    } else {
      return conn.reply(m.chat, `❌ *Gagal mengidentifikasi user! Masukkan nomor atau tag user yang valid*`, m)
    }

    let action = command.toLowerCase() === 'block' ? 'block' : 'unblock'
    await conn.updateBlockStatus(user, action)
    
    conn.reply(m.chat, `✅ Berhasil ${action === 'block' ? 'memblokir user' : 'membuka blokir user'}\n\n– nama : @${number}`, null, {
      contextInfo: {
        mentionedJid: [user]
      }
    })

  } catch (e) {
    console.error(e)
    conn.reply(m.chat, `‼️ *Terjadi kesalahan saat ${command} user!*`, m)
  }
}

handler.help = ['block <@user/nomor>', 'unblock <@user/nomor>']
handler.tags = ['owner']
handler.command = /^(block|unblock)$/i
handler.owner = true

module.exports = handler