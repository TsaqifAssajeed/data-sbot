let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.skill)}”`, m)
}
handler.help = ['cekskill']
handler.tags = ['cek']
handler.command = /^(cekskill)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.skill = [
'pengendali air muani', 'bisa menghilang kalo liat cewek cantik/cowok ganteng', 'bisa menyamarkan keberadaan nya dari orang orang sekitar (kasian NPC)', 'kentut nya ber api', 'menggandakan uang (Di Print Doang Njir Menggandakan Apaan)', 'Pengendali Pasir + Semen (Nguli Njir)', 'ahli ngocok (100 Kocokan Semenit)', 'bisa coli 100 kali sehari tanpa merasa lelah', 'ahli ngoding (Kyk Aping)', 'menguasai seluruh elemen', 'gapunya skill (Kasian)', 'memanipulasi orang (dikasih muani njir orang nya)', 'kemampuan untuk melihat dan melacak tobrut', 'ahli nyari situs bokep enak', 'ahli membuat pudding coklat seperti pak hambali', 'ahli di segala mata pelajaran', 'kepintaran seperti Amba Einstein', 'jago tidur (Bisa Tidur 3 Hari Gak Bangun Bangun Njir)',
]