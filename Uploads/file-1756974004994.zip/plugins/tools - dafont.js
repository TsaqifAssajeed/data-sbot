const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) {
    throw `*Cara Pakai: ${usedPrefix}${command} <subcommand> [query/link]*\n\n` +
          `Subcommand:\n` +
          `1. *search [nama_font]* - Cari font berdasarkan nama\n` +
          `2. *dl [link_download]* - Unduh font dari link\n\n` +
          `Contoh:\n` +
          `${usedPrefix}${command} search fancy\n` +
          `${usedPrefix}${command} dl https://dl.dafont.com/dl/?f=fancy_nancy_2`;
  }

  let [subcommand, ...query] = args;
  subcommand = subcommand?.toLowerCase();
  let queryText = query.join(' ');

  if (subcommand === 'search') {
    if (!queryText) throw 'Masukkan nama font untuk dicari!';
    await handleSearch(m, conn, queryText);
  } else if (subcommand === 'dl') {
    if (!queryText) throw 'Masukkan link download!';
    await handleDownload(m, conn, queryText);
  } else {
    throw `Subcommand tidak valid! Gunakan:\n` +
          `${usedPrefix}${command} search [nama_font]\n` +
          `${usedPrefix}${command} dl [link_download]`;
  }
};

async function handleSearch(m, conn, query) {
  await conn.sendMessage(m.chat, { text: 'Mencari font...' }, { quoted: m });

  try {
    let result = await dafont(query);
    if (result.length === 0) {
      throw `Font "${query}" tidak ditemukan!`;
    }

    let teks = `*『 PENCARIAN DAFONT 』*\n\n`;
    result.forEach((font, i) => {
      teks += `*${i + 1}. ${font.name}*\n` +
              `┌─────────────────\n` +
              `├ *Pembuat:* ${font.creator}\n` +
              `├ *Total Unduhan:* ${font.total_down}\n` +
              `├ *Link:* ${font.link}\n` +
              `└─────────────────\n\n`;
    });
    teks += `Untuk mengunduh, gunakan:\n*.dafont dl [link]*`;

    await conn.sendMessage(m.chat, { text: teks }, { quoted: m });
  } catch (error) {
    console.error(error);
    throw 'Gagal mencari font. Coba lagi nanti.';
  }
}

async function handleDownload(m, conn, url) {
  if (!url.startsWith('https://dl.dafont.com/')) {
    throw 'Link download tidak valid!';
  }

  await conn.sendMessage(m.chat, { text: 'Mengunduh font...' }, { quoted: m });

  try {
    const response = await axios({
      method: 'get',
      url,
      responseType: 'arraybuffer',
    });

    const fontName = url.split('=').pop();
    const fileName = `${fontName}.zip`;

    await conn.sendMessage(m.chat, {
      document: response.data,
      mimetype: 'application/zip',
      fileName,
    }, { quoted: m });
  } catch (error) {
    console.error(error);
    throw 'Gagal mengunduh font. Coba lagi nanti.';
  }
}

async function dafont(query) {
  try {
    const { data } = await axios.get('https://www.dafont.com/search.php?q=' + encodeURIComponent(query));
    const $ = cheerio.load(data);
    const result = [];

    $('.lv1left.dfbg').each((i, el) => {
      let elem = $(el).text();
      let name = elem.split('by')[0].trim();
      let creator = elem.split('by')[1]?.trim() || 'Tidak Diketahui';
      let total_down = $(el).next().next().find('.light').text().trim() || 'N/A';
      let link = $(el).next().next().next().find('a.dl').attr('href');
      if (link) {
        result.push({
          name,
          creator,
          total_down,
          link: 'https:' + link,
        });
      }
    });

    return result;
  } catch (error) {
    throw error;
  }
}

handler.command = /^dafont$/i;
handler.tags = ['tools'];
module.exports = handler;
