let handler = async (m, { conn, usedPrefix, command }) => {
    let who;
    if (m.isGroup) {
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            who = m.mentionedJid[0];
        } else if (m.quoted) {
            who = m.quoted.sender;
        } else {
            who = m.sender;
        }
    } else {
        who = m.sender;
    }

    if (!who) throw '*[ ! ] User tidak valid!*';
    
    let users = global.db.data.users;
    if (!users[who]) users[who] = { limit: 0 };

    const fdoc = {
        key: {
            remoteJid: 'status@broadcast',
            participant: '0@s.whatsapp.net'
        },
        message: {
            documentMessage: {
                title: namebot,
            }
        }
    };

    await conn.reply(m.chat, `Sisa Limit @${who.split('@')[0]} Adalah ${users[who].limit}`, m, { contextInfo: { mentionedJid: [who] } });
};

handler.help = ['limit [@user | reply]'];
handler.tags = ['xp'];
handler.command = /^(limit|ceklimit)$/i;

module.exports = handler;