// 📝 plugin group - addpoin

// 📝 plugin group - addpoin

const fs = require('fs');
const path = require('path');

// Fungsi untuk menyimpan data
const libDir = path.join(__dirname, '../lib');
const poinFile = path.join(libDir, 'data_poin.json');

// Pastikan folder dan file ada
if (!fs.existsSync(libDir)) fs.mkdirSync(libDir, { recursive: true });
if (!fs.existsSync(poinFile)) fs.writeFileSync(poinFile, JSON.stringify({}));

// Fungsi load dan save poin
function loadPoin() {
  return JSON.parse(fs.readFileSync(poinFile));
}
function savePoin(data) {
  fs.writeFileSync(poinFile, JSON.stringify(data, null, 2));
}

let handler = async (m, { conn, text, args, command }) => {
  const data = loadPoin();
  const groupId = m.chat;
  data[groupId] = data[groupId] || {};

  const mention = m.mentionedJid[0];
  const jumlah = parseInt(args[1]);

  if (command === 'addpoin') {
    if (!mention) return m.reply('*❌ Format salah!*\n\n📝 Contoh:\n.addpoin @user 10');
    if (isNaN(jumlah)) return m.reply('😔 Jumlah poin tidak valid!');

    const userId = mention;
    data[groupId][userId] = (data[groupId][userId] || 0) + jumlah;
    savePoin(data);

    return m.reply(`✅ Poin ditambahkan\n\n🪪 Nama: ${await conn.getName(userId)}\n🪙 Poin: +${jumlah} poin`);
  }

  if (command === 'rempoin') {
    if (!mention) return m.reply('*❌ Format salah!*\n\n📝 Contoh:\n.rempoin @user 5');
    if (isNaN(jumlah)) return m.reply('😔 Jumlah poin tidak valid!');

    const userId = mention;
    data[groupId][userId] = Math.max((data[groupId][userId] || 0) - jumlah, 0);
    savePoin(data);

    return m.reply(`✅ Poin dikurangi\n\n🪪 Nama: ${await conn.getName(userId)}\n🪙 Poin: -${jumlah} poin`);
  }

  if (command === 'toppoin') {
    const poinList = Object.entries(data[groupId])
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([user, poin], i) => `${i + 1}. @${user.split('@')[0]} *${poin} poin* 🪙`)
      .join('\n');

    if (!poinList) return m.reply('😔 Belum ada data poin di grup ini.');
    return m.reply(`🫅🏻 LIST TOP POIN :\n\n${poinList}`, null, {
      mentions: Object.keys(data[groupId])
    });
  }

  if (command === 'delpoin') {
    if (mention) {
      const userId = mention;
      if (!data[groupId][userId]) return m.reply('😔 User belum memiliki poin.');
      delete data[groupId][userId];
      savePoin(data);
      return m.reply(`🗑️ Poin untuk ${await conn.getName(userId)} berhasil direset!`);
    } else {
      data[groupId] = {};
      savePoin(data);
      return m.reply('🗑️ Semua poin di grup ini telah dihapus!');
    }
  }

  if (command === 'poin') {
    if (args[0] === 'info') {
      return m.reply(`📘 *TUTORIAL FITUR POIN* 🪙

Berikut daftar perintah yang bisa digunakan:

📌 *.addpoin @user <jumlah>*
➠ Menambahkan poin ke user.
🧩 Contoh: *.addpoin @andi 10*

📌 *.rempoin @user <jumlah>*
➠ Mengurangi poin dari user.
🧩 Contoh: *.rempoin @andi 5*

📌 *.delpoin @user*
➠ Reset poin user jadi 0.
🧩 Contoh: *.delpoin @andi*

📌 *.delpoin*
➠ Hapus semua data poin grup.

📌 *.toppoin*
➠ Melihat 10 besar user dengan poin tertinggi.

📌 *.poin @user*
➠ Melihat jumlah poin user.

📌 *.poin info*
➠ Menampilkan tutorial ini. 🥰

🔐 *Hanya admin yang bisa menggunakan perintah-perintah ini.*
`);
    }

    if (mention) {
      const userId = mention;
      const poin = data[groupId][userId] || 0;
      return m.reply(`📊 Poin untuk *${await conn.getName(userId)}* adalah: *${poin} poin* 🪙`);
    }

    return m.reply('❌ Format salah!\n\n📝 Contoh:\n.poin @user\n.poin info');
  }
};

handler.help = ['addpoin <@user> <jumlah>', 'rempoin <@user> <jumlah>', 'delpoin [@user]', 'toppoin', 'poin @user/info'];
handler.tags = ['group'];
handler.command = /^addpoin|rempoin|delpoin|toppoin|poin$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;