
let handler = async (m, { conn }) => {
let capt = `
╔═════════════════❑
║     🤖 *LIST SEWA JAGPRO* 🤖
╟─────────────────
 📅  1 Minggu : Rp.10.000
 📅  2 Minggu : Rp.15.000
 📅  1 Bulan  : Rp.20.000
═══════════════════❏
🛠️ *Sewa bot bisa memasukkan bot ke grup dan mendapatkan premium sehingga bisa mengakses fitur premium di bot.*

📲 *Pembayaran?*
- Hanya Menerima *Dana:* ${dana}
Ketik *[ .owner ]* untuk membeli fitur premium ke owner langsung

`;

conn.sendMessage(m.chat, {
      text: capt,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true,
      title: `List Harga Sewa ${namebot}`,
      body: author,
      thumbnailUrl: thumb,
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}, { quoted: m })
}
handler.help = ['sewabot']
handler.tags = ['info']
handler.command = /^(rental|sewa|sewabot)$/i

module.exports = handler