// 📝 plugin jpmch - kirim pesan ke semua saluran

// ✨ Plugin jpmch - kirim pesan ke saluran ✨

let handler = async (m, { conn, text, command }) => {
    // Konfigurasi delay dalam detik
    const delayjpmch = 5;

    if (command === 'listchannels') {
        // Ambil semua saluran
        let channels = Object.entries(conn.chats)
            .filter(([jid, chat]) => jid.endsWith('@newsletter') && chat.isChats)
            .map(v => ({ jid: v[0], metadata: v[1].metadata || {} }));

        let response = `📋 *Daftar Saluran:*\n\n`;
        if (channels.length === 0) {
            response += `Tidak ada saluran yang ditemukan. 😅\n`;
        } else {
            channels.forEach(c => {
                response += `JID: ${c.jid}\n`;
                response += `Metadata: ${JSON.stringify(c.metadata, null, 2)}\n\n`;
            });
        }
        response += `> Jika saluran tidak terdeteksi, coba restart bot atau gunakan .refreshchannels`;
        return conn.reply(m.chat, response, m);
    }

    if (command === 'refreshchannels') {
        try {
            await conn.chatModify({ refresh: true }, m.chat);
            return conn.reply(m.chat, `🔄 *Menyegarkan data saluran...* Coba lagi .jpmch atau .listchannels setelah beberapa detik.`, m);
        } catch (error) {
            return conn.reply(m.chat, `❌ Gagal menyegarkan data saluran: ${error.message}`, m);
        }
    }

    // Filter semua saluran tanpa validasi admin
    let channels = Object.entries(conn.chats)
        .filter(([jid, chat]) => jid.endsWith('@newsletter') && chat.isChats)
        .map(v => v[0]);

    console.log('Saluran terdeteksi:', channels);

    // Validasi jika tidak ada saluran
    if (channels.length === 0) {
        return conn.reply(m.chat, 
            `🚫 *Oops!* Tidak ada saluran yang ditemukan nih! 😅\n` +
            `> Coba gunakan .listchannels untuk melihat daftar saluran.\n` +
            `> Gunakan .refreshchannels untuk menyegarkan data saluran.`, m);
    }

    // Validasi input teks
    if (!text || text.trim() === '') {
        return conn.reply(m.chat, 
            `✨ *Halo bro!* ✨\n` +
            `Formatnya salah nih, wajib masukin teks ya! 📩\n` +
            `📝 *Cara pakai:* .jpmch <teks>\n` +
            `🌟 *Contoh:* .jpmch Halo bro, apa kabar?\n` +
            `📊 *Jumlah saluran:* ${channels.length}`, m);
    }

    // Quote khusus untuk JPMCH
    const qlocJpmch = {
        key: {
            participant: '0@s.whatsapp.net',
            ...(m.chat ? { remoteJid: `status@broadcast` } : {})
        },
        message: {
            locationMessage: {
                name: `📣 Broadcast Saluran`,
                jpegThumbnail: ""
            }
        }
    };

    try {
        // Kirim notifikasi proses
        await conn.reply(m.chat, 
            `🚀 *Siap bro!* Mengirim pesan JPMCH ke ${channels.length} saluran... ⏳`, m);

        let successCount = 0;

        // Kirim pesan ke setiap saluran
        for (let id of channels) {
            try {
                await conn.sendMessage(id, {
                    text: text.trim()
                }, {
                    quoted: qlocJpmch
                });
                successCount++;
                await new Promise(resolve => setTimeout(resolve, delayjpmch * 1000));
            } catch (error) {
                console.log(`Gagal mengirim ke ${id}: ${error}`);
            }
        }

        // Kirim laporan selesai
        await conn.reply(m.chat, 
            `🎉 *Selesai bro!* 🎉\n` +
            `✅ Terkirim ke: ${successCount} dari ${channels.length} saluran\n\n` +
            `> Jika ada yang tidak terkirim, pastikan bot memiliki akses untuk mengirim pesan ke saluran tersebut.`, m);

    } catch (error) {
        console.error(error);
        await conn.reply(m.chat, 
            `😱 *Aduh!* Ada error nih bro saat kirim JPMCH! Coba lagi ya! 🙏\n` +
            `> Debug info: ${error.message}`, m);
    }
};

handler.help = ['jpmch <teks>', 'listchannels', 'refreshchannels'];
handler.tags = ['owner'];
handler.command = /^(jpmch|listchannels|refreshchannels)$/i;
handler.owner = true;

module.exports = handler;