const { toAudio, toPTT } = require('../scrape/converter')

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (m.quoted ? m.quoted : m.msg).mimetype || ''
  
  if (!/video|audio/.test(mime)) {
    throw `Balas video/audio dengan perintah *${usedPrefix + command}*`
  }

  let media = await q.download()
  if (!media) throw 'Media tidak dapat diunduh'

  if (/^(tomp3|toaudio)$/i.test(command)) {
    let audio = await toAudio(media, 'mp4')
    if (!audio.data) throw 'Gagal mengonversi ke MP3.'
    
    // 🔊 Kirim audio biasa (bisa diputar langsung)
    await conn.sendMessage(m.chat, {
      audio: audio.data,
      mimetype: 'audio/mpeg'
    }, { quoted: m })

    // 📄 Kirim juga sebagai dokumen MP3
    await conn.sendMessage(m.chat, {
      document: audio.data,
      mimetype: 'audio/mpeg',
      fileName: `convert_${+new Date()}.mp3`
    }, { quoted: m })

  } else if (/^tovn$/i.test(command)) {
    let ptt = await toPTT(media, 'mp4')
    if (!ptt.data) throw 'Gagal mengonversi ke voice note.'

    // 🔊 Kirim voice note
    await conn.sendMessage(m.chat, {
      audio: ptt.data,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true
    }, { quoted: m })

    // 📄 Kirim juga sebagai dokumen OGG
    await conn.sendMessage(m.chat, {
      document: ptt.data,
      mimetype: 'audio/ogg; codecs=opus',
      fileName: `convert_${+new Date()}.ogg`
    }, { quoted: m })
  }
}

handler.help = ['tomp3 (reply)']
handler.tags = ['tools']
handler.command = /^tomp3|toaudio$/i

module.exports = handler
