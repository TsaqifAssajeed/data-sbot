//by ErerexID Chx
let handler = async (m, { conn, text }) => {
    if (!text) throw `*• Example:* .tweet *your message*`;

    try {
        const avatar = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/24fa902ead26340f3df2c.png');
        const displayName = m.pushName;
        const username = m.pushName.replace(/ /g, '_');
        const replies = '176k';
        const retweets = '672k';
        const theme = 'dark';

        const url = `https://some-random-api.com/canvas/misc/tweet?displayname=${encodeURIComponent(displayName)}&username=${encodeURIComponent(username)}&avatar=${encodeURIComponent(avatar)}&comment=${encodeURIComponent(text)}&replies=${encodeURIComponent(replies)}&retweets=${encodeURIComponent(retweets)}&theme=${encodeURIComponent(theme)}`;

        await conn.sendMessage(m.chat, {
            image: { url: url },
            caption: "Success! Here is your fake tweet image."
        }, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.');
    }
}

handler.help = ['tweet *your message*'];
handler.tags = ['fun'];
handler.command = /^(tweet|faketweet)$/i;

module.exports = handler;