const Chords = require('../scrape/chord');

let handler = async (m, { conn, text, command }) => {
  try {
    if (!text) {
      return m.reply(`Please provide a song title or artist name to search for chords!\n\nExample:\n.${command} Shape of You`);
    }

    m.reply('Searching for chords, please wait...');

    const chords = new Chords(text);
    const results = await chords.getSearch();

    if (results.length === 0) {
      return m.reply('No chords found for the given song or artist.');
    }

    const firstResult = results[0]; // Getting the first result from search
    const detail = await chords.getDetail(firstResult.link);

    if (detail) {
      let message = `
🎸 *Chords Found!* 🎸

📜 Title: ${detail.title}
👤 Artist: ${detail.artist}
🗓️ Date: ${detail.date}
🔗 [View Artist Profile](${detail.artistProfileLink})

🎶 Chords:
${detail.chords}
`;

      await conn.sendMessage(m.chat, { text: message, footer: 'BabyBotz' }, { quoted: m });
    } else {
      m.reply('Failed to fetch chords details.');
    }
  } catch (error) {
    console.error(error);
    m.reply("An error occurred: " + error.message);
  }
};

handler.help = ['chords'];
handler.tags = ['tools'];
handler.command = /^(chords|chord)$/i;

module.exports = handler;