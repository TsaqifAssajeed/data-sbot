const fs = require('fs');
const path = require('path');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!m.quoted || !m.quoted.mtype.includes('document')) {
    throw `📁 *Fitur Simpan File*\n\n➤ Balas file yang ingin disimpan\n➤ Ketik: *${usedPrefix + command} [path/namafile]*\n\nContoh:\n.save ./folder/file.js\n.save ./media/11/`;
  }

  let inputPath = text?.trim() || '';
  let dir = '.';
  let filename = m.quoted.fileName || 'file.unknown';

  // Tentukan apakah input adalah direktori
  if (inputPath) {
    let resolvedPath = path.resolve(inputPath);
    let isDirectory = false;

    if (inputPath.endsWith('/')) {
      isDirectory = true;
    } else if (fs.existsSync(resolvedPath)) {
      try {
        isDirectory = fs.statSync(resolvedPath).isDirectory();
      } catch { isDirectory = false }
    }

    if (isDirectory) {
      dir = resolvedPath;
    } else {
      dir = path.dirname(resolvedPath);
      filename = path.basename(resolvedPath);
    }
  }

  if (!filename || filename === '.') {
    throw `❗ Nama file tidak valid.`;
  }

  const fullPath = path.resolve(dir, filename);

  // Cek folder valid
  if (!fs.existsSync(dir)) {
    throw `❗ Direktori *${dir}* tidak ditemukan.`;
  }

  if (!fs.statSync(dir).isDirectory()) {
    throw `❗ Path *${dir}* bukan direktori.`;
  }

  // Pastikan target bukan direktori
  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isDirectory()) {
    throw `❗ Path *${fullPath}* adalah direktori, bukan file.`;
  }

  // Tampilkan loading
  const loading = await conn.sendMessage(m.chat, { text: '⏳ Menyimpan file...' });
  const msgKey = loading.key;

  for (let i = 0; i < 2; i++) {
    await sleep(800);
    await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: { conversation: `⏳ Menyimpan${'.'.repeat(i + 1)}` }
      }
    }, {});
  }

  try {
    const buffer = await m.quoted.download();
    fs.writeFileSync(fullPath, buffer);

    await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: { conversation: `✅ File berhasil disimpan di:\n📁 *${fullPath}*` }
      }
    }, {});
  } catch (err) {
    await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: msgKey,
        type: 14,
        editedMessage: { conversation: `❌ Gagal menyimpan file!\nError: ${err.message}` }
      }
    }, {});
  }
};

handler.help = ['save [path/nama_file]'];
handler.tags = ['owner'];
handler.command = /^save$/i;
handler.rowner = true;

module.exports = handler;
