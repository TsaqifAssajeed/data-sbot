const { createCanvas } = require('canvas')
const moment = require('moment-timezone')
const fs = require('fs')
const path = require('path')

let handler = async (m, { args, usedPrefix, command }) => {
  let text = args.join(' ')
  if (!text) {
    return m.reply(`❌ Format salah!\nGunakan: ${usedPrefix}${command} timezone|toko|nama_penjual|kontak_penjual|items|metode_pembayaran|info_tambahan\n\n
Contoh:\n${usedPrefix}${command} WITA|TOKO JAGOAN|Jagoan|6285776461481|Es Teh-5000-2,Nasi Goreng-15000-1|Cash|Terima kasih sudah datang!`)
  }

  let [timezone, toko, namaPenjual, kontakPenjual, items, metodePembayaran, infoTambahan] = text.split('|')
  if (!timezone || !toko || !namaPenjual || !kontakPenjual || !items || !metodePembayaran) {
    return m.reply(`❌ Format tidak lengkap!\nGunakan: ${usedPrefix}${command} timezone|toko |nama_penjual|kontak_penjual|items|metode_pembayaran|info_tambahan`)
  }

  const validTimezones = {
    'WIB': 'Asia/Jakarta',
    'WITA': 'Asia/Makassar',
    'WIT': 'Asia/Jayapura'
  }
  if (!validTimezones[timezone.toUpperCase()]) {
    return m.reply(`❌ Timezone tidak valid! Gunakan: WIB, WITA, atau WIT`)
  }

  try {
    let daftarBarang = items.split(',').map((item, index) => {
      let [nama, harga, jumlah] = item.split('-')
      return {
        nomor: index + 1,
        nama,
        harga: parseInt(harga),
        jumlah: parseInt(jumlah),
        total: parseInt(harga) * parseInt(jumlah)
      }
    })

    const canvasWidth = 600
    const canvasHeight = 600 + daftarBarang.length * 30
    const canvas = createCanvas(canvasWidth, canvasHeight)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#fff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    ctx.save()
    ctx.font = 'bold 40px monospace' // Smaller and bolder font
    ctx.fillStyle = 'rgba(63, 135, 207, 0.07)' // Purer blue, less transparent
    ctx.textAlign = 'center'
    ctx.translate(canvasWidth / 2, canvasHeight / 2)
    ctx.rotate((-45 * Math.PI) / 180) // Bottom-right to top-left

    const watermarkText = toko.toUpperCase()
    const textWidth = ctx.measureText(watermarkText).width
    const stepX = textWidth + 10 // Horizontal spacing
    const stepY = 50 // Vertical spacing
    let row = 0
    for (let y = -canvasHeight * 2; y < canvasHeight * 2; y += stepY) {
      const offset = row % 3 === 1 ? stepX / 2 : 0 // Staggered pattern
      for (let x = -canvasWidth * 2 + offset; x < canvasWidth * 2; x += stepX) {
        ctx.fillText(watermarkText, x, y)
      }
      row++
    }
    ctx.restore()

    ctx.fillStyle = '#000'

    ctx.font = 'bold 20px monospace'
    ctx.textAlign = 'center'
    ctx.fillText(toko.toUpperCase(), canvasWidth / 2, 40)
    ctx.font = '14px monospace'
    ctx.fillText(`Kontak Penjual: ${kontakPenjual}`, canvasWidth / 2, 65)

    let transaksiNomor = Math.floor(Math.random() * 1000000000000000)
    let currentDate = moment().tz(validTimezones[timezone.toUpperCase()]).format('DD/MM/YYYY HH:mm:ss')
    ctx.textAlign = 'left'
    ctx.fillText(`Nomor Transaksi: ${transaksiNomor}`, 20, 100)
    ctx.fillText(`Tanggal: ${currentDate} ${timezone.toUpperCase()}`, 20, 125)

    ctx.beginPath()
    ctx.moveTo(20, 150)
    ctx.lineTo(canvasWidth - 20, 150)
    ctx.stroke()

    let startY = 175
    daftarBarang.forEach((item, i) => {
      ctx.fillText(`${item.nomor}. ${item.nama} - Rp${item.harga.toLocaleString()} x ${item.jumlah} = Rp${item.total.toLocaleString()}`, 20, startY + i * 30)
    })

    let lastItemY = startY + daftarBarang.length * 30 + 10
    ctx.beginPath()
    ctx.moveTo(20, lastItemY)
    ctx.lineTo(canvasWidth - 20, lastItemY)
    ctx.stroke()

    let subtotal = daftarBarang.reduce((sum, item) => sum + item.total, 0)
    let pajak = Math.floor(subtotal * 0.1)
    let totalPembayaran = subtotal + pajak

    ctx.fillText(`Subtotal: Rp${subtotal.toLocaleString()}`, 20, lastItemY + 25)
    ctx.fillText(`Pajak (10%): Rp${pajak.toLocaleString()}`, 20, lastItemY + 50)
    ctx.fillText(`Total Pembayaran: Rp${totalPembayaran.toLocaleString()}`, 20, lastItemY + 75)
    ctx.fillText(`Metode Pembayaran: ${metodePembayaran}`, 20, lastItemY + 100)
    if (infoTambahan) {
      ctx.fillText(`Info Tambahan: ${infoTambahan}`, 20, lastItemY + 125)
    }

    ctx.font = 'bold 14px monospace'
    ctx.textAlign = 'center'
    ctx.fillText('TERIMA KASIH TELAH BERBELANJA', canvasWidth / 2, lastItemY + 160)
    ctx.fillText(namaPenjual.toUpperCase(), canvasWidth / 2, lastItemY + 180)

    const buffer = canvas.toBuffer('image/png')
    await conn.sendFile(m.chat, buffer, 'struk.jpg', '🧾 Struk Berhasil di buat\n> Thanks telah order', m)
  } catch (e) {
    m.reply(`❌ Error\nLogs error: ${e.message}`)
  }
}

handler.command = ['struk']
handler.help = ['struk']
handler.tags = ['maker']
module.exports = handler