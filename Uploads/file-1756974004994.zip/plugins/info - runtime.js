const ms = require('ms');

let handler = async (m, { conn, text }) => {
    const pushname = m.pushName || "Kawan"; // Nama pengguna
    const uptime = process.uptime() * 1000;
    const days = Math.floor(uptime / (1000 * 60 * 60 * 24));
    const hours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((uptime % (1000 * 60)) / 1000);

    let uptimeStr = '';
    if (days > 0) uptimeStr += `${days} hari${days > 1 ? 'i' : ''}, `;
    if (hours > 0) uptimeStr += `${hours} jam${hours > 1 ? 'm' : ''}, `;
    if (minutes > 0) uptimeStr += `${minutes} menit${minutes > 1 ? 't' : ''}, `;
    if (seconds > 0) uptimeStr += `${seconds} detik${seconds > 1 ? 'k' : ''}`;

    // ✅ Respon hanya untuk kata "bot" atau "Bot" sebagai kata tunggal
    const inputText = m.text.trim(); // Menghapus spasi di awal/akhir
    if (inputText === 'bot' || inputText === 'Bot') {
        const botReplies = [
            `Iyah? Bot udah nyala sejak ${uptimeStr} lalu, *${pushname}*! 🚀✨`,
            `Halo *${pushname}*, bot udah aktif selama ${uptimeStr}! 😎🔥`,
            `Bot disini, *${pushname}*! Sudah berjalan ${uptimeStr} lalu. 🤖💪`,
            `Yo *${pushname}*, bot online sejak ${uptimeStr}! 😜🎉`,
            `Hai *${pushname}*, bot siap dari ${uptimeStr}! 🌟⚡`,
            `What's up, *${pushname}*? Bot udah aktif dari ${uptimeStr}. 😺🛠️`,
            `Hey *${pushname}*, bot jalan terus dari ${uptimeStr}! 🦾😍`,
            `Halo *${pushname}*, bot setia menemani sejak ${uptimeStr}! 🐾🌈`,
            `Bot panggilanmu, *${pushname}*! Online sejak ${uptimeStr} lalu. 😇🎯`,
            `bat bet bot, *${pushname}*? bot bot boti ini sudah jalan dari  ${uptimeStr}! 🤤🤤`,
            `Halo *${pushname}*, bot standby dari ${uptimeStr}! 🛡️⚙️`,
            `Bot hadir, *${pushname}*! Aktif selama ${uptimeStr}. 😸🌠`,
            `Hai *${pushname}*, bot ga pernah lelah sejak ${uptimeStr}! 💡🚴`,
            `Yo, *${pushname}*! Bot udah beroperasi ${uptimeStr}. 😻🔔`,
            `Halo *${pushname}*, bot siap melayani ${uptimeStr}! 🦁🎈`,
        ];
        const response = botReplies[Math.floor(Math.random() * botReplies.length)];
        await conn.sendMessage(m.chat, { text: response }, { quoted: m });
    }
};

// Menggunakan regex untuk mendeteksi kata "bot" atau "Bot" sebagai kata tunggal
handler.customPrefix = /^(bot|Bot|.ping|.runtime|rt||.rt|runtime)$/;
handler.command = new RegExp;
handler.fail = null;

module.exports = handler;