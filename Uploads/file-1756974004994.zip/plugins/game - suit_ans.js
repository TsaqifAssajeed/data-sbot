let handler = m => m
const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

handler.before = async function (m, { conn }) {
  this.suit = this.suit || {}

  if (typeof db.data.users[m.sender].suit !== 'number') db.data.users[m.sender].suit = 0
  if (typeof db.data.users[m.sender].suitLoseStreak !== 'number') db.data.users[m.sender].suitLoseStreak = 0

  let room = Object.values(this.suit).find(room => room.id && room.status && [room.p, room.p2].includes(m.sender))
  let mmr = rwd(20, 30)

  if (room) {
    let win = ''
    let tie = false

    if (m.sender == room.p2 && /^(acc(ept)?|terima|gas|oke?|no|yes|tolak|gamau|nanti|ga(k.)?bisa)/i.test(m.text) && m.isGroup && room.status == 'wait') {
      if (/^(no?|tolak|gamau|nanti|ga(k.)?bisa)/i.test(m.text)) {
        conn.reply(m.chat, `❌ @${room.p2.split`@`[0]} menolak suit!!\n\n> game suit dibatalkan`, m)
        delete this.suit[room.id]
        return !0
      }

      room.status = 'play'
      room.asal = m.chat
      clearTimeout(room.waktu)

      let botNumber = conn.user.jid.split('@')[0]
      m.reply(`🎮 SUIT DIMULAI 🎮\n\n> silahkan pilih suit di room chat bot\n\n📌 pilih suitmu disini :\nwa.me/${botNumber}`)

      await delay(1500)
      if (!room.pilih) conn.reply(room.p, '📌 PILIH SUITMU :\n\n- batu\n- gunting\n- kertas\n\n> ketik pilihanmu tanpa reply chat!', m)
      await delay(1500)
      if (!room.pilih2) conn.reply(room.p2,  '📌 PILIH SUITMU :\n\n- batu\n- gunting\n- kertas\n\n> ketik pilihanmu tanpa reply chat!', m)

      room.waktu_milih = setTimeout(() => {
        if (!room.pilih && !room.pilih2) conn.reply(room.asal, `😡 Kedua pemain tidak memilih\n\n> game suit dibatalkan!`, m)
        else if (!room.pilih || !room.pilih2) {
          win = !room.pilih ? room.p2 : room.p
          conn.reply(room.asal, `@${(room.pilih ? room.p2 : room.p).split`@`[0]} ga niat main! 😡\n\n> game suit dibatalkan!`, m)
          db.data.users[win].exp += room.poin
          db.data.users[win == room.p ? room.p2 : room.p].exp -= room.poin_lose
        }
        delete this.suit[room.id]
      }, room.timeout)
    }

    let j = m.sender == room.p
    let j2 = m.sender == room.p2
    let reg = /^(gunting|batu|kertas)/i

    if (j && reg.test(m.text) && !room.pilih && !m.isGroup) {
      room.pilih = reg.exec(m.text.toLowerCase())[0]
      room.text = m.text
      m.reply(`✅ Kamu telah memilih\n\n- ${m.text}${!room.pilih2 ? '\n\n> menunggu lawan memilih...' : ''}`)
    }

    if (j2 && reg.test(m.text) && !room.pilih2 && !m.isGroup) {
      room.pilih2 = reg.exec(m.text.toLowerCase())[0]
      room.text2 = m.text
      m.reply(`✅ Kamu telah memilih\n\n- ${m.text}${!room.pilih ? '\n\n> menunggu lawan memilih...' : ''}`)
    }

    if (room.pilih && room.pilih2) {
      clearTimeout(room.waktu_milih)

      const p = room.pilih
      const p2 = room.pilih2

      if (p === p2) tie = true
      else if ((p === 'batu' && p2 === 'gunting') || (p === 'gunting' && p2 === 'kertas') || (p === 'kertas' && p2 === 'batu')) win = room.p
      else win = room.p2

      const pWin = win
      const pLose = win === room.p ? room.p2 : room.p

      if (!tie) {
        db.data.users[pWin].exp += room.poin
        db.data.users[pLose].exp -= room.poin_lose
        db.data.users[pWin].suit += mmr
        db.data.users[pLose].suit -= mmr / 2

        db.data.users[pWin].suitLoseStreak = 0
        db.data.users[pLose].suitLoseStreak = (db.data.users[pLose].suitLoseStreak || 0) + 1

        let loseStreak = db.data.users[pLose].suitLoseStreak

        if (room.asal && loseStreak >= 3) {
          await conn.groupParticipantsUpdate(room.asal, [pLose], 'remove').catch(e => m.reply(`❌ Gagal kick @${pLose.split('@')[0]} karena bot bukan admin.`, m))
          db.data.users[pLose].suitLoseStreak = 0
          conn.reply(room.asal, `‼️ LOSE STREAK\n\n- @${pLose.split`@`[0]} CUPU!!\n\n> kalah 3x dan telah di kick!! 😹`, m)
        }
      }

      conn.reply(room.asal, `
🎮 *HASIL SUIT* 🎮\n\n🧑🏻‍🦰 player : @${room.p.split`@`[0]}\n- ${room.text}\n- ${tie ? 'seri 😭' : (room.p === win ? 'menang 🥳' : 'kalah 😹')}\n\n🧑🏻‍🦱 player : @${room.p2.split`@`[0]}\n- ${room.text2}\n- ${tie ? 'seri 😭' : (room.p2 === win ? 'menang 🥳' : 'kalah 😹')}
`.trim(), m)

      delete this.suit[room.id]
    }
  }
  return !0
}

handler.exp = 0
module.exports = handler

function rwd(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}