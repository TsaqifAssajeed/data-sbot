// ✨ Plugin fun - say ✨

// ✨ Plugin - say.js ✨


let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('❗Contoh:\n.say Penyakit andi gila🥴.');

  const fakeFrom = '0@s.whatsapp.net';
  const fakeText = '@ Group ini disebut.';
  const fakeJid = 'status@broadcast';

  await conn.fakeReply(m.chat, text, fakeFrom, fakeText, fakeJid);
};

handler.help = ['say <teks>'];
handler.tags = ['fun'];
handler.command = /^say$/i;

module.exports = handler;