const uploadImage = require('../lib/uploadImage');
const axios = require('axios');

let handler = async (m) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';

  if (!mime || !/image\/(png|jpe?g)/.test(mime)) {
    throw 'Reply gambar QR-nya dengan perintah *.readqr*';
  }

  let media = await q.download();
  let fileSizeLimit = 5 * 1024 * 1024;

  if (media.length > fileSizeLimit) {
    throw 'Ukuran media tidak boleh lebih dari 5MB';
  }

  try {
    let link = await uploadImage(media);
    console.log('🔗 Link asli dari isupa:', link);

    // Tambahkan .png jika perlu
    if (!/\.(png|jpg|jpeg|gif)$/i.test(link)) {
      link += '.png';
      console.log('📎 Link dengan ekstensi ditambahkan:', link);
    }

    let apiUrl = `${global.apisiput}api/tools/qr2text?url=${encodeURIComponent(link)}`;
    let response = await axios.get(apiUrl);

    // ✅ Fix parsing respons sesuai struktur yang benar
    let result = response?.data?.data?.text;
    if (!result) throw 'QR tidak terbaca atau kosong!';

    await m.reply(`✅ QR berhasil dibaca!\n\n📤 URL Gambar: ${link}\n\n📥 Isi QR:\n${result}`);
  } catch (err) {
    //console.error('❌ Gagal baca QR:', err);
    throw `Terjadi kesalahan saat membaca QR:\nPastikan yang kamu kirim atau reply adalah bentuk Qr`;
  }
};

handler.help = ['readqr <reply image>'];
handler.tags = ['tools'];
handler.command = /^readqr$/i;
handler.limit = true;

module.exports = handler;
