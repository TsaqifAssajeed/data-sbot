const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const fetch = require('node-fetch');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const uploadImage = require('../lib/uploadImage');
const { uguu, tmpfiles } = require('../lib/uploader');
const crypto = require('crypto');
const fakeUserAgent = require('fake-useragent');
const { execSync } = require('child_process');

const randomBytes = crypto.randomBytes(5).toString("hex");



//gofiles
const API_TOKEN = 'bN9plMUcwLRQG9RuYI2WkIam0IKfOmdG';

async function uploadGoFile(buffer, fileName) {
  const form = new FormData();
  form.append('file', buffer, fileName);

  const res = await axios.post('https://upload.gofile.io/uploadFile', form, {
    headers: {
      ...form.getHeaders(),
      Authorization: `Bearer ${API_TOKEN}`
    }
  });

  const { status, data } = res.data;
  if (status !== 'ok') throw new Error('Upload ke GoFile gagal');

  // ✅ Bangun direct link manual
  const server = data.servers?.[0];
  const parentFolder = data.parentFolder;
  const name = data.name;

  if (!server || !parentFolder || !name) throw new Error('Gagal membentuk direct link');

  return `https://${server}.gofile.io/download/web/${parentFolder}/${name}`;
}




// GitHub Configuration (disamakan dengan tools - togithub.js) => https://github.com/settings/tokens
const GIT_USERNAME = 'typographuniverse';
const GIT_TOKEN = process.env.GITHUB_TOKEN || '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';
const GIT_REPO = 'uploader-Jagpro';
const GIT_BRANCH = 'main';
const GIT_EMAIL = 'typographuniverse@example.com';
const LOCAL_DIR = '/home/container/tmp';
const TARGET_FOLDER = 'Uploads';
const GIT_REMOTE = `https://${GIT_USERNAME}:${GIT_TOKEN}@github.com/${GIT_USERNAME}/${GIT_REPO}.git`;

// Atasi batasan sistem file (disamakan dengan tools - togithub.js)
process.env.GIT_DISCOVERY_ACROSS_FILESYSTEM = '1';

const createFormData = (content, fieldName, ext) => {
    const formData = new FormData();
    formData.append(fieldName, content, `${randomBytes}.${ext}`);
    return formData;
};

const handleErrorResponse = (error, mime) => {
    console.error('Error:', error.message || error);
    if (mime === 'application/json' && /json|type|format/i.test(error.message || error)) {
        return 'Tidak mendukung tipe media tersebut';
    }
    return `Gagal membuat link: ${error.message || error}`;
};

let handler = async (m, { conn }) => {
    let q = m.quoted || m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!mime) throw '❌ Tidak ada media ditemukan, Mohon kirim media atau Reply Medianya';

    await conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

    try {
        let media = await q.download();
        if (!media) throw '❌ Gagal mengunduh media';

        const fileSizeLimit = 100 * 1024 * 1024; // Disamakan dengan MAX_SIZE di tools - togithub.js
        if (media.length > fileSizeLimit) throw '❌ Ukuran file melebihi 100MB';

        const fileType = await fromBuffer(media);
        let fileExt = fileType?.ext || mime.split('/')[1] || 'bin';
        const fileName = `file-${Date.now()}.${fileExt}`;

        const isSticker = /webp/.test(mime);

// Link 1: CloudkuImages
        let link1 = 'Gagal membuat link';
        try {
            const form = createFormData(media, "file", fileExt);
            const response = await fetch('https://cloudkuimages.guru/upload.php', {
                method: 'POST',
                body: form,
                headers: { "User-Agent": fakeUserAgent() },
            });
            const result = await response.json();
            if (result.status === 'success') {
                link1 = result.data.url;
            } else {
                throw new Error(result.message || 'Upload failed');
            }
        } catch (e) {
            link1 = handleErrorResponse(e, mime);
        }

        // Link 2: Catbox
        let link2 = 'Gagal membuat link';
        try {
            link2 = await uploadImage(media);
        } catch (e) {
            link2 = handleErrorResponse(e, mime);
        }
 

        // Link 6: Pomf2
        let link5 = 'Gagal membuat link';
        try {
            const form = createFormData(media, "files[]", fileExt);
            const res = await fetch("https://pomf2.lain.la/upload.php", {
                method: "POST",
                body: form,
                headers: { "User-Agent": fakeUserAgent() },
            });
            const json = await res.json();
            if (!json.success) throw new Error('UploadPomf2 gagal');
            link5 = json.files[0].url;
        } catch (e) {
            link5 = handleErrorResponse(e, mime);
        }

        // Link 7: Ucarecdn
        let link4 = 'Gagal membuat link';
        if (mime !== 'application/json') {
            try {
                const form = createFormData(media, "file", fileExt);
                form.append("UPLOADCARE_PUB_KEY", "demopublickey");
                form.append("UPLOADCARE_STORE", "1");
                const response = await fetch("https://upload.uploadcare.com/base/", {
                    method: "POST",
                    body: form,
                    headers: { "User-Agent": fakeUserAgent() },
                });
                const { file } = await response.json();
                link4 = `https://ucarecdn.com/${file}/${randomBytes}.${fileExt}`;
            } catch (e) {
                link4 = handleErrorResponse(e, mime);
            }
        }

        // Link 8: GitHub (disamakan dengan tools - togithub.js)
        let link3 = 'Gagal membuat link';
        try {
            const gitFileName = `file-${Date.now()}.${fileExt}`;
            const filePath = path.join(LOCAL_DIR, TARGET_FOLDER, gitFileName);

            // Periksa dan inisialisasi direktori tmp
            if (fs.existsSync(LOCAL_DIR)) {
                try {
                    execSync(`git -C ${LOCAL_DIR} rev-parse --is-inside-work-tree`, { stdio: 'ignore' });
                } catch (gitError) {
                    fs.rmSync(LOCAL_DIR, { recursive: true, force: true });
                    execSync(`git clone -b ${GIT_BRANCH} ${GIT_REMOTE} ${LOCAL_DIR}`, { stdio: 'inherit' });
                }
            } else {
                execSync(`git clone -b ${GIT_BRANCH} ${GIT_REMOTE} ${LOCAL_DIR}`, { stdio: 'inherit' });
            }

            // Tulis file
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
            fs.writeFileSync(filePath, media);

            // Jalankan perintah Git
            execSync(`git -C ${LOCAL_DIR} add .`, { stdio: 'inherit' });
            execSync(`git -C ${LOCAL_DIR} config user.name "${GIT_USERNAME}"`);
            execSync(`git -C ${LOCAL_DIR} config user.email "${GIT_EMAIL}"`);
            execSync(`git -C ${LOCAL_DIR} commit -m "Upload ${gitFileName}"`, { stdio: 'inherit' });
            execSync(`git -C ${LOCAL_DIR} push origin ${GIT_BRANCH}`, { stdio: 'inherit' });

            link3 = `https://raw.githubusercontent.com/${GIT_USERNAME}/${GIT_REPO}/${GIT_BRANCH}/${TARGET_FOLDER}/${gitFileName}`;

            // Hapus isi folder tmp setelah upload
            if (fs.existsSync(LOCAL_DIR)) {
                fs.readdirSync(LOCAL_DIR).forEach((item) => {
                    const itemPath = path.join(LOCAL_DIR, item);
                    fs.rmSync(itemPath, { recursive: true, force: true });
                });
            }
        } catch (e) {
            link3 = handleErrorResponse(e, mime);
        }

// Link 8: GoFile.io
let link6 = 'Gagal membuat link';
try {
    link6 = await uploadGoFile(media, fileName);
} catch (e) {
    link6 = handleErrorResponse(e, mime);
}

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        const messageText = [
            '▣────────────────···',
            `*Link 1 (CloudkuImages)*:\n${link1}\n⏳ Tanpa Expired`,
            `*Link 2 (Catbox)*:\n${link2}\n⏳ Tanpa Expired`,
            `*Link 3 (GitHub)*:\n${link3}\n⏳ Tanpa Expired`,
            `*Link 4 (Ucarecdn)*:\n${link4}\n⏳ Tanpa Expired`,
            `*Link 5 (Pomf2)*:\n${link5}\n⏳ Tanpa Expired`,
            `*Link 6 (GoFile.io)*:\n${link6}\n⏳ Expired jika tidak diakses 10 hari`,

           
            '▣────────────────···'
        ].join('\n\n');

        await conn.sendMessage(
            m.chat,
            { text: messageText, footer: '✅ Semua link tersedia, pilih salah satu.' },
            { quoted: m }
        );

    } catch (e) {
        console.error('Error:', e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply(`❌ Gagal mengunggah file.\n\n*Error:* ${e.message || e}`);
    }
};

handler.help = ['tourl'];
handler.tags = ['tools'];
handler.command = /^tourl$/i;
handler.limit = true;

module.exports = handler;

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    delete require.cache[file];
    require(file);
});