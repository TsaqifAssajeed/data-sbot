
const esprima = require('esprima')

let handler = async (m, { text, quoted, usedPrefix, command }) => {
  const code = text || (quoted && quoted.text)
  if (!code) return m.reply(`📌 Contoh:\n${usedPrefix + command} console.log("halo")\nAtau balas pesan berisi kode.`)

  // ✅ Cek Syntax Error dulu dengan Esprima
  try {
    esprima.parseScript(code)
  } catch (err) {
    const row = err.lineNumber || 0
    const col = err.column || 0
    const lines = code.split('\n')
    const barisError = lines[row - 1] || ''
    const pointer = ' '.repeat(Math.max(col - 1, 0)) + '^'

    let pesan = `❌ *Syntax Error Terdeteksi!*

📌 *Jenis:* ${err.description}
📍 *Lokasi:* Baris ${row}, Kolom ${col}

📄 *Cuplikan Baris ${row}:*
\`\`\`js
${barisError}
${pointer}
\`\`\`
`
    return m.reply(pesan)
  }

  // ✅ Jika tidak ada syntax error, cek runtime error
  try {
    new Function(code)
    return m.reply('✅ Kode valid. Tidak ada syntax maupun runtime error.')
  } catch (err) {
    let pesan = `⚠️ *Runtime Error Terdeteksi!*

📌 *Jenis:* ${err.name}
📢 *Pesan:* ${err.message}
📎 Catatan: Runtime error terjadi saat kode dijalankan, bukan karena salah tulis struktur.
`
    return m.reply(pesan)
  }
}

handler.help = ['cekcode <teks>/<reply>']
handler.tags = ['tools']
handler.command = /^cekcode$/i
handler.limit = true

module.exports = handler