// ✨ Plugin ai - sunoai ✨

// ✨ Plugin tools - musicgen ✨

const axios = require('axios');
const fetch = require('node-fetch');

// === GPT Lyrics Generator ===
async function gptLirik(judul) {
    try {
        let body = {
            model: "gpt-4o-mini",
            messages: [
                {
                    role: "user",
                    content: `Buatkan lirik lagu lengkap dengan judul "${judul}".
Tuliskan lirik full (Verse + Chorus), jangan cuma "lalala".`
                }
            ]
        };

        let res = await fetch(`https://api.termai.cc/api/chat/gpt?key=${global.apixtermkey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        let json = await res.json();
        let reply = json?.response; // sesuai respon API

        return reply ? reply.trim() : "lalala... (AI generated)";
    } catch (e) {
        console.error("GPT Error:", e);
        return "lalala... (AI generated)";
    }
}

// === Main Handler ===
let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(
        `Contoh penggunaan:\n` +
        `• ${usedPrefix + command} Judul Lagu\n` +
        `• ${usedPrefix + command} Judul | Style Musik | Lirik`
    );

    let title, style, lyrics;

    if (text.includes('|')) {
        // Mode manual
        let [judul, gaya, ...lirikArr] = text.split('|').map(s => s.trim());
        title = judul;
        style = gaya || "Pop, emotional";
        lyrics = lirikArr.join('|') || "lalala... (AI generated)";
    } else {
        // Mode otomatis (GPT buat lirik)
        title = text.trim();
        style = "Pop, emotional, AI generated"; 
        await m.reply("⏳ Mencari/generate lirik otomatis...");
        lyrics = await gptLirik(title);
    }

    await m.reply('⏳ Membuat lagu, mohon tunggu...\n*Pembuatan lagu bisa lebih dari 2-5 menit*');

    try {
        const result = await generateMusic(title, style, lyrics);

        if (!result?.data || !result.data.length) throw '❌ Gagal mendapatkan audio.';

        // Ambil audio pertama saja
        const audioItem = result.data[0];
        const audioBuffer = await axios.get(audioItem.audio_url, {
            responseType: 'arraybuffer'
        }).then(res => res.data);

        // Kirim audio dulu
        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${audioItem.title}.mp3`,
            ptt: false
        }, { quoted: m });

        // Baru kirim lirik setelah audio
        await conn.sendMessage(m.chat, {
            text: `📑 *Lirik Lagu:*\n\n${lyrics}`
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal membuat lagu');
    }
};

handler.command = handler.help = ['aimusic', 'musicgen', 'sunoai'];
handler.tags = ['tools'];
handler.limit = true;

module.exports = handler;

// === Generate Music with API ===
async function generateMusic(title, style, lyrics) {
    const payload = { 
        title, 
        style, 
        lyrics: lyrics,  
        aksesKey: global.aksesKey
    };

    console.log("🎼 Payload ke musik API:", payload);

    const { data } = await axios.post('https://api.botcahx.eu.org/api/maker/aimusic', payload);

    let status = 'pending';
    let result = null;
    while (status === 'pending') {
        await new Promise(r => setTimeout(r, 10000));
        const { data: statusData } = await axios.get('https://api.botcahx.eu.org/api/maker/aimusic/status', {
            params: { jobId: data.jobId }
        });
        status = statusData.status;
        result = statusData.result;
        if (status === 'error') return { error: statusData.error };
        if (status === 'done') return result;
    }
}