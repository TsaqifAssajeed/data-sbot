// ✨ Plugin rpg - mobil - buy ✨

let carList = [ { jenis: 'Rolls-Royce Phantom', harga: 2000000000 }, { jenis: 'Mazda RX-7', harga: 75000000 }, { jenis: 'Ford Mustang', harga: 120000000 }, { jenis: 'Lamborghini Aventador', harga: 700000000 }, { jenis: 'Nissan GT-R', harga: 500000000 }, { jenis: 'Chevrolet Camaro', harga: 150000000 }, { jenis: 'Toyota Supra MK4', harga: 300000000 }, { jenis: 'Subaru Impreza WRX', harga: 180000000 }, { jenis: 'Dodge Challenger', harga: 200000000 }, { jenis: 'Ferrari 488', harga: 900000000 }, { jenis: 'McLaren P1', harga: 1200000000 }, { jenis: 'Porsche 911 Turbo', harga: 850000000 }, { jenis: 'Aston Martin DB11', harga: 950000000 }, { jenis: 'Bugatti Chiron', harga: 2500000000 }, { jenis: 'Koenigsegg Jesko', harga: 3000000000 }, { jenis: 'Audi R8', harga: 1100000000 } ];

let handler = async (m, { conn, args, usedPrefix }) => { let user = global.db.data.users[m.sender];

if (!user.cars) user.cars = [];
if (!user.carHealth) user.carHealth = {};
if (!user.carLevel) user.carLevel = {};

if (!args[0]) {
    return conn.reply(m.chat, `❌ Format salah!

Gunakan :

> ${usedPrefix}mobil list\n> ${usedPrefix}mobil beli <jenis>\n> ${usedPrefix}mobil jual <jenis>\n> ${usedPrefix}mobil servis <jenis>\n> ${usedPrefix}mobil upgrade <jenis>`, m); }

let action = args[0].toLowerCase();

if (action === 'list') {
    let daftarMobil = carList.map(c => `🚗 Jenis : ${c.jenis}\n💰 Harga : Rp${c.harga}`).join('\n\n');
    return conn.reply(m.chat, `🛒 Daftar Mobil yang Tersedia :\n\n${daftarMobil}`, m);
}

if (action === 'beli') {
    let jenisMobil = args.slice(1).join(' ').toLowerCase();
    let mobil = carList.find(c => c.jenis.toLowerCase() === jenisMobil);

    if (!mobil) {
        return conn.reply(m.chat, `❌ Jenis mobil tidak ditemukan!

Gunakan :\n> ${usedPrefix}mobil list untuk melihat daftar mobil.`, m); }

if (user.money < mobil.harga) {
        return conn.reply(m.chat, `🥲 Uang Anda tidak cukup!

💸 Saldo Anda: Rp${user.money}`, m); }

user.money -= mobil.harga;
    user.cars.push(mobil.jenis);
    user.carHealth[mobil.jenis] = 100;
    user.carLevel[mobil.jenis] = 1;

    return conn.reply(m.chat, `✅ Sukses membeli mobil\n\n- 🚘 mobil : ${mobil.jenis}\n- 💰 harga : Rp${mobil.harga}`, m);
}

if (action === 'jual') {
    let jenisMobil = args.slice(1).join(' ').toLowerCase();
    let mobilIndex = user.cars.findIndex(c => c.toLowerCase() === jenisMobil);

    if (mobilIndex === -1) {
        return conn.reply(m.chat, "😹 Anda tidak memiliki mobil tersebut untuk dijual!", m);
    }

    let mobil = carList.find(c => c.jenis.toLowerCase() === jenisMobil);
    let hargaJual = Math.floor(mobil.harga * 0.7);
    user.money += hargaJual;
    user.cars.splice(mobilIndex, 1);
    delete user.carHealth[mobil.jenis];
    delete user.carLevel[mobil.jenis];

    return conn.reply(m.chat, `✅ Sukses menjual mobil\n\n🚘 mobil : ${mobil.jenis}\n💰 harga : Rp${hargaJual}`, m);
}

if (action === 'servis') {
    let jenisMobil = args.slice(1).join(' ').toLowerCase();
    let mobil = user.cars.find(c => c.toLowerCase() === jenisMobil);

    if (!mobil) {
        return conn.reply(m.chat, "❌ Anda tidak memiliki mobil tersebut untuk diservis!", m);
    }

    let mobilData = carList.find(c => c.jenis.toLowerCase() === jenisMobil);
    let biayaServis = Math.floor(mobilData.harga * 0.1);

    if (user.money < biayaServis) {
        return conn.reply(m.chat, `💸 Uang Anda tidak cukup untuk servis!

Biaya servis: Rp${biayaServis}`, m); }

user.money -= biayaServis;
    user.carHealth[mobil] = 100;

    return conn.reply(m.chat, `🔧 Mobil ${mobil} telah diservis dan kembali ke kondisi maksimal!`, m);
}

if (action === 'upgrade') {
    let jenisMobil = args.slice(1).join(' ').toLowerCase();
    let mobil = user.cars.find(c => c.toLowerCase() === jenisMobil);

    if (!mobil) {
        return conn.reply(m.chat, "❌ Anda tidak memiliki mobil tersebut untuk di-upgrade!", m);
    }

    let mobilData = carList.find(c => c.jenis.toLowerCase() === jenisMobil);
    let biayaUpgrade = Math.floor(mobilData.harga * 0.2);

    if (user.money < biayaUpgrade) {
        return conn.reply(m.chat, `💸 Uang Anda tidak cukup untuk upgrade!

Biaya upgrade: Rp${biayaUpgrade}`, m); }

user.money -= biayaUpgrade;
    user.carLevel[mobil] = (user.carLevel[mobil] || 1) + 1;

    return conn.reply(m.chat, `🚀 Mobil ${mobil} telah di-upgrade ke level *${user.carLevel[mobil]}*`, m);
}

};

handler.help = ['mobil list', 'mobil beli <jenis>', 'mobil jual <jenis>', 'mobil servis <jenis>', 'mobil upgrade <jenis>']; handler.tags = ['rpg']; handler.command = ['mobil'];

module.exports = handler;