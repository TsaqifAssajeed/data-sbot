let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.peliharaan)}”`, m)
}
handler.help = ['cekpeliharaan']
handler.tags = ['cek']
handler.command = /^(cekpeliharaan)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.peliharaan = [
'Babi Ngepet🐽', 'Monyet Sigma🐒', 'Kadal Yapping🦎', 'Rusa Knalpot Racing🦌', 'Badak Mas Amba🦏', 'Kijang Ahli Mberr🦌', 'Ayam Kampus👀', 'Ayam Semok Montok🐔', 'Kuda Lumping Jawa🐎', 'Burung Mas Amba🕊️', 'Singa Di Ranjang🦁', 'Tikus Kantor🐀', '🐠Ikan Laga Laga (Seronoknya Main Laga Laga)', 'Harimau Berkontol Besar 20CM🐅', 'Serigala Berbulu Domba🐺', 'Sweety Fox🦊😋', 'Kucing Mewing🐱', 'Anjing Gyatt🐶', 'Jerapah Ahli Sepong🦒', 'Angsa Mengemud i🦢', 'Bebek Bakar Madu🦆', 'Buaya Darat🐊 (Hai Cantik Boleh Kenalan Gak)', 'Cacing Besar Alaska🪱', 'Ubur Ubur Spogebob🪼', 'Kraken Njir🐙', 'Kepiting Kikir🦀', 'Dinosaurus Khas Balikpapan🦖',
]