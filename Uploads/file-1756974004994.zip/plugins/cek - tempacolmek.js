let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.tempatcolmek)}”`, m)
}
handler.help = ['tempatcolmek']
handler.tags = ['cek']
handler.command = /^(tempatcolmek)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.tempatcolmek = [
'Di Dalem Kamar\n*Normal Sih Tapi Sambil Liatin Foto Lisa Blackpink Njir*💀', 'Di Kali\n*Kyk Gaada Tempat Lain Aja Neng*', 'Di Dalem Kamar Nya Bestie\n*Sekalian Aja Minta Di Colmekin Sama Bestie*😂', 'Di Depan Cowok Lu\n*Lu Ngapain Cok, Itu Kontol Cowok Lu Nganggur Malah Colmek*😂😂😂', 'Di Rumah Nya Jokowi\n*Di Kamar Gw Aja Sini, Ngapain Ke Rumah Penghutang Negara*😠', 'Di Atas Atap\n*Stress Lu Ya?*😅', 'Di Dalem Wc Guru\n*Wah Itu Guru Lu Mau Berak Njir Ada Ada Aja Lu*😑', 'Di Kantor DPR\n*Lu Diangkat Jadi Wakil DPR Karna Cara Colmek Lu Yang Nggak Biasa*💀', 'Di Depan Ortunya Cowok Lu\n*Ada Ada Aja Lu, Tapi Calon Bapak Mertua Lu Kok Titid Nya Tegang?*😅', 'Di Boxing Arena\n*Ini Tempat Adu Jotos Woi Bukan Adu Colmek, Pulang Lu Sono*😑', 'Di Kandang Ayam\n*Jangan Woi Ntar Memek Lu Bau Ayam*😂', 'Di Depan Guru\n*Lu Kalo Colmek Liat Tempat Lah, Ntar Di Ewe Guru Lagi Yang Kena Batunya*😂', 'Di Ruang Tamu\n*Ntar Kalo Ada Tamu Terus Ku Di Ewe Gimana?*😑', 'Di Meja Billiard\n*Lu Kalo Gatau Main Billiard Pulang Aja, Kurang Kerjaan Lu*😂', 'Di Tengah Lapangan\n*Lu Di Videoin Tuh, Ntar Lagi Viral*😋', 'Di Dalam Kereta\n*Hati Hati Ntar Di Sodok Penumpang*😂', 'Di Kantor Polisi\n*Ntar Lagi Ada Kasus Viral (Polisi Rudapaksa Cewek Random)*😂', 'Di RS\n*Orang Orang Pada Datang Berobat, Lu Malah Datang Colmek*😑', 'Di Dalem Wc Sekolah\n*Siswa Lain Kasian Itu Mau Berak, Cepet Dikit*😑',
]