const axios = require('axios')

let handler = async (m, { text, quoted, usedPrefix, command }) => {
  let url = text || (quoted && quoted.text)
  

  if (!url) return m.reply(`📌 Contoh:\n${usedPrefix + command} https://sub4unlock.co/feqKNU\natau balas pesan berisi URL dari sub4unlock.co.`)


  url = url.trim()
  const urlRegex = /^(https?:\/\/)(www\.)?sub4unlock\.co(\/.*)?$/
  if (!urlRegex.test(url)) {
    return m.reply(`❌ *URL Tidak Valid!*\n📌 Hanya URL dari sub4unlock.co yang diizinkan (contoh: https://sub4unlock.co/feqKNU).`)
  }


  await m.reply('⏳ Sedang memproses bypass...')

  const apiKey = global.fgsiKey // Ganti dengan API key ydi akunmu. daftar gratis https://fgsi.koyeb.app/
  const baseUrl = `${global.fgsi}/api/tools/skip/sub4unlock`

  try {
    const response = await axios.get(baseUrl, {
      params: {
        apikey: apiKey,
        url: url
      },
      headers: {
        accept: 'application/json'
      }
    })

    const data = response.data
    if (data.status) {
      let pesan = `✅ *Bypass Berhasil!*

📍 *Link Tujuan:* ${data.data.linkGo || 'Tidak tersedia'}
📎 *Media Sosial:* ${data.data.linkMediaSosials?.map(link => `\n- ${link.type}: ${link.url}`).join('') || 'Tidak tersedia'}
`
      return m.reply(pesan)
    } else {
      let pesan = `❌ *Gagal Bypass URL!*

📌 *Pesan:* ${data.message || 'Tidak ada pesan error'}
📍 *Status:* ${data.status}
`
      return m.reply(pesan)
    }
  } catch (error) {
    // Debugging: Log error lengkap
    console.error('Error details:', error)
    let pesan = `⚠️ *Error Terdeteksi!*

📌 *Jenis:* ${error.name || 'AxiosError'}
📢 *Pesan:* ${error.response?.data?.message || error.message}
📎 Catatan: Pastikan URL valid, API key aktif, dan coba lagi. Jika masalah berlanjut, periksa log server.
`
    return m.reply(pesan)
  }
}

handler.help = ['skipsub4 <url>/<reply>']
handler.tags = ['tools']
handler.command = /^skipsub4$/i
handler.limit = true

module.exports = handler