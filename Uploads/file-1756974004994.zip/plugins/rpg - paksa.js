let handler = async (m, { conn, args }) => {
    let __timers = (new Date() - (global.db.data.users[m.sender].lastngewe || 0))
    let _timers = (7200000 - __timers) // 2 jam dalam milidetik
    let timers = _timers >= 0 ? clockString(_timers) : "waktu sudah habis"
    let name = conn.getName(m.sender)
    let user = global.db.data.users[m.sender]
    let id = m.sender
    let kerja = 'ewe-paksa'
    conn.misi = conn.misi ? conn.misi : {}
    
    if (id in conn.misi) {
        conn.reply(m.chat, `Selesaikan Misi ${conn.misi[id][0]} Terlebih Dahulu`, m)
        throw false
    }

    if (new Date() - user.lastngewe < 7200000 && user.lastngewe) { // 2 jam cooldown check
        m.reply(`⏳ Silahkan Menunggu Selama ${timers} lagi untuk melakukan *Ewe-paksa* kembali`)
        return
    }

    // Check if a user is tagged
    let targetId = args[0] ? args[0].replace('@', '') + '@s.whatsapp.net' : null
    let target = targetId ? global.db.data.users[targetId] : null

    if (target && targetId !== m.sender) { // If a valid target is tagged and it's not the sender
        let success = Math.random() < 0.5 // 50% chance for robbery success
        if (success) {
            let moneyToTransfer = Math.floor(user.money * 0.5) // 50% of sender's money
            if (moneyToTransfer > 0) {
                user.money -= moneyToTransfer
                target.money = (target.money || 0) + moneyToTransfer
                
                let revoltMessage = `
Maaf @${m.sender.split('@')[0]}, user @${targetId.split('@')[0]} telah berontak! 
Kamu dibegal balik, 50% uangmu (${moneyToTransfer}) diberikan kepada @${targetId.split('@')[0]}!
`.trim()
                
                conn.reply(m.chat, revoltMessage, m, { mentions: [m.sender, targetId] })
                user.lastngewe = new Date() * 1 // Set cooldown after robbery
                return
            } else {
                conn.reply(m.chat, `Kamu tidak punya cukup uang untuk dibegal, @${m.sender.split('@')[0]}!`, m)
                return
            }
        } else {
            conn.reply(m.chat, `Beruntung! @${targetId.split('@')[0]} gagal memberontak, lanjutkan *Ewe-paksa*!`, m, { mentions: [targetId] })
            // Proceed to original logic if robbery fails
        }
    }

    // Original logic for ewe-paksa
    let randomaku1 = Math.floor(Math.random() * 1000000)
    let randomaku2 = Math.floor(Math.random() * 1000000)
    
    var dimas = `
Ehh Mau Ngapainn 😣😣...
`.trim()

    var dimas2 = `
Ahhh Pelan Pelann, Sakittt😖😖😖....
AHHH...AHHHH...Pelan Pelan...😖😖😖
`.trim()

    var dimas3 = `
🥵Ahhhh, Sakitttt!! >////<
 Plok...Plokkk...Plokkkk🥵🥵😩😖
`.trim()

    var dimas4 = `
😖Ahhhh.... Penuhhh.... Angettt 🥵🥵😖
`.trim()

    var hsl = `
*—[ Hasil Ewe Paksa ${name} ]—*
➤ 💰 Uang = [ ${randomaku1} ]
➤ ✨ Exp = [ ${randomaku2} ]
➤ 😍 Order Selesai = +1
`.trim()

    user.money += randomaku1
    user.exp += randomaku2
    
    conn.misi[id] = [
        kerja,
        setTimeout(() => {
            delete conn.misi[id]
        }, 27000)
    ]
    
    setTimeout(() => {
        m.reply(hsl)
    }, 27000)

    setTimeout(() => {
        m.reply(dimas4)
    }, 25000)

    setTimeout(() => {
        m.reply(dimas3)
    }, 20000)

    setTimeout(() => {
        m.reply(dimas2)
    }, 15000)

    setTimeout(() => {
        m.reply(dimas)
    }, 10000)

    setTimeout(() => {
        m.reply('kamu membawa dia ke kamar dan membuka paksa baju nya😋...')
    }, 0)
    
    setTimeout(() => {
        m.reply(`⏳ Waktu untuk *Ewe-paksa* selanjutnya sudah tiba! Gunakan *ewe-paksa* sekarang untuk mendapatkan lebih banyak hadiah!`)
    }, 7200000) // 2 jam untuk pesan cooldown
    
    user.lastngewe = new Date() * 1
}

handler.help = ['ewe-paksa [@tag]']
handler.tags = ['rpg']
handler.command = /^(ewe-paksa)$/i
handler.register = true
handler.group = true
module.exports = handler 

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    let result = []
    if (h > 0) result.push(`${h} jam`)
    if (m > 0) result.push(`${m} menit`)
    if (s > 0) result.push(`${s} detik`)
    if (result.length === 0) result.push('kurang dari 1 detik')
    return result.join(' ')
}