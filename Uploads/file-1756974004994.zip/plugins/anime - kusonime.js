const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn, text, command }) => {
  try {
    if (!text) {
      return m.reply(`Please provide an anime title to search!\n\nExample:\n.${command} Naruto`);
    }

    m.reply('Searching for anime, please wait...');

    const results = await searchAnime(text);

    if (!results || results.length === 0) {
      return m.reply('No anime found for the given title.');
    }

    let message = `
🎥 *Anime Search Results!* 🎥
    `;

    results.forEach((res, index) => {
      message += `
🔹 *Anime ${index + 1}*
- 🎬 Title: ${res.title}
- 🔗 [Link](${res.link})
      `;
    });

    await conn.sendMessage(m.chat, { text: message, footer: 'BabyBotz' }, { quoted: m });
  } catch (error) {
    console.error(error);
    m.reply("An error occurred: " + error.message);
  }
};

handler.help = ["kusonime"];
handler.tags = ["anime"];
handler.command = /^(kusonime)$/i;

module.exports = handler;

async function searchAnime(keyword) {
  try {
    const optionsGet = {
      headers: {
        "user-agent": "Mozilla/5.0 (Linux; Android 9; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36",
      },
    };

    const { data } = await axios.get(`https://kusonime.com/?s=${encodeURIComponent(keyword)}&post_type=anime`, optionsGet);

    const $ = cheerio.load(data);

    let results = [];
    $("div > div > ul > div > div > div a").each((i, el) => {
      const title = $(el).attr('title') || "Unknown Title";
      const link = $(el).attr('href');
      const thumbnail = $(el).find('img').attr('src');

      if (title && link && thumbnail) {
        results.push({ title, link, thumbnail });
      }
    });

    return results;
  } catch (error) {
    console.error('Error:', error.message);
    return null;
  }
}