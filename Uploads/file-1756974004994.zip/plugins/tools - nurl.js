const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');

let handler = async (m, { conn, args, usedPrefix, command }) => {
    try {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        let wait = await m.reply('_⌛ Sedang memproses..._');

        if (!mime) {
            let text = (q.text || q.contentText || q.message || '').trim();
            if (!text) throw `Reply/Kirim File atau pesan teks dengan caption *${usedPrefix + command}*`;

            let filename = './tmp/' + Date.now() + '.txt';
            fs.writeFileSync(filename, text);

            let formData = new FormData();
            formData.append('file', fs.createReadStream(filename));
            formData.append('expirationOption', 'permanent');

            let res = await fetch('https://Nauval.mycdn.biz.id/upload', {
                method: 'POST',
                body: formData
            });

            let json = await res.json();

            fs.unlinkSync(filename);

            if (json.success) {
                await conn.reply(m.chat, `
📤 *FILE UPLOAD BERHASIL*

📝 *Link:* ${json.fileUrl}
⏳ *Expired:* Permanent
📁 *Size:* ${formatSize(Buffer.byteLength(text, 'utf-8'))}

_File akan disimpan permanen di server_
                `.trim(), m);
            } else {
                throw 'Upload gagal: ' + json.message;
            }

            if (wait) {
                await wait.delete();
            }
            return;
        }

        let media = await q.download();
        if (media.length > 100 * 1024 * 1024) throw 'File size terlalu besar (Max 100MB)';

        let filename = './tmp/' + Date.now() + '.' + mime.split('/')[1];
        fs.writeFileSync(filename, media);

        let formData = new FormData();
        formData.append('file', fs.createReadStream(filename));
        formData.append('expirationOption', 'permanent');

        let res = await fetch('https://Nauval.mycdn.biz.id/upload', {
            method: 'POST',
            body: formData
        });

        let json = await res.json();

        fs.unlinkSync(filename);

        if (json.success) {
            await conn.reply(m.chat, `
📤 *FILE UPLOAD BERHASIL*

📝 *Link:* ${json.fileUrl}
⏳ *Expired:* Permanent
📁 *Size:* ${formatSize(media.length)}

_File akan disimpan permanen di server_
            `.trim(), m);
        } else {
            throw 'Upload gagal: ' + json.message;
        }

        if (wait) {
            await wait.delete();
        }

    } catch (e) {
        console.error(e);
        await m.reply(`❌ *ERROR:* ${e.message}`);
    }
};

function formatSize(size) {
    if (size >= 1024 * 1024 * 1024) {
        return (size / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    }
    if (size >= 1024 * 1024) {
        return (size / (1024 * 1024)).toFixed(2) + ' MB';
    }
    if (size >= 1024) {
        return (size / 1024).toFixed(2) + ' KB';
    }
    return size + ' B';
}

handler.help = ['nurl'];
handler.tags = ['tools'];
handler.command = /^(nurl|up)$/i;

handler.limit = true;
handler.premium = false;

module.exports = handler;