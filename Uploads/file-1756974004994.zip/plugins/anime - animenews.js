const axios = require('axios');
const cheerio = require('cheerio');
const schedule = require('node-schedule');
const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');

// Path ke file database animenews
const databasePath = path.resolve('./lib/animenews.json');

// Inisialisasi database jika belum ada
if (!fs.existsSync(databasePath)) {
  fs.writeFileSync(databasePath, JSON.stringify({
    schedule: {
      hour: 7,
      minute: 0
    },
    activeGroups: [], // Menyimpan ID grup yang diaktifkan
    isActive: false // Status global untuk mengecek apakah ada grup aktif
  }, null, 2));
}

// Baca database
let database = JSON.parse(fs.readFileSync(databasePath));

// Konfigurasi zona waktu dan waktu broadcast
const broadcastConfig = {
  timeZone: 'Asia/Makassar', // WITA (UTC+8)
  schedule: database.schedule || { hour: 7, minute: 0 }, // Default 07:00 WITA
};

// Validasi konfigurasi waktu
if (
  broadcastConfig.schedule.hour < 0 || broadcastConfig.schedule.hour > 23 ||
  broadcastConfig.schedule.minute < 0 || broadcastConfig.schedule.minute > 59
) {
  throw new Error('Konfigurasi waktu tidak valid. Gunakan jam 0-23 dan menit 0-59.');
}

// Variabel untuk menyimpan job jadwal
let broadcastJob = null;

// Set untuk melacak pengiriman harian
const dailyBroadcastStatus = new Map();

// Fungsi untuk mengambil berita terbaru dari kategori otaku
async function listAnimeNews() {
  try {
    const response = await axios.get('https://www.greenscene.co.id/category/otaku/');
    const $ = cheerio.load(response.data);
    const newsArticles = [];

    $('.td-block-span6').each((i, element) => {
      const title = $(element).find('.entry-title a').text().trim();
      const link = $(element).find('.entry-title a').attr('href');
      const date = $(element).find('.td-post-date').text().trim();
      const thumbnail = $(element).find('.td-module-thumb img').attr('src');

      if (title && link && date && thumbnail) {
        const currentYear = new Date().getFullYear();
        const articleYear = parseInt(date.split(' ')[2]);
        if (articleYear >= currentYear) {
          newsArticles.push({ title, link, date, thumbnail });
        }
      }
    });

    return newsArticles;
  } catch (error) {
    return `Error: ${error.message}`;
  }
}

// Fungsi untuk mengirimkan berita
async function sendAnimeNews(conn, chatId) {
  try {
    let newsList = await listAnimeNews();
    if (typeof newsList === 'string' || newsList.length === 0) {
      console.log('Tidak Ditemukan Berita Anime Terbaru!');
      await conn.sendMessage(chatId, { text: 'Tidak Ditemukan Berita Anime Terbaru!' });
      return false;
    }

    let randomArticle = newsList[Math.floor(Math.random() * newsList.length)];

    let newsMessage = `*Berita Anime Terbaru:*\n\n`;
    newsMessage += `🔹 *Judul*: ${randomArticle.title}\n`;
    newsMessage += `📅 *Tanggal*: ${randomArticle.date}\n`;
    newsMessage += `🔗 *Link*: ${randomArticle.link}\n\n`;

    await conn.sendFile(chatId, randomArticle.thumbnail, 'thumbnail.jpg', newsMessage);
    console.log(`Berita anime dikirim ke ${chatId}`);
    return true;
  } catch (error) {
    console.error(`Gagal mengirim berita ke ${chatId}:`, error.message);
    await conn.sendMessage(chatId, { text: `❌ Error: ${error.message}` });
    return false;
  }
}

// Objek handler
const handler = {
  // Fungsi utama untuk memulai autobroadcast untuk grup tertentu
  startAnimeNewsBroadcast: function (conn, chatId) {
    if (!database.activeGroups.includes(chatId)) {
      database.activeGroups.push(chatId);
      console.log(`Grup ${chatId} ditambahkan ke daftar aktif`);
    }

    if (broadcastJob) {
      console.log('⚠️ Jadwal broadcast animenews sudah berjalan!');
      fs.writeFileSync(databasePath, JSON.stringify(database, null, 2));
      return true; // Tidak perlu membuat ulang job
    }

    console.log(`⏳ Menjadwalkan animenews pada ${broadcastConfig.schedule.hour}:${broadcastConfig.schedule.minute.toString().padStart(2, '0')} WITA...`);

    const rule = new schedule.RecurrenceRule();
    rule.hour = broadcastConfig.schedule.hour;
    rule.minute = broadcastConfig.schedule.minute;
    rule.tz = broadcastConfig.timeZone;

    broadcastJob = schedule.scheduleJob(rule, async () => {
      console.log(`🚀 Broadcast animenews dipicu pada ${new Date().toLocaleString('en-US', { timeZone: broadcastConfig.timeZone })}`);
      await this.sendBroadcast(conn);
    });

    database.isActive = true;
    fs.writeFileSync(databasePath, JSON.stringify(database, null, 2));

    console.log('✅ Jadwal animenews telah dibuat!');
    return true;
  },

  // Fungsi untuk menghentikan autobroadcast untuk grup tertentu
  stopAnimeNewsBroadcast: function (chatId) {
    if (database.activeGroups.includes(chatId)) {
      database.activeGroups = database.activeGroups.filter(id => id !== chatId);
      console.log(`Grup ${chatId} dihapus dari daftar aktif`);
    }

    if (database.activeGroups.length === 0 && broadcastJob) {
      broadcastJob.cancel();
      broadcastJob = null;
      database.isActive = false;
      console.log('🛑 Jadwal animenews telah dihentikan karena tidak ada grup aktif!');
    }

    fs.writeFileSync(databasePath, JSON.stringify(database, null, 2));
    return true;
  },

  // Fungsi untuk mengirim broadcast ke grup yang diaktifkan
  sendBroadcast: async function (conn) {
    try {
      const date = new Date(new Date().toLocaleString('en-US', { timeZone: broadcastConfig.timeZone }));
      const today = date.toDateString();

      if (dailyBroadcastStatus.get(today)) {
        console.log('Broadcast animenews sudah dikirim hari ini');
        return;
      }

      if (!database.activeGroups || database.activeGroups.length === 0) {
        console.log('Tidak ada grup yang diaktifkan untuk animenews');
        await conn.sendMessage(conn.user.id, {
          text: 'Tidak ada grup yang diaktifkan untuk animenews. 😔'
        });
        return;
      }

      let successCount = 0;
      let failedCount = 0;

      for (let groupId of database.activeGroups) {
        try {
          // Verifikasi apakah bot masih admin di grup
          let groupMetadata = await conn.groupMetadata(groupId);
          const botId = conn.user.id.split(':')[0] + '@s.whatsapp.net';
          const botParticipant = groupMetadata.participants.find(p => p.id === botId);
          if (!botParticipant || !botParticipant.admin) {
            console.log(`Bot bukan admin di grup ${groupId}, menghapus dari daftar aktif`);
            database.activeGroups = database.activeGroups.filter(id => id !== groupId);
            failedCount++;
            continue;
          }

          if (await sendAnimeNews(conn, groupId)) {
            successCount++;
          } else {
            failedCount++;
          }
        } catch (error) {
          failedCount++;
          console.error(`Gagal mengirim ke grup ${groupId}:`, error.message);
        }
        await new Promise(resolve => setTimeout(resolve, 7000)); // Delay 7 detik
      }

      dailyBroadcastStatus.set(today, true);
      fs.writeFileSync(databasePath, JSON.stringify(database, null, 2)); // Simpan perubahan activeGroups
      console.log(`Broadcast animenews selesai: ${successCount} grup berhasil, ${failedCount} grup gagal`);

      if (successCount > 0 || failedCount > 0) {
        await conn.sendMessage(conn.user.id, {
          text: `🎉 Broadcast animenews selesai: ${successCount} grup berhasil, ${failedCount} grup gagal`
        });
      }

    } catch (error) {
      console.error('Error dalam autobroadcast animenews:', error);
      await conn.sendMessage(conn.user.id, {
        text: `❌ Error dalam autobroadcast animenews: ${error.message}`
      });
    }
  },

  // Fungsi untuk mengatur waktu broadcast
  setBroadcastTime: function ({ hour, minute }) {
    if (
      typeof hour !== 'number' || typeof minute !== 'number' ||
      hour < 0 || hour > 23 || minute < 0 || minute > 59
    ) {
      console.log('Error: Jam atau menit tidak valid. Gunakan format 0-23 untuk jam dan 0-59 untuk menit.');
      return false;
    }

    broadcastConfig.schedule.hour = hour;
    broadcastConfig.schedule.minute = minute;
    database.schedule.hour = hour;
    database.schedule.minute = minute;
    fs.writeFileSync(databasePath, JSON.stringify(database, null, 2));
    console.log(`Waktu animenews diubah ke ${hour}:${minute.toString().padStart(2, '0')} WITA ⏰`);

    if (broadcastJob) {
      this.stopAnimeNewsBroadcast(null); // Hentikan semua jadwal
      if (database.activeGroups.length > 0) {
        this.startAnimeNewsBroadcast(global.conn, database.activeGroups[0]); // Mulai ulang dengan grup pertama
      }
    }

    return true;
  },

  // Fungsi untuk mendapatkan waktu broadcast
  getBroadcastTime: function () {
    return { ...broadcastConfig.schedule };
  }
};

// Handler untuk perintah
handler.before = async (m, { conn, isOwner }) => {
  if (!m.text || m.fromMe || !m.chat) return;

  const text = m.text.toLowerCase();

  // Perintah .animenews
  if (text.match(/^\.animenews$/i)) {
    console.log(`Perintah .animenews diterima dari ${m.sender}`);
    try {
      await conn.reply(m.chat, 'Sedang mencari berita anime... Silahkan tunggu', m);
      await sendAnimeNews(conn, m.chat);
      await conn.reply(m.chat, 'Semoga Membantu! 🙂', m);
      return false;
    } catch (error) {
      console.error('Error dalam .animenews:', error);
      await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` }, { quoted: m });
      return false;
    }
  }

  // Perintah .animenews info
  if (text.match(/^\.animenews info$/i)) {
    console.log(`Perintah .animenews info diterima dari ${m.sender}`);
    try {
      const features = `📢 *Daftar Fitur AnimeNews* 📢

1️⃣ *.animenews*  
   Ketik: \`.animenews\`  
   Langsung mengambil dan menampilkan berita anime terbaru.

2️⃣ *.animenews jadwal*  
   Ketik: \`.animenews jadwal\`  
   Tampilkan waktu broadcast saat ini (misalnya, 07:00 WITA) dan status grup ini (aktif/tidak aktif).

3️⃣ *.animenews on*  
   Ketik: \`.animenews on\`  
   Mulai jadwal broadcast berita anime otomatis untuk grup ini.

4️⃣ *.animenews off*  
   Ketik: \`.animenews off\`  
   Hentikan jadwal broadcast berita anime untuk grup ini.

5️⃣ *.animenews set <jam:menit>*  
   Ketik: \`.animenews set 09:21\`  
   Ubah waktu broadcast untuk semua grup aktif (format HH:mm). Default: 07:00 WITA.

🌟 Perintah kecuali *.animenews* hanya untuk *Owner* dan memerlukan bot sebagai admin!`;
      await conn.sendMessage(m.chat, { text: features }, { quoted: m });
      return false;
    } catch (error) {
      console.error('Error dalam .animenews info:', error);
      await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` }, { quoted: m });
      return false;
    }
  }

  // Perintah .animenews jadwal
  if (text.match(/^\.animenews jadwal$/i)) {
    console.log(`Perintah .animenews jadwal diterima dari ${m.sender}`);
    try {
      if (!isOwner) {
        await conn.sendMessage(m.chat, { text: `🚫 Maaf, hanya *Owner* yang bisa melihat jadwal animenews!` }, { quoted: m });
        return false;
      }

      const time = `${broadcastConfig.schedule.hour}:${broadcastConfig.schedule.minute.toString().padStart(2, '0')} WITA`;
      const message = `📅 *Jadwal AnimeNews*\n\n🕒 Waktu: ${time}\n\nGrup ini: ${database.activeGroups.includes(m.chat) ? '✅ Aktif' : '⛔ Tidak aktif'}`;
      await conn.sendMessage(m.chat, { text: message }, { quoted: m });
      return false;
    } catch (error) {
      console.error('Error dalam .animenews jadwal:', error);
      await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` }, { quoted: m });
      return false;
    }
  }

  // Perintah .animenews on
  if (text.match(/^\.animenews on$/i)) {
    console.log(`Perintah .animenews on diterima dari ${m.sender}`);
    try {
      if (!isOwner) {
        await conn.sendMessage(m.chat, { text: `🚫 Maaf, hanya *Owner* yang bisa memulai jadwal animenews!` }, { quoted: m });
        return false;
      }

      // Verifikasi apakah bot admin
      let groupMetadata = await conn.groupMetadata(m.chat);
      const botId = conn.user.id.split(':')[0] + '@s.whatsapp.net';
      const botParticipant = groupMetadata.participants.find(p => p.id === botId);
      if (!botParticipant || !botParticipant.admin) {
        await conn.sendMessage(m.chat, { text: `🚫 Bot harus menjadi admin untuk mengaktifkan animenews di grup ini!` }, { quoted: m });
        return false;
      }

      if (handler.startAnimeNewsBroadcast(conn, m.chat)) {
        await conn.sendMessage(m.chat, { text: `🎉 Jadwal animenews berhasil dimulai pada ${broadcastConfig.schedule.hour}:${broadcastConfig.schedule.minute.toString().padStart(2, '0')} WITA untuk grup ini!` }, { quoted: m });
      } else {
        await conn.sendMessage(m.chat, { text: `⚠️ Jadwal animenews sudah aktif untuk grup ini!` }, { quoted: m });
      }
      return false;
    } catch (error) {
      console.error('Error dalam .animenews on:', error);
      await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` }, { quoted: m });
      return false;
    }
  }

  // Perintah .animenews off
  if (text.match(/^\.animenews off$/i)) {
    console.log(`Perintah .animenews off diterima dari ${m.sender}`);
    try {
      if (!isOwner) {
        await conn.sendMessage(m.chat, { text: `🚫 Maaf, hanya *Owner* yang bisa menghentikan jadwal animenews!` }, { quoted: m });
        return false;
      }

      if (handler.stopAnimeNewsBroadcast(m.chat)) {
        await conn.sendMessage(m.chat, { text: `🛑 Jadwal animenews berhasil dihentikan untuk grup ini!` }, { quoted: m });
      } else {
        await conn.sendMessage(m.chat, { text: `⚠️ Jadwal animenews tidak aktif untuk grup ini!` }, { quoted: m });
      }
      return false;
    } catch (error) {
      console.error('Error dalam .animenews off:', error);
      await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` }, { quoted: m });
      return false;
    }
  }

  // Perintah .animenews set
  if (text.startsWith('.animenews set')) {
    console.log(`Perintah .animenews set diterima dari ${m.sender}`);
    try {
      if (!isOwner) {
        await conn.sendMessage(m.chat, { text: `🚫 Maaf, hanya *Owner* yang bisa mengubah waktu animenews!` }, { quoted: m });
        return false;
      }

      const timeMatch = m.text.match(/\.animenews set\s+(\d{1,2}):(\d{1,2})/);
      if (!timeMatch) {
        await conn.sendMessage(m.chat, { text: `❌ Format waktu salah! Contoh: \`.animenews set 09:21\`` }, { quoted: m });
        return false;
      }

      const hour = parseInt(timeMatch[1], 10);
      const minute = parseInt(timeMatch[2], 10);

      if (handler.setBroadcastTime({ hour, minute })) {
        await conn.sendMessage(m.chat, { text: `✅ Waktu animenews berhasil diubah ke ${hour}:${minute.toString().padStart(2, '0')} WITA untuk semua grup aktif!` }, { quoted: m });
      } else {
        await conn.sendMessage(m.chat, { text: `❌ Gagal mengubah waktu. Pastikan format HH:mm (0-23 untuk jam, 0-59 untuk menit)!` }, { quoted: m });
      }
      return false;
    } catch (error) {
      console.error('Error dalam .animenews set:', error);
      await conn.sendMessage(m.chat, { text: `❌ Error: ${error.message}` }, { quoted: m });
      return false;
    }
  }
};

// Properti handler untuk perintah
handler.command = /^(animenews|animenews info|animenews jadwal|animenews on|animenews off|animenews set)$/i;
handler.owner = true; // Hanya .animenews yang tidak memerlukan owner
handler.group = true;
handler.botAdmin = true;
handler.help = [
  'animenews',
  'animenews info',
  'animenews jadwal',
  'animenews on',
  'animenews off',
  'animenews set <HH:mm>'
];
handler.tags = ['anime'];

// Inisialisasi jadwal saat bot mulai
if (global.conn) {
  setTimeout(() => {
    if (database.isActive && database.activeGroups.length > 0) {
      console.log('🔄 Mengaktifkan animenews berdasarkan pengaturan sebelumnya...');
      handler.startAnimeNewsBroadcast(global.conn, database.activeGroups[0]);
    }
  }, 10000); // Tunggu 10 detik agar koneksi stabil
} else {
  console.error('❌ Koneksi ke WhatsApp belum ada!');
}

module.exports = handler;