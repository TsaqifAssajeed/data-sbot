/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

let handler = async (m, { conn, text }) => {
    if (!text) throw 'Prompt tidak boleh kosong. Gunakan perintah dengan memasukkan prompt.';

    await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    try {
        await conn.sendMessage(m.chat, {
            image: { url: `https://imgen.duck.mom/prompt/${encodeURIComponent(text)}` },
            caption: `Succes Get Your Prompt✨`
        }, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan saat mengambil gambar.');
    }
};

handler.help = ['diff'].map(v => v + ' [prompt]');
handler.tags = ['anime', 'ai'];
handler.command = /^(diff)$/i;

module.exports = handler;