// ✨ Plugin info-totalfitur dengan emot & total scrape ✨

let fs = require('fs')
let path = require('path')

let handler = async (m, { conn, args, command }) => {
  let fitur = Object.values(features).filter(v => v.help && !v.disabled).map(v => v.help).flat(1)
  let totalf = Object.values(global.features).filter(v => v.help && v.tags).length
  let hasil = fitur.length

  // Hitung total file dalam folder scrape
  let scrapePath = '/home/container/scrape'
  let totalScrape = 0
  try {
    let files = fs.readdirSync(scrapePath)
    totalScrape = files.length
  } catch (err) {
    totalScrape = 0 // Jika folder tidak ada atau error
  }

  let txt = `╭─〔 𝙄𝙉𝙁𝙊 𝙁𝙄𝙏𝙐𝙍 ✨ 〕\n`
  txt += `│ 🤖 Nama Bot: *${namebot}*\n`
  txt += `│ ⚙ Total Fitur: *${hasil}*\n`
  txt += `│ 📁 Total Folder : *${totalf}*\n`
  txt += `│ 📑 Total Scrape : *${totalScrape}*\n`
  txt += `│ 🔥 Total Api Premium : *4*\n`
  txt += `╰───────────────⟢`

  conn.reply(m.chat, txt, fkontak, adReply)
}

handler.help = ['totalfitur *[total features view]*']
handler.tags = ['info']
handler.command = ['totalfitur']

module.exports = handler
