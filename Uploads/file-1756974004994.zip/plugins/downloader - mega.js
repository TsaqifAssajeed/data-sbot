const { File } = require('megajs');
const path = require('path');

let handler = async (m, { conn, usedPrefix, command, args }) => {
    // Validasi input URL dengan emoji
    let input = `*Format Salah* ❌\nContoh:\n\n> ${usedPrefix + command} https://mega.nz/file/ex4FAL6C#FvtquKNK5ia8M5oe1ZpFG8e0y4KnMWciqw5RGopxk0g`;
    if (!args[0]) return conn.sendMessage(m.chat, { text: input }, { quoted: m });

    // Debugging: Log struktur m
    console.log('Struktur m:', JSON.stringify(m, null, 2));

    // Pesan awal dengan emoji loading
    let processingMsg;
    try {
        processingMsg = await conn.sendMessage(m.chat, { text: '⏳ _Sedang memproses unduhan, mohon tunggu..._' }, { quoted: m });
    } catch (e) {
        console.error('Gagal mengirim pesan proses:', e);
        return conn.sendMessage(m.chat, { text: '⚠️ Terjadi kesalahan saat memulai proses.' }, { quoted: m });
    }

    try {
        const data = await MegaDl(args[0]);

        // Validasi data yang diunduh
        if (!data.buffer || !data.name) {
            throw new Error('Gagal mendapatkan file atau nama file tidak valid.');
        }

        const ext = path.extname(data.name) || '';
        await conn.sendMessage(m.chat, { 
            document: data.buffer, 
            fileName: data.name, 
            mimetype: ext ? `application/${ext.slice(1)}` : 'application/octet-stream' 
        }, { quoted: m });

        // Pesan sukses dengan emoji
        await conn.sendMessage(m.chat, { text: `✅ _File *${data.name}* berhasil diunduh!_` }, { quoted: m });
    } catch (e) {
        console.error('Error saat mengunduh:', e);
        await conn.sendMessage(m.chat, { text: `❌ Error: ${e.message || 'Gagal mengunduh file.'}` }, { quoted: m });
    } finally {
        // Hapus pesan proses jika ada
        if (processingMsg && processingMsg.key) {
            try {
                await conn.sendMessage(m.chat, { delete: processingMsg.key });
            } catch (e) {
                console.error('Gagal menghapus pesan proses:', e);
            }
        }
    }
};

handler.help = ['megadl <url>'];
handler.tags = ['downloader'];
handler.command = /^(mega|megadl)$/i;
handler.limit = 2;
handler.premium = false;

module.exports = handler;

async function MegaDl(url) {
    if (!(url && url.match(/mega\.nz/i))) throw new Error('URL tidak valid, pastikan menggunakan link Mega.nz 🔗');
    
    try {
        const file = File.fromURL(url);
        await file.loadAttributes();
        const buffer = await file.downloadBuffer();
        
        if (!buffer) throw new Error('Gagal mengunduh file 📥');
        
        return {
            downloadUrl: url,
            name: file.name,
            fileSize: file.size,
            buffer
        };
    } catch (e) {
        throw new Error(`Gagal memproses file: ${e.message} 🚫`);
    }
}