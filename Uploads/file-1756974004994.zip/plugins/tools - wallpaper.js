const axios = require('axios');
const cheerio = require('cheerio');
const { default: makeWASocket } = require('@whiskeysockets/baileys');

const uphd = async (searchTerm) => {
    try {
        const response = await axios.get(`https://www.uhdpaper.com/search?q=${encodeURIComponent(searchTerm)}&by-date=true`);
        const html = response.data;
        const $ = cheerio.load(html);
        const results = [];

        $('article.post-outer-container').each((index, element) => {
            const title = $(element).find('.snippet-title h2').text().trim() || 'Tidak ada judul';
            let imageUrl = $(element).find('.snippet-title img').attr('src');
            const resolution = $(element).find('.wp_box b').text().trim() || 'Resolusi tidak tersedia';
            let link = $(element).find('a').attr('href');

            if (imageUrl && !imageUrl.startsWith('http')) {
                imageUrl = `https://www.uhdpaper.com${imageUrl}`;
            }
            
            if (link && !link.startsWith('http')) {
                link = `https://www.uhdpaper.com${link}`;
            }

            if (title && imageUrl && resolution && link) {
                results.push({ title, imageUrl, resolution, link });
            }
        });

        return results;
    } catch (error) {
        console.error('Error fetching wallpapers:', error.message);
        return [];
    }
};

let handler = async (m, { conn, args }) => {
    if (!args[0]) {
        return m.reply('🖼️ *Wallpaper Finder*\n\nMasukkan kata kunci pencarian wallpaper *DALAM BAHASA INGGRIS*!\n\n> AGAR TIDAK ERROR, GUNAAKN HANYA SATU KATA SAYA DALAM QUERY NYA.!! MISAL .wallpaper nature');
    }

    m.reply('🔍 Mencari wallpaper terbaik untuk Anda, mohon tunggu...');
    const results = await uphd(args.join(' '));

    if (!results || results.length === 0) {
        return m.reply('❌ Tidak ditemukan wallpaper dengan kata kunci tersebut. \n> Coba kata kunci lain! dan pastikan dalam bahasa inggris misal .wallpaper ghost');
    }

    const wallpaper = results[0]; // Ambil hasil pertama
    const caption = `✨ *${wallpaper.title}* ✨\n\n📏 *Resolusi*: ${wallpaper.resolution}\n🔗 *Link Download*: [Klik di sini](${wallpaper.link})\n\n_Cari wallpaper lainnya hanya dengan bot ini!_`;

    try {
        await conn.sendFile(m.chat, wallpaper.imageUrl, 'wallpaper.jpg', caption, m);
    } catch (err) {
        console.error('Error sending wallpaper:', err.message);
        return m.reply('❌ Gagal mengirim wallpaper. Coba lagi nanti!');
    }
};

handler.help = ['wallpaper'];
handler.tags = ['tools'];
handler.command = /^(wallpaper|wpsearch|uhdwall)$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;