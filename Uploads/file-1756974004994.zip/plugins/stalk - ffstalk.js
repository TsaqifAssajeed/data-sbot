const axios = require('axios');

let handler = async (m, { conn, text, args, prefix, command }) => {
  if (!args[0]) {
    return m.reply(`Masukkan ID Game Free Fire dan (opsional) Region.\n\nContoh:\n${prefix + command} 12345678 ID`);
  }

  const [ffId, region = 'GLOBAL'] = args;
  const validRegions = ['ID', 'US', 'BR', 'IN', 'SG', 'PK', 'GLOBAL'];
  if (!validRegions.includes(region.toUpperCase())) {
    return m.reply(`Region tidak valid. Gunakan salah satu: ${validRegions.join(', ')}`);
  }

  try {
    await m.reply('_Sedang memproses data..._');

 const userUid = 'ljeHvIZSWzM5IUjZ1sb0w69XlcP2'; // Ganti dengan useruid Anda dari hlgamingofficial.com
    const apiKey = 'h0Ez0Xcg6wKPHhQHAVJK5GNZ2iGMKV'; // API key Anda

    // Kirim POST request ke API
    const response = await axios.post(
      'https://hl-gaming-official-main-api-beige.vercel.app/api',
      {
        sectionName: 'AllData',
        PlayerUid: ffId,
        region: region.toLowerCase(),
        useruid: userUid,
        api: apiKey
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36'
        }
      }
    );

    // Log respons API untuk debugging
    console.log('API Status:', response.status);
    console.log('API Response:', JSON.stringify(response.data, null, 2));

    // Periksa apakah data ada dan valid
    if (!response.data || !response.data.result || !response.data.result.AccountInfo) {
      return m.reply(`Data tidak ditemukan atau ID/Region/UserUID salah.\n> Respons API: ${JSON.stringify(response.data || 'Kosong')}`);
    }

    const result = response.data.result;

    // Periksa apakah ID cocok
    let idWarning = '';
    if (result.AccountInfo.AccountBPID.toString() !== ffId) {
      idWarning = `⚠️ *Peringatan*: ID yang diminta (${ffId}) tidak ditemukan. Menampilkan data untuk ID ${result.AccountInfo.AccountBPID}.\n`;
    }

    // Struktur data akun
    const account = {
      id: result.AccountInfo?.AccountBPID || ffId,
      name: result.AccountInfo?.AccountName || 'Tidak tersedia',
      level: result.AccountInfo?.AccountLevel || 'Tidak tersedia',
      xp: result.AccountInfo?.AccountEXP || 'Tidak tersedia',
      region: result.AccountInfo?.AccountRegion || region.toUpperCase(),
      like: result.AccountInfo?.AccountLikes || 'Tidak tersedia',
      bio: result.socialinfo?.AccountSignature || 'Tidak tersedia',
      create_time: result.AccountInfo?.AccountCreateTime
        ? new Date(parseInt(result.AccountInfo.AccountCreateTime) * 1000).toLocaleString() : 'Tidak tersedia',
      last_login: result.AccountInfo?.AccountLastLogin
        ? new Date(parseInt(result.AccountInfo.AccountLastLogin) * 1000).toLocaleString() : 'Tidak tersedia',
      honor_score: result.creditScoreInfo?.score || 'Tidak tersedia',
      booyah_pass: result.AccountInfo?.booyahPass ? 'Aktif' : 'Tidak tersedia',
      booyah_pass_badge: result.AccountInfo?.booyahBadge || 'Tidak tersedia',
      evo_access_badge: result.AccountInfo?.evoBadge || 'Tidak tersedia',
      equipped_title: result.AccountProfileInfo?.equippedTitle || 'Tidak tersedia',
      BR_points: result.AccountInfo?.BrRankPoint || 'Tidak tersedia',
      CS_points: result.AccountInfo?.CsRankPoint || 'Tidak tersedia',
    };

    // Struktur data pet
    const petInfo = {
      name: result.petInfo?.name || 'Tidak tersedia',
      level: result.petInfo?.level || 'Tidak tersedia',
      type: result.petInfo?.type || 'Tidak tersedia',
      xp: result.petInfo?.xp || 'Tidak tersedia',
    };

    // Struktur data guild
    const guild = {
      name: result.GuildInfo?.name || 'Tidak tersedia',
      id: result.GuildInfo?.id || 'Tidak tersedia',
      level: result.GuildInfo?.level || 'Tidak tersedia',
      member: result.GuildInfo?.memberCount || 'Tidak tersedia',
      capacity: result.GuildInfo?.capacity || 'Tidak tersedia',
    };

    // Struktur data ketua guild
    const ketuaGuild = {
      name: result.captainBasicInfo?.name || 'Tidak tersedia',
      id: result.captainBasicInfo?.id || 'Tidak tersedia',
      level: result.captainBasicInfo?.level || 'Tidak tersedia',
      xp: result.captainBasicInfo?.xp || 'Tidak tersedia',
      like: result.captainBasicInfo?.likes || 'Tidak tersedia',
      equipped_title: result.captainBasicInfo?.equippedTitle || 'Tidak tersedia',
      BR_points: result.captainBasicInfo?.BrRankPoint || 'Tidak tersedia',
      CS_points: result.captainBasicInfo?.CsRankPoint || 'Tidak tersedia',
      BP_badges: result.captainBasicInfo?.bpBadge || 'Tidak tersedia',
      create_time: result.captainBasicInfo?.createTime
        ? new Date(parseInt(result.captainBasicInfo.createTime) * 1000).toLocaleString() : 'Tidak tersedia',
      last_login: result.captainBasicInfo?.lastLogin
        ? new Date(parseInt(result.captainBasicInfo.lastLogin) * 1000).toLocaleString() : 'Tidak tersedia',
    };

    // Format output
    const resultText = `*[ STALK FF ]*\n\n` +
      idWarning +
      `> *Account Info:*\n` +
      `  *ID*: ${account.id}\n` +
      `  *Name*: ${account.name}\n` +
      `  *Level*: ${account.level}\n` +
      `  *XP*: ${account.xp}\n` +
      `  *Region*: ${account.region}\n` +
      `  *Like*: ${account.like}\n` +
      `  *Bio*: ${account.bio}\n` +
      `  *Created At*: ${account.create_time}\n` +
      `  *Last Login*: ${account.last_login}\n` +
      `  *Honor Score*: ${account.honor_score}\n` +
      `  *Booyah Pass*: ${account.booyah_pass}\n` +
      `  *Booyah Badge*: ${account.booyah_pass_badge}\n` +
      `  *Evo Access Badge*: ${account.evo_access_badge}\n` +
      `  *Equipped Title*: ${account.equipped_title}\n` +
      `  *BR Points*: ${account.BR_points}\n` +
      `  *CS Points*: ${account.CS_points}\n\n` +
      `> *Pet Info:*\n` +
      `  *Name*: ${petInfo.name}\n` +
      `  *Level*: ${petInfo.level}\n` +
      `  *Type*: ${petInfo.type}\n` +
      `  *XP*: ${petInfo.xp}\n\n` +
      `> *Guild Info:*\n` +
      `  *Name*: ${guild.name}\n` +
      `  *ID*: ${guild.id}\n` +
      `  *Level*: ${guild.level}\n` +
      `  *Members*: ${guild.member}\n` +
      `  *Capacity*: ${guild.capacity}\n\n` +
      `> *Guild Leader Info:*\n` +
      `  *Name*: ${ketuaGuild.name}\n` +
      `  *ID*: ${ketuaGuild.id}\n` +
      `  *Level*: ${ketuaGuild.level}\n` +
      `  *XP*: ${ketuaGuild.xp}\n` +
      `  *Like*: ${ketuaGuild.like}\n` +
      `  *Equipped Title*: ${ketuaGuild.equipped_title}\n` +
      `  *BR Points*: ${ketuaGuild.BR_points}\n` +
      `  *CS Points*: ${ketuaGuild.CS_points}\n` +
      `  *BP Badge*: ${ketuaGuild.BP_badges}\n` +
      `  *Created At*: ${ketuaGuild.create_time}\n` +
      `  *Last Login*: ${ketuaGuild.last_login}`;

    await conn.sendMessage(m.chat, { text: resultText, mentions: [m.sender] }, { quoted: m });
  } catch (error) {
    console.error('Error:', error);
    m.reply(`Terjadi kesalahan saat mengambil data.\n> Error: ${error.message}\n> Pastikan useruid, API key, ID, dan region valid. Periksa hlgamingofficial.com/p/api.html.\n> Respons API: ${error.response ? JSON.stringify(error.response.data || 'Kosong') : 'Tidak ada respons'}`);
  }
};

handler.command = ['ffstalk', 'stalkff', 'cekidff'];
handler.help = ['ffstalk <id> [region]', 'stalkff <id> [region]', 'cekidff <id> [region]'];
handler.tags = ['stalk', 'premium'];
handler.limit = true;
handler.premium = true;

module.exports = handler;