// rpg - shop.js
// Konstanta harga beli (B) dan jual (S) untuk setiap item
const potion = 20000;
const Spotion = 100;
const Bdiamond = 100000;
const Sdiamond = 1000;
const Bcommon = 100000;
const Scommon = 1000;
const Buncommon = 100000;
const Suncommon = 100;
const Bmythic = 100000;
const Smythic = 1000;
const Blegendary = 200000;
const Slegendary = 5000;
const Bsampah = 120;
const Ssampah = 5;
const Bkayu = 1000;
const Skayu = 400;
const Bbotol = 300;
const Sbotol = 50;
const Bkaleng = 400;
const Skaleng = 100;
const Bkardus = 400;
const Skardus = 50;
const Bpisang = 5500;
const Spisang = 100;
const Bmangga = 4600;
const Smangga = 150;
const Bjeruk = 6000;
const Sjeruk = 300;
const Banggur = 5500;
const Sanggur = 150;
const Bapel = 5500;
const Sapel = 400;
const Bbibitpisang = 550;
const Sbibitpisang = 50;
const Bbibitmangga = 550;
const Sbibitmangga = 50;
const Bbibitjeruk = 550;
const Sbibitjeruk = 50;
const Bbibitanggur = 550;
const Sbibitanggur = 50;
const Bbibitapel = 550;
const Sbibitapel = 50;
const Bgardenboxs = 65000;
const Sgardenboxs = 350000; // Perbaikan penamaan dari Sgardenboc
const Bberlian = 150000;
const Sberlian = 10000;
const Bemasbiasa = 150000; // Emas biasa
const Semasbiasa = 15000;
const Bphonix = 1000000000;
const Sphonix = 1000000;
const Bgriffin = 100000000;
const Sgriffin = 100000;
const Bkyubi = 100000000;
const Skyubi = 100000;
const Bnaga = 100000000;
const Snaga = 100000;
const Bcentaur = 100000000;
const Scentaur = 100000;
const Bkuda = 50000000;
const Skuda = 100000;
const Brubah = 100000000;
const Srubah = 100000;
const Bkucing = 5000000;
const Skucing = 50000;
const Bserigala = 50000000;
const Sserigala = 500000;
const Bmakananpet = 50000;
const Smakananpet = 500;
const Bmakananphonix = 80000;
const Smakananphonix = 5000;
const Bmakanangriffin = 80000;
const Smakanangriffin = 5000;
const Bmakanannaga = 150000;
const Smakanannaga = 10000;
const Bmakanankyubi = 150000;
const Smakanankyubi = 10000;
const Bmakanancentaur = 150000;
const Smakanancentaur = 10000;
const Bhealtmonster = 20000;
const Bpet = 150000;
const Spet = 1000;
const Blimit = 10000;
const Slimit = 5000;
const Baqua = 5000;
const Saqua = 1000;
const Biron = 20000;
const Siron = 5000;
const Bstring = 50000;
const Sstring = 5000;
const Bsword = 150000;
const Ssword = 15000;
const Bumpan = 1500;
const Sumpan = 100;
const Bpancingan = 50000;
const Spancingan = 50000;
const Bbatu = 500;
const Sbatu = 100;
const Btiketcoin = 500;
const Bkoinexpg = 500000;

let handler = async (m, { conn, command, args, usedPrefix }) => {
    // Menentukan harga armor berdasarkan level
    const _armor = global.db.data.users[m.sender].armor;
    const armor = _armor === 0 ? 20000 : _armor === 1 ? 49999 : _armor === 2 ? 99999 : _armor === 3 ? 149999 : _armor === 4 ? 299999 : 0;

    // Parsing argumen
    let action = (args[0] || '').toLowerCase();
    let item = (args[1] || '').toLowerCase();
    let count = args[2] && args[2].length > 0 ? Math.min(999999999999999, Math.max(parseInt(args[2]), 1)) : 1;

    // Daftar harga untuk ditampilkan di menu
    const Kchat = `
Penggunaan: *${usedPrefix}shop <buy|sell> <item> <jumlah>*
Contoh: *${usedPrefix}shop buy potion 1*

==========================
*Kebutuhan | Harga Beli | Harga Jual*
Limit:       ${Blimit} | ${Slimit}
TiketM:      ${Bhealtmonster} | -
Cupon:       ${Btiketcoin} | -
KoinExpg:    ${Bkoinexpg} | -

==========================
*Bibit | Harga Beli | Harga Jual*
BibitPisang: ${Bbibitpisang} | ${Sbibitpisang}
BibitAnggur: ${Bbibitanggur} | ${Sbibitanggur}
BibitMangga: ${Bbibitmangga} | ${Sbibitmangga}
BibitJeruk:  ${Bbibitjeruk} | ${Sbibitjeruk}
BibitApel:   ${Bbibitapel} | ${Sbibitapel}
Gardenboxs:  ${Bgardenboxs} | ${Sgardenboxs}

==========================
*Barang    | Harga Beli | Harga Jual*
Potion:      ${potion} | ${Spotion}
Diamond:     ${Bdiamond} | ${Sdiamond}
Common:      ${Bcommon} | ${Scommon}
Uncommon:    ${Buncommon} | ${Suncommon}
Mythic:      ${Bmythic} | ${Smythic}
Legendary:   ${Blegendary} | ${Slegendary}
Sampah:      ${Bsampah} | ${Ssampah}
Armor:       ${armor} | -
String:      ${Bstring} | ${Sstring}
Iron:        ${Biron} | ${Siron}
Sword:       ${Bsword} | ${Ssword}
Batu:        ${Bbatu} | ${Sbatu}
Botol:       ${Bbotol} | ${Sbotol}
Kaleng:      ${Bkaleng} | ${Skaleng}
Kardus:      ${Bkardus} | ${Skardus}
Kayu:        ${Bkayu} | ${Skayu}
Berlian:     ${Bberlian} | ${Sberlian}
Emas:        ${Bemasbiasa} | ${Semasbiasa}

==========================
*Makanan | Harga Beli | Harga Jual*
Pisang:      ${Bpisang} | ${Spisang}
Anggur:      ${Banggur} | ${Sanggur}
Mangga:      ${Bmangga} | ${Smangga}
Jeruk:       ${Bjeruk} | ${Sjeruk}
Apel:        ${Bapel} | ${Sapel}
MakananPet:  ${Bmakananpet} | ${Smakananpet}
MakananNaga: ${Bmakanannaga} | ${Smakanannaga}
MakananKyubi:${Bmakanankyubi} | ${Smakanankyubi}
MakananGriffin: ${Bmakanangriffin} | ${Smakanangriffin}
MakananPhonix: ${Bmakananphonix} | ${Smakananphonix}
MakananCentaur: ${Bmakanancentaur} | ${Smakanancentaur}

==========================
*Minuman | Harga Beli | Harga Jual*
Aqua:        ${Baqua} | ${Saqua}

==========================
*Fishing   | Harga Beli | Harga Jual*
Pancingan:   ${Bpancingan} | ${Spancingan}
Umpan:       ${Bumpan} | ${Sumpan}
`.trim();

    try {
        // Validasi perintah
        if (!/shop|toko|buy|beli|sell|jual/i.test(command)) {
            return conn.reply(m.chat, Kchat, m);
        }

        // Validasi action (buy atau sell)
        if (!['buy', 'sell'].includes(action)) {
            return conn.reply(m.chat, Kchat, m);
        }

        // Objek untuk memetakan item ke harga beli dan jual
        const items = {
            potion: { buy: potion, sell: Spotion, db: 'potion' },
            diamond: { buy: Bdiamond, sell: Sdiamond, db: 'diamond' },
            common: { buy: Bcommon, sell: Scommon, db: 'common' },
            uncommon: { buy: Buncommon, sell: Suncommon, db: 'uncommon' },
            mythic: { buy: Bmythic, sell: Smythic, db: 'mythic' },
            legendary: { buy: Blegendary, sell: Slegendary, db: 'legendary' },
            sampah: { buy: Bsampah, sell: Ssampah, db: 'sampah' },
            kaleng: { buy: Bkaleng, sell: Skaleng, db: 'kaleng' },
            kardus: { buy: Bkardus, sell: Skardus, db: 'kardus' },
            botol: { buy: Bbotol, sell: Sbotol, db: 'botol' },
            kayu: { buy: Bkayu, sell: Skayu, db: 'kayu' },
            pisang: { buy: Bpisang, sell: Spisang, db: 'pisang' },
            anggur: { buy: Banggur, sell: Sanggur, db: 'anggur' },
            mangga: { buy: Bmangga, sell: Smangga, db: 'mangga' },
            jeruk: { buy: Bjeruk, sell: Sjeruk, db: 'jeruk' },
            apel: { buy: Bapel, sell: Sapel, db: 'apel' },
            bibitpisang: { buy: Bbibitpisang, sell: Sbibitpisang, db: 'bibitpisang' },
            bibitanggur: { buy: Bbibitanggur, sell: Sbibitanggur, db: 'bibitanggur' },
            bibitmangga: { buy: Bbibitmangga, sell: Sbibitmangga, db: 'bibitmangga' },
            bibitjeruk: { buy: Bbibitjeruk, sell: Sbibitjeruk, db: 'bibitjeruk' },
            bibitapel: { buy: Bbibitapel, sell: Sbibitapel, db: 'bibitapel' },
            gardenboxs: { buy: Bgardenboxs, sell: Sgardenboxs, db: 'gardenboxs' },
            berlian: { buy: Bberlian, sell: Sberlian, db: 'berlian' },
            emas: { buy: Bemasbiasa, sell: Semasbiasa, db: 'emas' },
            pet: { buy: Bpet, sell: Spet, db: 'pet' },
            limit: { buy: Blimit, sell: Slimit, db: 'limit' },
            makananpet: { buy: Bmakananpet, sell: Smakananpet, db: 'makananpet' },
            makanannaga: { buy: Bmakanannaga, sell: Smakanannaga, db: 'makanannaga' },
            makananphonix: { buy: Bmakananphonix, sell: Smakananphonix, db: 'makananphonix' },
            makanankyubi: { buy: Bmakanankyubi, sell: Smakanankyubi, db: 'makanankyubi' },
            makanangriffin: { buy: Bmakanangriffin, sell: Smakanangriffin, db: 'makanangriffin' },
            makanancentaur: { buy: Bmakanancentaur, sell: Smakanancentaur, db: 'makanancentaur' },
            tiketm: { buy: Bhealtmonster, sell: null, db: 'healtmonster' },
            aqua: { buy: Baqua, sell: Saqua, db: 'aqua' },
            iron: { buy: Biron, sell: Siron, db: 'iron' },
            string: { buy: Bstring, sell: Sstring, db: 'string' },
            sword: { buy: Bsword, sell: Ssword, db: 'sword' },
            batu: { buy: Bbatu, sell: Sbatu, db: 'batu' },
            umpan: { buy: Bumpan, sell: Sumpan, db: 'umpan' },
            pancingan: { buy: Bpancingan, sell: Spancingan, db: 'pancingan' },
            cupon: { buy: Btiketcoin, sell: null, db: 'cupon', currency: 'tiketcoin' },
            armor: { buy: armor, sell: null, db: 'armor' },
        };

        // Logika pembelian
        if (action === 'buy') {
            if (!items[item]) {
                return conn.reply(m.chat, `Item *${item}* tidak ditemukan. Gunakan *${usedPrefix}shop* untuk melihat daftar item.`, m);
            }

            const { buy, db, currency = 'money' } = items[item];
            const cost = buy * count;
            const user = global.db.data.users[m.sender];

            if (item === 'armor' && user.armor >= 5) {
                return conn.reply(m.chat, 'Armormu sudah *Level Max*', m);
            }

            if (user[currency] < cost) {
                return conn.reply(m.chat, `${currency === 'tiketcoin' ? 'Tiketcoin' : 'Uang'} anda tidak cukup untuk membeli ${count} ${item} dengan harga ${cost} ${currency === 'tiketcoin' ? 'tiketcoin' : 'money'}.`, m);
            }

            user[currency] -= cost;
            if (item === 'armor') {
                user.armor += 1;
            } else {
                user[db] = (user[db] || 0) + count;
            }

            let message = `Sukses membeli ${count} ${item} dengan harga ${cost} ${currency === 'tiketcoin' ? 'tiketcoin' : 'money'}`;
            if (item === 'potion') {
                message += `\n\nGunakan potion dengan ketik: *${usedPrefix}use potion <jumlah>*`;
            } else if (['common', 'uncommon', 'mythic', 'legendary'].includes(item)) {
                message += `\n\nBuka crate dengan ketik: *${usedPrefix}open ${item}*`;
            } else if (item === 'cupon') {
                message += `\n\nCara mendapatkan tiketcoin: mainkan semua fitur game.`;
            }

            conn.reply(m.chat, message, m);
        }
        // Logika penjualan
        else if (action === 'sell') {
            if (!items[item] || items[item].sell === null) {
                return conn.reply(m.chat, `Item *${item}* tidak dapat dijual atau tidak ditemukan. Gunakan *${usedPrefix}shop* untuk melihat daftar item.`, m);
            }

            const { sell, db } = items[item];
            const gain = sell * count;
            const user = global.db.data.users[m.sender];

            if ((user[db] || 0) < count) {
                return conn.reply(m.chat, `${item.charAt(0).toUpperCase() + item.slice(1)} anda tidak cukup untuk dijual.`, m);
            }

            user[db] -= count;
            user.money = (user.money || 0) + gain;
            conn.reply(m.chat, `Sukses menjual ${count} ${item} dengan harga ${gain} money`, m);
        }
        // Jika action tidak valid, tampilkan menu
        else {
            conn.reply(m.chat, Kchat, m);
        }
    } catch (e) {
        conn.reply(m.chat, Kchat, m);
        console.log(e);
    }
};

handler.help = ['shop <buy|sell> <item> <jumlah>'];
handler.tags = ['rpg'];
handler.command = /^(shop|toko|buy|beli|sell|jual)$/i;
handler.limit = false;
handler.group = true;

module.exports = handler;