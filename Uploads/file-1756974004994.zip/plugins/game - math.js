// ✨ Plugin game - math ✨

let handler = async (m, { conn, args, usedPrefix, command }) => {
  conn.math = conn.math || {}
  let id = m.chat

  // Fitur menyerah
  if (command === 'surender') {
    if (!(id in conn.math)) return conn.reply(m.chat, '❌ Tidak ada soal yang sedang berlangsung.', m)
    let [_, math] = conn.math[id]
    conn.reply(m.chat, `🏳️ *Menyerah?*\nJawaban yang benar adalah: *${math.result}*`, m)
    clearTimeout(conn.math[id][3])
    delete conn.math[id]
    return
  }

  // Mulai tantangan math
  if (args.length < 1) throw `
📚 *Mode tersedia:* ${Object.keys(modes).join(' | ')}

💡 *Contoh:* ${usedPrefix}math epic
`.trim()

  let mode = args[0].toLowerCase()
  if (!(mode in modes)) throw `
📚 *Mode tersedia:* ${Object.keys(modes).join(' | ')}

💡 *Contoh:* ${usedPrefix}math epic
`.trim()

  if (id in conn.math) return conn.reply(m.chat, '⚠️ Soal sebelumnya belum terjawab!', conn.math[id][0])

  let math = genMath(mode)
  conn.math[id] = [
    await conn.reply(m.chat, `🧠 *Tantangan Matematika!*\n\n➡️ *Soal:* ${math.str}\n⏳ *Waktu:* ${(math.time / 1000).toFixed(2)} detik\n🎁 *Bonus:* +${math.bonus} XP\n\nKetik jawabanmu tanpa reply.\nMenyerah? ketik *.surender*`, m),
    math, 4,
    setTimeout(() => {
      if (conn.math[id]) conn.reply(m.chat, `⏰ *Waktu habis!*\nJawaban yang benar: *${math.result}*`, conn.math[id][0])
      delete conn.math[id]
    }, math.time)
  ]
}
handler.help = ['math [mode]', 'surender']
handler.tags = ['game']
handler.command = /^math|surender$/i
handler.group = true

module.exports = handler

// Cek jawaban user
let before = async (m, { conn }) => {
  conn.math = conn.math || {}
  let id = m.chat
  if (!(id in conn.math)) return
  let [msg, math] = conn.math[id]
  if (m.text == math.result.toString()) {
    conn.reply(m.chat, `✅ *Benar!* ${m.name} menjawab dengan tepat!\n✨ Bonus: +${math.bonus} XP`, m)
    clearTimeout(conn.math[id][3])
    delete conn.math[id]
  }
}
module.exports.before = before

// Mode & generator
let modes = {
  master: [-3, 3, -3, 3, '+-', 15000, 10],
  gm: [-10, 10, -10, 10, '*/+-', 20000, 40],
  epic: [-40, 40, -20, 20, '*/', 40000, 150],
  legend: [-100, 100, -70, 70, '*/', 30000, 350],
  mythic: [-999999, 999999, -999999, 999999, '*/', 40000, 666],
  glory: [-99999999999, 99999999999, -99999999999, 999999999999, '*/', 60000, 888],
  platinum: [-999999999999999, 999999999999999, -999, 999, '/', 90000, 999]
}

let operators = {
  '+': '+',
  '-': '-',
  '*': '×',
  '/': '÷'
}

function genMath(mode) {
  let [a1, a2, b1, b2, ops, time, bonus] = modes[mode]
  let a = randomInt(a1, a2)
  let b = randomInt(b1, b2)
  let op = pickRandom([...ops])
  let result = (new Function(`return ${a} ${op.replace('/', '*')} ${b < 0 ? `(${b})` : b}`))()
  if (op == '/') [a, result] = [result, a]
  return {
    str: `${a} ${operators[op]} ${b}`,
    mode,
    time,
    bonus,
    result
  }
}

function randomInt(from, to) {
  if (from > to) [from, to] = [to, from]
  from = Math.floor(from)
  to = Math.floor(to)
  return Math.floor((to - from) * Math.random() + from)
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}