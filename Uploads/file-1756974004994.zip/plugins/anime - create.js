let handler = async (m, { text, usedPrefix, command }) => {
 if (!text) return m.reply `[ Notice ] ${usedPrefix + command} masukkan prompt nya!`;
    try {
       m.reply('*Process generating image, please wait...*');
       let sdxl = await (await fetch(`https://endpoint.web.id/ai/sdxl-anime?key=${global.key}&prompt=` + text)).json();
 
      if (sdxl.result && sdxl.result.image) {
      let baby = sdxl.result;
 conn.sendMessage(m.chat, { image: { url: baby.image }, caption: '[ Succes Get Image To Your Prompt ]' }, { quoted: m });
    } else if (sdxl.result.message) {
     m.reply(sdxl.result.message);
 } else {
     m.reply('*No image generated and no message available.*');
 }
 } catch (e) {
 m.reply('Terjadi kesalahan....');
 }
}

handler.help = ['anime-sdxl [ prompt ]']
handler.tags = ['anime', 'ai']
handler.command = /^(anime-sdxl)$/i
handler.limit = true

module.exports = handler