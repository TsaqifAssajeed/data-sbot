const fs = require('fs');
const path = require('path');
const menuPath = path.join(__dirname, './main - menu.js'); 

let handler = async (m, { args, isOwner }) => {
  try {
    if (!isOwner) return m.reply('‼️ *AKSES DITOLAK*\n\n– fitur ini hanya bisa digunakan oleh owner.');

    const newUrl = args[0];
    if (!newUrl || !newUrl.startsWith('http')) {
      return m.reply('‼️ *TERJADI KESALAHAN*\n\n– link audio yang kamu masukkan tidak valid, ikuti contoh berikut ini\n\n> .setaudio https://example.com/audio.aac');
    }

    if (!fs.existsSync(menuPath)) {
      return m.reply('⛔ *File main - menu.js tidak ditemukan.*');
    }

    let fileContent = fs.readFileSync(menuPath, 'utf8');

    const regex = /audio:\s*\{\s*url:\s*['"`](https?:\/\/[^'"`]+)['"`]\s*\}/g;
    const matches = [...fileContent.matchAll(regex)];

    if (matches.length === 0) {
      return m.reply('⛔ *Tidak ditemukan bagian "audio: { url: ... }" di main - menu.js*');
    }

    const updatedContent = fileContent.replace(regex, `audio: { url: '${newUrl}' }`);
    fs.writeFileSync(menuPath, updatedContent);

    m.reply(`✅ *Berhasil mengganti audio di menu*`);

  } catch (err) {
    console.error('Error saat .setaudio:', err);
    m.reply('*❌ Terjadi kesalahan saat mengubah audio, cek log terminal ya..*');
  }
};

handler.help = ['setaudio <url>'];
handler.tags = ['owner'];
handler.command = /^\.?setaudio$/i;
handler.owner = true;

module.exports = handler;