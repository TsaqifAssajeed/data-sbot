const axios = require('axios');

// Ambil URL dari global settings
const zenzURL = global.zenzapi || "https://www.zenz.biz.id"; // fallback default

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const [noresi, ekspedisi] = args;

  if (!noresi || !ekspedisi) {
    return m.reply(`📦 *Cek Resi Pengiriman*\n\n📌 Contoh:\n${usedPrefix + command} SPXID050183559137 shopee`);
  }

  try {
    m.reply('⏳ Mengecek resi, mohon tunggu...');

    const { data } = await axios.get(`${zenzURL}/tools/cekresi?noresi=${noresi}&ekspedisi=${ekspedisi}`, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    if (!data.status || !data.result) {
      return m.reply(`❌ Resi tidak ditemukan atau format salah.`);
    }

    const r = data.result;

    let teks = `✅ *Status Resi:*\n\n`;
    teks += `📦 *Kurir:* ${r.ekspedisi || ekspedisi}\n`;
    teks += `🆔 *Resi:* ${r.resi || noresi}\n`;
    teks += `📍 *Status:* ${r.status || '-'}\n`;
    teks += `📩 *Pesan:* ${r.message || '-'}\n\n`;

    if (Array.isArray(r.history) && r.history.length > 0) {
      teks += `🚚 *Riwayat Pengiriman:*\n`;
      for (let h of r.history) {
        const waktu = h.date || h.time || h.waktu || '-';
        const isi = h.desc || h.description || h.keterangan || '-';
        teks += `• [${waktu}] ${isi}\n`;
      }
    }

    m.reply(teks.trim());

  } catch (e) {
    console.error('[CEKRESI ERROR]', e.response?.data || e.message);
    m.reply('⚠️ Gagal mengakses API cek resi.\n' + (e.response?.data?.message || e.message));
  }
};

handler.help = ['cekresi'].map(v => v + ' <noresi> <ekspedisi>');
handler.tags = ['tools'];
handler.command = /^cekresi$/i;

module.exports = handler;
