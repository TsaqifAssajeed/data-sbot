// WATERMARK NIH JANGAN DI DELETE CODE BY JAGOAN PROJECT 

// PANEL MURAH? SPEK GACOR? GAS LANGSUNG KE NOMOR +62 895-3622-82300

const axios = require("axios");

let idch = salurandaftar; // GANTI DENGAN ID CH KAMU
const saluran = `https://whatsapp.com/channel/0029Vb3pLfFEawdyEy1WTj1F`; // GANTI DENGAN LINK CH KAMU

let handler = async (m, { conn, text }) => {
   try {
      let user = m.sender;
      let name = (await conn.getName(user)) || 'No Name';
      let ppUrl = 'https://github.com/ChandraGO/Data-Jagoan-Project/blob/master/src/avatar_contact.png';
      try {
         ppUrl = await conn.profilePictureUrl(user, 'image'); // Mengambil foto profil pengirim
      } catch (e) {}

      // Mendapatkan waktu pengiriman dalam format lokal Indonesia
      let date = new Date();
      let sendTime = new Intl.DateTimeFormat('id-ID', {
         timeZone: 'Asia/Jakarta',
         hour: '2-digit',
         minute: '2-digit',
         second: '2-digit',
         day: '2-digit',
         month: '2-digit',
         year: '2-digit'
      }).format(date).replace(/\//g, '-').replace(/, /g, ' || ') + ' WIB';

      // Format pesan untuk dikirim ke saluran
      let channelMessage = text || 'no caption';
      let channelContextInfo = {
         mentionedJid: [user],
         groupMentions: [],
         isForwarded: true,
         forwardingScore: 256,
         forwardedNewsletterMessageInfo: {
            newsletterJid: idch,
            newsletterName: 'PESAN TERKIRIM DARI GROUP',
            serverMessageId: -1
         },
         externalAdReply: {
            title: `Pengirim : ${name}`,
            body: sendTime,
            thumbnailUrl: ppUrl,
            sourceUrl: saluran,
            mediaType: 1,
            renderLargerThumbnail: false,
            showAdAttribution: true
         }
      };

      if (m.quoted && m.quoted.fileSha256) {
         let quoted = m.quoted;
         let mime = quoted.mimetype || '';
         let media = await quoted.download();

         if (mime.includes('image')) {
            await conn.sendMessage(idch, { image: media, caption: channelMessage, contextInfo: channelContextInfo });
         } else if (mime.includes('video')) {
            await conn.sendMessage(idch, { video: media, caption: channelMessage, contextInfo: channelContextInfo });
         } else if (mime.includes('audio')) {
            await conn.sendMessage(idch, { audio: media, ptt: true, mimetype: mime, contextInfo: channelContextInfo });
         } else {
            return m.reply('‼️ *MEDIA TIDAK DIDUKUNG*\n\n- hanya gambar, video, audio.');
         }
      } else if (text) {
         await conn.sendMessage(idch, { text: channelMessage, contextInfo: channelContextInfo });
      } else {
         return m.reply('‼️ *FORMAT TIDAK LENGKAP*\n\n> harap masukkan teks atau media untuk dikirim ke saluran.');
      }

      // Kirim pesan konfirmasi dengan link saluran tertaut
      await conn.sendMessage(m.chat, {
         text: '✅ Berhasil mengirim ke saluran!',
         contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardingScore: 256,
            forwardedNewsletterMessageInfo: {
               newsletterJid: idch,
               newsletterName: 'PESAN TERKIRIM KE SALURAN',
               serverMessageId: -1
            },
            externalAdReply: {
               title: `Pengirim: ${name}`,
               body: sendTime,
               thumbnailUrl: ppUrl,
               sourceUrl: saluran,
               mediaType: 1,
               renderLargerThumbnail: false
            }
         }
      }, { quoted: m });
   } catch (err) {
      console.error(err);
      m.reply(`❌ Gagal mengirim ke saluran.\n\n📄 *Logs error:* \n\`\`\`${err.message}\`\`\``);
   }
};

handler.tags = ['owner'];
handler.help = ['chatch <teks>'];
handler.command = /^(chatch)$/i;
handler.group = true;
handler.owner = false;

module.exports = handler;