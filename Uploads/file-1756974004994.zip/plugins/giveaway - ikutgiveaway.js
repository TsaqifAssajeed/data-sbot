const fs = require('fs');
const path = require('path');

// Helper function to ensure database directory exists
const ensureDatabaseDir = () => {
    const dir = path.join(__dirname, '../database');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
};

// Helper function to load giveaways from JSON file
const loadGiveaways = () => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (err) {
        console.error('Error loading giveaways:', err);
        return {};
    }
};

// Helper function to save giveaways to JSON file
const saveGiveaways = (giveaways) => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        ensureDatabaseDir();
        fs.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), 'utf8');
    } catch (err) {
        console.error('Error saving giveaways:', err);
    }
};

let handler = async (m, { conn, usedPrefix }) => {
    // Initialize conn.giveway from JSON file
    conn.giveway = loadGiveaways();

    let id = m.chat;
    if (!(id in conn.giveway)) throw `‼️ *UPSS!! TIDAK BISA*\n\n– tidak ada giveaway yang sedang berlangsung di group ini, untuk memulai giveaway ikuti contoh dibawah ini.\n📝 Contoh penggunaan :\n\n– ${usedPrefix}mulaigiveaway akun epep`;

    let absen = conn.giveway[id][1];
    const wasVote = absen.includes(m.sender);
    if (wasVote) throw '*‼️ KAMU SUDAH IKUT*';
    absen.push(m.sender);

    // Shuffle the absen array
    shuffleArray(absen);

    let d = new Date;
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
    let list = absen.map((v, i) => `${i + 1}. @${v.split`@`[0]}`).join('\n');

    conn.reply(m.chat, `*✅ BERHASIL IKUT GIVEAWAY*

– 📆 tanggal : ${date}
– 🎁 hadiah  : ${conn.giveway[id][2]}

– 👨‍👨‍👧‍👦 peserta giveaway :

${list}

– 👨‍👨‍👧‍👦 total peserta : *${absen.length}*

> .keluargiveaway untuk menghapuskan diri dari daftar peserta giveaway

> ${global.namebot}`, m, { contextInfo: { mentionedJid: absen } });

    // Save updated giveaway data
    saveGiveaways(conn.giveway);
};

// Fisher-Yates Shuffle Algorithm
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

handler.help = ['ikutgiveaway'];
handler.tags = ['giveaway'];
handler.command = /^(ikut|ikutgiveaway)$/i;
handler.group = true;
module.exports = handler;