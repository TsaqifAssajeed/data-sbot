let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.ras)}”`, m)
}
handler.help = ['cekras']
handler.tags = ['cek']
handler.command = /^(cekras)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.ras = [
'Manusia Biasa', 'Ras Manusia+Iblis', 'Ras Manusia+Babi Ngepet😂', 'Ras Nigga', 'Ras Elf', 'Ras Nabati (Njir Tumbuhan😂)', 'Ras Iblis Murni', 'Ras Jomok', 'Ras Manusia Setengah Hewan', 'Ras Laba Laba Sunda', 'Ras Peri', 'Ras Werewolf', 'Ras Kucing Miaww', 'Ras Siput', 'Ras Kalajengking', 'Ras Goblin', 'Ras Monster', 'Ras Dwarf', 'Ras Manusia+Kambing (WTF💀💀💀)', 'Ras Ikan (😂😂😂)', 'Ras Kuda (Kontol/Memek Lu Pasti Besar)', 'Ras Iblis Campuran Elf (Ras Terkuat)', 'Ras Yapping',
]