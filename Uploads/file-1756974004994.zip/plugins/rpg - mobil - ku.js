// ✨ Plugin rpg - mobil - ku ✨

let handler = async (m, { conn }) => { let user = global.db.data.users[m.sender];

if (!user.cars || user.cars.length === 0) {
    return conn.reply(m.chat, "😔 Anda belum memiliki mobil.\n\n beli mobil :\n> *.mobil beli <jenis>*", m);
}

let carList = user.cars.map(car => {
    let health = user.carHealth[car] || 100; // Jika tidak ada data kesehatan, set default 100%
    let level = user.carLevel[car] || 1; // Jika tidak ada data level, set default level 1
    let healthBar = "█".repeat(Math.floor(health / 10)) + "░".repeat(10 - Math.floor(health / 10));
    return `🚗 *${car}*

⚙️ Level : ${level}\n❤️ Kesehatan : ${health}%\n [ ${healthBar} ]`; }).join('\n\n');

return conn.reply(m.chat, `🚘 *Garasi Mobil Anda* 🚘\n\n${carList}`, m);

};

handler.help = ['mycars']; handler.tags = ['rpg']; handler.command = ['mycars', 'mycar'];

module.exports = handler;