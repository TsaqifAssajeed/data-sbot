const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

let autoReadViewOnce = false; // Status awal OFF

let handler = async (m, { conn, args }) => {
    let chat = m.chat;
    
    if (args[0] === 'on') {
        autoReadViewOnce = true;
        return m.reply("✅ Auto Read View Once diaktifkan!");
    }
    if (args[0] === 'off') {
        autoReadViewOnce = false;
        return m.reply("❌ Auto Read View Once dinonaktifkan!");
    }
    
    if (!autoReadViewOnce || !m.quoted) return;

    let msg = m.quoted.message || m.quoted;
    if (!msg.viewOnce) return;

    await conn.sendMessage(chat, { react: { text: "⏳", key: m.key } });
    
    try {
        let mediaType = msg.mimetype.includes("image") ? "image" :
                        msg.mimetype.includes("video") ? "video" :
                        msg.mimetype.includes("audio") ? "audio" : null;

        if (!mediaType) return;

        let mediaStream = await downloadContentFromMessage(msg, mediaType);
        let buffer = Buffer.from([]);
        for await (const chunk of mediaStream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        if (!buffer.length) return;

        let sendOptions = { quoted: m };
        if (mediaType === 'video') {
            sendOptions.video = buffer;
            sendOptions.caption = msg.caption || "";
        } else if (mediaType === 'image') {
            sendOptions.image = buffer;
            sendOptions.caption = msg.caption || "";
        } else if (mediaType === 'audio') {
            sendOptions.audio = buffer;
            sendOptions.mimetype = "audio/mpeg";
            sendOptions.ptt = true;
        }

        await conn.sendMessage(chat, sendOptions);
        await conn.sendMessage(chat, { react: { text: "✅", key: m.key } });
    } catch (err) {
        console.error("❌ Error:", err);
        await conn.sendMessage(chat, { react: { text: "❌", key: m.key } });
    }
};

handler.command = ['autorvo'];
handler.help = ['autorvo [on/off]', 'autorvo [on/off]'];
handler.tags = ['tools'];

module.exports = handler;
