// ✨ Plugin owner - setdefaultlimit ✨

const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, text, command }) => {
  try {
    // cek owner (real owner)
    const meJid = conn.decodeJid ? conn.decodeJid(conn.user?.id || '') : (conn.user?.id || '');
    const ownerList = (global.owner || []).map(v => Array.isArray(v) ? v[0] : v).filter(Boolean);
    const ownerJids = [meJid, ...ownerList].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    const isROwner = ownerJids.includes(m.sender);
    if (!isROwner && !m.fromMe) return m.reply('❌ Akses ditolak. Hanya owner utama yang bisa menjalankan perintah ini.');

    const handlerPath = path.join(__dirname, '..', 'handler.js'); // plugins/.. -> root/handler.js
    if (!fs.existsSync(handlerPath)) return m.reply('❌ handler.js tidak ditemukan di path: ' + handlerPath);

    const code = fs.readFileSync(handlerPath, 'utf8');

    // Cari blok "else global.db.data.users[m.sender] = { ... }"
    const blockRegex = /}\s*else\s+global\.db\.data\.users\[m\.sender\]\s*=\s*{([\s\S]*?)\n\s*}\s*/;
    const blockMatch = code.match(blockRegex);
    if (!blockMatch) return m.reply('❌ Gagal menemukan blok default user di handler.js (pattern not found).');

    const blockFull = blockMatch[0]; // seluruh block yang ketemu (termasuk "else ... = { ... }")
    const inner = blockMatch[1];     // isi dalam kurung kurawal

    const limitMatch = inner.match(/limit\s*:\s*(\d+)/);
    if (!limitMatch) return m.reply('❌ Gagal menemukan properti `limit` di blok default user.');

    const current = Number(limitMatch[1]);

    // Perintah: .defaultlimit
    if (/^defaultlimit$/i.test(command)) {
      return m.reply(`📌 Default limit user baru saat ini: *${current}*`);
    }

    // Perintah: .setdefaultlimit <angka>
    if (/^setdefaultlimit$/i.test(command)) {
      if (!text) return m.reply('📌 Contoh penggunaan:\n.setdefaultlimit 200');
      const n = parseInt(text.trim());
      if (isNaN(n) || n < 0) return m.reply('❌ Nilai tidak valid. Masukkan angka (>=0).');

      // ganti hanya angka limit di dalam blok itu
      const newInner = inner.replace(/limit\s*:\s*\d+/, `limit: ${n}`);
      const newBlock = blockFull.replace(inner, newInner);
      const newCode = code.replace(blockFull, newBlock);

      try {
        fs.writeFileSync(handlerPath, newCode, 'utf8');
      } catch (e) {
        return m.reply('❌ Gagal menulis handler.js: ' + e.message);
      }

      // simpan database sebelum restart (jika ada)
      try {
        if (global.db && typeof global.db.read === 'function') await global.db.read();
        if (global.db && typeof global.db.write === 'function') await global.db.write();
      } catch (e) {
        // ignore db save error but log
        console.error('Gagal save DB sebelum restart:', e);
      }

      await m.reply(`✅ Default limit user baru telah diubah menjadi *${n}*.`);

      // restart otomatis jika parent process mendukung
      if (typeof process.send === 'function') {
        await m.reply('♻️ Melakukan restart otomatis... (tunggu sekitar 1 Menit)');
        setTimeout(() => {
          try { process.send('reset'); }
          catch (err) { console.error('Failed to send reset signal:', err); }
        }, 1000);
      } else {
        await m.reply('⚠️ Restart otomatis tidak didukung pada environment ini (process.send undefined). Silakan restart proses bot secara manual.');
      }
      return;
    }

    // fallback
    return m.reply('❌ Perintah tidak dikenali. Gunakan .defaultlimit atau .setdefaultlimit <angka>');
  } catch (err) {
    console.error(err);
    return m.reply('❌ Terjadi kesalahan: ' + (err.message || err));
  }
};

handler.help = ['defaultlimit', 'setdefaultlimit <jumlah>'];
handler.tags = ['owner'];
handler.command = /^(defaultlimit|setdefaultlimit)$/i;
handler.rowner = true; // require real owner
module.exports = handler;