const { proto } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, groupMetadata, usedPrefix, text, command }) => {
    if (!text && !m.quoted) return m.reply("‼️ *Format salah..*\n\n📝 *Contoh penggunaan :*\n\n— .pushkontak 10|text\n\n📝 *Note :*\n\n— 10 adalah waktu delay pushkontak\n> waktu delay 1 - 180");

    let arg = text.split('|');
    if (arg.length !== 2 || isNaN(arg[0]) || arg[1].trim().length === 0) {
        return m.reply('‼️ *Format salah..*\n\n📝 *Contoh penggunaan :*\n\n> ' + usedPrefix + 'pushkontak 180|text');
    }

    let delay = parseInt(arg[0]);
    if (delay < 1 || delay > 180) {
        return m.reply('‼️ Delay harus antara 1 hingga 180 detik.');
    }

    let get = groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
    let count = get.length;
    let sentCount = 0;

    m.reply("⏳ Mengirim pesan kepada " + count + " kontak dengan delay " + delay + " detik.");

    // Fake quoted status/story WA
    const fakeStatus = {
        key: {
            remoteJid: 'status@broadcast',
            fromMe: false,
            id: 'BEBEBE',
            participant: '0@s.whatsapp.net'
        },
        message: {
            conversation: 'GROUP INI DISEBUT :V'
        }
    };

    for (let i = 0; i < get.length; i++) {
        setTimeout(async function () {
            let target = get[i];
            let messageContent = {
                text: arg[1] + (m.quoted ? ("\n\n" + m.quoted.text) : ""),
                contextInfo: {
                    mentionedJid: [target],
                    externalAdReply: {
                        title: '‼️ Push contact.',
                        body: `Pesan dikirim otomatis.`,
                        thumbnailUrl: 'https://st2.depositphotos.com/1139310/5467/v/450/depositphotos_54675153-stock-illustration-flat-icon-of-phone-notes.jpg', // Ganti dengan gambar custom kamu
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        showAdAttribution: true
                    }
                }
            };

            await conn.sendMessage(target, messageContent, { quoted: fakeStatus });

            sentCount++;
            if (sentCount === count) {
                m.reply("✅ Berhasil push kontak :\nJumlah pesan terkirim : " + sentCount);
            }
        }, delay * 1000 * (i + 1));
    }
};

handler.command = ['pushkontak'];
handler.tags = ['owner', 'group'];
handler.help = ['pushkontak'];
handler.group = true;
handler.owner = true;

module.exports = handler;