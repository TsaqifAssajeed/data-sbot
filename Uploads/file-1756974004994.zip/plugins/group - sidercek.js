const fs = require('fs')
const path = require('path')

const dbPath = path.join(__dirname, '../database/sider.json')

function loadSiderDB() {
    if (!fs.existsSync(dbPath)) return {}
    return JSON.parse(fs.readFileSync(dbPath))
}

function saveSiderDB(db) {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

setInterval(async () => {
    const db = loadSiderDB()
    const chats = global.db.data.chats

    for (const [chatId, config] of Object.entries(db)) {
        if (!config.aktif || !config.sejak) continue

        const elapsed = Date.now() - config.sejak
        if (elapsed < 86400000) continue // belum 1 hari

        const groupMeta = await global.conn.groupMetadata(chatId)
        const peserta = groupMeta.participants.map(p => p.id)
        const totalData = chats[chatId]?.total || {}

        // deteksi awal user < 5 chat
        const potensiKick = peserta.filter(id => (totalData[id] || 0) < 5)
        if (potensiKick.length === 0) continue

        // kirim peringatan
        const waktuAktif = new Date(config.sejak).toLocaleString()
        const teksAwal = `⏰ *Waktu Telah Habis!*\n` +
            `Grup *${groupMeta.subject}* telah mengaktifkan fitur *Sider* sejak *${waktuAktif}*.\n\n` +
            `User yang masih pasif (chat < 5) akan di-*kick* hari ini. Goodbye:\n\n` +
            potensiKick.map((id, i) => `${i + 1}. @${id.split('@')[0]}`).join('\n')

        await global.conn.sendMessage(chatId, {
            text: teksAwal,
            contextInfo: { mentionedJid: potensiKick }
        })

        // kick dimulai
        const start = Date.now()
        const berhasilKick = []

        for (const [i, id] of potensiKick.entries()) {
    const currentTotal = totalData[id] || 0
    if (currentTotal >= 5) continue

    try {
        await global.conn.groupParticipantsUpdate(chatId, [id], 'remove')
        berhasilKick.push(id)
   } catch (e) {
    console.log(`❗ Gagal kick ${id}:`, e.message)

    if (e.message.includes('rate-overlimit')) {
        console.log('⚠️ Terkena rate limit, tunggu 60 detik...')
        await sleep(60000)
    }
}


    if (i < potensiKick.length - 1) {
        await sleep(15000) // 15 detik delay antar kick
    }
}


        const end = Date.now()
        const durasi = Math.floor((end - start) / 1000)

        // update database
        config.aktif = false
        config.listKick = berhasilKick
        saveSiderDB(db)

        // kirim laporan akhir
        const teksAkhir = `✅ Semua member *sider* telah di-*kick* dalam waktu *${durasi} detik*.\n` +
            `Fitur *sider* telah *otomatis dimatikan* di grup ini.`

        await global.conn.sendMessage(chatId, {
            text: teksAkhir
        })
    }

}, 80000)
