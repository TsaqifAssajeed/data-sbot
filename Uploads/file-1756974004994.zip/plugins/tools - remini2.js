const axios = require('axios');
const FormData = require('form-data');

async function upscaleImage(imageBuffer, scale = 7, faceEnhance = true) {
    try {
        if (scale < 2 || scale > 10) {
            throw new Error("Scale harus antara 2 sampai 10");
        }

        const base64Image = `data:image/jpeg;base64,${imageBuffer.toString("base64")}`;

        const start = await axios.post(
            "https://fooocus.one/api/predictions",
            {
                version: "f121d640bd286e1fdc67f9799164c1d5be36ff74576ee11c803ae5b665dd46aa",
                input: {
                    face_enhance: faceEnhance,
                    image: base64Image,
                    scale
                }
            },
            {
                headers: {
                    "Content-Type": "application/json",
                    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/107.0.0.0 Safari/537.36",
                    Origin: "https://fooocus.one",
                    Referer: "https://fooocus.one/id/apps/batch-upscale-image"
                }
            }
        );

        const predictionId = start.data.data.id;

        let result;
        while (true) {
            const res = await axios.get(
                `https://fooocus.one/api/predictions/${predictionId}`,
                {
                    headers: {
                        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/107.0.0.0 Safari/537.36",
                        Referer: "https://fooocus.one/id/apps/batch-upscale-image"
                    }
                }
            );

            if (res.data.status === "succeeded") {
                result = res.data.output;
                break;
            } else if (res.data.status === "failed") {
                throw new Error("Upscale gagal");
            }

            await new Promise((r) => setTimeout(r, 3000));
        }

        return result;
    } catch (err) {
        console.error("Error saat upscale:", err.message);
        throw err;
    }
}

let handler = async (m, { conn, usedPrefix, command }) => {
    conn.hd2 = conn.hd2 ? conn.hd2 : {};
    if (m.sender in conn.hd2) {
        throw "Masih ada proses yang belum selesai, silahkan tunggu sampai selesai yah >//<";
    }

    conn.hd2[m.sender] = true;

    // Tambahkan timeout untuk mencegah penguncian permanen
    setTimeout(() => {
        if (m.sender in conn.hd2) {
            delete conn.hd2[m.sender];
            console.log(`Penguncian hd2 untuk ${m.sender} dihapus karena timeout`);
        }
    }, 60000); // Timeout setelah 60 detik

    m.reply("⏳ Sedang diproses, harap tunggu...");

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";

    // Validasi jika media tidak ada
    if (!mime) {
        delete conn.hd2[m.sender];
        throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;
    }

    // Validasi jika media adalah video
    if (/video/.test(mime)) {
        delete conn.hd2[m.sender];
        throw "❌ Maaf, fitur ini hanya mendukung foto. Silakan kirim foto untuk diproses.";
    }

    // Validasi jika media bukan gambar
    if (!/image/.test(mime)) {
        delete conn.hd2[m.sender];
        throw "❌ Media yang dikirim harus berupa foto (jpg, png, dll). Silakan kirim foto untuk diproses.";
    }

    let img = await q.download?.();
    let error;

    try {
        const resultUrl = await upscaleImage(img, 2, true); // Scale default 2, faceEnhance true
        conn.sendFile(m.chat, resultUrl, null, "✅ Berhasil! Berikut hasilnya:", m);
    } catch (er) {
        error = true;
        console.error(`Error pada hd2: ${er}`);
        m.reply("❌ Gagal memproses gambar, coba lagi nanti.");
    } finally {
        delete conn.hd2[m.sender];
    }
};

handler.help = ["hd2 *[reply/send media]*"];
handler.tags = ["tools"];
handler.premium = false;
handler.command = ["hd2","remini2"];
module.exports = handler;