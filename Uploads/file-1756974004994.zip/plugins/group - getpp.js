// 📝 plugin group - getpp

const fs = require("fs");

let handler = async (m, { conn, args }) => {
    try {
        let who;

        if (m.isGroup) {
            if (m.mentionedJid.length > 0) {
                who = m.mentionedJid[0];
            } else if (args[0]) {
                // Jika ada nomor yang diberikan sebagai argumen
                let input = args[0].replace(/[^0-9]/g, '');
                who = input + '@s.whatsapp.net';
            } else {
                return m.reply("‼️ Harap tag pengguna atau masukkan nomornya.\nContoh: .getpp 628xxxxxxxxxx");
            }
        } else {
            if (args[0]) {
                let input = args[0].replace(/[^0-9]/g, '');
                who = input + '@s.whatsapp.net';
            } else {
                who = m.sender;
            }
        }

        // Ambil foto profil atau fallback ke default
        let pp = await conn.profilePictureUrl(who, 'image').catch(_ => fs.readFileSync('./media/avatar_contact.png'));

        // Kirim foto profilnya
        await conn.sendFile(m.chat, pp, 'profile.jpg', `@${who.split`@`[0]} keren amat pp lu..`, m, null, { mentions: [who] });
    } catch (e) {
        console.error(e);
        m.reply("‼️ Tidak dapat mengambil foto profile");
    }
};

handler.help = ['getppusr', 'getprofileuser'];
handler.tags = ['owner'];
handler.command = /^(get(pp|profile|user))$/i;

handler.limit = true;

module.exports = handler;