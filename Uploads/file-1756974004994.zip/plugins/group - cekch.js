const { default: makeWASocket } = require("@whiskeysockets/baileys");

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply("⚠️ *Gunakan perintah dengan link channel!*\n📌 Contoh: !cekidch https://whatsapp.com/channel/example");
    if (!text.includes("https://whatsapp.com/channel/")) return m.reply("❌ *Link tautan tidak valid!* Pastikan menggunakan link yang benar.");
    
    let result = text.split("https://whatsapp.com/channel/")[1];
    try {
        let res = await conn.newsletterMetadata("invite", result);
        console.log("Respons API:", res);
        
        if (!res || !res.id) {
            return m.reply("⚠️ *Data tidak ditemukan!* Mungkin channel tidak publik atau API mengalami perubahan.");
        }

        // Ambil link channel dari metadata menggunakan "jid"
        let metadata = await conn.newsletterMetadata("jid", res.id);
        let channelLink = metadata?.link || `https://whatsapp.com/channel/${result}`;
    
        let teks = `
🔹 *Nama:* ${res.name}
🆔 *ID:* ${res.id}
👥 *Total Pengikut:* ${res.subscribers.toLocaleString()}
✅ *Verified:* ${res.verification === "VERIFIED" ? "Terverifikasi" : "Tidak"}
        `;
        
        let interactiveButtons = [
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "📋 Salin ID",
                    id: res.id,
                    copy_code: res.id
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "🔗 Kunjungi Channel",
                    url: channelLink
                })
            }
        ];
        
        let interactiveMessage = {
            text: teks,
            title: "📢 *Informasi Channel WhatsApp*",
            footer: "Jagoan Project",
            interactiveButtons
        };
        
        return conn.sendMessage(m.chat, interactiveMessage, { quoted: m });
    } catch (e) {
        console.error("Error:", e);
        return m.reply("❌ *Terjadi kesalahan!* Pastikan bot memiliki akses dan coba lagi.");
    }
};

handler.help = ['cekidch'].map(a => a + ' *[Cek ID Channel WhatsApp]*');
handler.tags = ['tools'];
handler.command = /^(cekidch|idch)$/i;

module.exports = handler;
