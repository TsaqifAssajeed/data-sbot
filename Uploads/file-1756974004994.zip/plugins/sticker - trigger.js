/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/


const { spawn } = require('child_process')
const fs = require('fs')
const path = require('path')
const https = require('https')
const { Sticker } = require('wa-sticker-formatter')

const tmp = path.join(__dirname, '../tmp/')
const overlayUrl = 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/trigermentah.png'

// Pastikan direktori tmp ada
if (!fs.existsSync(tmp)) {
  fs.mkdirSync(tmp, { recursive: true })
}

// Fungsi unduh overlay trigger
function downloadImage(url, dest) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest)
    https.get(url, response => {
      if (response.statusCode !== 200) {
        return reject(new Error(`Gagal mengunduh overlay: ${response.statusCode}`))
      }
      response.pipe(file)
      file.on('finish', () => file.close(resolve))
    }).on('error', err => {
      fs.unlink(dest, () => reject(err))
    })
  })
}

// Fungsi utama membuat stiker animasi dengan efek shake
async function running(img, duration = 1.8, fps = 30) {
  return new Promise(async (resolve, reject) => {
    const timestamp = +new Date()
    const inputImage = path.join(tmp, `${timestamp}.png`)
    const overlayImage = path.join(tmp, `${timestamp}-trigger.png`)
    const outputWebp = path.join(tmp, `${timestamp}.webp`)
    const frameList = []

    try {
      fs.writeFileSync(inputImage, img)
      await downloadImage(overlayUrl, overlayImage)

      const frameCount = Math.floor(duration * fps)

      for (let i = 0; i < frameCount; i++) {
        const xShake = (i % 5 === 0 ? 8 : -8)
        const yShake = (i % 6 === 0 ? 8 : -8)
        const framePath = path.join(tmp, `frame-${timestamp}-${i}.png`)
        frameList.push(framePath)

        const args = [
          '-y',
          '-i', inputImage,
          '-i', overlayImage,
          '-filter_complex',
          `
            [0:v]scale=512:512[bg];
            [1:v]scale=512:512[ov];
            [bg][ov]overlay=0:0[merged];
            [merged]pad=520:520:4:4:color=0x00000000[padded];
            [padded]crop=512:512:${4 + xShake}:${4 + yShake}
          `.replace(/\s+/g, ''),
          '-frames:v', '1',
          framePath
        ]

        await new Promise((res, rej) => {
          const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] })
          let errorOutput = ''
          proc.stderr.on('data', data => errorOutput += data.toString())
          proc.on('error', err => rej(new Error(`ffmpeg error untuk frame ${i}: ${err.message}\n${errorOutput}`)))
          proc.on('close', code => {
            if (code !== 0) {
              rej(new Error(`ffmpeg gagal untuk frame ${i}: ${errorOutput}`))
            } else {
              res()
            }
          })
        })
      }

      // Gabungkan frame jadi animasi WebP
      const inputs = frameList.flatMap(f => ['-i', f])
      const filter = `concat=n=${frameCount}:v=1:a=0,format=yuva420p`
      const argsWebp = [
        '-y',
        ...inputs,
        '-filter_complex', filter,
        '-r', fps.toString(),
        '-loop', '0',
        '-vcodec', 'libwebp',
        outputWebp
      ]

      await new Promise((res, rej) => {
        const proc = spawn('ffmpeg', argsWebp, { stdio: ['ignore', 'pipe', 'pipe'] })
        let errorOutput = ''
        proc.stderr.on('data', data => errorOutput += data.toString())
        proc.on('error', err => rej(new Error(`ffmpeg error membuat WebP: ${err.message}\n${errorOutput}`)))
        proc.on('close', code => {
          if (code !== 0) {
            rej(new Error(`ffmpeg gagal membuat WebP: ${errorOutput}`))
          } else {
            res()
          }
        })
      })

      if (!fs.existsSync(outputWebp)) {
        throw new Error(`File output ${outputWebp} tidak ditemukan`)
      }

      const result = fs.readFileSync(outputWebp)

      // Pembersihan
      const filesToDelete = [inputImage, overlayImage, ...frameList, outputWebp]
      filesToDelete.forEach(file => {
        if (fs.existsSync(file)) fs.unlinkSync(file)
      })

      resolve(result)
    } catch (e) {
      const filesToDelete = [inputImage, overlayImage, ...frameList, outputWebp]
      filesToDelete.forEach(file => {
        if (fs.existsSync(file)) fs.unlinkSync(file)
      })
      reject(e)
    }
  })
}

// Handler perintah .trigger
let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  
  // Validasi jenis media
  const supportedFormats = ['image/png', 'image/jpeg', 'image/jpg','image/webp']
  if (!supportedFormats.includes(mime)) {
    let errorMessage = '✳️ Media tidak didukung! Balas gambar (PNG, JPEG, atau JPG) dengan caption *trigger* untuk membuat stiker animasi.'
    if (mime === 'image/gif') {
      errorMessage = '✳️ GIF tidak didukung! Gunakan gambar statis (PNG, JPEG, atau JPG).'
    } else if (mime.startsWith('video/')) {
      errorMessage = '✳️ Video tidak didukung! Gunakan gambar statis (PNG, JPEG, atau JPG).'
    } else if (mime) {
      errorMessage = `✳️ Format ${mime} tidak didukung! Gunakan gambar statis (PNG, JPEG, atau JPG).`
    }
    throw errorMessage
  }

  try {
    const img = await q.download()
    m.reply('_⏳ Membuat efek trigger..._')
    const webpBuffer = await running(img)
    
    // Membuat stiker dengan metadata
    const sticker = new Sticker(webpBuffer, {
      pack: global.packname || 'Wanted Sticker',
      author: global.author || 'Jagoan Project',
      type: 'full',
      quality: 20
    })
    
    const stickerBuffer = await sticker.toBuffer()
    await conn.sendFile(m.chat, stickerBuffer, 'trigger.webp', '', m, { asSticker: true })
  } catch (e) {
    console.error(e)
   // m.reply(`⚠️ Gagal membuat stiker trigger pastikan media bukan video atau gambar bergerak laporan error :\n${e.message}`)
     m.reply(`⚠️ Gagal membuat stiker trigger pastikan media bukan video atau gambar bergerak`)
  }
}

handler.help = ['trigger']
handler.tags = ['sticker']
handler.command = /^trigger$/i
handler.limit = true

module.exports = handler