const fs = require('fs').promises;
const path = require('path');

let handler = async (m, { text }) => {
  const settingsPath = '/home/container/settings.js';
  const pilihan = text.trim().split(/\s+/)[0]?.toLowerCase();
  const newApiKey = text.trim().split(/\s+/)[1];

  if (!pilihan || !newApiKey) {
    return m.reply(`*Set API Key*\n\nKetik:\n1. *.setapikey 1 <new_apikey>* - Ganti BOTCAHX API key\n2. *.setapikey 2 <new_apikey>* - Ganti XTERM API key\n\nContoh: *.setapikey 1 new-botcahx-key*`);
  }

  if (pilihan !== '1' && pilihan !== '2') {
    return m.reply("❌ Pilihan tidak valid. Ketik *.setapikey 1 <new_apikey>* atau *.setapikey 2 <new_apikey>*.");
  }

  try {
    // Baca file settings.js
    let settingsContent = await fs.readFile(settingsPath, 'utf8');

    // Tentukan variabel yang akan diganti
    const targetVariable = pilihan === '1' ? 'global.btc' : 'global.apixtermkey';
    const regex = new RegExp(`(${targetVariable}\\s*=\\s*")[^"]*(";)`);

    // Periksa apakah variabel ada di file
    if (!regex.test(settingsContent)) {
      return m.reply(`❌ Variabel ${targetVariable} tidak ditemukan di ${settingsPath}.`);
    }

    // Ganti API key
    settingsContent = settingsContent.replace(regex, `$1${newApiKey}$2`);

    // Simpan file kembali
    await fs.writeFile(settingsPath, settingsContent, 'utf8');

    // Perbarui global variable di memori
    if (pilihan === '1') {
      global.btc = newApiKey;
    } else {
      global.apixtermkey = newApiKey;
    }

    return m.reply(`✅ Berhasil mengganti ${targetVariable} menjadi "${newApiKey}" di ${settingsPath}.`);
  } catch (e) {
    console.error("Error in setapikey:", e.message);
    return m.reply(`❌ Gagal mengganti API key: ${e.message}`);
  }
};

handler.help = ['setapikey'];
handler.tags = ['owner'];
handler.command = /^(setapikey)$/i;
handler.rowner = true;

module.exports = handler;