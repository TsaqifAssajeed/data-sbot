const fs = require('fs');
const path = require('path');

// Helper function to ensure database directory exists
const ensureDatabaseDir = () => {
    const dir = path.join(__dirname, '../database');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
};

// Helper function to load giveaways from JSON file
const loadGiveaways = () => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
        return {};
    } catch (err) {
        console.error('Error loading giveaways:', err);
        return {};
    }
};

// Helper function to save giveaways to JSON file
const saveGiveaways = (giveaways) => {
    const filePath = path.join(__dirname, '../database/giveaways.json');
    try {
        ensureDatabaseDir();
        fs.writeFileSync(filePath, JSON.stringify(giveaways, null, 2), 'utf8');
    } catch (err) {
        console.error('Error saving giveaways:', err);
    }
};

let handler = async (m, { conn, usedPrefix }) => {
    // Initialize conn.giveway from JSON file
    conn.giveway = loadGiveaways();

    let id = m.chat;
    if (!(id in conn.giveway)) throw `‼️ *UPSS!! TIDAK BISA*\n\n– Tidak ada giveaway yang sedang berlangsung di grup ini. Untuk memulai giveaway, gunakan perintah:\n📝 Contoh: ${usedPrefix}mulaigiveaway akun epep`;

    let absen = conn.giveway[id][1];
    const wasParticipant = absen.includes(m.sender);
    if (!wasParticipant) throw '*‼️ KAMU BELUM IKUT GIVEAWAY*\n\n– Kamu belum terdaftar sebagai peserta giveaway. Gunakan perintah *.ikut* untuk bergabung.';

    // Remove the participant from the absen array
    conn.giveway[id][1] = absen.filter(participant => participant !== m.sender);

    // Save updated giveaway data
    saveGiveaways(conn.giveway);

    let d = new Date;
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });

    conn.reply(m.chat, `*✅ BERHASIL KELUAR DARI GIVEAWAY*

– 📆 Tanggal: ${date}
– 🎁 Hadiah: ${conn.giveway[id][2]}

Kamu telah keluar dari daftar peserta giveaway.`, m);
};

handler.help = ['keluargiveaway'];
handler.tags = ['giveaway'];
handler.command = /^(keluargiveaway)$/i;
handler.group = true;
module.exports = handler;