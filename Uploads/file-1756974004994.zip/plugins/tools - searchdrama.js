const axios = require('axios');

// API key TMDb
const TMDB_API_KEY = '330319fd3a450be0b42d11c8463f6e70';

async function searchDrama(query) {
    try {
        // Cari film/drama berdasarkan query
        const searchResponse = await axios.get(`https://api.themoviedb.org/3/search/multi?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&language=en-US`);
        const results = searchResponse.data.results;

        if (results.length === 0) {
            return { error: 'Tidak ditemukan drama atau film dengan judul tersebut!' };
        }

        // Ambil result secara acak
        const randomIndex = Math.floor(Math.random() * results.length);
        const media = results[randomIndex];
        const mediaId = media.id;
        const mediaType = media.media_type === 'movie' ? 'movie' : 'tv';

        // Ambil detail drama/film
        const detailResponse = await axios.get(`https://api.themoviedb.org/3/${mediaType}/${mediaId}?api_key=${TMDB_API_KEY}&language=en-US`);
        const details = detailResponse.data;

        // Ambil daftar pemain (cast)
        const creditsResponse = await axios.get(`https://api.themoviedb.org/3/${mediaType}/${mediaId}/credits?api_key=${TMDB_API_KEY}&language=en-US`);
        const cast = creditsResponse.data.cast.slice(0, 5).map(actor => actor.name).join(', '); // Ambil 5 aktor utama

        // Buat link ke halaman TMDb
        const tmdbLink = `https://www.themoviedb.org/${mediaType}/${mediaId}`;

        // Format data
        return {
            title: mediaType === 'movie' ? details.title : details.name,
            overview: details.overview || 'Sinopsis tidak tersedia.',
            release_date: mediaType === 'movie' ? details.release_date : details.first_air_date,
            cast: cast || 'Informasi pemain tidak tersedia.',
            poster: details.poster_path ? `https://image.tmdb.org/t/p/w500${details.poster_path}` : null,
            type: mediaType === 'movie' ? 'Film' : 'Serial/Drama',
            link: tmdbLink
        };
    } catch (error) {
        return { error: `Error: ${error.message}` };
    }
}

var handler = async (m, { conn, text }) => {
    if (!text) {
        return conn.reply(m.chat, 'Masukkan judul drama/film! Contoh: .searchdrama Moana', m);
    }

    await conn.reply(m.chat, 'Sedang mencari drama/film... Silahkan tunggu', m);

    const result = await searchDrama(text);

    if (result.error) {
        return conn.reply(m.chat, result.error, m);
    }

    let dramaMessage = `*Informasi Drama/Film:*\n\n`;
    dramaMessage += `🔹 *Judul*: ${result.title}\n`;
    dramaMessage += `📺 *Tipe*: ${result.type}\n`;
    dramaMessage += `📅 *Tanggal Rilis*: ${result.release_date || 'Tidak diketahui'}\n`;
    dramaMessage += `👥 *Pemain Utama*: ${result.cast}\n`;
    dramaMessage += `📜 *Sinopsis*: ${result.overview}\n`;
    dramaMessage += `🔗 *Link*: ${result.link}\n\n`;

    // Konfigurasi tombol
    const buttons = [
    
        {
            buttonId: `.searchdrama ${text}`,
            buttonText: { displayText: 'Next Drama' },
            type: 1
        }
    ];

    const buttonMessage = {
        image: result.poster ? { url: result.poster } : null,
        caption: dramaMessage,
        footer: 'Semoga membantu! 🙂',
        buttons: buttons,
        headerType: 4,
        viewOnce: true
    };

    await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
}

handler.help = ['searchdrama <judul>'];
handler.tags = ['tools'];
handler.command = /^(searchdrama|sd)$/i;

module.exports = handler;