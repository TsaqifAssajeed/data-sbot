const axios = require('axios');

const handler = async (m, { conn, text, args, command, usedPrefix }) => {
  try {
    // Validate input format
    if (!text.includes('|') || text.split('|').length !== 4) {
      return m.reply(`✨ Masukkan input dengan format:\n\nMode|Nama|Username|Teks Tweet\n\n📝 Contoh: *${usedPrefix + command} dark|chandra|jagpro|Hello ah ah💦*\n\n🔧 Mode tersedia: dark, dim, atau light`);
    }

    
    await m.reply('⏳ Sedang memproses...'); // Loading message

    let [mode, name, username, tweet] = text.split('|').map(v => v.trim());

    // Validate mode
    if (!['dark', 'dim', 'light'].includes(mode.toLowerCase())) {
      return m.reply('❌ Mode harus dark, dim, atau light!');
    }

    // Validate required fields
    if (!name || !username || !tweet) {
      return m.reply('❌ Semua data wajib diisi! Pastikan format sesuai contoh. 📋');
    }

    // Validate tweet length (Twitter max 280 characters)
    if (tweet.length > 280) {
      return m.reply('❌ Teks tweet maksimal 280 karakter!');
    }

    // Default profile picture URL from API documentation
    const profileUrl = 'https://avatars.githubusercontent.com/u/159487561?v=4';

    // Use mode as theme
    const theme = mode.toLowerCase();

    // Default values as per API
    const retweets = 1000;
    const quotes = 200;
    const likes = 5000;
    const client = 'Twitter for iPhone';

    // Use fallback for API base URL
    const baseUrl = global.apisiput || 'https://api.siputzx.my.id/';
    const imageUrl = `${baseUrl}api/m/tweet?profile=${encodeURIComponent(profileUrl)}&name=${encodeURIComponent(name)}&username=${encodeURIComponent(username)}&tweet=${encodeURIComponent(tweet)}&image=null&theme=${theme}&retweets=${retweets}&quotes=${quotes}&likes=${likes}&client=${encodeURIComponent(client)}`;

    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: '✅ Fake Twitter post berhasil dibuat! 🎉'
    }, { quoted: m });

  } catch (err) {
    console.error('Error in faketwitter handler:', err);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply('😓 Terjadi kesalahan saat memproses permintaan. Coba lagi nanti ya! 🔄');
  }
};

handler.help = ['faketwitter <mode|nama|username|teks tweet>'];
handler.tags = ['maker'];
handler.command = /^faketw|faketwitter$/i;
handler.limit = true;
handler.premium = true

module.exports = handler;