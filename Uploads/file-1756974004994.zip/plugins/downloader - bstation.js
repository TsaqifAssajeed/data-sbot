const axios = require("axios");
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `Usage: ${usedPrefix + command} <url>\n*Contoh*: ${usedPrefix + command} https://www.bilibili.tv/id/video/4793141561528832?bstar_from=bstar-web.homepage.trending.all`;
    let url = args[0];

   await m.reply('Tunggu sebentar kak....');

    try {
        let response = await axios.get(`https://api.ryzendesu.vip/api/downloader/bilibili?url=${encodeURIComponent(url)}`);
        let data = response.data;

        if (!data.status) throw "Failed to fetch video data";

       
        let { title, views, like, mediaList } = data.data;
        let videoList = mediaList.videoList;
        let video = videoList[0]; // Ambil video pertama
        let videoUrl = video.url;

       
        let tempVideoPath = path.resolve("tmp", `${Date.now()}_video.mp4`);
        let tempProcessedPath = path.resolve("tmp", `${Date.now()}_processed.mp4`);

        let videoResponse = await axios({
            method: "get",
            url: videoUrl,
            responseType: "stream",
        });

        await new Promise((resolve, reject) => {
            let stream = fs.createWriteStream(tempVideoPath);
            videoResponse.data.pipe(stream);
            stream.on("finish", resolve);
            stream.on("error", reject);
        });

      
        execSync(`ffmpeg -i ${tempVideoPath} -metadata title="${title}" -metadata comment="Duration: ${video.duration}" -c copy ${tempProcessedPath}`);

   
        await conn.sendMessage(
            m.chat, 
            { 
                video: { url: tempProcessedPath }, 
                caption: `*Title:* ${title}\n*Views:* ${views}\n*Likes:* ${like}` 
            }, 
            { quoted: m }
        );

        
        fs.unlinkSync(tempVideoPath);
        fs.unlinkSync(tempProcessedPath);

    } catch (e) {
        throw `Error: ${e.message}`;
    }
};

handler.help = ["bstation <url>"];
handler.tags = ["downloader"];
handler.command = /^(bstation|bilibili)$/i;

module.exports = handler;