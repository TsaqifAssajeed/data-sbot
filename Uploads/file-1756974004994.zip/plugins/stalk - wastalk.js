let moment = require('moment-timezone')
let PhoneNum = require('awesome-phonenumber')

let regionNames = new Intl.DisplayNames(['en'], { type: 'region' })

let handler = async (m, { conn, text, usedPrefix, command: cmd }) => {
    try {
        let num = m.quoted?.sender || m.mentionedJid?.[0] || text
        if (!num) throw `🌟 *Example:* ${usedPrefix + cmd} *[Number or Tag]* 🌟`
        num = num.replace(/\D/g, '') + '@s.whatsapp.net'

        let data = (await conn.onWhatsApp(num))[0]
        if (!data?.exists) throw '❌ *User not found on WhatsApp!* ❌'

        let img = await conn.profilePictureUrl(num, 'image').catch(_ => './media/avatar_contact.png')
        let bio = await conn.fetchStatus(num).catch(_ => { })
        let pushname = data.pushname || 'Tanpa Nama'
        let business = await conn.getBusinessProfile(num).catch(_ => { })

        let format = PhoneNum(`+${num.split('@')[0]}`)
        let country = regionNames.of(format.getRegionCode('international'))
        let flag = getFlagEmoji(format.getRegionCode('international')) || ''

        let presence = 'unknown'
        await conn.presenceSubscribe(num)
        conn.ev.on('presence.update', (update) => {
            if (update.id === num) {
                presence = update.presence === 'composing' ? 'typing 📝'
                    : update.presence === 'available' ? 'online ✅'
                    : 'offline 🚫'
            }
        })

        let caption = `🌍 *WhatsApp Profile Stalk* 🌍\n\n` +
                      `👤 *Nama:* ${pushname}\n` +
                      `📍 *Negara:* ${country.toUpperCase()} ${flag}\n` +
                      `🔗 *WA Link:* wa.me/${num.split('@')[0]}\n` +
                      `🏷️ *Mention:* @${num.split('@')[0]}\n` +
                      `📝 *Status:* ${bio?.status || '❌ Tidak ada status'}\n` +
                      `📅 *Tanggal Status:* ${bio?.setAt ? moment(bio.setAt.toDateString()).locale('id').format('LL') : '❓ Unknown'}\n` +
                      `🌐 *Kehadiran:* ${presence}\n\n` +
                      (business ?
                        `💼 *WhatsApp Business Profile* 💼\n\n` +
                        `🆔 *Business ID:* ${business.wid || '❓ Unknown'}\n` +
                        `🌐 *Website:* ${business.website || '❌ Tidak ada'}\n` +
                        `📧 *Email:* ${business.email || '❌ Tidak ada'}\n` +
                        `🏷️ *Kategori:* ${business.category || '❓ Unknown'}\n` +
                        `📍 *Alamat:* ${business.address || '❌ Tidak ada'}\n` +
                        `⏰ *Zona Waktu:* ${business.business_hours?.timezone || '❓ Unknown'}\n` +
                        `📜 *Deskripsi:* ${business.description || '❌ Tidak ada'}\n`
                        : '📱 *Akun WhatsApp Standar* 📱')

        if (img) {
            await conn.sendMessage(m.chat, {
                image: { url: img },
                caption,
                mentions: [num]
            }, { quoted: m })
        } else {
            await m.reply(caption)
        }

    } catch (e) {
        await m.reply(`⚠️ *Error:* ${e.message || 'Terjadi kesalahan!'} ⚠️`)
    }
}

function getFlagEmoji(countryCode) {
    try {
        const codePoints = countryCode.toUpperCase().split('')
            .map(char => 127397 + char.charCodeAt())
        return String.fromCodePoint(...codePoints)
    } catch {
        return null
    }
}

handler.help = ['wastalk'].map(a => a + ' *[nomor atau tag]*')
handler.tags = ['stalk']
handler.command = /^(wa|whatsapp)stalk$/i

module.exports = handler
