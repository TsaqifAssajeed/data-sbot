let handler = async (m, { conn, isOwner, text, isAdmin, command }) => {
  let who
  if (m.isGroup) {
    if (!(isAdmin || isOwner)) {
      global.dfail('admin', m, conn)
      throw false
    }
    if (isOwner) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
    else who = m.chat
  } else {
    if (!isOwner) {
      global.dfail('owner', m, conn)
      throw false
    }
    who = text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
  }

  try {
    if (command === 'ban' || command === 'banchat' || command === 'mute on') {
      if (who.endsWith('g.us')) global.db.data.chats[who].isBanned = true
      else global.db.data.users[who].banned = true
      m.reply(`Berhasil Mute! ${await conn.user.name} tidak aktif di chat ${await conn.getName(who) == undefined ? 'ini' : await conn.getName(who)}.`)
    } else if (command === 'unbanchat' || command === 'unmute' || command === 'mute off') {
      global.db.data.chats[m.chat].isBanned = false
      m.reply('*[ ✓ ] Successfully unmuted chat!*')
    }
  } catch (e) {
    throw `Nomor tidak ada di database!`
  }
}

handler.help = ['mute on', 'mute off', 'unmute'].map(a => a + ' *[mute/unmute bot]*')
handler.tags = ['owner', 'group', 'premium']
handler.command = /^ban(chat)?|banchat|unbanchat|unmute|mute (on|off)$/i
handler.rowner = true
handler.owner = true
handler.premium = true

module.exports = handler
