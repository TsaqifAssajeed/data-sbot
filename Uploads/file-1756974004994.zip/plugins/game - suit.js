let timeout = 60000
let poin = 500
let poin_lose = 100

let handler = async (m, { conn, usedPrefix }) => {
  conn.suit = conn.suit || {}

  if (Object.values(conn.suit).find(room => room.id.startsWith('suit') && [room.p, room.p2].includes(m.sender))) 
    return m.reply('❌ Suit yang sebelumnya belum selesai!!')

  if (!m.mentionedJid[0]) 
    return m.reply(`❌ FORMAT SALAH!!\n\n📝 NOTE :\n\n Tag orang yang mau di tantang suit!!\n\n📌 CONTOH :\n\n– *${usedPrefix}suit @maul*`, m.chat, { contextInfo: { mentionedJid: [owner[1] + '@s.whatsapp.net'] } })

  if (Object.values(conn.suit).find(room => room.id.startsWith('suit') && [room.p, room.p2].includes(m.mentionedJid[0]))) 
    return m.reply(`😹 Orang yang kamu tantang sedang bermain suit bersama orang lain :(`)

  let id = 'suit_' + new Date() * 1
  let caption = `
🎮 ROOM SUIT DIBUAT 🎮

🧑🏻‍🦰 player 1 : @${m.sender.split`@`[0]}
🧑🏻‍🦱 player 2 : @${m.mentionedJid[0].split`@`[0]}

kepada @${m.mentionedJid[0].split`@`[0]} dipersilahkan untuk menjawab.

TERIMA :
- terima
- oke
- gas

TOLAK :
- tolak
- gabisa
- nanti`.trim()

  // Gunakan await untuk reply
  await m.reply(caption, m.chat, { contextInfo: { mentionedJid: [m.sender, m.mentionedJid[0]] } })

  conn.suit[id] = {
    id,
    p: m.sender,
    p2: m.mentionedJid[0],
    status: 'wait',
    poin,
    poin_lose,
    timeout,
    waktu: setTimeout(() => {
      if (conn.suit[id]) conn.reply(m.chat, `⏰ WAKTU HABIS!\n\n> game suit dibatalkan!!`, m)
      delete conn.suit[id]
    }, timeout)
  }
}

handler.tags = ['game']
handler.help = ['suit @tag']
handler.command = /^suit$/i
handler.limit = false
handler.group = true

module.exports = handler