const moment = require("moment-timezone");

function randomID(len = 12) {
   let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; // langsung kapital + angka
   let id = "";
   for (let i = 0; i < len; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
   }
   return id.toUpperCase(); // pastikan kapital semua
}

// fungsi format rupiah dengan titik ribuan
function formatRupiah(angka) {
   let numberString = angka.replace(/[^,\d]/g, ""); // hanya ambil angka
   let sisa = numberString.length % 3;
   let rupiah = numberString.substr(0, sisa);
   let ribuan = numberString.substr(sisa).match(/\d{3}/g);

   if (ribuan) {
      let separator = sisa ? "." : "";
      rupiah += separator + ribuan.join(".");
   }
   return "Rp. " + rupiah;
}

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
   if (!isOwner) return m.reply("❌ Fitur ini hanya untuk Owner!");

   let q = m.quoted ? m.quoted : m;
   let mime = (q.msg || q).mimetype || "";

   if (!mime || !mime.startsWith("image")) 
      return m.reply(`📌 Reply gambar produk dengan caption:\n${usedPrefix + command} <nama produk>|<harga>\n\nContoh:\n${usedPrefix + command} Kaos Polos|50000`);

   if (!text.includes("|")) return m.reply("⚠️ Format salah!\nContoh: .uptestich Kaos Polos|50000");

   let [produk, harga] = text.split("|");
   if (!produk || !harga) return m.reply("⚠️ Nama produk & harga wajib diisi!\nContoh: .uptestich Kaos Polos|50000");

   // format harga jadi rupiah
   let hargaFormatted = formatRupiah(harga.trim());

   // ambil channel dari settings.js
   let idch = global.chtesti;  
   if (!idch) return m.reply("❌ Channel saluran belum diatur di settings.js");

   // ambil tanggal sekarang lokal WIB
   let tanggalOnly = moment().tz("Asia/Makassar").format("DD-MM-YYYY");
let jamOnly = moment().tz("Asia/Makassar").format("HH:mm");


   // buat ID transaksi random
   let trxID = randomID(7);

   // ✅ Ambil nama pengirim media (Customer)
   let originalSender = m.quoted ? m.quoted.sender : m.sender;
   let customerName = await conn.getName(originalSender) || originalSender.split("@")[0];

   // format caption
   let caption = `🛍️ *DETAIL ORDERAN*\n\n
👤 *Customer* : ${customerName}
📦 *Produk*      : ${produk.trim()}
💰 *Harga*        : ${hargaFormatted}
📅 *Tanggal*    : ${tanggalOnly}
🕒 *Jam*           : ${jamOnly} WITA
🔖 *ID*                : JAGPRO-${trxID}\n\n🙏 Terimakasih telah order, ditunggu next ordernya, Semoga puas dengan pelayanan kami ✨💕\n> ${namestore}`;

   // kirim ke saluran
   await conn.sendMessage(idch, {
      image: await q.download(),
      caption: caption
   });

   // balasan sukses ke chat
   await conn.sendMessage(m.chat, {
      text: '✅ Order berhasil dikirim ke Saluran Testimoni!',
      contextInfo: {
         mentionedJid: [originalSender],
         isForwarded: true,
         forwardingScore: 256,
         forwardedNewsletterMessageInfo: {
            newsletterJid: idch,
            newsletterName: '📢 PESAN TERKIRIM KE SALURAN',
            serverMessageId: -1
         },
         externalAdReply: {
            title: `👤 Pengirim: ${m.pushName || m.sender.split("@")[0]}`,
            body: `📆 ${tanggalOnly}`,
            thumbnailUrl: await conn.profilePictureUrl(m.sender, "image").catch(_ => null),
            sourceUrl: "https://whatsapp.com/channel/" + idch.split("@")[0],
            mediaType: 1,
            renderLargerThumbnail: true
         }
      }
   });
};

handler.command = /^uptestich|uptesti$/i;
handler.owner = true; 
module.exports = handler;
