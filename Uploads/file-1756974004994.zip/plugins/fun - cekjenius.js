/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/


const { createCanvas } = require('canvas');

const handler = async (m, { conn, text }) => {
  let name = text.trim();
  if (!name) {
    throw `*Contoh :* .cekgenius Axel`;
  }

  // Mengubah nama menjadi huruf pertama kapital dan sisanya kecil
  name = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();

  const canvas = createCanvas(637, 400);  // Ukuran canvas yang lebih tinggi untuk teks deskripsi
  const ctx = canvas.getContext('2d');

  // Gradasi warna biru untuk tema kecerdasan
  const colors = ['#1E90FF', '#4682B4', '#5F9EA0', '#00BFFF', '#87CEEB'];
  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);

  colors.forEach((color, index) => {
    gradient.addColorStop(index / (colors.length - 1), color);
  });

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Menambahkan judul dengan font lebih bersemangat
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 36px "Poppins", sans-serif';
  ctx.textAlign = 'center';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
  ctx.shadowOffsetX = 3;
  ctx.shadowOffsetY = 3;
  ctx.shadowBlur = 6;
  ctx.fillText('HASIL PENGECEKAN GENIUS', canvas.width / 2, 50);

  // Menampilkan nama dengan font lebih mencolok
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 40px "Lora", serif';
  ctx.fillText(name, canvas.width / 2, 120);

  // Progress bar dengan desain lebih cerah
  ctx.fillStyle = '#E0E0E0';
  ctx.fillRect(50, 180, 537, 20);

  const randomGenius = pickRandom(geniusLevels);
  const levelMatch = randomGenius.match(/Kecerdasan Level : (\d+)%/);

  if (!levelMatch) {
    return conn.sendMessage(m.chat, '⚠️ Terjadi kesalahan dalam mendapatkan level kecerdasan!', m);
  }

  const level = parseInt(levelMatch[1]);
  const progressWidth = (537 * level) / 100;

  // Menambahkan progress bar dengan gradien cerah
  const progressGradient = ctx.createLinearGradient(50, 180, 587, 180);
  progressGradient.addColorStop(0, '#1E90FF');
  progressGradient.addColorStop(1, '#87CEEB');
  ctx.fillStyle = progressGradient;
  ctx.fillRect(50, 180, progressWidth, 20);

  // Menambahkan persentase di atas progress bar
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 22px "Open Sans", sans-serif';
  ctx.fillText(`${level}%`, 170, 195);

  // Deskripsi berdasarkan level kecerdasan
  const description = getDescriptionByLevel(level);
  const lines = wrapText(description, 80);  // Fungsi untuk membungkus teks agar muat

  let textY = 230;
  if (lines.length > 3) {  // Jika teks lebih panjang dari 3 baris, pindahkan ke bawah
    textY = 280;
  }

  // Menambahkan bayangan dan outline pada teks
  ctx.fillStyle = '#FFD700';  // Warna teks kuning emas
  ctx.font = 'bold 18px "Poppins", sans-serif';
  ctx.textAlign = 'center';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowOffsetX = 3;
  ctx.shadowOffsetY = 3;
  ctx.shadowBlur = 10;
  ctx.lineWidth = 4;  // Outline teks
  ctx.strokeStyle = '#FF4500';  // Outline warna merah oranye

  // Menulis teks deskripsi baris per baris
  lines.forEach((line, index) => {
    const lineY = textY + (index * 25);  // Memberi jarak antar baris
    ctx.strokeText(line, canvas.width / 2, lineY);
    ctx.fillText(line, canvas.width / 2, lineY);
  });

  // Mengirimkan gambar hasil cek genius
  const buffer = canvas.toBuffer();
  conn.sendFile(m.chat, buffer, 'genius.png', 'Ini adalah hasil cek kecerdasanmu!', m);
};

handler.help = ['cekgenius <nama>'];
handler.tags = ['fun'];
handler.command = /^(cekgenius|cekgenius)$/i;

module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}

// Fungsi untuk membungkus teks agar muat dalam canvas
function wrapText(text, maxLength) {
  const lines = [];
  const words = text.split(' ');
  let currentLine = '';

  words.forEach(word => {
    if (currentLine.length + word.length < maxLength) {
      currentLine += word + ' ';
    } else {
      lines.push(currentLine);
      currentLine = word + ' ';
    }
  });

  // Menambahkan sisa teks jika ada
  if (currentLine.length > 0) {
    lines.push(currentLine);
  }

  return lines;
}

// Fungsi untuk menentukan deskripsi berdasarkan level kecerdasan
function getDescriptionByLevel(level) {
  if (level <= 5) return 'Baru mulai berkembang.';
  if (level <= 15) return 'Potensimu terlihat.';
  if (level <= 25) return 'Pemikiranmu tajam.';
  if (level <= 35) return 'Kecerdasan berkembang pesat.';
  if (level <= 45) return 'Semakin bijaksana.';
  if (level <= 55) return 'Hampir puncak, inovatif.';
  if (level <= 65) return 'Pemikir luar biasa.';
  if (level <= 75) return 'Mampu memecahkan masalah kompleks.';
  if (level <= 85) return 'Menuju kesempurnaan.';
  if (level <= 95) return 'Mendekati sempurna.';
  if (level === 100) return 'Jenius sejati, sempurna!';
  return 'Deskripsi tidak tersedia';
}

const geniusLevels = [
  'Kecerdasan Level : 4%\n\nBaru mulai berkembang.',
  'Kecerdasan Level : 7%\n\nPotensimu terlihat.',
  'Kecerdasan Level : 12%\n\nPemikiranmu tajam.',
  'Kecerdasan Level : 22%\n\nKecerdasan berkembang pesat.',
  'Kecerdasan Level : 27%\n\nSemakin bijaksana.',
  'Kecerdasan Level : 35%\n\nHampir puncak, inovatif.',
  'Kecerdasan Level : 41%\n\nPemikir luar biasa.',
  'Kecerdasan Level : 48%\n\nMampu memecahkan masalah kompleks.',
  'Kecerdasan Level : 56%\n\nMenuju kesempurnaan.',
  'Kecerdasan Level : 64%\n\nMendekati sempurna.',
  'Kecerdasan Level : 71%\n\nJenius sejati.',
  'Kecerdasan Level : 77%\n\nTak terkalahkan.',
  'Kecerdasan Level : 83%\n\nMengubah dunia.',
  'Kecerdasan Level : 90%\n\nKecerdasan luar biasa.',
  'Kecerdasan Level : 95%\n\nTak terhentikan.',
  'Kecerdasan Level : 100%\n\nJenius sejati, sempurna!'
];