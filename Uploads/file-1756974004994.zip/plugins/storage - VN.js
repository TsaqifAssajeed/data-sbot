/* 🚀 Jagoan Project - Buat Bot Makin Keren! 🚀
📢 Jangan lupa *Subscribe* & *Like* semua video kami!
💬 Butuh panel untuk *Run WhatsApp Bot*? Hubungi: *0895-3622-82300*
🛒 Jual *Script Bot WhatsApp* hanya *70K* - Free Update! 🔥
✨ Dapatkan bot WhatsApp canggih & selalu up-to-date!  
*/

const path = require('path');
const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');
const { fromBuffer } = require('file-type');
const axios = require('axios');

const uploadFile = require('../lib/uploadFile.js');
const vnDbPath = path.join(__dirname, '../media/vnList.json');
const mediaDir = path.join(__dirname, '../media');
if (!fs.existsSync(mediaDir)) fs.mkdirSync(mediaDir, { recursive: true });

// Inisialisasi database VN
let vnDatabase = { vnList: [] };
if (fs.existsSync(vnDbPath)) {
    try {
        vnDatabase = JSON.parse(fs.readFileSync(vnDbPath, 'utf-8'));
    } catch (err) {
        console.error('Gagal membaca database VN:', err);
        vnDatabase = { vnList: [] };
    }
}

// Fungsi untuk menyimpan database VN
const saveVnDatabase = () => {
    try {
        fs.writeFileSync(vnDbPath, JSON.stringify(vnDatabase, null, 2));
    } catch (err) {
        console.error('Gagal menyimpan database VN:', err);
    }
};

// Fungsi untuk mengonversi audio ke format opus yang kompatibel
const convertToOpus = (inputBuffer) => {
    return new Promise((resolve, reject) => {
        const tempInput = path.join(mediaDir, `temp_input_${Date.now()}.tmp`);
        const tempOutput = path.join(mediaDir, `temp_output_${Date.now()}.ogg`);

        fs.writeFileSync(tempInput, inputBuffer);

        ffmpeg(tempInput)
            .audioCodec('libopus')
            .audioChannels(1) // Mono untuk VN
            .audioFrequency(48000) // Sampling rate 48kHz
            .audioBitrate('32k') // Bitrate rendah untuk VN
            .format('ogg')
            .on('error', (err) => {
                fs.unlinkSync(tempInput);
                reject(new Error(`Gagal mengonversi audio: ${err.message}`));
            })
            .on('end', () => {
                const outputBuffer = fs.readFileSync(tempOutput);
                fs.unlinkSync(tempInput);
                fs.unlinkSync(tempOutput);
                resolve(outputBuffer);
            })
            .save(tempOutput);
    });
};

// Fungsi untuk mendapatkan metadata audio
const getAudioMetadata = (buffer) => {
    return new Promise((resolve, reject) => {
        const tempFile = path.join(mediaDir, `temp_meta_${Date.now()}.tmp`);
        fs.writeFileSync(tempFile, buffer);

        ffmpeg.ffprobe(tempFile, (err, metadata) => {
            fs.unlinkSync(tempFile);
            if (err) return reject(new Error(`Gagal mendapatkan metadata: ${err.message}`));
            const audioStream = metadata.streams.find(s => s.codec_type === 'audio');
            resolve({
                duration: metadata.format.duration,
                sampleRate: audioStream?.sample_rate,
                channels: audioStream?.channels,
                bitrate: audioStream?.bit_rate
            });
        });
    });
};

// Fungsi untuk mengunduh, memverifikasi, dan mengonversi audio
const fetchAndConvertAudio = async (url) => {
    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        let buffer = Buffer.from(response.data);
        const fileType = await fromBuffer(buffer);
        console.log('Fetched audio:', { url, mime: fileType?.mime, size: buffer.length });

        if (!fileType || !fileType.mime.startsWith('audio/')) {
            throw new Error('File bukan audio yang valid');
        }

        // Dapatkan metadata
        const metadata = await getAudioMetadata(buffer);
        console.log('Audio metadata:', metadata);

        // Konversi ulang untuk memastikan kompatibilitas
        buffer = await convertToOpus(buffer);
        return buffer;
    } catch (err) {
        console.error('Gagal memproses audio:', err.message);
        throw new Error(`Gagal memproses audio dari ${url}: ${err.message}`);
    }
};


const handler = async (message, { usedPrefix, text, command, conn, isOwner }) => {
    const vnList = vnDatabase.vnList || [];

    const computedIsOwner = isOwner || (global.rowner
        ? Array.isArray(global.rowner)
            ? global.rowner.includes(message.sender)
            : global.rowner === message.sender
        : false);

    // Perintah: addvn (khusus owner)
    if (command === 'addvn') {
        if (!computedIsOwner) throw `🚫 Maaf, hanya *owner* yang bisa menggunakan perintah *${command}*!`;
        if (!text) throw `❌ Format tidak valid!\n\nGunakan: *${usedPrefix}${command} <nama>*\nContoh: *${usedPrefix}${command} anjing*`;
        
        const quoted = message.quoted ? message.quoted : message;
        const mime = (quoted.msg || quoted).mimetype || '';
        if (!mime.startsWith('audio/')) throw `‼️ Reply pesan audio/VN dengan caption *${usedPrefix}${command} <nama>*`;

        let media = await quoted.download();
        if (!media) throw `❌ Gagal mengunduh audio! Pastikan Anda mereply pesan audio.`;

        // Validasi ukuran file (maksimal 5MB, seperti tourl.js)
        const fileSizeLimit = 5 * 1024 * 1024;
        if (media.length > fileSizeLimit) throw `❌ Ukuran audio tidak boleh melebihi 5MB!`;

        // Cek apakah nama VN sudah ada
        if (vnList.some(item => item.key.toLowerCase() === text.toLowerCase())) {
            throw `❌ Nama VN *${text}* sudah ada! Gunakan nama lain.`;
        }

        // Konversi audio untuk memastikan kompatibilitas
        let uploadMedia = media;
        try {
            console.log('Mengonversi audio ke opus...');
            uploadMedia = await convertToOpus(media);
        } catch (err) {
            throw `❌ Gagal mengonversi audio: ${err.message}`;
        }

        // Upload file untuk mendapatkan link
        let link;
        try {
            if (typeof uploadFile !== 'function') {
                console.error('uploadFile bukan fungsi, nilai:', uploadFile);
                throw new Error('Modul uploadFile tidak valid. Pastikan /lib/uploadFile.js mengekspor fungsi yang benar.');
            }
            link = await uploadFile(uploadMedia);
        } catch (err) {
            console.error('Gagal mengunggah audio:', err);
            throw `❌ Gagal mengunggah audio: ${err.message}`;
        }
        
        // Simpan ke database
        vnList.push({ key: text, url: link });
        saveVnDatabase();
        return message.reply(`✅ Berhasil menambahkan VN *${text}* ke daftar global!\n\n> Ketik *${usedPrefix}listvn* untuk melihat daftar.`);
    }

    // Perintah: listvn (bisa diakses semua orang)
    if (command === 'listvn') {
        if (!vnList.length) throw `😔 Belum ada VN tersimpan. Owner bisa tambahkan dengan *${usedPrefix}addvn*!`;

        const userName = message.pushName || message.name || 'Teman';
        const vnListText = vnList
            .map((item, index) => `${index + 1}. ${item.key}`)
            .join('\n');

        const replyMessage = `👋 Halo, ${userName}!\n\n📋 *Daftar Voice Note:*\n${vnListText}\n\n✨ Ketik nama VN atau *${usedPrefix}getvn <nama|nomor>* untuk memutar.\n✨ Owner bisa hapus dengan *${usedPrefix}delvn <nama|nomor|all>*`;
        return message.reply(replyMessage);
    }

    // Perintah: getvn (bisa diakses semua orang)
    if (command === 'getvn') {
        if (!vnList.length) throw `😔 Belum ada VN tersimpan. Owner bisa tambahkan dengan *${usedPrefix}addvn*!`;

        if (!text) {
            const vnListText = vnList
                .map((item, index) => `${index + 1}. ${item.key}`)
                .join('\n');
            const instruction = `📋 *Daftar Voice Note:*\n${vnListText}\n\n🎵 Ketik *${usedPrefix}getvn <nama|nomor>* untuk memutar VN.\nContoh:\n- *${usedPrefix}getvn anjing*\n- *${usedPrefix}getvn 3*`;
            return message.reply(instruction);
        }

        let vnItem;
        // Cek apakah input adalah angka (nomor urutan)
        const index = parseInt(text) - 1;
        if (!isNaN(index)) {
            if (index < 0 || index >= vnList.length) {
                throw `🔍 Nomor *${text}* tidak valid! Gunakan *${usedPrefix}listvn* untuk melihat daftar.`;
            }
            vnItem = vnList[index];
        } else {
            // Cari berdasarkan nama
            vnItem = vnList.find(item => item.key.toLowerCase() === text.toLowerCase());
            if (!vnItem) throw `🔍 VN *${text}* tidak ditemukan! Gunakan *${usedPrefix}listvn* untuk melihat daftar.`;
        }

        try {
            // Unduh, konversi, dan kirim audio
            const audioBuffer = await fetchAndConvertAudio(vnItem.url);
            return await conn.sendMessage(message.chat, {
                audio: audioBuffer,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true,
                fileName: `${vnItem.key}.ogg`
            });
        } catch (err) {
            console.error('Gagal mengirim VN:', err);
            // Fallback: Kirim tanpa ptt
            try {
                const audioBuffer = await fetchAndConvertAudio(vnItem.url);
                return await conn.sendMessage(message.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: false,
                    fileName: `${vnItem.key}.ogg`
                });
            } catch (fallbackErr) {
                console.error('Gagal mengirim fallback:', fallbackErr);
                throw `❌ Gagal memutar VN: ${err.message}`;
            }
        }
    }

    // Perintah: delvn (khusus owner)
    if (command === 'delvn') {
        if (!computedIsOwner) throw `🚫 Maaf, hanya *owner* yang bisa menggunakan perintah *${command}*!`;
        if (!vnList.length) throw `😔 Belum ada VN tersimpan. Owner bisa tambahkan dengan *${usedPrefix}addvn*!`;

        if (!text) {
            const vnListText = vnList
                .map((item, index) => `${index + 1}. ${item.key}`)
                .join('\n');
            const instruction = `📋 *Daftar Voice Note:*\n${vnListText}\n\n🗑️ Ketik *${usedPrefix}delvn <nama|nomor|all>* untuk menghapus VN.\nContoh:\n- *${usedPrefix}delvn anjing*\n- *${usedPrefix}delvn 3*\n- *${usedPrefix}delvn all*`;
            return message.reply(instruction);
        }

        // Cek apakah input adalah 'all'
        if (text.toLowerCase() === 'all') {
            vnDatabase.vnList = [];
            saveVnDatabase();
            return message.reply(`🗑️ Berhasil menghapus *semua* Voice Note dari daftar global!`);
        }

        // Cek apakah input adalah angka (nomor urutan)
        const index = parseInt(text) - 1;
        if (!isNaN(index)) {
            if (index < 0 || index >= vnList.length) {
                throw `🔍 Nomor *${text}* tidak valid! Gunakan *${usedPrefix}listvn* untuk melihat daftar.`;
            }
            const removedItem = vnList.splice(index, 1)[0];
            saveVnDatabase();
            return message.reply(`🗑️ Berhasil menghapus VN *${removedItem.key}* (nomor ${text}) dari daftar global!`);
        }

        // Hapus berdasarkan nama (fungsi existing)
        const vnIndex = vnList.findIndex(item => item.key.toLowerCase() === text.toLowerCase());
        if (vnIndex === -1) throw `🔍 VN *${text}* tidak ditemukan! Gunakan *${usedPrefix}listvn* untuk melihat daftar.`;

        const removedItem = vnList.splice(vnIndex, 1)[0];
        saveVnDatabase();
        return message.reply(`🗑️ Berhasil menghapus VN *${removedItem.key}* dari daftar global!`);
    }

    // Pencarian VN berdasarkan nama langsung (bisa diakses semua orang)
    if (text && !command) {
        const keyword = text.toLowerCase();
        const matchedItem = vnList.find(item => item.key.toLowerCase() === keyword);

        if (matchedItem) {
            try {
                // Unduh, konversi, dan kirim audio
                const audioBuffer = await fetchAndConvertAudio(matchedItem.url);
                return await conn.sendMessage(message.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true,
                    fileName: `${matchedItem.key}.ogg`
                });
            } catch (err) {
                console.error('Gagal mengirim VN:', err);
                // Fallback: Kirim tanpa ptt
                try {
                    const audioBuffer = await fetchAndConvertAudio(matchedItem.url);
                    return await conn.sendMessage(message.chat, {
                        audio: audioBuffer,
                        mimetype: 'audio/ogg; codecs=opus',
                        ptt: false,
                        fileName: `${matchedItem.key}.ogg`
                    });
                } catch (fallbackErr) {
                    console.error('Gagal mengirim fallback:', fallbackErr);
                    throw `❌ Gagal memutar VN: ${err.message}`;
                }
            }
        }
    }
};

// Handler untuk pencarian VN secara langsung
handler.all = async (message) => {
    const vnList = vnDatabase.vnList || [];
    const text = message.text.toLowerCase();
    const matchedItem = vnList.find(item => item.key.toLowerCase() === text);

    if (matchedItem) {
        try {
            const conn = global.conn; // Gunakan conn dari global
            if (!conn || typeof conn.sendMessage !== 'function') {
                console.error('Koneksi conn tidak valid:', conn);
                throw new Error('Koneksi bot tidak tersedia');
            }
            // Unduh, konversi, dan kirim audio
            const audioBuffer = await fetchAndConvertAudio(matchedItem.url);
            return await conn.sendMessage(message.chat, {
                audio: audioBuffer,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true,
                fileName: `${matchedItem.key}.ogg`
             } , { quoted: message }); // ✅ balas pesan user yang ketik nama VN
        } catch (err) {
            console.error('Gagal mengirim VN:', err);
            // Fallback: Kirim tanpa ptt
            try {
                const audioBuffer = await fetchAndConvertAudio(matchedItem.url);
                return await conn.sendMessage(message.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: false,
                    fileName: `${matchedItem.key}.ogg`
                });
            } catch (fallbackErr) {
                console.error('Gagal mengirim fallback:', fallbackErr);
                throw `❌ Gagal memutar VN: ${err.message}`;
            }
        }
    }
};

// Konfigurasi handler
handler.help = ['addvn <nama>', 'listvn', 'getvn <nama|nomor>', 'delvn <nama|nomor|all>'];
handler.tags = ['storage'];
handler.command = /^addvn|listvn|getvn|delvn$/i;
handler.group = false; // Bisa digunakan di grup atau chat pribadi
handler.limit = false; // Batasi penggunaan untuk mencegah spam

module.exports = handler;