let handler = async (m, { conn, text }) => {
  if (!text) throw `Judulnya?`;
  try {
    let otaku = await require('../lib/scraper.js').otakudesu.search(text);
    let otakuinfo = `▸ *Title:* ${otaku[0].title}
▸ *Genre:* ${otaku[0].genres.join(', ')}
▸ *Status*: ${otaku[0].status}
▸ *Rating*: ${otaku[0].rating}
▸ *Link*: ${otaku[0].link}`;
    return conn.sendFile(m.chat, otaku[0].image, 'otaku.jpeg', otakuinfo, m);
  } catch (e) {
    m.reply(`Terjadi Kesalahan, Judul Yang Kamu Cari Tidak Dapat Di Temukan`);
  }
};

handler.help = ['otakusearch'];
handler.tags = ['anime'];
handler.command = /^(otakusearch)$/i;
handler.limit = true;

module.exports = handler;
