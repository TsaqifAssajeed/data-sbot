// ✨ Plugin tools - enc ✨

const fs = require('fs')
const path = require('path')
const obfuscator = require('javascript-obfuscator')

let handler = async (m, { conn, args }) => {
  const q = m.quoted || m
  const mime = q?.mimetype || ''
  const isJS = mime === 'application/javascript' || /\.js$/i.test(q?.fileName || '')

  if (!isJS) return m.reply('❌ Balas atau kirim file `.js` untuk dienkripsi.\nContoh: kirim file lalu balas dengan *.enc <watermark>*')

  const watermark = (args.join(' ') || 'EncryptedByMahiru')
    .replace(/[^\w\u4e00-\u9fff]/g, '') // huruf, angka, simbol Cina
    .slice(0, 40)

  const fileName = q.fileName || 'file.js'
  m.reply(`⏳ Mendownload file *${fileName}*...`)
  let buffer
  try {
    buffer = await q.download()
  } catch {
    return m.reply('❌ Gagal mengunduh file.')
  }

  m.reply(`🔐 Mengenkripsi file dengan watermark: *${watermark}* ...`)

  try {
    const result = obfuscator.obfuscate(buffer.toString(), {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 0.85,
      deadCodeInjection: true,
      deadCodeInjectionThreshold: 0.4,
      debugProtection: true,
      debugProtectionInterval: 4000,
      disableConsoleOutput: true,
      selfDefending: true,
      renameGlobals: true,
      identifierNamesGenerator: 'hexadecimal', // menggunakan hexadecimal agar sulit dibaca
      identifiersPrefix: watermark,
      splitStrings: true,
      splitStringsChunkLength: 5,
      stringArray: true,
      stringArrayEncoding: ['rc4'],
      stringArrayThreshold: 0.75,
      transformObjectKeys: true
    })

    const outPath = path.join('./tmp', `enc-${Date.now()}-${fileName}`)
    fs.writeFileSync(outPath, result.getObfuscatedCode())

    await conn.sendMessage(m.chat, {
      document: fs.readFileSync(outPath),
      mimetype: 'application/javascript',
      fileName: `${fileName}`,
      caption: `✅ File dienkripsi dengan watermark: *${watermark}*`
    }, { quoted: m })

    fs.unlinkSync(outPath)
  } catch (err) {
    console.error(err)
    return m.reply(`❌ Gagal enkripsi:\n${err.message}`)
  }
}

handler.help = ['enc <watermark>']
handler.tags = ['tools']
handler.command = /^enc(rypt)?(hard)?$/i
handler.premium = true

module.exports = handler