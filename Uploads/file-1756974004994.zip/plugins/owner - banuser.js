// 📝 plugin owner - banuser

let ms = require('ms');

let handler = async (m, { conn, isOwner, args, text }) => {
    if (!isOwner) {
        global.dfail('owner', m, conn);
        throw false;
    }

    let who;
    let duration;
    let input = text.trim();

    if (m.isGroup) {
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            who = m.mentionedJid[0];
            duration = args[1];
        } else if (m.quoted) {
            who = m.quoted.sender;
            duration = args[0];
        } else if (input) {
            let parts = input.split(' ');
            let number = parts[0].replace(/[^0-9]/g, '').replace(/^(\+62|62)/, '62');
            if (!number.startsWith('62')) throw '‼️ Nomor harus dimulai dengan 62.\n\n📝 Contoh penggunaan :\n\n— .banuser 6285257129838 1h';
            who = number + '@s.whatsapp.net';
            duration = parts[1];
        } else {
            throw '❌ Format salah!!\n\n📝 Cara penggunaan :\n\n— .banuser <@user> <durasi>\n— .banuser <reply chat> <durasi>\n— .banuser <nomor> <durasi>\n\n📝 Contoh penggunaan :\n\n— .banuser @arman 10d\n— .banuser reply 30h\n— .banuser 6285257129838 40s\n\n⏰ Format waktu :\n\n— s = detik\n— m = menit\n— h = jam\n— d = hari\n\n> tanpa format waktu = permanent.';
        }
    } else {
        if (input) {
            let parts = input.split(' ');
            let number = parts[0].replace(/[^0-9]/g, '').replace(/^(\+62|62)/, '62');
            if (!number.startsWith('62')) throw 'Nomor harus dimulai dengan 62.\n\n📝 Contoh penggunaan :\n\n— .banuser 6285257129838 30m';
            who = number + '@s.whatsapp.net';
            duration = parts[1];
        } else {
            who = m.chat;
        }
    }

    // Tambahkan ini: Konversi LID ke JID dengan groupMetadata jika di grup
    if (who && m.isGroup && (who.endsWith('@lid') || who.startsWith('lid:'))) {
        try {
            const groupMeta = await conn.groupMetadata(m.chat); // Ambil metadata (sudah di-override di simple.js)
            const participant = groupMeta.participants.find(p => p.id === who || p.lid === who);
            if (participant && participant.jid) {
                who = participant.jid; // Ganti who dengan JID real
                console.log(`[DEBUG] Resolved LID ${who} to JID: ${participant.jid}`);
            } else {
                // Fallback jika tidak ditemukan di metadata
                who = await conn.resolveLid(who) || conn.decodeJid(who);
                console.log(`[DEBUG] Fallback conversion for LID: ${who}`);
            }
        } catch (e) {
            console.error('Gagal konversi LID via metadata:', e);
            throw '❌ Gagal mengonversi ID user. Pastikan bot admin grup atau coba lagi.';
        }
    } else if (who && (who.endsWith('@lid') || who.startsWith('lid:'))) {
        // Untuk non-grup, fallback biasa
        try {
            who = await conn.resolveLid(who) || conn.decodeJid(who);
            console.log(`[DEBUG] Converted LID to JID (non-group): ${who}`);
        } catch (e) {
            console.error('Gagal konversi LID:', e);
            throw '❌ Gagal mengonversi ID user. Coba lagi atau periksa log.';
        }
    }

    try {
        if (!who) throw '❌ User tidak valid!';
        if (!global.db?.data?.users) throw '‼️ Database pengguna tidak tersedia';

        let users = global.db.data.users;
        if (!users[who]) users[who] = {};

        users[who].banned = true;

        let bannedUntil = null;
        if (duration && duration.toLowerCase() !== 'permanent') {
            let msDuration = ms(duration);
            if (!msDuration) throw '❌ Format waktu salah!!\n\n📝 Gunakan contoh :\n\n— 10s\n— 30m\n— 1h\n— 2d\n\n> tanpa format waktu = permanent';
            bannedUntil = Date.now() + msDuration;
            users[who].bannedUntil = bannedUntil;
        } else {
            users[who].bannedUntil = null; // permanent
        }

        let durasiText = bannedUntil
            ? ` selama ${ms(bannedUntil - Date.now(), { long: true })}`
            : ' secara permanent';

        await conn.reply(m.chat, `✅ Berhasil banned user!!\n\n🪀 nomor : ${who.split('@')[0]}\n⛔ status : banned\n⏰ durasi : ${durasiText}`, m);
    } catch (e) {
        console.log('Error occurred:', e);
        await conn.reply(m.chat, `Error: ${e.message || e}`, m);
    }
};

handler.help = ['banuser <nomor|@tag|reply> [durasi]'];
handler.tags = ['owner'];
handler.command = /^banuser$/i;
handler.rowner = true;

module.exports = handler;