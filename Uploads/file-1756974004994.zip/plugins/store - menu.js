const moment = require('moment-timezone');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// Path untuk database store, testimoni, dan addlistgambar
const storeDbPath = path.join(__dirname, '../database/databaseStore.json');
const testiDbPath = path.join(__dirname, '../media/testimoni.json');
const imageListDbPath = path.join(__dirname, '../database/imageList.json');

// Pastikan folder ./database dan ./media ada
const libDir = path.join(__dirname, '../database');
const mediaDir = path.join(__dirname, '../media');
if (!fs.existsSync(libDir)) fs.mkdirSync(libDir, { recursive: true });
if (!fs.existsSync(mediaDir)) fs.mkdirSync(mediaDir, { recursive: true });

// Inisialisasi database store
let storeDatabase = {};
if (fs.existsSync(storeDbPath)) {
    try {
        storeDatabase = JSON.parse(fs.readFileSync(storeDbPath, 'utf-8'));
    } catch (err) {
        console.error('Gagal membaca database store:', err);
        storeDatabase = {};
    }
}

// Inisialisasi database testimoni
let testiDatabase = {};
if (fs.existsSync(testiDbPath)) {
    try {
        testiDatabase = JSON.parse(fs.readFileSync(testiDbPath, 'utf-8'));
    } catch (err) {
        console.error('Gagal membaca database testimoni:', err);
        testiDatabase = {};
    }
}

// Inisialisasi database addlistgambar
let imageListDatabase = {};
if (fs.existsSync(imageListDbPath)) {
    try {
        imageListDatabase = JSON.parse(fs.readFileSync(imageListDbPath, 'utf-8'));
    } catch (err) {
        console.error('Gagal membaca database addlistgambar:', err);
        imageListDatabase = {};
    }
}

// Fungsi untuk menyimpan database store
const saveStoreDatabase = () => {
    try {
        fs.writeFileSync(storeDbPath, JSON.stringify(storeDatabase, null, 2));
    } catch (err) {
        console.error('Gagal menyimpan database store:', err);
    }
};

// Fungsi untuk menyimpan database testimoni
const saveTestiDatabase = () => {
    try {
        fs.writeFileSync(testiDbPath, JSON.stringify(testiDatabase, null, 2));
    } catch (err) {
        console.error('Gagal menyimpan database testimoni:', err);
    }
};

// Fungsi untuk menyimpan database addlistgambar
const saveImageListDatabase = () => {
    try {
        fs.writeFileSync(imageListDbPath, JSON.stringify(imageListDatabase, null, 2));
    } catch (err) {
        console.error('Gagal menyimpan database addlistgambar:', err);
    }
};

// Konfigurasi contextInfo untuk testimoni
const contextInfoConfig = {
    externalAdReply: {
        title: 'Testimoni Buyer',
        body: 'Terverifikasi Whatsapp',
        thumbnailUrl: 'https://lampungnewspaper.disway.id/upload/8d1372c08280c41b46e791b7ada73eb6.jpg',
        sourceUrl: '120363315304652958@newsletter',
        mediaType: 1,
        renderLargerThumbnail: false
    },
    quoted: {
        key: { 
            fromMe: false, 
            participant: '0@s.whatsapp.net', 
            remoteJid: '17608914335-1615035634@g.us' 
        }, 
        message: { conversation: 'Testimoni Pelanggan' }
    }
};

// Fungsi utama handler
const handler = async (message, { usedPrefix, text, command, conn, isAdmin, isOwner }) => {
    if (!conn) {
        console.error('Error: Objek conn tidak didefinisikan di handler utama');
        return message.reply('❌ Terjadi kesalahan: Koneksi bot tidak tersedia. Hubungi admin bot.');
    }

    // Inisialisasi database per grup
    const groupId = message.chat;
    if (!storeDatabase[groupId]) {
        storeDatabase[groupId] = { store: [] };
    }
    if (!testiDatabase[groupId]) {
        testiDatabase[groupId] = { testimoni: {} };
    } else if (!testiDatabase[groupId].testimoni) {
        testiDatabase[groupId].testimoni = {};
    }
    if (!imageListDatabase[groupId]) {
        imageListDatabase[groupId] = { imageList: {} };
    } else if (!imageListDatabase[groupId].imageList) {
        imageListDatabase[groupId].imageList = {};
    }
    const storeData = storeDatabase[groupId].store || [];
    const imageListData = imageListDatabase[groupId].imageList || {};
    const testimoniData = testiDatabase[groupId].testimoni || {};

    // Fungsi untuk menyapa berdasarkan waktu dengan emoji
    const greetings = (() => {
        const hours = moment().tz('Asia/Makassar').hour();
        return hours < 6 ? '🌙 Selamat Malam' 
             : hours < 12 ? '☀️ Selamat Pagi' 
             : hours < 16 ? '🌞 Selamat Siang' 
             : hours < 19 ? '🌅 Selamat Sore'
             : '🌙 Selamat Malam';
    })();

    // Perintah: list (bisa diakses semua orang)
    if (command === 'list') {
        if (!storeData.length && Object.keys(imageListData).length === 0) {
            throw `😔 Belum ada item di store grup ini. Admin bisa tambahkan dengan *${usedPrefix}addlist*!`;
        }

        const userName = message.pushName || message.name || 'Teman';
        const textItems = storeData
            .map(item => item.key)
            .sort((a, b) => a.localeCompare(b))
            .map(key => `📌 ${key}`)
            .join('\n');
        const imageItems = Object.keys(imageListData)
            .sort((a, b) => a.localeCompare(b))
            .map(key => `🖼️ ${key}`)
            .join('\n');
        const itemList = [textItems, imageItems].filter(Boolean).join('\n\n🖼️ *Gambar Items:*\n');
        const replyMessage = `${greetings}, ${userName}! 🎉\n\n📋 *Daftar Item di Store Grup:*\n${itemList || 'Tidak ada item'}\n\n✨ Ketik nama kata kunci untuk menggunakannya!`;
        return message.reply(replyMessage);
    }

    // Cek apakah pengguna adalah admin atau owner untuk perintah selain list
    if (!isAdmin && !isOwner && ['addlist', 'dellist', 'editlist', 'pay', 'proses', 'done', 'addtesti', 'deltesti', 'testimoni', 'testi'].includes(command)) {
        throw `🚫 Maaf, hanya *admin grup* atau *owner* yang bisa menggunakan perintah *${command}*!`;
    }

    // Perintah: addlist (khusus admin/owner, mendukung teks dan gambar)
    if (command === 'addlist') {
        let q = message.quoted ? message.quoted : message;
        let mimetype = (q.msg || q).mimetype || '';

        if (mimetype.startsWith('image/')) {
            // Tambah item gambar
            if (!text) throw `❌ *Format tidak valid*\n\n📝 *Contoh penggunaan:* \n\n> ${usedPrefix}addlist <nama>|<caption> (dengan reply/kirim gambar)\nContoh: ${usedPrefix}addlist produk1|Ini produk terbaik`;

            // Pisahkan nama dan caption
            const [key, ...captionParts] = text.split('|').map(part => part.trim());
            const caption = captionParts.join('|') || key; // Gunakan key sebagai caption jika tidak ada caption

            if (!key) throw `❌ *Nama item tidak boleh kosong!*\n\nGunakan: ${usedPrefix}addlist <nama>|<caption>`;
            if (key.includes('|')) throw `❌ Nama item tidak boleh mengandung karakter '|'!`;

            // Ambil buffer gambar
            let media;
            try {
                media = await q.download();
            } catch (err) {
                console.error('Gagal mengunduh media:', err);
                throw `❌ Gagal mengunduh gambar! Pastikan Anda mereply/kirim gambar.`;
            }
            if (!media) throw `❌ Gagal mengunduh gambar! Pastikan Anda mereply/kirim gambar.`;

            // Buat hash dari buffer
            let hash = crypto.createHash('sha256').update(media).digest('hex');
            // Konversi buffer ke Base64
            let base64Image = media.toString('base64');

            // Simpan metadata dan Base64 ke database addlistgambar
            imageListDatabase[groupId].imageList[key.toLowerCase()] = {
                hash: hash,
                image: base64Image,
                caption: caption,
                createdAt: new Date().toISOString()
            };

            saveImageListDatabase();
            return message.reply(`✅ *Berhasil menambahkan item gambar*\n\n – Nama: ${key}\n – Caption: ${caption}\n\n> Ketik ${usedPrefix}list untuk melihat daftar.`);
        } else {
            // Tambah item teks
            if (!text.includes('|')) throw `❌ Format salah!\n\nGunakan: *${usedPrefix}${command} <nama>|<respon>*\nContoh: *${usedPrefix}${command} assalamualaikum|waalaikumsalam*`;

            const [key, ...responseParts] = text.split('|').map(part => part.trim());
            const response = responseParts.join('|');

            if (!key || !response) throw `❌ Format tidak valid!\n\nGunakan: *${usedPrefix}${command} <nama>|<respon>*\nContoh: *${usedPrefix}${command} assalamualaikum|waalaikumsalam*`;

            storeData.push({ key, response, isImage: false });
            saveStoreDatabase();
            return message.reply(`✅ Berhasil menambahkan *${key}* ke store grup ini! 🎉`);
        }
    }

    // Perintah: dellist (khusus admin/owner, mendukung teks dan gambar)
    if (command === 'dellist') {
        if (!storeData.length && Object.keys(imageListData).length === 0) {
            throw `😔 Belum ada item di store grup ini. Tambahkan dengan *${usedPrefix}addlist*!`;
        }

        // Jika tidak ada teks, tampilkan daftar item
        if (!text) {
            const textItems = storeData
                .map((item, index) => `${index + 1}. ${item.key}`)
                .join('\n');
            const imageItems = Object.keys(imageListData)
                .sort()
                .map((key, index) => `${storeData.length + index + 1}. ${key} (gambar)`)
                .join('\n');
            const itemList = [textItems, imageItems].filter(Boolean).join('\n\n🖼️ *Gambar Items:*\n');
            const instruction = `📋 *Daftar Item di Store Grup:*\n${itemList || 'Tidak ada item'}\n\n🗑️ *Cara Menghapus ada dua:*\n- Ketik *${usedPrefix}dellist <nama item>* untuk hapus berdasarkan nama.\n- Ketik *${usedPrefix}dellist <nomor>* untuk hapus berdasarkan urutan.`;
            return message.reply(instruction);
        }

        let removedItem;
        const index = parseInt(text) - 1;
        if (!isNaN(index)) {
            // Hapus berdasarkan nomor urutan
            if (index >= 0 && index < storeData.length) {
                // Item teks
                removedItem = storeData.splice(index, 1)[0];
                saveStoreDatabase();
                return message.reply(`🗑️ Berhasil menghapus *${removedItem.key}* dari store grup ini! 🎉`);
            } else if (index >= storeData.length && index < storeData.length + Object.keys(imageListData).length) {
                // Item gambar
                const imageIndex = index - storeData.length;
                const imageKey = Object.keys(imageListData).sort()[imageIndex];
                removedItem = imageListData[imageKey];
                delete imageListData[imageKey];
                saveImageListDatabase();
                return message.reply(`🗑️ Berhasil menghapus *${imageKey}* (gambar) dari store grup ini! 🎉`);
            } else {
                throw `🔍 Nomor *${text}* tidak ditemukan! Gunakan *${usedPrefix}dellist* untuk melihat daftar.`;
            }
        } else {
            // Hapus berdasarkan nama item
            const itemIndex = storeData.findIndex(item => item.key.toLowerCase() === text.toLowerCase());
            if (itemIndex !== -1) {
                removedItem = storeData.splice(itemIndex, 1)[0];
                saveStoreDatabase();
                return message.reply(`🗑️ Berhasil menghapus *${removedItem.key}* dari store grup ini! 🎉`);
            } else if (imageListData[text.toLowerCase()]) {
                removedItem = imageListData[text.toLowerCase()];
                delete imageListData[text.toLowerCase()];
                saveImageListDatabase();
                return message.reply(`🗑️ Berhasil menghapus *${text}* (gambar) dari store grup ini! 🎉`);
            } else {
                throw `🔍 Item *${text}* tidak ditemukan! Gunakan *${usedPrefix}dellist* untuk melihat daftar.`;
            }
        }
    }

    // Perintah: editlist (khusus admin/owner, mendukung teks dan gambar)
    if (command === 'editlist') {
        let q = message.quoted ? message.quoted : message;
        let mimetype = (q.msg || q).mimetype || '';

        if (mimetype.startsWith('image/')) {
            // Edit item gambar
            if (!text) throw `❌ *Format tidak valid*\n\n📝 *Contoh penggunaan:* \n\n> ${usedPrefix}editlist <nama>|<caption> (dengan reply/kirim gambar)\nContoh: ${usedPrefix}editlist produk1|Ini produk terbaik`;

            // Pisahkan nama dan caption
            const [key, ...captionParts] = text.split('|').map(part => part.trim());
            const caption = captionParts.join('|') || key;

            if (!key) throw `❌ *Nama item tidak boleh kosong!*\n\nGunakan: ${usedPrefix}editlist <nama>|<caption>`;
            if (key.includes('|')) throw `❌ Nama item tidak boleh mengandung karakter '|'!`;

            const item = imageListData[key.toLowerCase()];
            if (!item) throw `🔍 Item *${key}* tidak ditemukan! Cek daftar dengan *${usedPrefix}list*.`;

            // Ambil buffer gambar
            let media;
            try {
                media = await q.download();
            } catch (err) {
                console.error('Gagal mengunduh media:', err);
                throw `❌ Gagal mengunduh gambar! Pastikan Anda mereply/kirim gambar.`;
            }
            if (!media) throw `❌ Gagal mengunduh gambar! Pastikan Anda mereply/kirim gambar.`;

            // Buat hash dari buffer
            let hash = crypto.createHash('sha256').update(media).digest('hex');
            // Konversi buffer ke Base64
            let base64Image = media.toString('base64');

            // Update metadata dan Base64
            imageListData[key.toLowerCase()] = {
                hash: hash,
                image: base64Image,
                caption: caption,
                createdAt: new Date().toISOString()
            };

            saveImageListDatabase();
            return message.reply(`✏️ Berhasil mengedit item gambar *${key}* dengan caption: ${caption}! 🎉`);
        } else {
            // Edit item teks
            if (!text.includes('|')) throw `❌ Format salah!\n\nGunakan: *${usedPrefix}${command} <nama>|<respon>*\nContoh: *${usedPrefix}${command} assalamualaikum|waalaikumsalam*`;

            const [key, ...responseParts] = text.split('|').map(part => part.trim());
            const newResponse = responseParts.join('|');

            if (!key || !newResponse) throw `❌ Format tidak valid!\n\nGunakan: *${usedPrefix}${command} <nama>|<respon>*\nContoh: *${usedPrefix}${command} assalamualaikum|waalaikumsalam*`;

            const item = storeData.find(item => item.key === key);
            if (item) {
                item.response = newResponse;
                saveStoreDatabase();
                return message.reply(`✏️ Berhasil mengedit item *${key}*! 🎉`);
            } else {
                throw `🔍 Item *${key}* tidak ditemukan! Cek daftar dengan *${usedPrefix}list*.`;
            }
        }
    }

    // Perintah: proses atau p (khusus admin/owner)
    if (command === 'proses' || command === 'p') {
        const quotedMsgData = message.quoted ? message.quoted : null;
        if (!quotedMsgData) return message.reply(`❗ Reply pesanan yang ingin diproses!`);

        let prosesText = `📦 *TRANSAKSI PENDING* 📦\n\n📅 *Tanggal*: ${moment().format('DD-MM-YYYY')}\n⏰ *Jam*: ${moment().format('HH:mm')}\n🔄 *Status*: Pending\n\n📝 *Catatan*: ${quotedMsgData.text || 'Tidak ada catatan'}\n\nPesanan @${quotedMsgData.sender.split("@")[0]} sedang diproses! 🚚`;

        if (global.gambarstore) {
            return conn.sendMessage(message.chat, { image: { url: global.gambarstore }, caption: prosesText }, { mentions: [quotedMsgData.sender] });
        } else {
            return message.reply(prosesText);
        }
    }

     // Perintah: done atau d (khusus admin/owner)
    if (command === 'done' || command === 'd') {
        const quotedMsgData = message.quoted ? message.quoted : null;
        if (!quotedMsgData) return message.reply(`❗ Reply pesanan yang selesai!`);

        // Ambil nama transaksi dari input text
        const transactionName = text ? text.trim() : 'Tidak ada';
        let suksesText = `🎉 *TRANSAKSI BERHASIL* 🎉\n\n🛍 *Nama Barang:* ${transactionName}\n📅 *Tanggal*: ${moment().format('DD-MM-YYYY')}\n⏰ *Jam*: ${moment().format('HH:mm')}\n✅ *Status*: Berhasil\n\nTerima kasih @${quotedMsgData.sender.split("@")[0]}! Ayo order lagi ya! 😊`;

        let adReply = {
            contextInfo: {
                mentionedJid: [quotedMsgData.sender],
                isForwarded: true,
                forwardingScore: 256,
                externalAdReply: {
                    title: `✅ SELESAI`,
                    body: `Jangan lupa order lagi ya!`,
                    thumbnailUrl: global.gambarstore || global.thumb,
                    sourceUrl: "120363315304652958@newsletter",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        };

        return conn.sendMessage(message.chat, {
            text: suksesText,
            ...adReply
        }, { mentions: [quotedMsgData.sender] });
    }

    // Perintah: pay, payment, pembayaran, bayar (khusus admin/owner)
    if (['pay', 'payment', 'pembayaran', 'bayar'].includes(command)) {
        const paymentText = `💸 *PAYMENT* 💸\n\n- 💳 *Dana*: ${global.dana}\n- 📱 *Gopay*: ${global.gopay || '-'}\n- 💵 *Ovo*: ${global.ovo}\n- 🏦 *Bank Lokal*: \n  ${global.banklokal}\n- 📷 *QRIS*: Scan QR di atas\n\n⚠️ Jangan lupa kirim bukti pembayaran ya! 😊`;

        if (global.urlQRIS) {
            return conn.sendMessage(message.chat, { image: { url: global.urlQRIS }, caption: paymentText });
        } else {
            return message.reply(paymentText);
        }
    }

    // Perintah: addtesti (khusus admin/owner)
    if (command === 'addtesti') {
        console.log(`Menerima perintah addtesti: ${text}, groupId: ${groupId}, mimetype: ${message.mtype}`);
        if (!text) throw `❌ *Format tidak valid*\n\n📝 *Contoh penggunaan :* \n\n> ${usedPrefix}addtesti <nama>`;

        let q = message.quoted ? message.quoted : message;
        let mimetype = (q.msg || q).mimetype || '';

        if (!mimetype.startsWith('image/')) throw `‼️ *Reply/kirim foto dengan caption ${usedPrefix}addtesti <nama>*`;

        // Ambil buffer gambar
        let media;
        try {
            media = await q.download();
        } catch (err) {
            console.error('Gagal mengunduh media:', err);
            throw `❌ Gagal mengunduh gambar! Pastikan Anda mereply/kirim gambar.`;
        }
        if (!media) throw `❌ Gagal mengunduh gambar! Pastikan Anda mereply/kirim gambar.`;

        // Buat hash dari buffer
        let hash = crypto.createHash('sha256').update(media).digest('hex');
        // Konversi buffer ke Base64
        let base64Image = media.toString('base64');

        // Simpan metadata dan Base64 ke database testimoni
        testiDatabase[groupId].testimoni[text.toLowerCase()] = {
            hash: hash,
            image: base64Image,
            caption: `Testimoni: ${text}`,
            createdAt: new Date().toISOString()
        };

        saveTestiDatabase();
        return message.reply(`✅ *Berhasil menambahkan testimoni*\n\n – Nama: ${text}\n\n> Ketik ${usedPrefix}testimoni untuk melihat daftar.`);
    }

    // Perintah: deltesti (khusus admin/owner)
    if (command === 'deltesti') {
        console.log(`Menerima perintah deltesti: ${text} untuk groupId: ${groupId}`);
        if (!testiDatabase[groupId].testimoni || Object.keys(testiDatabase[groupId].testimoni).length === 0) {
            throw `‼️ *Belum ada testimoni di grup ini*`;
        }

        // Jika tidak ada teks, tampilkan daftar testimoni dengan nomor
        if (!text) {
            const testiList = Object.keys(testiDatabase[groupId].testimoni)
                .sort()
                .map((name, index) => `${index + 1}. ${name}`)
                .join('\n');
            const instruction = `📋 *Daftar Testimoni:*\n${testiList}\n\n🗑️ *Cara Menghapus:*\n- Ketik *${usedPrefix}deltesti <nomor>* untuk hapus berdasarkan nomor.\nContoh: *${usedPrefix}deltesti 1*`;
            return message.reply(instruction);
        }

        // Validasi input sebagai nomor
        const index = parseInt(text) - 1;
        if (isNaN(index) || index < 0 || index >= Object.keys(testiDatabase[groupId].testimoni).length) {
            throw `❌ *Nomor tidak valid!* Gunakan *${usedPrefix}deltesti* untuk melihat daftar.`;
        }

        // Ambil nama testimoni berdasarkan nomor
        const testiName = Object.keys(testiDatabase[groupId].testimoni).sort()[index];
        delete testiDatabase[groupId].testimoni[testiName];
        saveTestiDatabase();
        return message.reply(`✅ *Berhasil menghapus testimoni*\n\n – Nama: ${testiName}\n\n> Telah dihapus dari daftar testimoni`);
    }

    // Perintah: testimoni atau testi (khusus admin/owner)
    if (command === 'testimoni' || command === 'testi') {
        if (!text) {
            // Tampilkan daftar testimoni
            if (!testiDatabase[groupId].testimoni || Object.keys(testiDatabase[groupId].testimoni).length === 0) {
                throw `‼️ *Belum ada testimoni di grup ini*`;
            }
            let list = Object.keys(testiDatabase[groupId].testimoni)
                .sort()
                .map(name => `– ${name}`)
                .join('\n');
            let replyText = `📸 *Daftar Testimoni:*\n\n${list}\n\n> Ketik ${usedPrefix}testimoni <nama> untuk detail.`;
            return conn.fakeReply(message.chat, replyText, '0@s.whatsapp.net', 'Testimoni Pelanggan', '17608914335-1615035634@g.us');
        } else {
            // Tampilkan detail testimoni
            let testi = testiDatabase[groupId].testimoni[text.toLowerCase()];
            if (!testi) throw `‼️ *Testimoni tidak ditemukan*`;

            // Konversi Base64 kembali ke buffer
            let buffer = Buffer.from(testi.image, 'base64');
            console.log(`Mengirim gambar testimoni: ${text}, caption: ${testi.caption}`);
            return conn.sendMessage(message.chat, { 
                image: buffer, 
                caption: testi.caption,
                contextInfo: contextInfoConfig
            });
        }
    }

    // Pencarian kata kunci (bisa diakses semua orang)
    if (text && !command) {
        const keyword = text.toLowerCase();
        const matchedTextItem = storeData.find(item => item.key.toLowerCase() === keyword);
        const matchedImageItem = imageListData[keyword];

        if (matchedTextItem) {
            return message.reply(`${matchedTextItem.response}`);
        } else if (matchedImageItem) {
            // Konversi Base64 kembali ke buffer
            let buffer = Buffer.from(matchedImageItem.image, 'base64');
            console.log(`Mengirim gambar item: ${keyword}, caption: ${matchedImageItem.caption}`);
            return conn.sendMessage(message.chat, { 
                image: buffer, 
                caption: matchedImageItem.caption
            });
        }
    }

    throw `❌ Perintah tidak dikenali! Coba lagi ya! 😅`;
};

// Handler untuk pencarian kata kunci secara langsung
handler.all = async (message, { conn }) => {
    if (!conn) {
        console.error('Error: Objek conn tidak didefinisikan di handler.all');
        return; // Tidak bisa mengirim pesan tanpa conn
    }

    const groupId = message.chat;
    if (!storeDatabase[groupId]) {
        storeDatabase[groupId] = { store: [] };
    }
    if (!testiDatabase[groupId]) {
        testiDatabase[groupId] = { testimoni: {} };
    } else if (!testiDatabase[groupId].testimoni) {
        testiDatabase[groupId].testimoni = {};
    }
    if (!imageListDatabase[groupId]) {
        imageListDatabase[groupId] = { imageList: {} };
    } else if (!imageListDatabase[groupId].imageList) {
        imageListDatabase[groupId].imageList = {};
    }
    const storeData = storeDatabase[groupId].store || [];
    const imageListData = imageListDatabase[groupId].imageList || {};

    const text = message.text?.toLowerCase() || '';
    const matchedTextItem = storeData.find(item => item.key.toLowerCase() === text);
    const matchedImageItem = imageListData[text];

    if (matchedTextItem) {
        try {
            return await message.reply(`${matchedTextItem.response}`);
        } catch (e) {
            console.error('Gagal mengirim respons teks:', e);
        }
    } else if (matchedImageItem) {
        try {
            // Konversi Base64 kembali ke buffer
            let buffer = Buffer.from(matchedImageItem.image, 'base64');
            console.log(`Mengirim gambar item: ${text}, caption: ${matchedImageItem.caption}`);
            return await conn.sendMessage(message.chat, { 
                image: buffer, 
                caption: matchedImageItem.caption
            });
        } catch (e) {
            console.error('Gagal mengirim gambar:', e);
        }
    }
};

// Konfigurasi handler
handler.help = ['list', 'addlist', 'dellist', 'editlist', 'pay', 'proses', 'done', 'addtesti <nama>', 'deltesti [nomor]', 'testimoni [nama]', 'testi [nama]'];
handler.tags = ['store'];
handler.command = /^list|addlist|dellist|editlist|pay|proses|done|payment|pembayaran|bayar|addtesti|deltesti|testimoni|testi$/i;
handler.group = true; // Hanya bisa digunakan di grup

module.exports = handler;