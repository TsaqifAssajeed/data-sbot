const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

let handler = async (m, { conn }) => {
    const performOCR = async (imagePath) => {
        try {
            let form = new FormData();
            form.append('apikey', 'K81241004488957');
            form.append('file', fs.createReadStream(imagePath));
            form.append('language', 'eng');

            let response = await axios.post('https://api.ocr.space/parse/image', form, {
                headers: form.getHeaders(),
            });

            if (response.data.OCRExitCode !== 1) {
                throw new Error('Gagal melakukan OCR, periksa gambar atau API key.');
            }

            const resultText = response.data.ParsedResults[0]?.ParsedText || 'Tidak ada teks yang terdeteksi.';
            return resultText;

        } catch (error) {
            console.error('Terjadi kesalahan:', error);
            throw error;
        }
    };

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!mime) throw `Balas gambar dengan perintah .ocr`;
    if (!/image\/(jpe?g|png)/.test(mime)) throw `_*Jenis ${mime} tidak didukung!*_`;

    try {
        let img = await q.download();
        if (!img) throw `Gambar gagal diunduh!`;

        let tempPath = './tmp/temp_image.jpg';
        fs.writeFileSync(tempPath, img);

        let textResult = await performOCR(tempPath);
        console.log('Hasil OCR:', textResult);

        await m.reply(textResult);

        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error(err);
        throw `Terjadi kesalahan: ${err.message || err}`;
    }
};

handler.help = ['ocr', 'totext'];
handler.tags = ['tools','premium'];
handler.command = /^(ocr|totext)$/i;
handler.limit = true;
handler.premium = true;

module.exports = handler;