let handler = async (m, { conn }) => {
    conn.tebakbendera2 = conn.tebakbendera2 ? conn.tebakbendera2 : {}
    let id = m.chat
    if (!(id in conn.tebakbendera2)) {
        m.reply('❌ Tidak ada soal yang sedang berjalan di chat ini!')
        return
    }
    let jawaban = conn.tebakbendera2[id].jawaban
    let clue = jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_')
    m.reply('💡 Petunjuk nih: ```' + clue + '```')
}
handler.command = /^teii/i
handler.limit = true
module.exports = handler