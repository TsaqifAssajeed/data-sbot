// ✨ Plugin maker - carbon ✨

const fetch = require('node-fetch');
const express = require('express');

// START Proxy Server Internal (otomatis jalan bareng bot)
const PORT = 3000;
require('../settings.js'); // pastikan path benar, sesuaikan lokasi settings.js kamu
const app = express();
app.use(express.json());

app.post('/carbon', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ status: false, message: 'No text provided' });

    const url = `https://api.botcahx.eu.org/api/maker/carbon?text=${encodeURIComponent(text)}&apikey=${global.btc}`;
    const result = await fetch(url).then(r => r.json());

    if (!result.status || !result.result) {
      return res.status(500).json({ status: false, message: result.message || 'Carbon API failed' });
    }

    res.json({ status: true, result: result.result });
  } catch (err) {
    console.error('[Carbon Proxy Error]', err);
    res.status(500).json({ status: false, message: 'Internal proxy error' });
  }
});

app.listen(PORT, () => console.log(`✅ Internal Carbon Proxy aktif di http://localhost:${PORT}`));
// END Proxy Server

// Plugin handler untuk command .carbon
let handler = async (m, { conn, args }) => {
  let text = args.length ? args.join(' ') : m.quoted?.text;
  if (!text) throw '❗ Masukkan teks atau balas pesan yang berisi teks!';

  try {
    m.reply('⏳ Membuat carbon...');

    const res = await fetch('http://localhost:3000/carbon', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });

    const json = await res.json();

    if (!json.status || !json.result) throw json.message || 'Gagal membuat carbon.';

    await conn.sendFile(m.chat, json.result, 'carbon.jpg', '', m);
  } catch (e) {
    console.error('[Carbon Error]', e);
    throw '❌ Gagal membuat carbon. Coba lagi nanti.';
  }
};

handler.help = ['carbon'];
handler.tags = ['maker', 'premium'];
handler.command = /^(carbon|carbonara)$/i;
handler.limit = true;
handler.premium = true;

module.exports = handler;