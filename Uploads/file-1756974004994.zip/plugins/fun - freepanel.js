let handler = async (m, { conn, text }) => {
    const pushname = m.pushName || "Kawan"; // Nama pengguna

      // ✅ Respon untuk freepanel
     if (/freepanel|.freepanel|getpanel|panelgratis|panel/i.test(m.text)) {
        const panelInfo = `*Data Akun Panel Kamu 📦*

*📡 ID Server (1)* 
*👤 Username :* jagpro
*🔐 Password :* jagpro123

*🌐 Spesifikasi Server*
* Ram : Unlimited
* Disk : Unlimited
* CPU : Unlimited
* Kami menggunakan Aplikasi, Silahkan Downlaod dan install :
https://jagoanproject.free.nf/?i=1

*Syarat & Ketentuan :*
* Jangan Pakai DDOS
* Simpan data ini sebaik mungkin
* Giveaway adalah milik bersama, jangan rusuh
* Claim garansi wajib membawa bukti chat pembelian, *tanpa bukti teks ini, tidak bisa klaim garansi* JADI TOLONG DI SIMPAN..!!`;
        await conn.sendMessage(m.chat, { text: panelInfo }, { quoted: m });
    }
};

handler.customPrefix = /^(freepanel|getpanel|panelgratis|bagi panel|free panel|panel)$/i;
handler.command = new RegExp;
handler.fail = null;

module.exports = handler;
