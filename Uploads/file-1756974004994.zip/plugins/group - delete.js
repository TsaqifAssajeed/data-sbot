const store = {}; // In-memory store untuk menyimpan metadata pesan

// Save message to store
async function saveMessageToStore(message) {
    const messageData = {
        id: message.key.id,
        chat: message.key.remoteJid,
        sender: message.key.participant || message.key.remoteJid,
        fromMe: message.key.fromMe,
        timestamp: message.messageTimestamp
    };
    store[message.key.id] = messageData; // Simpan ke store dengan ID pesan sebagai kunci
}

// Read message from store
async function readMessageFromStore(messageId) {
    return store[messageId] || null; // Ambil data dari store atau kembalikan null jika tidak ada
}

// Delete message from store after deletion
async function deleteMessageFromStore(messageId) {
    delete store[messageId]; // Hapus data dari store
}

let handler = async function (m, { conn, command, isReaction = false, reaction = null }) {
    // Save every incoming message to store (only for group chats)
    if (m.isGroup && !isReaction) {
        await saveMessageToStore(m);
    }

    let messageToDelete;

    // Handle reply-based deletion
    if (!isReaction) {
        if (!m.quoted) throw `*• Example:* .delete *[reply to message]*`;
        messageToDelete = m.quoted;
    } else {
        // Handle reaction-based deletion
        if (reaction?.emoji !== '❌') return; // Only proceed if reaction is ❌
        const storedMessage = await readMessageFromStore(m.id);
        if (!storedMessage) return conn.reply(m.chat, '🚩 Pesan tidak ditemukan di database!', m);
        messageToDelete = {
            chat: storedMessage.chat,
            id: storedMessage.id,
            sender: storedMessage.sender
        };
    }

    if (!m.isGroup) return conn.reply(m.chat, '🚩 Perintah ini hanya dapat digunakan di dalam grup!', m);

    // Get group metadata to check admin status
    let groupMetadata;
    try {
        groupMetadata = conn.chats[m.chat]?.metadata || await conn.groupMetadata(m.chat);
    } catch (error) {
        console.error('Error fetching group metadata:', error);
        return conn.reply(m.chat, '🚩 Gagal mendapatkan metadata grup!', m);
    }

    // Normalize participants to ensure jid is available
    const participants = groupMetadata.participants?.map(p => ({
        id: p.id,
        jid: p.jid || (p.lid && conn.decodeJid(p.lid, groupMetadata)) || conn.decodeJid(p.id, groupMetadata),
        lid: p.lid || p.id,
        admin: p.admin || null
    })) || [];

    // Find bot and user
    const botNumber = conn.user.jid;
    const botParticipant = participants.find(p => (
        p.jid === botNumber ||
        p.lid === botNumber ||
        p.id === botNumber ||
        conn.decodeJid(p.jid, groupMetadata) === botNumber ||
        conn.decodeJid(p.id, groupMetadata) === botNumber
    ));
    const userParticipant = participants.find(p => (
        p.jid === m.sender ||
        p.lid === m.sender ||
        p.id === m.sender ||
        conn.decodeJid(p.jid, groupMetadata) === m.sender ||
        conn.decodeJid(p.id, groupMetadata) === m.sender
    ));

    const isAdmin = participant => participant?.admin === 'admin' || participant?.admin === 'superadmin';
    const isBotAdmin = isAdmin(botParticipant);
    const isUserAdmin = isAdmin(userParticipant);
    const isOwner = global.owner.some(([number]) => number === m.sender.split('@')[0]);

    // Debugging
    console.log('Debug: Bot JID:', botNumber);
    console.log('Debug: Participants:', participants);
    console.log('Debug: Bot Participant:', botParticipant);
    console.log('Debug: isBotAdmin:', isBotAdmin);

    // Check if bot is admin
    if (!isBotAdmin) {
        global.dfail('botAdmin', m, conn);
        return conn.reply(m.chat, '🚩 Bot bukan admin!', m);
    }

    // Check if user is admin or owner
    if (!isUserAdmin && !isOwner) {
        global.dfail('admin', m, conn);
        return conn.reply(m.chat, '🚩 Kamu bukan admin grup atau owner!', m);
    }

    // Ensure messageToDelete.sender is a valid JID
    const senderJid = conn.decodeJid(messageToDelete.sender, groupMetadata);
    if (!senderJid.endsWith('@s.whatsapp.net')) {
        return conn.reply(m.chat, `🚩 ID ${senderJid} tidak valid untuk dihapus (bukan JID)!`, m);
    }

    // Delete the message
    try {
        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: messageToDelete.chat,
                fromMe: messageToDelete.sender === conn.user.jid,
                id: messageToDelete.id,
                participant: senderJid
            }
        });
        await conn.reply(m.chat, '[ Status Delete ] : Berhasil menghapus pesan!', m);
    } catch (e) {
        console.error('Error deleting message:', e);
        await conn.reply(m.chat, `🚩 Gagal menghapus pesan: ${e.message}`, m);
    }

    // Remove the message from store after deletion
    if (isReaction) {
        await deleteMessageFromStore(m.id);
    }
};

// Reaction handler
handler.onReaction = async (reaction, conn) => {
    if (!reaction.isGroup) return;
    await handler(reaction, { conn, isReaction: true, reaction });
};

handler.help = ['del *<reply>*', 'delete *<reply>*', 'React with ❌ to delete'];
handler.tags = ['tools'];
handler.command = /^del(ete)?$/i;
handler.limit = false;
handler.group = true;
handler.botAdmin = true;

module.exports = handler;