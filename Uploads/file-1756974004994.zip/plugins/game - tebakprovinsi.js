let soalProvinsi = [
   { soal: "Provinsi ini memiliki Rumah Gadang sebagai rumah adatnya", jawaban: "sumatera barat" },
  { soal: "Provinsi ini dikenal dengan tradisi Tabuik", jawaban: "sumatera barat" },
  { soal: "Salah satu kuliner khas provinsi ini adalah Bika Ambon", jawaban: "sumatera utara" },
  { soal: "Provinsi ini memiliki Danau Maninjau dan Ngarai Sianok", jawaban: "sumatera barat" },
  { soal: "Provinsi ini dikenal dengan tari Saman", jawaban: "aceh" },
  { soal: "Provinsi ini memiliki Banda Neira sebagai lokasi bersejarah rempah-rempah", jawaban: "maluku" },
  { soal: "Provinsi ini memiliki tradisi perang Pasola", jawaban: "nusa tenggara timur" },
  { soal: "Provinsi ini memiliki gunung berapi aktif tertinggi di Indonesia, Gunung Kerinci", jawaban: "jambi" },
  { soal: "Provinsi ini memiliki kota Sabang, titik paling barat Indonesia", jawaban: "aceh" },
  { soal: "Provinsi ini terkenal dengan alat musik angklung", jawaban: "jawa barat" },
  { soal: "Taman Nasional Komodo berada di provinsi ini", jawaban: "nusa tenggara timur" },
  { soal: "Provinsi ini memiliki tradisi Ngaben", jawaban: "bali" },
  { soal: "Provinsi ini dikenal dengan Tari Piring dan Randai", jawaban: "sumatera barat" },
  { soal: "Provinsi ini memiliki kain tenun khas bernama Songket Palembang", jawaban: "sumatera selatan" },
  { soal: "Provinsi ini memiliki Festival Lembah Baliem", jawaban: "papua pegunungan" },
  { soal: "Provinsi ini dikenal dengan wisata Raja Ampat", jawaban: "papua barat daya" },
  { soal: "Provinsi ini memiliki makanan khas Pempek", jawaban: "sumatera selatan" },
  { soal: "Provinsi ini dikenal dengan wisata Danau Sentani", jawaban: "papua" },
  { soal: "Ibu kotanya adalah Gorontalo dan memiliki Danau Limboto", jawaban: "gorontalo" },
  { soal: "Provinsi ini memiliki Festival Krakatau dan Tari Melinting", jawaban: "lampung" },
  { soal: "Provinsi ini memiliki tradisi Sekaten dan keraton", jawaban: "yogyakarta" },
  { soal: "Provinsi ini memiliki wisata Kawah Ijen dan api biru", jawaban: "jawa timur" },
  { soal: "Provinsi ini memiliki rumah adat Tongkonan", jawaban: "sulawesi selatan" },
  { soal: "Provinsi ini terkenal dengan kopi Toraja", jawaban: "sulawesi selatan" },
  { soal: "Provinsi ini memiliki kota Samarinda dan Sungai Mahakam", jawaban: "kalimantan timur" },
  { soal: "Provinsi ini terkenal dengan budaya Betawi", jawaban: "dki jakarta" },
  { soal: "Provinsi ini memiliki suku Osing dan Banyuwangi Festival", jawaban: "jawa timur" },
  { soal: "Provinsi ini memiliki kain batik Pekalongan dan Lasem", jawaban: "jawa tengah" },
  { soal: "Provinsi ini memiliki Gunung Rinjani dan tradisi Bau Nyale", jawaban: "nusa tenggara barat" },
  { soal: "Provinsi ini memiliki rumah adat Sao Ria Temo dan istana Raja Sikka", jawaban: "nusa tenggara timur" },
  { soal: "Provinsi ini memiliki suku Baduy dan kampung adat Kanekes", jawaban: "banten" },
  { soal: "Provinsi ini dikenal dengan Danau Tondano dan Bunaken", jawaban: "sulawesi utara" },
  { soal: "Provinsi ini memiliki Benteng Fort Rotterdam dan Pantai Losari", jawaban: "sulawesi selatan" },
  { soal: "Provinsi ini terkenal dengan rumah adat Banjar dan pasar terapung", jawaban: "kalimantan selatan" },
  { soal: "Provinsi ini memiliki upacara adat Naik Dango dari suku Dayak", jawaban: "kalimantan barat" },
  { soal: "Provinsi ini punya makanan khas Ayam Cincane", jawaban: "kalimantan timur" },
  { soal: "Provinsi ini memiliki Pulau Derawan dan Kepulauan Maratua", jawaban: "kalimantan timur" },
  { soal: "Provinsi ini punya situs megalitikum di Lore Lindu", jawaban: "sulawesi tengah" },
  { soal: "Provinsi ini dikenal dengan Monumen Mandala dan Pantai Losari", jawaban: "sulawesi selatan" },
  { soal: "Provinsi ini memiliki kampung warna-warni Jodipan dan Gunung Bromo", jawaban: "jawa timur" },
  { soal: "Provinsi ini dikenal dengan museum Sangiran, situs manusia purba", jawaban: "jawa tengah" },
  { soal: "Provinsi ini memiliki makanan khas Lempuk Durian", jawaban: "bengkulu" },
  { soal: "Provinsi ini dikenal dengan rumah panggung Limas dan Sungai Musi", jawaban: "sumatera selatan" },
  { soal: "Provinsi ini memiliki tradisi lompat batu di Nias", jawaban: "sumatera utara" },
  { soal: "Provinsi ini terkenal dengan Festival Danau Sentarum", jawaban: "kalimantan barat" },
  { soal: "Provinsi ini memiliki Bukit Kelam dan Sungai Kapuas", jawaban: "kalimantan barat" },
  { soal: "Provinsi ini memiliki Sungai Batanghari dan Masjid Agung Jambi", jawaban: "jambi" },
  { soal: "Provinsi ini dikenal dengan Candi Muaro Jambi", jawaban: "jambi" },
  { soal: "Provinsi ini memiliki Pulau Weh dan Masjid Raya Baiturrahman", jawaban: "aceh" },
  { soal: "Provinsi ini dikenal dengan Benteng Belgica dan suku Alifuru", jawaban: "maluku" },
  { soal: "Provinsi ini memiliki Gunung Gamalama dan rempah Ternate-Tidore", jawaban: "maluku utara" },
  { soal: "Provinsi ini memiliki Lembah Harau dan Istano Basa Pagaruyung", jawaban: "sumatera barat" },
  { soal: "Provinsi ini punya pulau eksotis seperti Kei dan Tanimbar", jawaban: "maluku" },
  { soal: "Provinsi ini punya keraton dan pantai Parangtritis", jawaban: "yogyakarta" },
  { soal: "Provinsi ini memiliki Danau Tempe dan sagu sebagai makanan pokok", jawaban: "sulawesi selatan" },
  { soal: "Provinsi ini dikenal dengan wisata Labuan Bajo", jawaban: "nusa tenggara timur" },
  { soal: "Provinsi ini punya pasar terapung Lok Baintan", jawaban: "kalimantan selatan" },
  { soal: "Provinsi ini memiliki Tugu Khatulistiwa dan budaya Dayak", jawaban: "kalimantan barat" },
  { soal: "Provinsi ini terkenal dengan tari Zapin dan Gurindam 12", jawaban: "kepulauan riau" },
  { soal: "Provinsi ini dikenal dengan pulau Belitung dan pantainya yang eksotis", jawaban: "kepulauan bangka belitung" },
  { soal: "Provinsi ini dikenal dengan Keraton Kesultanan Ternate dan rempah pala", jawaban: "maluku utara" },
{ soal: "Provinsi ini punya tradisi Ma’Nene di Tana Toraja", jawaban: "sulawesi selatan" },
{ soal: "Provinsi ini punya makanan khas Tinutuan (bubur manado)", jawaban: "sulawesi utara" },
{ soal: "Provinsi ini memiliki Benteng Otanaha dan Danau Limboto", jawaban: "gorontalo" },
{ soal: "Provinsi ini punya tradisi Mapalus dan upacara Tulude", jawaban: "sulawesi utara" },
{ soal: "Provinsi ini terkenal dengan Festival Danau Toba", jawaban: "sumatera utara" },
{ soal: "Provinsi ini punya Pantai Tanjung Tinggi dan Laskar Pelangi", jawaban: "kepulauan bangka belitung" },
{ soal: "Provinsi ini dikenal sebagai penghasil lada putih", jawaban: "kepulauan bangka belitung" },
{ soal: "Provinsi ini memiliki keraton Kesultanan Siak", jawaban: "riau" },
{ soal: "Provinsi ini terkenal dengan pantun Melayu dan Sungai Siak", jawaban: "riau" },
{ soal: "Provinsi ini memiliki Gunung Dempo dan Air Terjun Lematang", jawaban: "sumatera selatan" },
{ soal: "Provinsi ini memiliki Danau Ranau dan Gunung Seminung", jawaban: "lampung" },
{ soal: "Provinsi ini memiliki tradisi Megalitik di Lembah Bada", jawaban: "sulawesi tengah" },
{ soal: "Provinsi ini dikenal dengan tari Cakalele dan rumah Baileo", jawaban: "maluku" },
{ soal: "Provinsi ini punya Taman Nasional Wakatobi", jawaban: "sulawesi tenggara" },
{ soal: "Provinsi ini punya suku Tolaki dan kuliner Sinonggi", jawaban: "sulawesi tenggara" },
{ soal: "Provinsi ini dikenal dengan Danau Matano dan tambang nikel", jawaban: "sulawesi selatan" },
{ soal: "Provinsi ini memiliki kain tradisional bernama Tenun Ikat Sumba", jawaban: "nusa tenggara timur" },
{ soal: "Provinsi ini punya festival Bau Nyale dan Pantai Senggigi", jawaban: "nusa tenggara barat" },
{ soal: "Provinsi ini memiliki Gunung Tambora dan Sumbawa", jawaban: "nusa tenggara barat" },
{ soal: "Provinsi ini punya hutan tropis Leuser", jawaban: "aceh" },
{ soal: "Provinsi ini dikenal dengan istilah 'Serambi Mekah'", jawaban: "aceh" },
{ soal: "Provinsi ini punya Candi Muara Takus", jawaban: "riau" },
{ soal: "Provinsi ini memiliki tradisi Guel dan rumah adat Aceh", jawaban: "aceh" },
{ soal: "Provinsi ini dikenal dengan Taman Nasional Kerinci Seblat", jawaban: "jambi" },
{ soal: "Provinsi ini memiliki Benteng Kuto Besak dan Pulau Kemaro", jawaban: "sumatera selatan" },
{ soal: "Provinsi ini memiliki pantai Widarapayung dan Batik Besurek", jawaban: "bengkulu" },
{ soal: "Provinsi ini memiliki Pantai Panjang dan Monumen Thomas Parr", jawaban: "bengkulu" },
{ soal: "Provinsi ini punya pulau Natuna dan Tambelan", jawaban: "kepulauan riau" },
{ soal: "Provinsi ini punya suku Laut dan budaya Melayu yang kental", jawaban: "kepulauan riau" },
{ soal: "Provinsi ini punya upacara adat Seren Taun dan tradisi angklung", jawaban: "jawa barat" },
{ soal: "Provinsi ini dikenal dengan Tari Topeng Cirebon dan Batik Mega Mendung", jawaban: "jawa barat" },
{ soal: "Provinsi ini memiliki Batik Solo dan kuliner Selat Solo", jawaban: "jawa tengah" },
{ soal: "Provinsi ini terkenal dengan nasi liwet dan keraton Kasunanan", jawaban: "jawa tengah" },
{ soal: "Provinsi ini memiliki Gunung Merapi dan Candi Prambanan", jawaban: "yogyakarta" },
{ soal: "Provinsi ini punya tradisi Sekaten dan Abdi Dalem", jawaban: "yogyakarta" },
{ soal: "Provinsi ini memiliki rumah adat Joglo dan batik khas Pekalongan", jawaban: "jawa tengah" },
{ soal: "Provinsi ini dikenal dengan Gunung Semeru dan Reog Ponorogo", jawaban: "jawa timur" },
{ soal: "Provinsi ini punya makanan khas rujak cingur dan rawon", jawaban: "jawa timur" },
{ soal: "Provinsi ini punya Gunung Bromo dan Kawah Ijen", jawaban: "jawa timur" },
{ soal: "Provinsi ini punya tradisi Karapan Sapi dan Batik Madura", jawaban: "jawa timur" },
{ soal: "Provinsi ini dikenal dengan Bandara Kertajati dan Situ Patenggang", jawaban: "jawa barat" },
{ soal: "Provinsi ini memiliki Pantai Pangandaran dan Nasi Tutug Oncom", jawaban: "jawa barat" },
{ soal: "Provinsi ini punya Festival Tabuik dan Jam Gadang", jawaban: "sumatera barat" },
{ soal: "Provinsi ini memiliki tradisi Pacu Jawi", jawaban: "sumatera barat" },
{ soal: "Provinsi ini dikenal dengan Tari Piring dan Rumah Gadang", jawaban: "sumatera barat" },
{ soal: "Provinsi ini memiliki hutan lindung Bukit Duabelas dan suku Anak Dalam", jawaban: "jambi" },
{ soal: "Provinsi ini punya Pantai Lampuuk dan Tari Saman", jawaban: "aceh" },
{ soal: "Provinsi ini punya ritual adat Bakar Batu", jawaban: "papua" },
{ soal: "Provinsi ini memiliki rumah Honai dan Pegunungan Jayawijaya", jawaban: "papua" },
{ soal: "Provinsi ini punya Danau Sentani dan tradisi Fouw", jawaban: "papua" },
{ soal: "Provinsi ini dikenal dengan Taman Nasional Lorentz", jawaban: "papua" },
{ soal: "Provinsi ini memiliki Danau Paniai dan tradisi suku Mee", jawaban: "papua tengah" },
{ soal: "Provinsi ini memiliki Pegunungan Arfak dan Kota Manokwari", jawaban: "papua barat" },
{ soal: "Provinsi ini dikenal dengan Suku Moi dan pantai Sorong", jawaban: "papua barat daya" },
{ soal: "Provinsi ini memiliki Teluk Cenderawasih dan hiu paus", jawaban: "papua barat" },
{ soal: "Provinsi ini memiliki Raja Ampat, surga bawah laut Indonesia", jawaban: "papua barat" },
{ soal: "Provinsi ini memiliki Bukit Teletubbies di NTT", jawaban: "nusa tenggara timur" },
{ soal: "Provinsi ini dikenal dengan suku Sasak dan Gunung Rinjani", jawaban: "nusa tenggara barat" },
{ soal: "Provinsi ini memiliki kampung adat Wae Rebo dan Komodo", jawaban: "nusa tenggara timur" }
]

let sesiTebak = {}

const timeout = 60000 // ubah waktu disini!!

let handler = async (m, { conn, command }) => {
  let id = m.chat
  switch (command) {
    case 'tebakprovinsi':
      if (sesiTebak[id]) return conn.reply(m.chat, '🤬 Masih ada soal yang belum dijawab!!\n\n> ketik .skip untuk menyerah!!', m)

      let data = soalProvinsi[Math.floor(Math.random() * soalProvinsi.length)]
      let kirim = await conn.sendMessage(m.chat, {
        text: `🎮 *TEBAK PROVINSI* 🎮\n\n📜 Soal : ${data.soal}\n⏰ Waktu : 60 detik\n\n‼️Reply chat ini untuk menjawab!!\n\n> *.skip* jika ingin menyerah.`,
      })

      sesiTebak[id] = {
        jawaban: data.jawaban.toLowerCase(),
        idPesan: kirim.key.id,
        timeout: setTimeout(() => {
          if (sesiTebak[id]) {
            conn.sendMessage(m.chat, { text: `⏰ Waktu habis!\n\nJawabannya adalah :\n *${data.jawaban}*` })
            delete sesiTebak[id]
          }
        }, timeout)
      }
      break

    case 'skip':
      if (!sesiTebak[id]) return conn.reply(m.chat, '❌ Tidak ada sesi tebakan yang aktif.', m)
      clearTimeout(sesiTebak[id].timeout)
      await conn.sendMessage(m.chat, { text: `🏳️ *MENYERAH!!*\n\nJawabannya adalah :\n *${sesiTebak[id].jawaban}*` })
      delete sesiTebak[id]
      break
  }
}

handler.before = async function (m, { conn }) {
  let id = m.chat
  if (!sesiTebak[id]) return
  if (!m.quoted || m.quoted.id !== sesiTebak[id].idPesan) return

  let jawaban = sesiTebak[id].jawaban
  if (m.text.toLowerCase() === jawaban) {
    clearTimeout(sesiTebak[id].timeout)
    let hadiah = Math.floor(Math.random() * 501) + 500 // 500 - 1000
    let user = global.db.data.users[m.sender]
    if (user) user.money = (user.money || 0) + hadiah
    await conn.reply(m.chat, `✅ Jawaban kamu benar!\n\n📝 Jawaban : *${jawaban}*\n🎁 Hadiah : ${hadiah} money`, m)
    delete sesiTebak[id]
  } else {
    conn.reply(m.chat, `❌ Jawaban kamu salah, coba lagi..`, m)
  }
}

handler.command = /^tebakprovinsi|skip$/i
handler.tags = ['game']
handler.help = ['tebakprovinsi', 'skip']
handler.limit = false
handler.register = true

module.exports = handler