let fs = require('fs')
let handler = m => m

handler.all = async function (m, { isBlocked }) {
    if (isBlocked) return
    if ((m.mtype === 'groupInviteMessage' || m.text.startsWith('Undangan untuk bergabung') || m.text.startsWith('Invitation to join') || m.text.startsWith('Buka tautan ini')) && !m.isBaileys && !m.isGroup) {
    let teks = `Invite bot ke Group?
╔═════════════════❑
║     🤖 *LIST SEWA JAGOAN PROJECT* 🤖
╟─────────────────
 📅  1 Minggu : Rp.10.000
 📅  2 Minggu : Rp.15.000
 📅  1 Bulan  : Rp.20.000
 📅  2 Bulan  : Rp.30.000
═══════════════════❏
🛠️ *Sewa bot bisa memasukkan bot ke grup dan mendapatkan premium sehingga bisa mengakses fitur premium di bot.*

📲 *Pembayaran?*
- Hanya Menerima *Dana:* ${dana}

Jika berminat hubungi: @${global.nomorown[0]} untuk order:)
`
    this.reply(m.chat, teks, m)
    const data = global.nomorown.filter(([id, isCreator]) => id && isCreator)
    this.sendContact(m.chat, data.map(([id, name]) => [id, name]), m)
    }
}

module.exports = handler