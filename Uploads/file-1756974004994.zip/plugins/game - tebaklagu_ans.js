let handler = m => m

handler.before = async function (m, { conn }) {
    if (!m.text || m.isBaileys || m.fromMe) return // Abaikan pesan bot dan media

    conn.game = conn.game || {}
    let id = 'tebaklagu-' + m.chat
    if (!(id in conn.game)) return

    let [msg, json, poin, timer] = conn.game[id]

    // Pastikan pesan bukan dari bot
    if (m.quoted && m.quoted.fromMe) return

    // Jawaban benar
    if (m.text.toLowerCase() === json.judul.toLowerCase()) {
        clearTimeout(timer)
        await conn.reply(m.chat, `✅ Jawaban benar!!\n\n🫅🏻 user : @${m.sender.split('@')[0]}\n🎉 hadiah : +${poin} XP`, msg, {
            mentions: [m.sender]
        })
        delete conn.game[id]
    } 
    // Jawaban salah
    else if (m.text.length <= 100 && !m.quoted) {
        await conn.reply(m.chat, `❌ Salah dek, coba lagi.`, m)
    }
}

module.exports = handler