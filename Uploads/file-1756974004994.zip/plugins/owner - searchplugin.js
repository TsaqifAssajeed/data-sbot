// JANGAN LU SHARE KE ORANG LAIN YAA ANJG!! APALAGI LU JUAL 😡
// WM : PUNYA ANDICK 😝
// JANGAN HAPUS WM BANG :V
// PANEL MURAH BERKUALITAS? SPEK DEWA? JAGPRO AJA BANG 🚀

const fs = require('fs');
const path = require('path');

let handler = async (m, { args, usedPrefix, command }) => {
  if (!args[0]) {
    return m.reply(`📌 Contoh penggunaan :\n\n${usedPrefix + command} play\n${usedPrefix + command} menu`);
  }

  const keyword = args[0].replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
  const pluginFolder = __dirname;
  const files = fs.readdirSync(pluginFolder).filter(file => file.endsWith('.js') && file !== __filename.split('/').pop());

  let found = [];

  for (const file of files) {
    try {
      const pluginPath = path.join(pluginFolder, file);
      const plugin = require(pluginPath);

      let cmds = [];

      // Ambil command
      if (typeof plugin.command === 'string') {
        cmds.push(plugin.command.toLowerCase());
      } else if (Array.isArray(plugin.command)) {
        cmds.push(...plugin.command.map(cmd => cmd.toLowerCase()));
      } else if (plugin.command instanceof RegExp) {
        const regexCmd = plugin.command.source
          .replace(/^\^/, '')
          .replace(/\$$/, '')
          .toLowerCase();
        cmds.push(regexCmd);
      }

      // Cek keyword cocok dengan salah satu command (pakai includes biar fleksibel)
      if (cmds.some(cmd => cmd.includes(keyword))) {
        found.push(`📁 ${file.replace(/\.js$/, '')}`);
      }
    } catch (err) {
      console.log(`😔 Gagal load plugin ${file}:`, err.message);
    }
  }

  if (found.length === 0) {
    return m.reply(`❌ Plugin command *${keyword}* tidak ditemukan`);
  }

  m.reply(`✅ Plugin command *${keyword}* ditemukan :\n\n${found.join('\n')}`);
};

handler.help = ['srchp <command>'];
handler.tags = ['owner'];
handler.command = /^srchp$/i;
handler.owner = true;

module.exports = handler;