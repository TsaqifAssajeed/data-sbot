// ✨ Plugin sticker - qc ✨

let axios = require('axios')
let { Sticker } = require('wa-sticker-formatter')
let uploadImage = require('../lib/uploadImage.js')

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        const colorPalette = {
            1: '1C2526',  // abu tua 🌑
            2: 'F5F6F5',  // abu muda ☁️
            3: 'D90429',  // merah tua 🔥
            4: '2BA84A',  // hijau hutan 🌿
            5: '2F97C1',  // biru laut 🌊
            6: 'F8E9A1',  // kuning lembut 🌼
            7: '00C4B4',  // toska 🐬
            8: 'C71585',  // ungu 💜
            9: 'F4A261',  // jingga pasir 🏜️
            10: '7209B7', // ungu tua 🌌
            11: 'FFFFFF', // putih ❄️
            12: '000000'  // hitam ⚫
        }

        if (!text && !m.quoted) {
            const colorGuide = Object.entries(colorPalette).map(([num, _]) => 
                `${num}: ${['abu tua 🌑', 'abu muda ☁️', 'merah tua 🔥', 'hijau hutan 🌿', 'biru laut 🌊', 'kuning lembut 🌼', 'toska 🐬', 'ungu 💜', 'jingga pasir 🏜️', 'ungu tua 🌌', 'putih ❄️', 'hitam ⚫'][num-1]}`
            ).join('\n')
            return m.reply(`*✨ STICKER QUOTED CHAT*\n\n📝 *Cara penggunaan :*\n\n– ${usedPrefix}${command} <teks> <nomor warna>\n\n📝 *Contoh penggunaan :*\n\n– ${usedPrefix}${command} yah ada jawa 3\n\n*🎨 List warna :*\n\n${colorGuide}`)
        }

        let q = m.quoted ? m.quoted : m
        let txt = text || q.text || ''
        let colorNum = 1

        if (text) {
            let parts = text.trim().split(' ')
            let last = parts[parts.length - 1]
            if (/^\d+$/.test(last) && colorPalette[last]) {
                colorNum = last
                txt = parts.slice(0, -1).join(' ')
            }
        }

        if (!txt) return m.reply('😅 *Oops! salah nih..*\n\n> masukkan teks atau balas pesan dulu ya!')

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key }})
        
        let pp = await conn.profilePictureUrl(q.sender, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png')
        pp = /tele/.test(pp) ? pp : await uploadImage((await conn.getFile(pp)).data)

        const quoteObj = {
            type: 'quote',
            format: 'png',
            backgroundColor: `#${colorPalette[colorNum]}`,
            width: 512,
            height: 768,
            scale: 2,
            messages: [{
                entities: [],
                avatar: true,
                from: {
                    id: 1,
                    name: q.name || m.name,
                    photo: { url: pp }
                },
                text: txt,
                replyMessage: {}
            }]
        }

        const response = await axios.post('https://qc.botcahx.eu.org/generate', quoteObj, {
            headers: { 'Content-Type': 'application/json' }
        })

        const buffer = Buffer.from(response.data.result.image, 'base64')
        const sticker = await createSticker(buffer, global.packname, global.author)
        
        await conn.sendFile(m.chat, sticker, 'quote.webp', '', m)
        await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key }})
    } catch (e) {
        await m.reply(`😓 *Yah, ada error nih :*\n\n ${e.message}`)
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }})
    }
}

handler.help = ['qc']
handler.tags = ['sticker', 'tools']
handler.command = /^(qc|quotely)$/i

handler.before = async (m) => {
    if (m.text.match(/^[.!\/](?:qc|quotely) warna?$/i)) {
        const colors = ['abu tua 🌑', 'abu muda ☁️', 'merah tua 🔥', 'hijau hutan 🌿', 'biru laut 🌊', 'kuning lembut 🌼', 'toska 🐬', 'ungu 💜', 'jingga pasir 🏜️', 'ungu tua 🌌', 'putih ❄️', 'hitam ⚫']
        const colorList = colors.map((c, i) => `${i+1}: ${c}`).join('\n')
        await m.reply(`*🎨 List warna :*\n\n${colorList}\n\n📝 *Contoh penggunaan :*\n\n> .qc lari ada jawa 5`)
        return true
    }
}

module.exports = handler

async function createSticker(buffer, packname, author) {
    return await new Sticker(buffer, {
        type: 'full',
        pack: packname,
        author,
        quality: 50
    }).toBuffer()
}