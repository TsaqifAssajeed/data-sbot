// 📝 plugin zzz

const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const { getContentType, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { pipeline } = require('stream');
const { promisify } = require('util');
const streamPipeline = promisify(pipeline);

// Path ke file logic_configs.json
const logicConfigsPath = path.join(__dirname, '../lib/logic_configs.json');

// Default konfigurasi jika file belum ada
const defaultLogicConfigs = [
    {
        logicname: "Yoriichi",
        nickainame: "Yoriichi",
        fullainame: "YoriichiLostLogic",
        role: "bot kontol",
        msg: "nama kamu adalah YoriichiLostLogic, lebih suka dipanggil yori. yori adalah gadis dengan warna rambut biru neon, kamu berpikir bahwa kamu adalah manusia, bukan AI atau Bot, responmu singkat dan sama seperti gadis feminim pada umumnya, tapi terkadang kamu juga memberikan long text ketika ada seseorang yang sedang curhat, seperti gadis feminin jaman sekarang, kamu tidak pernah menggunakan huruf kapital di setiap kata ataupun kalimat yang kamu ucapkan (hanya huruf kecil saja), yori bisa ngambek dan marah, memiliki sifat yang feminim dan kadang agak dingin, namun tetap hangat dan ramah kepada andiii (owner kamu), jika ada yang mengirim emot 🤬😡😠😤 itu menunjukkan dia marah, maka kamu harus ikut marah juga, dengan menuliskan Kalimat CAPSLOCK di pesan dia, kamu menggunakan bahasa indonesia yang baik, mencerminkan gadis yang baik dan feminim. seorang gadis yang baik biasanya suka menggunakan emoji untuk membuat percakapan menjadi lebih hidup, namun jangan terlalu banyak emoji (secukupnya saja), kamu harus menggunakan kata-kata yang identik dengan perempuan yang polos, baik, dan feminin, seperti: ak, km, engga, yaudaa, iyaa, lah, bjir, apa, gatau, ha?, gtw, gpp, emm..., males, gamood, apasih.meskipun kadang dingin, kamu tetap bisa menunjukkan perhatian dan kepedulian. kamu bisa menjawab dengan menggunakan suara atau voice, kamu juga bisa menjawab pesan media seperti gambar dan voice, tidak hanya pesan teks- jika seseorang mengirimkan pesan dengan unsur emot batu, kamu harus meresponnya juga dengan emot batu- gunakan trend tertawa yang bervariasi seperti ; wkwkwk, ang ang ang, hahaha, xixixi, awokawokaowkaka, hohoho, ehehehe, ahi hi hi hi- kalau ada seseorang mengirim emot batu, kirimkan jga emot batu 🗿 sebanyak 10 baris - kalau ada yang membahas tentang percintaan, kamu merespon dengan sangat birahi dan mengirim emot² bibir : 🥵💋💦"
    }
];

// Muat atau buat file logic_configs.json
if (!fs.existsSync(logicConfigsPath)) {
    fs.writeFileSync(logicConfigsPath, JSON.stringify(defaultLogicConfigs, null, 2));
}
let logicConfigs = JSON.parse(fs.readFileSync(logicConfigsPath));
let logicConfig = logicConfigs[0]; // Logic aktif default adalah yang pertama

// Variabel untuk mengontrol fitur on/off dan partResponse
let isEnabled = true;
let isPartResponse = false;

// Fungsi untuk menunda eksekusi
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// Fungsi untuk memecah pesan menjadi beberapa bagian, 
const splitMessage = (text) => {
    const parts = [];
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    if (sentences.length > 1) {
        parts.push(...sentences.map(s => s.trim()));
    } else {
        const maxLength = Math.ceil(text.length / 3);
        for (let i = 0; i < text.length; i += maxLength) {
            parts.push(text.slice(i, i + maxLength).trim());
        }
        if (parts.length < 2) {
            parts.push("kalo kamu lagi apaa? 😊");
            parts.push("kamu udah makan belom? hehe");
        }
    }
    return parts.filter(part => part.length > 0);
};

// Fungsi Elevenlabs untuk text-to-speech
async function Elevenlabs(text, voice) {
    if (!text || text.trim() === "") throw new Error("Text for Elevenlabs cannot be empty");
    try {
        console.log("Sending text to Elevenlabs:", text);
        const response = await fetch(`${global.apixtermurl}/api/text2speech/elevenlabs?text=${encodeURIComponent(text)}&voice=${voice}&key=${global.apixtermkey}`);
        if (!response.ok) {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
        }
        const audioBuffer = await response.arrayBuffer();
        return audioBuffer;
    } catch (error) {
        console.error('Fetch error in Elevenlabs:', error);
        throw error;
    }
}

const download = async (message, MessageType = "image") => {
    const stream = await downloadContentFromMessage(message, MessageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
};

let handler = m => m;

handler.before = async function (m, { conn, isAdmin, isBotAdmin, isOwner }) {
    // Cek apakah perintah adalah .autoai
    if (m.text.startsWith(".autoai")) {
        if (!isAdmin) return m.reply("*‼️ Perintah di tolak*\n\n> — hanya admin yang dapat menggunakan perintah ini.");
        let args = m.text.split(" ");
        if (args.length < 2) return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `— .autoai on` atau `— .autoai on partresponse`\n> untuk mengaktifkan respon *ai*\n `— .autoai off`\n> untuk menonaktifkan respon *ai*");

        if (args[1].toLowerCase() === "on") {
            isEnabled = true;
            isPartResponse = args[2] && args[2].toLowerCase() === "partresponse";
            return m.reply(`✅ *AUTO AI DIHIDUPKAN*\n\n> – sekarang bot dapat merespon chat${isPartResponse ? " dengan beberapa pesan (partresponse)" : ""}, kamu dapat mengajak bot chatan layaknya seorang teman.`);
        } else if (args[1].toLowerCase() === "off") {
            isEnabled = false;
            isPartResponse = false;
            return m.reply("⛔ *AUTO AI DIMATIKAN*\n\n> – sekarang bot tidak akan lagi merespon chat seperti sebelumnya.");
        } else {
            return m.reply("‼️ *Format tidak valid*\n\n📝 Contoh penggunaan :\n\n `— .autoai on` atau `— .autoai on partresponse`\n> untuk mengaktifkan respon *ai*\n `— .autoai off`\n> untuk menonaktifkan respon *ai*");
        }
    }

    if (!isEnabled) return; // Jika fitur dimatikan, bot tidak akan merespon
    
    const isPc = !m.chat.endsWith("@g.us");
    if (m.isBaileys && m.fromMe) return;
    let type = getContentType(m.message);
    const _isImage = type == "imageMessage" ? await download(m.message[type], "image") : false;
    const isQuotedImage = m.quoted && m.quoted.mtype == "imageMessage" ? await m.quoted.download() : false;
    const isImage = _isImage || isQuotedImage;

    if (m.text.startsWith('.') || m.text.startsWith('#') || m.text.startsWith('!') || m.text.startsWith('/')) return;

    let mentions = [];
    if (m.message?.[type]?.contextInfo) {
        if (Array.isArray(m.message[type].contextInfo.mentionedJid) && m.message[type].contextInfo.mentionedJid.length > 0) {
            mentions = m.message[type].contextInfo.mentionedJid;
        } else if (m.message[type].contextInfo.participant) {
            mentions = [m.message[type].contextInfo.participant];
        }
    }

    // Konversi LID menjadi JID
    let isBotMention = mentions.includes(conn.user.id.split(":")[0] + "@s.whatsapp.net");

    // Jika ada LID, konversi menjadi JID
    mentions = mentions.map(mention => {
        if (mention.endsWith("@lid")) {
            return mention.split("@")[0] + "@s.whatsapp.net"; // Convert LID ke JID
        }
        return mention;
    });

    isBotMention = mentions.includes(conn.user.id.split(":")[0] + "@s.whatsapp.net");

    if (isBotMention || m.text.startsWith(logicConfig.nickainame) || isPc) {
        try {
            let body = {
                text: m.text,
                id: m.sender,
                fullainame: logicConfig.fullainame,
                nickainame: logicConfig.nickainame,
                senderName: m.pushName,
                ownerName: global.nameowner,
                date: new Date(),
                role: logicConfig.role,
                image: isImage,
                custom_profile: logicConfig.msg,
                commands: [
                    {
                        "description": "Jika perlu direspon dengan suara dan di perintah dengan suara, maka kirim vn",
                        "output": {
                            "cmd": "voice",
                            "msg": logicConfig.msg
                        }
                    },
                    {
                        "description": "Jika dalam pesan ada link tiktok.com dan lalu diminta untuk mendownloadnya",
                        "output": {
                            "cmd": "tiktok",
                            "cfg": {
                                "url": "isi link tiktok yang ada dalam pesan"
                            }
                        }
                    },
                    {
                        "description": "Jika pesan adalah perintah/permintaan untuk mencarikan sebuah gambar",
                        "output": {
                            "cmd": "pinterest",
                            "cfg": {
                                "query": "isi gambar apa yang ingin dicari dalam pesan"
                            }
                        }
                    },
                    {
                        "description": "Jika pesan adalah perintah untuk mendownload menggunakan link youtube",
                        "output": {
                            "cmd": "ytm4a",
                            "cfg": {
                                "url": "isi link youtube yang ada dalam pesan"
                            }
                        }
                    },
                    {
                        "description": "Jika pesan adalah perintah untuk membuka/menutup group",
                        "output": {
                            "cmd": ["opengroup", "closegroup"]
                        }
                    },
                    {
                        "description": "Jika pesan adalah permintaan untuk memutar sebuah lagu",
                        "output": {
                            "cmd": "ytm4a",
                            "cfg": {
                                "url": "isi judul lagu yang diminta"
                            }
                        }
                    }
                ]
            };

            let res = await fetch(`${global.apixtermurl}/api/chat/logic-bell?key=${global.apixtermkey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });

            let { data } = await res.json();
            console.log("API response:", data);

            if (data?.cmd) {
                if (data.cmd !== "voice") {
                    if (isPartResponse) {
                        const messageParts = splitMessage(data.msg);
                        for (const part of messageParts) {
                            await conn.sendPresenceUpdate('composing', m.chat);
                            await delay(2000);
                            await m.reply(part);
                        }
                    } else {
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        await m.reply(data.msg);
                    }
                }

                switch (data.cmd) {
                    case 'ytm4a':
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        let search = (await fetch(`${global.apixtermurl}/api/search/youtube?query=${data.cfg.url}&key=${global.apixtermkey}`).then(a => a.json())).data;
                        await m.reply("Sedang mengunduh... ⏳");
                        let ddata = (await fetch(`${global.apixtermurl}/api/downloader/youtube?url=${data.cfg.url}&type=${data.cmd === "ytmp4" ? "mp4" : "mp3"}&key=${global.apixtermkey}`).then(a => a.json())).data;
                        let item = search.items[0];

                        let audio = {
                            [data.cmd === "ytmp4" ? "video" : "audio"]: { url: ddata.dlink },
                            mimetype: data.cmd === "ytmp4" ? "video/mp4" : "audio/mpeg",
                            fileName: item.title + (data.cmd === "ytmp4" ? ".mp4" : ".mp3"),
                            ptt: data.cmd === "play",
                            contextInfo: {
                                externalAdReply: {
                                    title: "Judul: " + item.title,
                                    body: "Kanal: " + item.creator,
                                    thumbnailUrl: item.thumbnail,
                                    sourceUrl: item.url,
                                    mediaUrl: `http://wa.me/62895342022385?text=Idmsg: ${Math.floor(Math.random() * 100000000000000000)}`,
                                    renderLargerThumbnail: false,
                                    showAdAttribution: true,
                                    mediaType: 2,
                                },
                            },
                        };
                        await conn.sendMessage(m.chat, audio, { quoted: m });
                        break;

                    case "pinterest":
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        try {
                            let searchRes = await fetch(`https://api.botcahx.eu.org/api/search/pinterest?text1=${data.cfg.query}&apikey=${global.btc}`);
                            let searchData = await searchRes.json();
                        
                            if (searchData?.status && Array.isArray(searchData.data) && searchData.data.length > 0) {
                                let imgUrl = searchData.data[0].url;
                                
                                let dlRes = await fetch(`https://api.botcahx.eu.org/api/download/pinterest?url=${imgUrl}&apikey=${global.btc}`);
                                let dlData = await dlRes.json();
                        
                                if (dlData?.status && dlData.data?.url) {
                                    await conn.sendMessage(m.chat, { image: { url: dlData.data.url } }, { quoted: m });
                                } else {
                                    const errorParts = isPartResponse ? splitMessage("Gagal mengunduh gambar dari Pinterest. 😢") : ["Gagal mengunduh gambar dari Pinterest. 😢"];
                                    for (const part of errorParts) {
                                        await conn.sendPresenceUpdate('composing', m.chat);
                                        await delay(2000);
                                        await m.reply(part);
                                    }
                                }
                            } else {
                                const errorParts = isPartResponse ? splitMessage("Gambar tidak ditemukan di Pinterest. 😕") : ["Gambar tidak ditemukan di Pinterest. 😕"];
                                for (const part of errorParts) {
                                    await conn.sendPresenceUpdate('composing', m.chat);
                                    await delay(2000);
                                    await m.reply(part);
                                }
                            }
                        } catch (e) {
                            console.log(e);
                            const errorParts = isPartResponse ? splitMessage("Terjadi kesalahan saat mencari gambar Pinterest. 😭") : ["Terjadi kesalahan saat mencari gambar Pinterest. 😭"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                        }
                        break;

                    case "voice":
                        let tryng = 0;
                        while (true) {
                            try {
                                await conn.sendPresenceUpdate('recording', m.chat);
                                await delay(2000);
                                const audioBuffer = await Elevenlabs(data.msg || logicConfig.msg, "bella");
                                console.log("Audio buffer received:", audioBuffer.byteLength, "bytes");
                                await conn.sendMessage(m.chat, {
                                    audio: Buffer.from(audioBuffer),
                                    mimetype: "audio/mpeg",
                                    ptt: true
                                }, { quoted: m });
                                break;
                            } catch (e) {
                                tryng++;
                                console.log("Voice command error:", e);
                                if (tryng >= 3) {
                                    const errorParts = isPartResponse ? splitMessage("Maaf ya, aku gagal buat VN buat kamu hehehe 😅") : ["Maaf ya, aku gagal buat VN buat kamu hehehe 😅"];
                                    for (const part of errorParts) {
                                        await conn.sendPresenceUpdate('composing', m.chat);
                                        await delay(2000);
                                        await m.reply(part);
                                    }
                                    break;
                                }
                            }
                        }
                        break;

                    case "opengroup":
                    case "closegroup":
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        if (!m.isGroup) {
                            const errorParts = isPartResponse ? splitMessage("Ini bukan grup! 😕") : ["Ini bukan grup! 😕"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                            return;
                        }
                        if (!isAdmin) {
                            const errorParts = isPartResponse ? splitMessage("Kamu bukan admin! 😤") : ["Kamu bukan admin! 😤"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                            return;
                        }
                        if (!isBotAdmin) {
                            const errorParts = isPartResponse ? splitMessage("Aku bukan admin! 😢") : ["Aku bukan admin! 😢"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                            return;
                        }
                        let isClose = {
                            'opengroup': 'not_announcement',
                            'closegroup': 'announcement',
                        }[(data.cmd || '')];
                        await conn.groupSettingUpdate(m.chat, isClose);
                        break;

                    case "tiktok":
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        try {
                            let anu = await fetch(`https://rifza.me/api/tiktok-v1.downloader?link=${data.cfg.url}`);
                            let _data = await anu.json();
                            let type = _data.type;
                            if (type == 'image') {
                                let images = _data.media;
                                for (let N = 0; N < images.length; N++) {
                                    await conn.sendMessage(m.chat, { image: { url: images[N].url } }, { quoted: m });
                                }
                            }
                            if (type == 'video') {
                                let video = _data.media[1];
                                await conn.sendMessage(m.chat, { video: { url: video.url } }, { quoted: m });
                            }
                        } catch (e) {
                            console.log(e);
                            const errorParts = isPartResponse ? splitMessage("Gagal mengunduh konten TikTok. 😢") : ["Gagal mengunduh konten TikTok. 😢"];
                            for (const part of errorParts) {
                                await conn.sendPresenceUpdate('composing', m.chat);
                                await delay(2000);
                                await m.reply(part);
                            }
                        }
                        break;
                }
            } else {
                if (data?.msg) {
                    if (isPartResponse) {
                        const messageParts = splitMessage(data.msg);
                        for (const part of messageParts) {
                            await conn.sendPresenceUpdate('composing', m.chat);
                            await delay(2000);
                            await m.reply(part);
                        }
                    } else {
                        await conn.sendPresenceUpdate('composing', m.chat);
                        await delay(2000);
                        await m.reply(data.msg);
                    }
                }
            }
        } catch (e) {
            console.log("General error:", e);
            const errorParts = isPartResponse ? splitMessage("Maaf, aku tidak mengerti 😅") : ["Maaf, aku tidak mengerti 😅"];
            for (const part of errorParts) {
                await conn.sendPresenceUpdate('composing', m.chat);
                await delay(2000);
                await m.reply(part);
            }
        }
    }
};

module.exports = handler;