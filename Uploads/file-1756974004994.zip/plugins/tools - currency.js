const axios = require("axios")

let handler = async (m, { args, usedPrefix, command }) => {
  if (args.length < 3) {
    return m.reply(`💱 *Format salah! tools ini untuk konversi nilai mata uang*\nContoh:\n${usedPrefix + command} 100 idr usd`)
  }

  let [amount, from, to] = args
  if (isNaN(amount)) return m.reply("❌ Jumlah harus berupa angka.")

  try {
    const res = await axios.post(global.apisiput + "api/currency/convert", {
      amount: parseFloat(amount),
      from: from.toUpperCase(),
      to: to.toUpperCase()
    })

    const data = res.data

    if (!data.success) {
      return m.reply(formatCurrencyError(data.error))
    }

    const { result, rate } = data.data

    m.reply(`💱 *Konversi Mata Uang:*\n\n` +
      `💰 Jumlah: ${amount} ${from.toUpperCase()}\n` +
      `➡️ Hasil: *${result.toLocaleString()} ${to.toUpperCase()}*\n` +
      `📈 Rate: 1 ${from.toUpperCase()} = ${rate.toLocaleString()} ${to.toUpperCase()}`
    )
  } catch (e) {
    const msg = e.response?.data?.error || e.message
    if (/not found/i.test(msg)) {
      return m.reply(formatCurrencyError(msg))
    }
    console.error(e)
    m.reply("❌ Terjadi kesalahan saat menghubungi server:\n" + msg)
  }
}

// Fungsi untuk memberi pesan error + daftar kode umum
function formatCurrencyError(msg) {
  return `❌ *Gagal melakukan konversi:*\n${msg}\n\n` +
         `✅ *Kode mata uang umum yang valid:*\n` +
         `\`\`\`\n` +
         `Fiat:\nUSD, EUR, GBP, IDR, JPY, CNY, INR, SGD, MYR, THB, AUD, CAD, BRL, MXN\n\n` +
         `Crypto:\nBTC, ETH, BNB, XRP, LTC, ADA, DOGE, SOL, USDT, USDC\n` +
         `\`\`\`\n` +
         `Contoh: *.currency 100 usd idr*`
}

handler.help = ['currency <jumlah> <dari> <ke>']
handler.tags = ['tools']
handler.command = /^currency$/i

module.exports = handler
