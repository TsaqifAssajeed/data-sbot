const fetch = require("node-fetch");

let handler = async (m, { jagpro, args, usedPrefix, command }) => {
  if (!args[0]) throw `🚩 Masukkan URL Spotify!\n\nContoh:\n${usedPrefix + command} https://open.spotify.com/track/3zakx7RAwdkUQlOoQ7SJRt`;

  const url = args[0];
  if (!url.match(/https:\/\/open.spotify.com\/track\//gi)) {
    throw `🚩 URL tidak valid. Harus berupa tautan lagu Spotify!`;
  }

  m.reply("⏳ Sedang memproses...");

  try {
    const apiURL = 'https://spotify.downloaderize.com/wp-json/spotify-downloader/v1/fetch';
    const headers = {
      'accept': '/',
      'content-type': 'application/json',
      'x-requested-with': 'XMLHttpRequest',
      'referer': 'https://spotify.downloaderize.com/'
    };

    const res = await fetch(apiURL, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        type: 'song',
        url
      })
    });

    const json = await res.json();

    if (!json.success || !json.data?.downloadLink) {
      throw '🚩 Gagal mengambil data dari server.';
    }

    const { title, artist, album, cover, releaseDate, downloadLink } = json.data;

    const caption = `🎵 *Spotify Downloader 2*\n\n` +
      `∘ *Title:* ${title}\n` +
      `∘ *Artist:* ${artist}\n` +
      `∘ *Album:* ${album}\n` +
      `∘ *Release Date:* ${releaseDate}`;

    await jagpro.sendMessage(m.chat, {
      text: caption,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: artist,
          thumbnailUrl: cover,
          sourceUrl: url,
          mediaType: 1,
          showAdAttribution: true,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

    await jagpro.sendMessage(m.chat, {
      audio: { url: downloadLink },
      mimetype: 'audio/mpeg',
      contextInfo: {
        externalAdReply: {
          title,
          body: artist,
          thumbnailUrl: cover,
          sourceUrl: url,
          mediaType: 1,
          showAdAttribution: true,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    throw `🚩 Terjadi kesalahan saat memproses permintaan.\n${e}`;
  }
};

handler.help = ['spotify2'];
handler.tags = ['downloader'];
handler.command = /^spotify2$/i;
handler.limit = true;
module.exports = handler;
