let handler = async (m, { conn }) => {
  let user = m.sender
  let now = new Date() * 1
  let trialDuration = 3600000 // 60 menit dalam milidetik

  if (global.db.data.users[user].premiumUsed) {
      return conn.reply(m.chat, `Anda sudah menggunakan free trial premium sebelumnya. Akses premium telah habis.`, m)
  }

  global.db.data.users[user].premium = true
  global.db.data.users[user].premiumDate = now + trialDuration
  global.db.data.users[user].premiumUsed = true // Menandai bahwa user sudah klaim trial
  
  conn.reply(m.chat, `🎉 *FREE TRIAL PREMIUM*

Anda telah mendapatkan akses premium selama *60 menit*.

*Premium berakhir dalam:* ${msToDate(trialDuration)}`, m)
}

handler.help = ['freetrial']
handler.tags = ['premium']
handler.command = /^(freetrial)$/i
handler.limit = false
module.exports = handler

function msToDate(ms) {
  let temp = ms
  let minutes = Math.floor((temp) / (60 * 1000));
  let seconds = Math.floor((temp % (60 * 1000)) / 1000);
  return minutes + " menit " + seconds + " detik";
}
