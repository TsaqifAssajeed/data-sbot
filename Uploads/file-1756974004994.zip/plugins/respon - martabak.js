let handler = async (m, { conn }) => {
	if (m.fromMe) return false
  conn.reply(m.chat, `OMG Martabak 🤤
`.trim(), m)
}
handler.customPrefix = /martabak/i
handler.command = new RegExp

module.exports = handler