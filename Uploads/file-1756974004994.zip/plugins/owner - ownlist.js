// ✨ Plugin owner - ownlist ✨

let handler = async (m, { conn }) => {
    if (!global.owner || global.owner.length === 0) {
        return m.reply('Belum ada owner yang terdaftar.')
    }

    let teks = '*≡ Daftar Owner Bot:*\n\n'
    global.owner.forEach(([id, name = '', isActive], index) => {
        teks += `*${index + 1}.* @${id}${name ? ` (${name})` : ''}${isActive ? ' ✅ Aktif' : ''}\n`
    })

    await conn.reply(m.chat, teks.trim(), m, {
        mentions: global.owner.map(([id]) => id + '@s.whatsapp.net')
    })
}

handler.help = ['ownerlist']
handler.tags = ['owner']
handler.command = /^ownerlist$/i
handler.owner = true

module.exports = handler