let handler = async (m, { command, text }) => {
  let ter = command[1].toLowerCase()
  let txt = m.quoted && m.quoted.text ? m.quoted.text : text ? text : ''
  
  if (!txt) {
    return m.reply(`• *Cara penggunaan:* \nKetik \`${command} <teks>\` atau reply pesan dengan \`${command}\`\nContoh: \`${command} saya suka coding\` atau reply pesan dengan \`${command}\``)
  }
  
  let result = txt.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase())
  await m.reply(result)
}

handler.help = [...'aiueo'].map(v => `h${v}l${v}h <teks>`)
handler.tags = ['fun']
handler.command = /^h([aiueo])l\1h/i
handler.limit = true

module.exports = handler