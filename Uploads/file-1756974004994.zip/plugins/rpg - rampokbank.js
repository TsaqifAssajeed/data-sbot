let { MessageType } = require('@whiskeysockets/baileys');

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    if (command.toLowerCase() === 'rampokbank') {
      let user = global.db.data.users[m.sender];

      // Cek apakah user dibanned
      if (user.banned) {
        let remaining = user.bannedUntil ? user.bannedUntil - Date.now() : 0;
        if (remaining > 0) {
          return conn.reply(m.chat, `⛔ Kamu masih di banned karena ketahuan merampok database uang di Bot!\n\n⏳ Sisa penjara: *${clockString(remaining)}*`, m);
        } else {
          // Otomatis unbanned jika waktu banned sudah habis
          user.banned = false;
          user.bannedUntil = 0;
          global.db.write();
        }
      }

      let now = new Date();
      let cooldown = 3 * 60 * 60 * 1000; // 3 jam cooldown
      let last = user.lastRampokBank || 0;
      let remainingCooldown = cooldown - (now - last);

      // Cek cooldown per user
      if (remainingCooldown > 0) {
        return conn.reply(m.chat, `*_⏳ Cooldown_*\n\n⏱️ Sisa waktu: *${clockString(remainingCooldown)}*`, m);
      }

      // Simpan waktu terakhir rampok untuk user ini
      user.lastRampokBank = now.getTime();

      // Inisialisasi data jackpot di database jika belum ada
      if (!global.db.data.settings.jackpotClaims) {
        global.db.data.settings.jackpotClaims = {
          '09:00': { claimed: false, timestamp: 0, user: '' },
          '16:00': { claimed: false, timestamp: 0, user: '' },
          '23:30': { claimed: false, timestamp: 0, user: '' }
        };
      }

      // Cek apakah waktu saat ini adalah waktu bonus (09:00, 16:00, atau 23:30)
      let isBonusTime = (now.getHours() === 9 && now.getMinutes() === 0) ||
                        (now.getHours() === 16 && now.getMinutes() === 0) ||
                        (now.getHours() === 23 && now.getMinutes() === 30);

      let bonusMultiplier = 1; // Default: tidak ada bonus
      let jackpotMessage = '';
      let currentSlot = '';

      // Tentukan slot waktu bonus
      if (now.getHours() === 9 && now.getMinutes() === 0) currentSlot = '09:00';
      else if (now.getHours() === 16 && now.getMinutes() === 0) currentSlot = '16:00';
      else if (now.getHours() === 23 && now.getMinutes() === 30) currentSlot = '23:30';

      // Cek status jackpot untuk waktu bonus
      if (isBonusTime && currentSlot) {
        let jackpotData = global.db.data.settings.jackpotClaims[currentSlot];
        // Reset jackpot jika sudah lebih dari 24 jam (hari berikutnya)
        if (jackpotData.timestamp && (now.getTime() - jackpotData.timestamp) > 24 * 60 * 60 * 1000) {
          jackpotData.claimed = false;
          jackpotData.user = '';
          jackpotData.timestamp = 0;
          global.db.write();
        }
        // Cek apakah jackpot sudah diklaim
        if (jackpotData.claimed) {
          isBonusTime = false; // Nonaktifkan bonus jika sudah diklaim
          jackpotMessage = `\n\n⚠️ Jackpot waktu spesial sudah diklaim oleh @${jackpotData.user.split('@')[0]} untuk slot ${currentSlot}!`;
        }
      }

      let chance = Math.random();
      if (chance <= 0.4) { // Peluang keberhasilan 40%
        // Berhasil merampok
        let reward = 1500000; // 1.5 juta
        if (isBonusTime && currentSlot && !global.db.data.settings.jackpotClaims[currentSlot].claimed) {
          bonusMultiplier = 2; // Bonus 2x jika waktu bonus dan jackpot belum diklaim
          global.db.data.settings.jackpotClaims[currentSlot].claimed = true;
          global.db.data.settings.jackpotClaims[currentSlot].user = m.sender;
          global.db.data.settings.jackpotClaims[currentSlot].timestamp = now.getTime();
          global.db.write();
        }
        user.money += reward * bonusMultiplier;
        global.db.write();

        let message = isBonusTime && bonusMultiplier === 2
          ? `🌟 *JACKPOT WAKTU SPESIAL!* 🌟\n\n✅ Kamu berhasil merampok bank di jam ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}!\n\n💸 Hasil merampok: *${(reward * bonusMultiplier).toLocaleString()}* (Bonus 2x!)`
          : `✅ Kamu berhasil merampok bank!\n\n💸 Hasil merampok: *${(reward * bonusMultiplier).toLocaleString()}*`;
        message += jackpotMessage;

        return conn.sendMessage(m.chat, {
          text: message,
          contextInfo: {
            externalAdReply: {
              title: '🤑 KAMU JADI SULTAN',
              body: '🏃🏻 KAMU BERHASIL KABUR!!',
              thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/rampkkkkkkkk.jpg',
              mediaType: 1,
              showAdAttribution: true,
              renderLargerThumbnail: true
            }
          }
        });
      } else {
        // Gagal -> banned
        user.banned = true;
        user.bannedUntil = now.getTime() + (30 * 60 * 1000); // Banned 30 menit
        global.db.write();

        // Kirim pesan banned
        await conn.sendMessage(m.chat, {
          text: `🚨 Niuuu Niiuuu Niuuuu\nKamu di Tangkap dan gagal merampok bank!!\n\n🚫 Kamu di banned selama 30 menit di sistem Bot.\n> Akan diberitahu jika kamu sudah bebas${jackpotMessage}`,
          contextInfo: {
            externalAdReply: {
              title: '👮🏻 Kamu tertangkap polisi!',
              body: 'Selamat menikmati waktu di sel tahanan!',
              thumbnailUrl: 'https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/tasngkapprampok.jpg',
              mediaType: 1,
              showAdAttribution: true,
              renderLargerThumbnail: true
            }
          }
        });

        // Atur timer untuk un tâban otomatis setelah 30 menit
        setTimeout(async () => {
          if (user.banned && user.bannedUntil <= Date.now()) {
            user.banned = false;
            user.bannedUntil = 0;
            global.db.write();

            try {
              await conn.sendMessage(m.chat, {
                text: `🏃....🚓 @${m.sender.split('@')[0]} telah di bebaskan dari penjara dan telah di-unban. Bisa menggunakan bot kembali.\n\n> Tolong kalau merampok pakai strategi yaa :v`,
                mentions: [m.sender]
              });
            } catch (err) {
              console.error(`❌ Gagal mengirim pesan unban: ${err}`);
            }
          }
        }, 30 * 60 * 1000); // 30 menit
      }
    } else if (command.toLowerCase() === 'cekrampok') {
      let who;
      if (m.isGroup) {
        who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : null;
      } else {
        who = m.sender;
      }

      if (!who) {
        return conn.reply(m.chat, `❓ Tag atau reply pesan seseorang untuk memeriksa status perampoknya!\n\nContoh: ${usedPrefix}cekrampok @user`, m);
      }

      let user = global.db.data.users[who];
      let isRobber = user.lastRampokBank && user.lastRampokBank > 0;
      let isBanned = user.banned && user.bannedUntil > Date.now();

      let message = `🔍 *Status Perampok @${who.split('@')[0]}*\n\n`;
      if (isRobber) {
        message += `🏦 *Pernah Merampok*: Ya\n`;
        message += `⏰ *Terakhir Merampok*: ${new Date(user.lastRampokBank).toLocaleString('id-ID')}\n`;
      } else {
        message += `🏦 *Pernah Merampok*: Tidak\n`;
      }

      if (isBanned) {
        let remaining = user.bannedUntil - Date.now();
        message += `🚨 *Status Penjara*: Sedang di penjara\n`;
        message += `⏳ *Sisa Waktu*: ${clockString(remaining)}`;
      } else {
        message += `🚨 *Status Penjara*: Bebas`;
      }

      return conn.reply(m.chat, message, m, { mentions: [who] });
    }
  } catch (e) {
    console.error(e);
    throw e;
  }
};

handler.help = ['rampokbank', 'cekrampok'];
handler.tags = ['rpg'];
handler.command = /^(rampokbank|cekrampok)$/i;
handler.premium = false;
handler.group = true;

module.exports = handler;

// Fungsi format waktu
function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}