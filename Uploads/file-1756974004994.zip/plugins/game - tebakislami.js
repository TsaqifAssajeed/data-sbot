let handler = async (m, { conn, args, usedPrefix, command }) => {
  conn.tebakislami = conn.tebakislami || {}
  let id = m.chat

  // Fitur menyerah
  if (command === 'surrender') {
    if (!(id in conn.tebakislami)) return conn.reply(m.chat, '❌ Tidak ada soal yang sedang berlangsung.', m)
    let [_, soal] = conn.tebakislami[id]
    conn.reply(m.chat, `🏳️ *Menyerah?*\nJawaban yang benar adalah: *${soal.jawab}*`, m)
    clearTimeout(conn.tebakislami[id][3])
    delete conn.tebakislami[id]
    return
  }

  if (id in conn.tebakislami) return conn.reply(m.chat, '⚠️ Soal sebelumnya belum terjawab!', conn.tebakislami[id][0])

  let soal = pickRandom(soalIslami)
  conn.tebakislami[id] = [
    await conn.reply(m.chat, `🕌 *Tebak Islami!*\n\n➡️ *Pertanyaan:* ${soal.pertanyaan}\n⏳ *Waktu:* 30 detik\n🎁 *Bonus:* +1500 Money\n\n> jawab tanpa reply chat ini!\n\nMenyerah? ketik *.surrender*`, m),
    soal, 4,
    setTimeout(() => {
      if (conn.tebakislami[id]) conn.reply(m.chat, `⏰ *Waktu habis!*\nJawaban yang benar: *${soal.jawab}*`, conn.tebakislami[id][0])
      delete conn.tebakislami[id]
    }, 30000)
  ]
}
handler.help = ['tebakislami', 'surrender']
handler.tags = ['game']
handler.command = /^tebakislami|surrender$/i
handler.group = true

module.exports = handler

// Cek jawaban user
let before = async (m, { conn }) => {
  conn.tebakislami = conn.tebakislami || {}
  let id = m.chat
  if (!(id in conn.tebakislami)) return
  let [msg, soal] = conn.tebakislami[id]
  if (m.text.toLowerCase() === soal.jawab.toLowerCase()) {
    global.db.data.users[m.sender].money += 1500
    conn.reply(m.chat, `✅ ${m.name} benar!!\n🎉 Bonus: +1500 Money`, m)
    clearTimeout(conn.tebakislami[id][3])
    delete conn.tebakislami[id]
  }
}
module.exports.before = before

// List soal
const soalIslami = [
  { pertanyaan: 'Siapakah nabi pertama dalam Islam?', jawab: 'Adam' },
  { pertanyaan: 'Apa nama kitab yang diturunkan kepada Nabi Muhammad?', jawab: 'Alquran' },
  { pertanyaan: 'Berapa jumlah rukun Islam?', jawab: '5' },
  { pertanyaan: 'Apa nama kota suci umat Islam?', jawab: 'Mekah' },
  { pertanyaan: 'Siapa nabi yang bisa membelah laut?', jawab: 'Musa' },
  { pertanyaan: 'Apa nama bulan suci umat Islam?', jawab: 'Ramadhan' },
  { pertanyaan: 'Berapa rakaat sholat Subuh?', jawab: '2' },
  { pertanyaan: 'Hari besar umat Islam yang jatuh pada 1 Syawal?', jawab: 'Idul Fitri' },
  { pertanyaan: 'Berapa jumlah rakaat sholat Maghrib?', jawab: '3' },
  { pertanyaan: 'Nama istri Nabi Muhammad yang pertama?', jawab: 'Khadijah' },
  { pertanyaan: 'Nama gunung tempat Nabi Musa menerima wahyu?', jawab: 'Tur Sina' },
  { pertanyaan: 'Apa nama malam yang lebih baik dari seribu bulan?', jawab: 'Lailatul Qadar' },
  { pertanyaan: 'Kota tempat Nabi Muhammad dilahirkan?', jawab: 'Mekah' },
  { pertanyaan: 'Kota tempat Nabi Muhammad hijrah?', jawab: 'Madinah' },
  { pertanyaan: 'Berapa jumlah total rakaat dalam sholat wajib?', jawab: '17' },
  { pertanyaan: 'Siapa khalifah pertama setelah wafatnya Nabi Muhammad?', jawab: 'Abu Bakar' },
  { pertanyaan: 'Berapa jumlah huruf dalam Basmallah?', jawab: '19' },
  { pertanyaan: 'Siapa nabi yang diangkat sejak dalam kandungan?', jawab: 'Yahya' },
  { pertanyaan: 'Apa nama hewan yang berbicara dalam Alquran?', jawab: 'Semut' },
  { pertanyaan: 'Siapakah penghuni surga yang pertama?', jawab: 'Muhammad' },
  { pertanyaan: 'Apa nama pintu surga untuk orang yang rajin puasa?', jawab: 'Rayyan' },
  { pertanyaan: 'Apa nama jin yang menjadi muslim dan mendengarkan Alquran?', jawab: 'Jin' },
  { pertanyaan: 'Surat apa yang paling panjang dalam Alquran?', jawab: 'Al-Baqarah' },
  { pertanyaan: 'Surat terakhir dalam Alquran?', jawab: 'An-Nas' },
  { pertanyaan: 'Berapa jumlah nabi yang wajib diketahui?', jawab: '25' },
  { pertanyaan: 'Apa nama malam turunnya Alquran?', jawab: 'Lailatul Qadar' },
  { pertanyaan: 'Siapa nabi yang memiliki mukjizat bisa menghidupkan orang mati?', jawab: 'Isa' },
  { pertanyaan: 'Siapa nabi yang paling banyak disebut dalam Alquran?', jawab: 'Musa' },
  { pertanyaan: 'Siapa nama ayah Nabi Muhammad?', jawab: 'Abdullah' },
  { pertanyaan: 'Siapa nama ibu Nabi Muhammad?', jawab: 'Aminah' },
  { pertanyaan: 'Apa nama hewan yang menjadi tunggangan Nabi saat Isra Miraj?', jawab: 'Buraq' },
  { pertanyaan: 'Apa nama surah pertama dalam Alquran?', jawab: 'Al-Fatihah' },
  { pertanyaan: 'Apa arti dari kata "Islam"?', jawab: 'Selamat' },
  { pertanyaan: 'Apa nama puasa sunah pada hari Senin dan Kamis?', jawab: 'Puasa Senin Kamis' },
  { pertanyaan: 'Apa nama istri Nabi yang terkenal cerdas dan meriwayatkan banyak hadits?', jawab: 'Aisyah' },
  { pertanyaan: 'Apa nama nabi yang bisa berbicara saat masih bayi?', jawab: 'Isa' },
  { pertanyaan: 'Siapa yang membangun Ka’bah bersama Nabi Ibrahim?', jawab: 'Ismail' },
  { pertanyaan: 'Apa nama telaga milik Nabi Muhammad di surga?', jawab: 'Al-Kautsar' },
  { pertanyaan: 'Apa nama surat yang hanya terdiri dari 3 huruf dan sering dibaca?', jawab: 'Al-Ikhlas' },
  { pertanyaan: 'Berapa jumlah takbir dalam sholat Idul Fitri?', jawab: '7' },
  { pertanyaan: 'Siapa nabi yang dikenal paling sabar?', jawab: 'Ayyub' },
  { pertanyaan: 'Siapa nabi yang ditelan ikan paus?', jawab: 'Yunus' },
  { pertanyaan: 'Apa nama kitab yang diturunkan kepada Nabi Isa?', jawab: 'Injil' },
  { pertanyaan: 'Apa nama kitab yang diturunkan kepada Nabi Musa?', jawab: 'Taurat' },
  { pertanyaan: 'Apa nama kitab yang diturunkan kepada Nabi Daud?', jawab: 'Zabur' },
  { pertanyaan: 'Siapa pemimpin kaum Quraisy yang paling menentang dakwah Nabi?', jawab: 'Abu Lahab' },
  { pertanyaan: 'Apa nama peperangan pertama umat Islam?', jawab: 'Badar' },
  { pertanyaan: 'Apa nama surah terpendek dalam Alquran?', jawab: 'Al-Kautsar' }
]

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}