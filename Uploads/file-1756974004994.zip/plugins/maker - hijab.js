const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require("fs");
const path = require("path");

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    const contextInfoError = async (title, msg, conn, sender) => {
        let ppUrl = global.thumb;
        try { ppUrl = await conn.profilePictureUrl(sender, 'image'); } catch (e) {}
        return {
            text: msg,
            contextInfo: {
                externalAdReply: {
                    title,
                    body: '',
                    thumbnailUrl: ppUrl,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        };
    };

    const contextInfoLoading = async (conn, sender) => {
        let ppUrl = global.thumb;
        try { ppUrl = await conn.profilePictureUrl(sender, 'image'); } catch (e) {}
        return {
            text: 'Sedang memproses...',
            contextInfo: {
                externalAdReply: {
                    title: '⏳ Memproses Gambar...',
                    body: '',
                    thumbnailUrl: ppUrl,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        };
    };

    const defaultPrompt = "tambahkan hijab untuk karakter dalam gambar, tetap pertahankan wajah dan backgroundnya";

    if (!mime) {
        return conn.sendMessage(m.chat, await contextInfoError(
            '❌ Gambar Tidak Ditemukan',
            `Kirim/reply gambar dengan caption *${usedPrefix}${command}*`,
            conn,
            m.sender
        ), { quoted: m });
    }
    if (!/image\/(jpe?g|png)/.test(mime)) {
        return conn.sendMessage(m.chat, await contextInfoError(
            '❌ Format Tidak Didukung',
            `Format ${mime} tidak didukung! Hanya jpeg/jpg/png`,
            conn,
            m.sender
        ), { quoted: m });
    }

    const promptText = text || defaultPrompt;
    await conn.sendMessage(m.chat, await contextInfoLoading(conn, m.sender), { quoted: m });
    await conn.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });

    try {
        const imgData = await q.download();
        if (!imgData) throw new Error("Gagal mendownload gambar");

        const base64Image = imgData.toString("base64");
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ];

        let success = false;
        let lastError;
        let resultImage;

        for (let i = 0; i < global.geminiApi.length; i++) {
            const apiKey = global.geminiApi[i];
            try {
                const genAI = new GoogleGenerativeAI(apiKey);
                const model = genAI.getGenerativeModel({
                    model: "gemini-2.0-flash-exp-image-generation",
                    generationConfig: {
                        responseModalities: ["text", "image"]
                    }
                });

                const response = await model.generateContent(contents);
                const candidate = response?.response?.candidates?.[0];

                if (!candidate?.content?.parts) throw new Error("Response tidak valid");

                for (const part of candidate.content.parts) {
                    if (part.inlineData?.data) {
                        resultImage = Buffer.from(part.inlineData.data, "base64");
                        success = true;
                        break;
                    }
                }

                if (success) break;
            } catch (err) {
                lastError = err;
                console.warn(`API key ke-${i + 1} gagal, mencoba yang berikutnya...`);
            }
        }

        if (!success || !resultImage) throw lastError || new Error("Gagal memproses gambar");

        const tempDir = path.join(process.cwd(), "tmp");
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

        const tempPath = path.join(tempDir, `gemini_${Date.now()}.png`);
        fs.writeFileSync(tempPath, resultImage);

        let ppUrl = global.thumb;
        try { ppUrl = await conn.profilePictureUrl(m.sender, 'image'); } catch (e) {}

        await conn.sendMessage(m.chat, {
            image: { url: tempPath },
            caption: "*Sudah berhijab cantik yaa 💖*",
            contextInfo: {
                externalAdReply: {
                    title: '✅ Gambar Berhasil Diproses',
                    body: '',
                    thumbnailUrl: ppUrl,
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        setTimeout(() => {
            try {
                if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
            } catch (err) {
                console.error("Gagal menghapus file temporary:", err);
            }
        }, 30000);

    } catch (error) {
        console.error("Error dalam handler:", error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return conn.sendMessage(m.chat, await contextInfoError(
            '❌ Kesalahan Pemrosesan',
            `Terjadi kesalahan: ${error.message}`,
            conn,
            m.sender
        ), { quoted: m });
    }
};

handler.help = ["hijabkan"];
handler.tags = ["ai", "maker"];
handler.command = ["hijabkan"];

module.exports = handler;