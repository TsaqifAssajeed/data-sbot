const fetch = require('node-fetch');
const axios = require('axios');
const fs = require('fs');
const uploadFile = require('../lib/uploadFile');
const uploadImage = require('../lib/uploadImage');

// Konfigurasi API
const api = {
  primary: {
    url: 'https://api.botcahx.eu.org/api/tools/removebg',
    key: global.btc // Ganti dengan API key botcahx yang valid
  },
  fallback: {
    url: 'https://aihub.xtermai.xyz',
    key: global.apixtermkey // Ganti dengan API key xtermai yang valid
  }
};

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    console.log('File yang mengeksekusi perintah ini:', __filename);

    // Ambil media dari pesan
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    if (!mime) return m.reply('❌ Tidak ada media yang ditemukan! Silakan kirim atau balas gambar.');

    // Unduh media
    const media = await q.download();
    if (!media) return m.reply('❌ Gagal mengunduh gambar, coba lagi nanti.');

    // Batas ukuran file (5MB)
    const fileSizeLimit = 5 * 1024 * 1024;
    if (media.length > fileSizeLimit) {
      return m.reply('❌ Ukuran gambar tidak boleh melebihi 5MB.');
    }

    // Cek apakah format didukung Telegram CDN
    const isTele = /image\/(png|jpe?g|gif)/.test(mime);

    // Unggah gambar atau file
    const uploadedUrl = await (isTele ? uploadImage : uploadFile)(media);
    console.log('URL gambar yang diunggah:', uploadedUrl);
    if (!uploadedUrl) return m.reply('❌ Gagal mengunggah gambar, coba lagi nanti.');

    m.reply('🔄 Sedang memproses penghapusan background, harap tunggu...');

    // Fungsi untuk menghapus background
    async function removeBackground(url, apiConfig, isFallback = false) {
      const endpoint = isFallback 
        ? `${apiConfig.url}/api/tools/image-removebg?url=${encodeURIComponent(url)}&key=${apiConfig.key}`
        : `${apiConfig.url}?url=${encodeURIComponent(url)}&apikey=${apiConfig.key}`;
      const response = await fetch(endpoint);
      const result = await response.json();
      return result;
    }

    // Variabel untuk melacak API yang digunakan
    let apiUsed = 'pertama';

    // Coba API utama (botcahx)
    let result = await removeBackground(uploadedUrl, api.primary);

    // Cek apakah API utama berhasil
    if (!result.url) {
      console.log('API utama (botcahx) gagal, mencoba API fallback (xtermai)...');
      m.reply('⚠️ Gagal memproses dengan API utama, mencoba metode alternatif...');

      // Fallback ke API xtermai
      result = await removeBackground(uploadedUrl, api.fallback, true);
      apiUsed = 'kedua';

      if (!result.status || !result.data?.url) {
        return m.reply('❌ Gagal menghapus background dengan kedua metode. Coba lagi nanti atau gunakan gambar lain.');
      }
      result.url = result.data.url; // Sesuaikan format respons fallback
    }

    const resultUrl = result.url;
    console.log('URL hasil removebg:', resultUrl);

    // Unduh hasil gambar
    const responseFile = await axios.get(resultUrl, { responseType: 'arraybuffer' });
    const filePath = './tmp/hasil-removebg.png';
    fs.writeFileSync(filePath, responseFile.data);

    // Kirim hasil ke pengguna dengan keterangan API yang digunakan
    await conn.sendFile(m.chat, filePath, 'hasil-removebg.png', `✨ Background berhasil dihapus!\n> menggunakan fungsi ${apiUsed}`, m);

  } catch (e) {
    console.error('Error:', e);
    m.reply('🚩 *Terjadi kesalahan server, coba lagi nanti!*');
  }
};

// Konfigurasi handler
handler.help = ['removebg'];
handler.command = ['removebg', 'nobg'];
handler.tags = ['tools'];
handler.premium = false;
handler.limit = true;

module.exports = handler;