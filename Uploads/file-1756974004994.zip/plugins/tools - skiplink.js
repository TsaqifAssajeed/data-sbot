const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let url = text.trim();

  if (!url) {
    return m.reply(`📌 Contoh:\n${usedPrefix + command} https://sfl.gl/WhatsAppModBerryV4`);
  }


  await m.reply('⏳ Sedang memproses bypass...');

  const apiKey = global.fgsiKey; // Ganti dengan API key Anda. Daftar gratis di https://fgsi.koyeb.app/
  const baseUrl = `${global.fgsi}/api/tools/skip/tutwuri`;

  try {
    const response = await axios.get(baseUrl, {
      params: {
        apikey: apiKey,
        url: url
      },
      headers: {
        accept: 'application/json'
      }
    });

    const data = response.data;
    if (data.status) {
      let pesan = `✅ *Bypass Berhasil!*

📍 *Link Tujuan:* ${data.data.linkGo || 'Tidak tersedia'}
`;
      return m.reply(pesan);
    } else {
      let pesan = `❌ *Gagal Bypass URL!*

📌 *Pesan:* ${data.message || 'Tidak ada pesan error'}
📍 *Status:* ${data.status}
`;
      return m.reply(pesan);
    }
  } catch (error) {
    console.error('Error details:', error);
    let pesan = `⚠️ *Error Terdeteksi!*

📌 *Jenis:* ${error.name || 'AxiosError'}
📢 *Pesan:* ${error.response?.data?.message || error.message}
📎 Catatan: Pastikan URL valid, API key aktif, dan coba lagi. Jika masalah berlanjut, periksa log server.
`;
    return m.reply(pesan);
  }
};

handler.help = ['skiplink <url>'];
handler.tags = ['tools'];
handler.command = /^skiplink$/i;
handler.limit = true;

module.exports = handler;