const axios = require('axios');
const fs = require('fs');

let handler = async (m, { conn, text }) => {
    const generateQR = async (textInput) => {
        try {
            const safeText = encodeURIComponent(String(textInput).trim());
            const apiUrl = `${global.apisiput}api/tools/text2qr?text=${safeText}`;
            const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

            if (response.status !== 200) {
                throw new Error('Gagal menghasilkan QR code, periksa teks atau API.');
            }

            return Buffer.from(response.data);
        } catch (error) {
            console.error('Terjadi kesalahan saat generate QR:', error);
            throw error;
        }
    };

    // Validasi input
    if (!text) throw 'Berikan teks untuk diubah ke QR code!\nContoh: .toqr https://example.com';

    const inputText = String(text).trim();
    if (!inputText) throw 'Teks tidak valid atau kosong!';

    // Bersihkan caption agar tidak ada karakter yang bisa memicu parse mention
    const safeCaption = `QR Code untuk: ${inputText}`.replace(/[@\n\r\t]/g, ' ').trim();

    try {
        const qrBuffer = await generateQR(inputText);
        const tempPath = './temp_qr.png';
        fs.writeFileSync(tempPath, qrBuffer);

        // Kirim gambar menggunakan conn.sendMessage (bukan m.reply)
        await conn.sendMessage(m.chat, {
            image: { stream: fs.createReadStream(tempPath) },
            caption: safeCaption
        }, { quoted: m });

        // Hapus file setelah digunakan
        fs.unlinkSync(tempPath);

    } catch (err) {
        console.error('Terjadi kesalahan:', err);
        throw `Terjadi kesalahan: ${err.message || err}`;
    }
};

handler.help = ['toqr'];
handler.tags = ['tools'];
handler.command = /^toqr$/i;
handler.limit = true;

module.exports = handler;
