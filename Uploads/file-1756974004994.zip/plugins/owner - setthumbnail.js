// 📝 plugin owner - setthumbnail

const fs = require('fs');
const path = require('path');

let handler = async (m, { text, command }) => {
  try {
    if (!text || !text.startsWith('http')) {
      return m.reply('‼️ Kirim perintah dengan link thumbnail!!\n\n📝 Contoh penggunaan :\n\n– .setthumb https://i.supa.codes/ZE0lNH');
    }

    let thumbURL = text.trim();

    // Update settings.js
    let settingsPath = path.join(__dirname, '../settings.js');
    let settingsContent = fs.readFileSync(settingsPath, 'utf-8');

    if (!settingsContent.includes('global.thumb')) {
      return m.reply('❌ Tidak ditemukan global.thumb di settings.js');
    }

    let newContent = settingsContent.replace(/global\.thumb\s*=\s*['"].*?['"];/, `global.thumb = '${thumbURL}';`);
    fs.writeFileSync(settingsPath, newContent);

    m.reply(`✅ Berhasil mengganti thumbnail!!\n\n– Link thumbnail : ${thumbURL}`);
  } catch (err) {
    console.error(err);
    m.reply('❌ Terjadi kesalahan saat mengubah thumbnail!');
  }
};

handler.help = ['setthumb <link>'];
handler.tags = ['owner'];
handler.command = /^setthumb$/i;
handler.owner = true;

module.exports = handler;