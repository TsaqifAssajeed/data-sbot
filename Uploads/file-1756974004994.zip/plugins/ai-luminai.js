

const axios = require('axios');

let handler = async (m, { conn, text }) => {
  if (!text) throw `*• Contoh penggunaan:* .luminai Siapakah orang yang menemukan Komputer di jaman Majapahit`;

  try {
    const fatkuns = m && (m.quoted || m);
    const quoted = fatkuns?.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]]
      : fatkuns?.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]]
      : fatkuns?.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]]
      : m.quoted || m;

    const mime = (quoted?.msg || quoted || {}).mimetype || '';
    let message;

    if (quoted && /image/.test(mime)) {
      const imageBuffer = await (m.quoted ? m.quoted.download() : m.download());
      const response = await axios.post('https://luminai.my.id/', {
        content: text,
        imageBuffer,
      });
      message = response.data.result;
    } else {
      const response = await axios.post('https://luminai.my.id/', {
        content: text,
      });
      message = response.data.result;
    }

    let responseMessage = {
      text: message,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          title: "LUMIN AI",
          body: namebot,
          thumbnailUrl: 'https://files.catbox.moe/5wsgtb.jpg',
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    };

    await conn.sendMessage(m.chat, responseMessage, { quoted: m });

  } catch (e) {
    return m.reply("`*Terjadi kesalahan saat memproses permintaan.*`");
  }
};

handler.command = ['luminai'];
handler.tags = ['ai'];
handler.help = ['luminai'].map(a => a + " *[text]*");

module.exports = handler;