const handler = async (m, { conn }) => {
  await conn.reply(
    m.chat,
    "*Waalaikummussalam warahmatullahi wabarokatuh*\n\n\n_📚 Baca yang dibawah ya!_\n\"Orang yang mengucapkan salam seperti ini maka ia mendapatkan 30 pahala, kemudian, orang yang dihadapan atau mendengarnya membalas dengan kalimat yang sama yaitu “Wa'alaikum salam warahmatullahi wabarakatuh” atau ditambah dengan yang lain (waridhwaana). Artinya selain daripada do'a selamat juga meminta pada Allah SWT\"\n",
    m,
  );
};
(handler.customPrefix =
  /^(assalam(ualaikum)?|(salamualaiku|(sa(lamu|m)liku|sala))m)$/i),
  (handler.command = new RegExp());
export default handler;
